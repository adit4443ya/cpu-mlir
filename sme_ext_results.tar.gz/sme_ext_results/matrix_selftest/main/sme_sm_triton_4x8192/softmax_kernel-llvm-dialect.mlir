module attributes {llvm.target_triple = "aarch64"} {
  llvm.func @free(!llvm.ptr)
  llvm.func @malloc(i64) -> !llvm.ptr
  llvm.func @softmax_kernel(%arg0: i64, %arg1: !llvm.ptr, %arg2: i64, %arg3: !llvm.ptr, %arg4: i32 {tt.divisibility = 16 : i32}, %arg5: i32 {tt.divisibility = 16 : i32}, %arg6: i32 {tt.divisibility = 16 : i32}, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32) {
    %0 = llvm.mlir.poison : !llvm.struct<(i64, ptr)>
    %1 = llvm.insertvalue %arg2, %0[0] : !llvm.struct<(i64, ptr)> 
    %2 = llvm.insertvalue %arg3, %1[1] : !llvm.struct<(i64, ptr)> 
    %3 = llvm.mlir.poison : !llvm.struct<(i64, ptr)>
    %4 = llvm.insertvalue %arg0, %3[0] : !llvm.struct<(i64, ptr)> 
    %5 = llvm.insertvalue %arg1, %4[1] : !llvm.struct<(i64, ptr)> 
    %6 = llvm.mlir.poison : vector<[4]xf32>
    %7 = llvm.mlir.constant(0 : i32) : i32
    %8 = llvm.mlir.poison : vector<1xf32>
    %9 = llvm.mlir.constant(8 : i32) : i32
    %10 = llvm.mlir.zero : i64
    %11 = llvm.mlir.constant(0 : index) : i64
    %12 = llvm.mlir.constant(8192 : index) : i64
    %13 = llvm.mlir.constant(dense<0xFF800000> : vector<8192xf32>) : vector<8192xf32>
    %14 = llvm.mlir.constant(4 : index) : i64
    %15 = llvm.mlir.constant(8 : index) : i64
    %16 = llvm.mlir.constant(-1 : index) : i64
    %17 = llvm.mlir.constant(0xFF800000 : f32) : f32
    %18 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %19 = llvm.mlir.constant(dense<5.000000e-01> : vector<[4]xf32>) : vector<[4]xf32>
    %20 = llvm.mlir.constant(dense<1.000000e+00> : vector<[4]xf32>) : vector<[4]xf32>
    %21 = llvm.mlir.constant(dense<1.44269502> : vector<[4]xf32>) : vector<[4]xf32>
    %22 = llvm.mlir.constant(dense<-0.693359375> : vector<[4]xf32>) : vector<[4]xf32>
    %23 = llvm.mlir.constant(dense<2.12194442E-4> : vector<[4]xf32>) : vector<[4]xf32>
    %24 = llvm.mlir.constant(dense<1.98756912E-4> : vector<[4]xf32>) : vector<[4]xf32>
    %25 = llvm.mlir.constant(dense<0.00139819994> : vector<[4]xf32>) : vector<[4]xf32>
    %26 = llvm.mlir.constant(dense<0.00833345205> : vector<[4]xf32>) : vector<[4]xf32>
    %27 = llvm.mlir.constant(dense<0.0416657962> : vector<[4]xf32>) : vector<[4]xf32>
    %28 = llvm.mlir.constant(dense<0.166666657> : vector<[4]xf32>) : vector<[4]xf32>
    %29 = llvm.mlir.constant(dense<-8.780000e+01> : vector<[4]xf32>) : vector<[4]xf32>
    %30 = llvm.mlir.constant(dense<8.880000e+01> : vector<[4]xf32>) : vector<[4]xf32>
    %31 = llvm.mlir.constant(dense<-1.270000e+02> : vector<[4]xf32>) : vector<[4]xf32>
    %32 = llvm.mlir.constant(dense<1.270000e+02> : vector<[4]xf32>) : vector<[4]xf32>
    %33 = llvm.mlir.constant(dense<23> : vector<[4]xi32>) : vector<[4]xi32>
    %34 = llvm.mlir.constant(dense<127> : vector<[4]xi32>) : vector<[4]xi32>
    %35 = llvm.mlir.poison : vector<[4]xf32>
    %36 = llvm.mlir.poison : vector<1xf32>
    %37 = llvm.mlir.poison : vector<[8]xf32>
    %38 = llvm.mlir.poison : vector<1xf32>
    %39 = llvm.mul %arg10, %arg4 : i32
    %40 = llvm.sext %39 : i32 to i64
    %41 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %42 = llvm.extractvalue %2[1] : !llvm.struct<(i64, ptr)> 
    %43 = llvm.load %42 : !llvm.ptr -> !llvm.ptr
    %44 = llvm.getelementptr %42[1] : (!llvm.ptr) -> !llvm.ptr, !llvm.ptr
    %45 = llvm.load %44 : !llvm.ptr -> !llvm.ptr
    %46 = llvm.insertvalue %43, %41[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %47 = llvm.insertvalue %45, %46[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %48 = llvm.insertvalue %40, %47[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %49 = llvm.mlir.constant(8192 : index) : i64
    %50 = llvm.insertvalue %49, %48[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %51 = llvm.mlir.constant(1 : index) : i64
    %52 = llvm.insertvalue %51, %50[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %53 = llvm.sext %arg6 : i32 to i64
    %54 = llvm.intr.smin(%53, %12) : (i64, i64) -> i64
    %55 = llvm.intr.smax(%54, %11) : (i64, i64) -> i64
    %56 = llvm.mlir.constant(8192 : index) : i64
    %57 = llvm.mlir.constant(1 : index) : i64
    %58 = llvm.mlir.zero : !llvm.ptr
    %59 = llvm.getelementptr %58[8192] : (!llvm.ptr) -> !llvm.ptr, f32
    %60 = llvm.ptrtoint %59 : !llvm.ptr to i64
    %61 = llvm.call @malloc(%60) : (i64) -> !llvm.ptr
    %62 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %63 = llvm.insertvalue %61, %62[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %64 = llvm.insertvalue %61, %63[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %65 = llvm.mlir.constant(0 : index) : i64
    %66 = llvm.insertvalue %65, %64[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %67 = llvm.insertvalue %56, %66[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %68 = llvm.insertvalue %57, %67[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %69 = llvm.icmp "slt" %55, %12 : i64
    llvm.cond_br %69, ^bb1, ^bb2
  ^bb1:  // pred: ^bb0
    %70 = llvm.extractvalue %68[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %71 = llvm.getelementptr %70[%11] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    llvm.store %13, %71 {alignment = 4 : i64} : vector<8192xf32>, !llvm.ptr
    llvm.br ^bb2
  ^bb2:  // 2 preds: ^bb0, ^bb1
    %72 = "llvm.intr.vscale"() : () -> i64
    %73 = llvm.mul %72, %14 : i64
    llvm.br ^bb3(%11 : i64)
  ^bb3(%74: i64):  // 2 preds: ^bb2, ^bb4
    %75 = llvm.icmp "slt" %74, %55 : i64
    llvm.cond_br %75, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %76 = llvm.mul %74, %16 overflow<nsw> : i64
    %77 = llvm.add %55, %76 : i64
    %78 = llvm.intr.smin(%73, %77) : (i64, i64) -> i64
    %79 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64)>
    %80 = llvm.insertvalue %43, %79[0] : !llvm.struct<(ptr, ptr, i64)> 
    %81 = llvm.insertvalue %45, %80[1] : !llvm.struct<(ptr, ptr, i64)> 
    %82 = llvm.mlir.constant(0 : index) : i64
    %83 = llvm.insertvalue %82, %81[2] : !llvm.struct<(ptr, ptr, i64)> 
    %84 = llvm.add %40, %74 : i64
    %85 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %86 = llvm.insertvalue %43, %85[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %87 = llvm.insertvalue %45, %86[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %88 = llvm.insertvalue %84, %87[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %89 = llvm.insertvalue %78, %88[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %90 = llvm.mlir.constant(1 : index) : i64
    %91 = llvm.insertvalue %90, %89[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %92 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %93 = llvm.insertvalue %61, %92[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %94 = llvm.insertvalue %61, %93[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %95 = llvm.insertvalue %74, %94[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %96 = llvm.insertvalue %78, %95[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %97 = llvm.mlir.constant(1 : index) : i64
    %98 = llvm.insertvalue %97, %96[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %99 = "arm_sve.intr.whilelt"(%10, %78) : (i64, i64) -> vector<[4]xi1>
    %100 = llvm.extractvalue %91[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %101 = llvm.extractvalue %91[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %102 = llvm.getelementptr %100[%101] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %103 = llvm.getelementptr %102[%11] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %104 = llvm.intr.masked.load %103, %99, %35 {alignment = 4 : i32} : (!llvm.ptr, vector<[4]xi1>, vector<[4]xf32>) -> vector<[4]xf32>
    %105 = llvm.extractvalue %98[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %106 = llvm.extractvalue %98[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %107 = llvm.getelementptr %105[%106] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %108 = llvm.getelementptr %107[%11] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    llvm.intr.masked.store %104, %108, %99 {alignment = 4 : i32} : vector<[4]xf32>, vector<[4]xi1> into !llvm.ptr
    %109 = llvm.add %74, %73 : i64
    llvm.br ^bb3(%109 : i64)
  ^bb5:  // pred: ^bb3
    %110 = llvm.mlir.constant(1 : index) : i64
    %111 = llvm.mlir.zero : !llvm.ptr
    %112 = llvm.getelementptr %111[1] : (!llvm.ptr) -> !llvm.ptr, f32
    %113 = llvm.ptrtoint %112 : !llvm.ptr to i64
    %114 = llvm.mlir.constant(64 : index) : i64
    %115 = llvm.add %113, %114 : i64
    %116 = llvm.call @malloc(%115) : (i64) -> !llvm.ptr
    %117 = llvm.ptrtoint %116 : !llvm.ptr to i64
    %118 = llvm.mlir.constant(1 : index) : i64
    %119 = llvm.sub %114, %118 : i64
    %120 = llvm.add %117, %119 : i64
    %121 = llvm.urem %120, %114 : i64
    %122 = llvm.sub %120, %121 : i64
    %123 = llvm.inttoptr %122 : i64 to !llvm.ptr
    %124 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64)>
    %125 = llvm.insertvalue %116, %124[0] : !llvm.struct<(ptr, ptr, i64)> 
    %126 = llvm.insertvalue %123, %125[1] : !llvm.struct<(ptr, ptr, i64)> 
    %127 = llvm.mlir.constant(0 : index) : i64
    %128 = llvm.insertvalue %127, %126[2] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.store %17, %123 : f32, !llvm.ptr
    %129 = llvm.mul %72, %15 : i64
    %130 = llvm.extractvalue %128[1] : !llvm.struct<(ptr, ptr, i64)> 
    %131 = llvm.load %130 {alignment = 4 : i64} : !llvm.ptr -> vector<1xf32>
    %132 = llvm.extractelement %131[%10 : i64] : vector<1xf32>
    %133 = llvm.insertelement %132, %36[%10 : i64] : vector<1xf32>
    llvm.br ^bb6(%11, %133 : i64, vector<1xf32>)
  ^bb6(%134: i64, %135: vector<1xf32>):  // 2 preds: ^bb5, ^bb7
    %136 = llvm.icmp "slt" %134, %12 : i64
    llvm.cond_br %136, ^bb7, ^bb8
  ^bb7:  // pred: ^bb6
    %137 = llvm.mul %134, %16 overflow<nsw> : i64
    %138 = llvm.add %137, %12 : i64
    %139 = llvm.intr.smin(%138, %129) : (i64, i64) -> i64
    %140 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %141 = llvm.insertvalue %61, %140[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %142 = llvm.insertvalue %61, %141[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %143 = llvm.insertvalue %134, %142[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %144 = llvm.insertvalue %139, %143[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %145 = llvm.mlir.constant(1 : index) : i64
    %146 = llvm.insertvalue %145, %144[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %147 = "arm_sve.intr.whilelt"(%10, %139) : (i64, i64) -> vector<[8]xi1>
    %148 = llvm.extractvalue %146[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %149 = llvm.extractvalue %146[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %150 = llvm.getelementptr %148[%149] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %151 = llvm.getelementptr %150[%11] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %152 = llvm.intr.masked.load %151, %147, %37 {alignment = 4 : i32} : (!llvm.ptr, vector<[8]xi1>, vector<[8]xf32>) -> vector<[8]xf32>
    %153 = llvm.extractelement %135[%10 : i64] : vector<1xf32>
    %154 = "llvm.intr.vscale"() : () -> i64
    %155 = llvm.trunc %154 : i64 to i32
    %156 = llvm.mul %155, %9 : i32
    %157 = "llvm.intr.vp.reduce.fmax"(%153, %152, %147, %156) : (f32, vector<[8]xf32>, vector<[8]xi1>, i32) -> f32
    %158 = llvm.insertelement %157, %8[%7 : i32] : vector<1xf32>
    %159 = llvm.add %134, %129 : i64
    llvm.br ^bb6(%159, %158 : i64, vector<1xf32>)
  ^bb8:  // pred: ^bb6
    %160 = llvm.extractelement %135[%10 : i64] : vector<1xf32>
    %161 = llvm.insertelement %160, %38[%10 : i64] : vector<1xf32>
    %162 = llvm.extractvalue %128[1] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.store %161, %162 {alignment = 4 : i64} : vector<1xf32>, !llvm.ptr
    %163 = llvm.load %123 : !llvm.ptr -> f32
    %164 = llvm.mlir.constant(8192 : index) : i64
    %165 = llvm.mlir.constant(1 : index) : i64
    %166 = llvm.mlir.zero : !llvm.ptr
    %167 = llvm.getelementptr %166[8192] : (!llvm.ptr) -> !llvm.ptr, f32
    %168 = llvm.ptrtoint %167 : !llvm.ptr to i64
    %169 = llvm.mlir.constant(64 : index) : i64
    %170 = llvm.add %168, %169 : i64
    %171 = llvm.call @malloc(%170) : (i64) -> !llvm.ptr
    %172 = llvm.ptrtoint %171 : !llvm.ptr to i64
    %173 = llvm.mlir.constant(1 : index) : i64
    %174 = llvm.sub %169, %173 : i64
    %175 = llvm.add %172, %174 : i64
    %176 = llvm.urem %175, %169 : i64
    %177 = llvm.sub %175, %176 : i64
    %178 = llvm.inttoptr %177 : i64 to !llvm.ptr
    %179 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %180 = llvm.insertvalue %171, %179[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %181 = llvm.insertvalue %178, %180[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %182 = llvm.mlir.constant(0 : index) : i64
    %183 = llvm.insertvalue %182, %181[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %184 = llvm.insertvalue %164, %183[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %185 = llvm.insertvalue %165, %184[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %186 = llvm.insertelement %163, %6[%7 : i32] : vector<[4]xf32>
    %187 = llvm.shufflevector %186, %6 [0, 0, 0, 0] : vector<[4]xf32> 
    llvm.br ^bb9(%11 : i64)
  ^bb9(%188: i64):  // 2 preds: ^bb8, ^bb10
    %189 = llvm.icmp "slt" %188, %12 : i64
    llvm.cond_br %189, ^bb10, ^bb11
  ^bb10:  // pred: ^bb9
    %190 = llvm.mul %188, %16 overflow<nsw> : i64
    %191 = llvm.add %190, %12 : i64
    %192 = llvm.intr.smin(%191, %73) : (i64, i64) -> i64
    %193 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %194 = llvm.insertvalue %61, %193[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %195 = llvm.insertvalue %61, %194[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %196 = llvm.insertvalue %188, %195[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %197 = llvm.insertvalue %192, %196[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %198 = llvm.mlir.constant(1 : index) : i64
    %199 = llvm.insertvalue %198, %197[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %200 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %201 = llvm.insertvalue %171, %200[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %202 = llvm.insertvalue %178, %201[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %203 = llvm.insertvalue %188, %202[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %204 = llvm.insertvalue %192, %203[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %205 = llvm.mlir.constant(1 : index) : i64
    %206 = llvm.insertvalue %205, %204[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %207 = "arm_sve.intr.whilelt"(%10, %192) : (i64, i64) -> vector<[4]xi1>
    %208 = llvm.extractvalue %199[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %209 = llvm.extractvalue %199[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %210 = llvm.getelementptr %208[%209] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %211 = llvm.getelementptr %210[%11] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %212 = llvm.intr.masked.load %211, %207, %35 {alignment = 4 : i32} : (!llvm.ptr, vector<[4]xi1>, vector<[4]xf32>) -> vector<[4]xf32>
    %213 = llvm.fsub %212, %187 : vector<[4]xf32>
    %214 = llvm.fcmp "uge" %213, %29 : vector<[4]xf32>
    %215 = llvm.select %214, %213, %29 : vector<[4]xi1>, vector<[4]xf32>
    %216 = llvm.fcmp "ule" %215, %30 : vector<[4]xf32>
    %217 = llvm.select %216, %215, %30 : vector<[4]xi1>, vector<[4]xf32>
    %218 = llvm.intr.fma(%217, %21, %19) : (vector<[4]xf32>, vector<[4]xf32>, vector<[4]xf32>) -> vector<[4]xf32>
    %219 = llvm.intr.floor(%218) : (vector<[4]xf32>) -> vector<[4]xf32>
    %220 = llvm.fcmp "uge" %219, %31 : vector<[4]xf32>
    %221 = llvm.select %220, %219, %31 : vector<[4]xi1>, vector<[4]xf32>
    %222 = llvm.fcmp "ule" %221, %32 : vector<[4]xf32>
    %223 = llvm.select %222, %221, %32 : vector<[4]xi1>, vector<[4]xf32>
    %224 = llvm.intr.fma(%22, %223, %217) : (vector<[4]xf32>, vector<[4]xf32>, vector<[4]xf32>) -> vector<[4]xf32>
    %225 = llvm.intr.fma(%23, %223, %224) : (vector<[4]xf32>, vector<[4]xf32>, vector<[4]xf32>) -> vector<[4]xf32>
    %226 = llvm.intr.fma(%225, %24, %25) : (vector<[4]xf32>, vector<[4]xf32>, vector<[4]xf32>) -> vector<[4]xf32>
    %227 = llvm.intr.fma(%226, %225, %26) : (vector<[4]xf32>, vector<[4]xf32>, vector<[4]xf32>) -> vector<[4]xf32>
    %228 = llvm.intr.fma(%227, %225, %27) : (vector<[4]xf32>, vector<[4]xf32>, vector<[4]xf32>) -> vector<[4]xf32>
    %229 = llvm.intr.fma(%228, %225, %28) : (vector<[4]xf32>, vector<[4]xf32>, vector<[4]xf32>) -> vector<[4]xf32>
    %230 = llvm.intr.fma(%229, %225, %19) : (vector<[4]xf32>, vector<[4]xf32>, vector<[4]xf32>) -> vector<[4]xf32>
    %231 = llvm.fmul %225, %225 : vector<[4]xf32>
    %232 = llvm.intr.fma(%230, %231, %225) : (vector<[4]xf32>, vector<[4]xf32>, vector<[4]xf32>) -> vector<[4]xf32>
    %233 = llvm.fadd %232, %20 : vector<[4]xf32>
    %234 = llvm.fptosi %223 : vector<[4]xf32> to vector<[4]xi32>
    %235 = llvm.add %234, %34 : vector<[4]xi32>
    %236 = llvm.shl %235, %33 : vector<[4]xi32>
    %237 = llvm.bitcast %236 : vector<[4]xi32> to vector<[4]xf32>
    %238 = llvm.fmul %233, %237 : vector<[4]xf32>
    %239 = llvm.extractvalue %206[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %240 = llvm.extractvalue %206[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %241 = llvm.getelementptr %239[%240] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %242 = llvm.getelementptr %241[%11] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    llvm.intr.masked.store %238, %242, %207 {alignment = 4 : i32} : vector<[4]xf32>, vector<[4]xi1> into !llvm.ptr
    %243 = llvm.add %188, %73 : i64
    llvm.br ^bb9(%243 : i64)
  ^bb11:  // pred: ^bb9
    %244 = llvm.mlir.constant(1 : index) : i64
    %245 = llvm.mlir.zero : !llvm.ptr
    %246 = llvm.getelementptr %245[1] : (!llvm.ptr) -> !llvm.ptr, f32
    %247 = llvm.ptrtoint %246 : !llvm.ptr to i64
    %248 = llvm.mlir.constant(64 : index) : i64
    %249 = llvm.add %247, %248 : i64
    %250 = llvm.call @malloc(%249) : (i64) -> !llvm.ptr
    %251 = llvm.ptrtoint %250 : !llvm.ptr to i64
    %252 = llvm.mlir.constant(1 : index) : i64
    %253 = llvm.sub %248, %252 : i64
    %254 = llvm.add %251, %253 : i64
    %255 = llvm.urem %254, %248 : i64
    %256 = llvm.sub %254, %255 : i64
    %257 = llvm.inttoptr %256 : i64 to !llvm.ptr
    %258 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64)>
    %259 = llvm.insertvalue %250, %258[0] : !llvm.struct<(ptr, ptr, i64)> 
    %260 = llvm.insertvalue %257, %259[1] : !llvm.struct<(ptr, ptr, i64)> 
    %261 = llvm.mlir.constant(0 : index) : i64
    %262 = llvm.insertvalue %261, %260[2] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.store %18, %257 : f32, !llvm.ptr
    %263 = llvm.extractvalue %262[1] : !llvm.struct<(ptr, ptr, i64)> 
    %264 = llvm.load %263 {alignment = 4 : i64} : !llvm.ptr -> vector<1xf32>
    %265 = llvm.extractelement %264[%10 : i64] : vector<1xf32>
    %266 = llvm.insertelement %265, %36[%10 : i64] : vector<1xf32>
    llvm.br ^bb12(%11, %266 : i64, vector<1xf32>)
  ^bb12(%267: i64, %268: vector<1xf32>):  // 2 preds: ^bb11, ^bb13
    %269 = llvm.icmp "slt" %267, %12 : i64
    llvm.cond_br %269, ^bb13, ^bb14
  ^bb13:  // pred: ^bb12
    %270 = llvm.mul %267, %16 overflow<nsw> : i64
    %271 = llvm.add %270, %12 : i64
    %272 = llvm.intr.smin(%271, %129) : (i64, i64) -> i64
    %273 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %274 = llvm.insertvalue %171, %273[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %275 = llvm.insertvalue %178, %274[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %276 = llvm.insertvalue %267, %275[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %277 = llvm.insertvalue %272, %276[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %278 = llvm.mlir.constant(1 : index) : i64
    %279 = llvm.insertvalue %278, %277[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %280 = "arm_sve.intr.whilelt"(%10, %272) : (i64, i64) -> vector<[8]xi1>
    %281 = llvm.extractvalue %279[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %282 = llvm.extractvalue %279[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %283 = llvm.getelementptr %281[%282] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %284 = llvm.getelementptr %283[%11] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %285 = llvm.intr.masked.load %284, %280, %37 {alignment = 4 : i32} : (!llvm.ptr, vector<[8]xi1>, vector<[8]xf32>) -> vector<[8]xf32>
    %286 = llvm.extractelement %268[%10 : i64] : vector<1xf32>
    %287 = "llvm.intr.vscale"() : () -> i64
    %288 = llvm.trunc %287 : i64 to i32
    %289 = llvm.mul %288, %9 : i32
    %290 = "llvm.intr.vp.reduce.fadd"(%286, %285, %280, %289) : (f32, vector<[8]xf32>, vector<[8]xi1>, i32) -> f32
    %291 = llvm.insertelement %290, %8[%7 : i32] : vector<1xf32>
    %292 = llvm.add %267, %129 : i64
    llvm.br ^bb12(%292, %291 : i64, vector<1xf32>)
  ^bb14:  // pred: ^bb12
    %293 = llvm.extractelement %268[%10 : i64] : vector<1xf32>
    %294 = llvm.insertelement %293, %38[%10 : i64] : vector<1xf32>
    %295 = llvm.extractvalue %262[1] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.store %294, %295 {alignment = 4 : i64} : vector<1xf32>, !llvm.ptr
    %296 = llvm.load %257 : !llvm.ptr -> f32
    %297 = llvm.mul %arg10, %arg5 : i32
    %298 = llvm.sext %297 : i32 to i64
    %299 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %300 = llvm.extractvalue %5[1] : !llvm.struct<(i64, ptr)> 
    %301 = llvm.load %300 : !llvm.ptr -> !llvm.ptr
    %302 = llvm.getelementptr %300[1] : (!llvm.ptr) -> !llvm.ptr, !llvm.ptr
    %303 = llvm.load %302 : !llvm.ptr -> !llvm.ptr
    %304 = llvm.insertvalue %301, %299[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %305 = llvm.insertvalue %303, %304[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %306 = llvm.insertvalue %298, %305[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %307 = llvm.mlir.constant(8192 : index) : i64
    %308 = llvm.insertvalue %307, %306[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %309 = llvm.mlir.constant(1 : index) : i64
    %310 = llvm.insertvalue %309, %308[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %311 = llvm.insertelement %296, %6[%7 : i32] : vector<[4]xf32>
    %312 = llvm.shufflevector %311, %6 [0, 0, 0, 0] : vector<[4]xf32> 
    llvm.br ^bb15(%11 : i64)
  ^bb15(%313: i64):  // 2 preds: ^bb14, ^bb16
    %314 = llvm.icmp "slt" %313, %55 : i64
    llvm.cond_br %314, ^bb16, ^bb17
  ^bb16:  // pred: ^bb15
    %315 = llvm.mul %313, %16 overflow<nsw> : i64
    %316 = llvm.add %55, %315 : i64
    %317 = llvm.intr.smin(%73, %316) : (i64, i64) -> i64
    %318 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %319 = llvm.insertvalue %171, %318[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %320 = llvm.insertvalue %178, %319[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %321 = llvm.insertvalue %313, %320[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %322 = llvm.insertvalue %317, %321[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %323 = llvm.mlir.constant(1 : index) : i64
    %324 = llvm.insertvalue %323, %322[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %325 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64)>
    %326 = llvm.insertvalue %301, %325[0] : !llvm.struct<(ptr, ptr, i64)> 
    %327 = llvm.insertvalue %303, %326[1] : !llvm.struct<(ptr, ptr, i64)> 
    %328 = llvm.mlir.constant(0 : index) : i64
    %329 = llvm.insertvalue %328, %327[2] : !llvm.struct<(ptr, ptr, i64)> 
    %330 = llvm.add %298, %313 : i64
    %331 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %332 = llvm.insertvalue %301, %331[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %333 = llvm.insertvalue %303, %332[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %334 = llvm.insertvalue %330, %333[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %335 = llvm.insertvalue %317, %334[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %336 = llvm.mlir.constant(1 : index) : i64
    %337 = llvm.insertvalue %336, %335[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %338 = "arm_sve.intr.whilelt"(%10, %317) : (i64, i64) -> vector<[4]xi1>
    %339 = llvm.extractvalue %324[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %340 = llvm.extractvalue %324[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %341 = llvm.getelementptr %339[%340] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %342 = llvm.getelementptr %341[%11] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %343 = llvm.intr.masked.load %342, %338, %35 {alignment = 4 : i32} : (!llvm.ptr, vector<[4]xi1>, vector<[4]xf32>) -> vector<[4]xf32>
    %344 = llvm.fdiv %343, %312 : vector<[4]xf32>
    %345 = llvm.extractvalue %337[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %346 = llvm.extractvalue %337[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %347 = llvm.getelementptr %345[%346] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %348 = llvm.getelementptr %347[%11] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    llvm.intr.masked.store %344, %348, %338 {alignment = 4 : i32} : vector<[4]xf32>, vector<[4]xi1> into !llvm.ptr
    %349 = llvm.add %313, %73 : i64
    llvm.br ^bb15(%349 : i64)
  ^bb17:  // pred: ^bb15
    llvm.call @free(%61) : (!llvm.ptr) -> ()
    llvm.call @free(%116) : (!llvm.ptr) -> ()
    llvm.call @free(%171) : (!llvm.ptr) -> ()
    llvm.call @free(%250) : (!llvm.ptr) -> ()
    llvm.return
  }
}
