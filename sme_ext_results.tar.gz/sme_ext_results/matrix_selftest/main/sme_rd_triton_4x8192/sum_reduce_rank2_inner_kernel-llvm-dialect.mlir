module attributes {llvm.target_triple = "aarch64"} {
  llvm.func @free(!llvm.ptr)
  llvm.func @malloc(i64) -> !llvm.ptr
  llvm.func @sum_reduce_rank2_inner_kernel(%arg0: i64, %arg1: !llvm.ptr, %arg2: i64, %arg3: !llvm.ptr, %arg4: i32, %arg5: i32, %arg6: i32, %arg7: i32, %arg8: i32, %arg9: i32) {
    %0 = llvm.mlir.poison : !llvm.struct<(i64, ptr)>
    %1 = llvm.insertvalue %arg2, %0[0] : !llvm.struct<(i64, ptr)> 
    %2 = llvm.insertvalue %arg3, %1[1] : !llvm.struct<(i64, ptr)> 
    %3 = llvm.mlir.poison : !llvm.struct<(i64, ptr)>
    %4 = llvm.insertvalue %arg0, %3[0] : !llvm.struct<(i64, ptr)> 
    %5 = llvm.insertvalue %arg1, %4[1] : !llvm.struct<(i64, ptr)> 
    %6 = llvm.mlir.constant(0 : i32) : i32
    %7 = llvm.mlir.poison : vector<1xf32>
    %8 = llvm.mlir.constant(8 : i32) : i32
    %9 = llvm.mlir.constant(0 : i64) : i64
    %10 = llvm.mlir.constant(0 : index) : i64
    %11 = llvm.mlir.constant(8192 : index) : i64
    %12 = llvm.mlir.constant(-1 : index) : i64
    %13 = llvm.mlir.constant(8 : index) : i64
    %14 = llvm.mlir.constant(8192 : i32) : i32
    %15 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %16 = llvm.mlir.poison : vector<1xf32>
    %17 = llvm.mlir.poison : vector<[8]xf32>
    %18 = llvm.mlir.poison : vector<1xf32>
    %19 = llvm.mul %arg7, %14 : i32
    %20 = llvm.sext %19 : i32 to i64
    %21 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %22 = llvm.extractvalue %5[1] : !llvm.struct<(i64, ptr)> 
    %23 = llvm.load %22 : !llvm.ptr -> !llvm.ptr
    %24 = llvm.getelementptr %22[1] : (!llvm.ptr) -> !llvm.ptr, !llvm.ptr
    %25 = llvm.load %24 : !llvm.ptr -> !llvm.ptr
    %26 = llvm.insertvalue %23, %21[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %27 = llvm.insertvalue %25, %26[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %28 = llvm.insertvalue %20, %27[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %29 = llvm.mlir.constant(8192 : index) : i64
    %30 = llvm.insertvalue %29, %28[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %31 = llvm.mlir.constant(1 : index) : i64
    %32 = llvm.insertvalue %31, %30[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %33 = llvm.mlir.constant(1 : index) : i64
    %34 = llvm.mlir.zero : !llvm.ptr
    %35 = llvm.getelementptr %34[1] : (!llvm.ptr) -> !llvm.ptr, f32
    %36 = llvm.ptrtoint %35 : !llvm.ptr to i64
    %37 = llvm.mlir.constant(64 : index) : i64
    %38 = llvm.add %36, %37 : i64
    %39 = llvm.call @malloc(%38) : (i64) -> !llvm.ptr
    %40 = llvm.ptrtoint %39 : !llvm.ptr to i64
    %41 = llvm.mlir.constant(1 : index) : i64
    %42 = llvm.sub %37, %41 : i64
    %43 = llvm.add %40, %42 : i64
    %44 = llvm.urem %43, %37 : i64
    %45 = llvm.sub %43, %44 : i64
    %46 = llvm.inttoptr %45 : i64 to !llvm.ptr
    %47 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64)>
    %48 = llvm.insertvalue %39, %47[0] : !llvm.struct<(ptr, ptr, i64)> 
    %49 = llvm.insertvalue %46, %48[1] : !llvm.struct<(ptr, ptr, i64)> 
    %50 = llvm.mlir.constant(0 : index) : i64
    %51 = llvm.insertvalue %50, %49[2] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.store %15, %46 : f32, !llvm.ptr
    %52 = "llvm.intr.vscale"() : () -> i64
    %53 = llvm.mul %52, %13 : i64
    %54 = llvm.extractvalue %51[1] : !llvm.struct<(ptr, ptr, i64)> 
    %55 = llvm.load %54 {alignment = 4 : i64} : !llvm.ptr -> vector<1xf32>
    %56 = llvm.extractelement %55[%9 : i64] : vector<1xf32>
    %57 = llvm.insertelement %56, %16[%9 : i64] : vector<1xf32>
    llvm.br ^bb1(%10, %57 : i64, vector<1xf32>)
  ^bb1(%58: i64, %59: vector<1xf32>):  // 2 preds: ^bb0, ^bb2
    %60 = llvm.icmp "slt" %58, %11 : i64
    llvm.cond_br %60, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %61 = llvm.mul %58, %12 overflow<nsw> : i64
    %62 = llvm.add %61, %11 : i64
    %63 = llvm.intr.smin(%62, %53) : (i64, i64) -> i64
    %64 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64)>
    %65 = llvm.insertvalue %23, %64[0] : !llvm.struct<(ptr, ptr, i64)> 
    %66 = llvm.insertvalue %25, %65[1] : !llvm.struct<(ptr, ptr, i64)> 
    %67 = llvm.mlir.constant(0 : index) : i64
    %68 = llvm.insertvalue %67, %66[2] : !llvm.struct<(ptr, ptr, i64)> 
    %69 = llvm.add %20, %58 : i64
    %70 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %71 = llvm.insertvalue %23, %70[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %72 = llvm.insertvalue %25, %71[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %73 = llvm.insertvalue %69, %72[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %74 = llvm.insertvalue %63, %73[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %75 = llvm.mlir.constant(1 : index) : i64
    %76 = llvm.insertvalue %75, %74[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %77 = "arm_sve.intr.whilelt"(%9, %63) : (i64, i64) -> vector<[8]xi1>
    %78 = llvm.extractvalue %76[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %79 = llvm.extractvalue %76[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %80 = llvm.getelementptr %78[%79] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %81 = llvm.getelementptr %80[%10] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %82 = llvm.intr.masked.load %81, %77, %17 {alignment = 4 : i32} : (!llvm.ptr, vector<[8]xi1>, vector<[8]xf32>) -> vector<[8]xf32>
    %83 = llvm.extractelement %59[%9 : i64] : vector<1xf32>
    %84 = "llvm.intr.vscale"() : () -> i64
    %85 = llvm.trunc %84 : i64 to i32
    %86 = llvm.mul %85, %8 : i32
    %87 = "llvm.intr.vp.reduce.fadd"(%83, %82, %77, %86) : (f32, vector<[8]xf32>, vector<[8]xi1>, i32) -> f32
    %88 = llvm.insertelement %87, %7[%6 : i32] : vector<1xf32>
    %89 = llvm.add %58, %53 : i64
    llvm.br ^bb1(%89, %88 : i64, vector<1xf32>)
  ^bb3:  // pred: ^bb1
    %90 = llvm.extractelement %59[%9 : i64] : vector<1xf32>
    %91 = llvm.insertelement %90, %18[%9 : i64] : vector<1xf32>
    %92 = llvm.extractvalue %51[1] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.store %91, %92 {alignment = 4 : i64} : vector<1xf32>, !llvm.ptr
    %93 = llvm.load %46 : !llvm.ptr -> f32
    %94 = llvm.sext %arg7 : i32 to i64
    %95 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %96 = llvm.extractvalue %2[1] : !llvm.struct<(i64, ptr)> 
    %97 = llvm.load %96 : !llvm.ptr -> !llvm.ptr
    %98 = llvm.getelementptr %96[1] : (!llvm.ptr) -> !llvm.ptr, !llvm.ptr
    %99 = llvm.load %98 : !llvm.ptr -> !llvm.ptr
    %100 = llvm.insertvalue %97, %95[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %101 = llvm.insertvalue %99, %100[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %102 = llvm.insertvalue %94, %101[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %103 = llvm.mlir.constant(1 : index) : i64
    %104 = llvm.insertvalue %103, %102[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %105 = llvm.mlir.constant(1 : index) : i64
    %106 = llvm.insertvalue %105, %104[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %107 = llvm.getelementptr %99[%94] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %108 = llvm.getelementptr inbounds|nuw %107[%10] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    llvm.store %93, %108 : f32, !llvm.ptr
    llvm.call @free(%39) : (!llvm.ptr) -> ()
    llvm.return
  }
}
