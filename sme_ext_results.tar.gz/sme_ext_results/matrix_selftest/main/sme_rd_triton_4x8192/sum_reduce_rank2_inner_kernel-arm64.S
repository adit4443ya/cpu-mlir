	.file	"LLVMDialectModule"
	.text
	.globl	sum_reduce_rank2_inner_kernel   // -- Begin function sum_reduce_rank2_inner_kernel
	.p2align	2
	.type	sum_reduce_rank2_inner_kernel,@function
sum_reduce_rank2_inner_kernel:          // @sum_reduce_rank2_inner_kernel
// %bb.0:
	str	x30, [sp, #-48]!                // 8-byte Folded Spill
	stp	x22, x21, [sp, #16]             // 16-byte Folded Spill
	ldr	x22, [x1, #8]
	mov	w0, #68                         // =0x44
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	w19, w7
	lsl	w21, w7, #13
	mov	x20, x3
	bl	malloc
	movi	d0, #0000000000000000
	cnth	x10
	add	x9, x0, #63
	add	x11, x22, w21, sxtw #2
	whilelo	p0.h, wzr, w10
	mov	x8, xzr
	and	x9, x9, #0xffffffffffffffc0
	mov	w12, #8192                      // =0x2000
	str	wzr, [x9]
.LBB0_1:                                // =>This Inner Loop Header: Depth=1
	subs	x13, x12, x10
	csel	x12, x12, x10, lt
	whilelt	p1.h, xzr, x12
	add	x12, x11, x8, lsl #2
	punpklo	p2.h, p1.b
	and	p3.b, p0/z, p0.b, p1.b
	ld1w	{ z1.s }, p2/z, [x11, x8, lsl #2]
	punpkhi	p1.h, p1.b
	inch	x8
	punpklo	p2.h, p3.b
	fadda	s0, p2, s0, z1.s
	ld1w	{ z1.s }, p1/z, [x12, #1, mul vl]
	punpkhi	p1.h, p3.b
	cmp	x8, #2, lsl #12                 // =8192
	mov	x12, x13
	fadda	s0, p1, s0, z1.s
	b.lt	.LBB0_1
// %bb.2:
	str	s0, [x9]
	ldp	x22, x21, [sp, #16]             // 16-byte Folded Reload
	ldr	x8, [x20, #8]
	str	s0, [x8, w19, sxtw #2]
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x30, [sp], #48                  // 8-byte Folded Reload
	b	free
.Lfunc_end0:
	.size	sum_reduce_rank2_inner_kernel, .Lfunc_end0-sum_reduce_rank2_inner_kernel
                                        // -- End function
	.section	".note.GNU-stack","",@progbits
