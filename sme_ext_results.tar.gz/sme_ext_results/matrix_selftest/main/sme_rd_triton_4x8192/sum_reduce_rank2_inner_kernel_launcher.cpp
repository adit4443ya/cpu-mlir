
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <chrono>
// From triton_test/utils/dsp/include
#include "common.h"
#include "prof.h"
#include "tensor.h"
// From triton_shared/backend/include
#include "ExecutionEngine/CRunnerUtils.h"
#include "ExecutionEngine/CRunnerUtils.cpp"

extern "C" void sum_reduce_rank2_inner_kernel(int64_t, MemRefDescriptor<float, 2> *, int64_t, MemRefDescriptor<float, 1> *,  int, int, int, int, int, int);
const int alignment = 128;



int main() {

Tensor<float, 2> t0({{4, 8192}, {8192, 1}, alignment}, MemType::HEAP);
MemRefDescriptor<float, 2> *dt0 = t0.toMemRefDesc(); 
Tensor<float, 1> t1({{4}, {1}, alignment}, MemType::HEAP);
MemRefDescriptor<float, 1> *dt1 = t1.toMemRefDesc(); 


t0.load_from_file("/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/matrix_selftest/main/sme_rd_triton_4x8192/sum_reduce_rank2_inner_kernel_t0.raw");
t1.load_from_file("/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/matrix_selftest/main/sme_rd_triton_4x8192/sum_reduce_rank2_inner_kernel_t1.raw");


  int gridX = 4;
  int gridY = 1;
  int gridZ = 1;
  if (gridX * gridY * gridZ > 0) {
    
    for(int x = 0; x < gridX; x++) {
      for(int y = 0; y < gridY; y++) {
        for(int z = 0; z < gridZ; z++) {
          sum_reduce_rank2_inner_kernel(2, dt0, 1, dt1, gridX, gridY, gridZ, x, y, z);
        }
      }
    }
    
  }
  

t0.dump_to_file("/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/matrix_selftest/main/sme_rd_triton_4x8192/sum_reduce_rank2_inner_kernel_o0.raw");
t1.dump_to_file("/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/matrix_selftest/main/sme_rd_triton_4x8192/sum_reduce_rank2_inner_kernel_o1.raw");

return 0;
}
