; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target triple = "aarch64"

declare void @free(ptr)

declare ptr @malloc(i64)

define void @sum_reduce_rank2_inner_kernel(i64 %0, ptr %1, i64 %2, ptr %3, i32 %4, i32 %5, i32 %6, i32 %7, i32 %8, i32 %9) {
  %11 = insertvalue { i64, ptr } poison, i64 %2, 0
  %12 = insertvalue { i64, ptr } %11, ptr %3, 1
  %13 = insertvalue { i64, ptr } poison, i64 %0, 0
  %14 = insertvalue { i64, ptr } %13, ptr %1, 1
  %15 = mul i32 %7, 8192
  %16 = sext i32 %15 to i64
  %17 = extractvalue { i64, ptr } %14, 1
  %18 = load ptr, ptr %17, align 8
  %19 = getelementptr ptr, ptr %17, i32 1
  %20 = load ptr, ptr %19, align 8
  %21 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %18, 0
  %22 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %21, ptr %20, 1
  %23 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %22, i64 %16, 2
  %24 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %23, i64 8192, 3, 0
  %25 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %24, i64 1, 4, 0
  %26 = call ptr @malloc(i64 68)
  %27 = ptrtoint ptr %26 to i64
  %28 = add i64 %27, 63
  %29 = urem i64 %28, 64
  %30 = sub i64 %28, %29
  %31 = inttoptr i64 %30 to ptr
  %32 = insertvalue { ptr, ptr, i64 } poison, ptr %26, 0
  %33 = insertvalue { ptr, ptr, i64 } %32, ptr %31, 1
  %34 = insertvalue { ptr, ptr, i64 } %33, i64 0, 2
  store float 0.000000e+00, ptr %31, align 4
  %35 = call i64 @llvm.vscale.i64()
  %36 = mul i64 %35, 8
  %37 = extractvalue { ptr, ptr, i64 } %34, 1
  %38 = load <1 x float>, ptr %37, align 4
  %39 = extractelement <1 x float> %38, i64 0
  %40 = insertelement <1 x float> poison, float %39, i64 0
  br label %41

41:                                               ; preds = %45, %10
  %42 = phi i64 [ %70, %45 ], [ 0, %10 ]
  %43 = phi <1 x float> [ %69, %45 ], [ %40, %10 ]
  %44 = icmp slt i64 %42, 8192
  br i1 %44, label %45, label %71

45:                                               ; preds = %41
  %46 = mul nsw i64 %42, -1
  %47 = add i64 %46, 8192
  %48 = call i64 @llvm.smin.i64(i64 %47, i64 %36)
  %49 = insertvalue { ptr, ptr, i64 } poison, ptr %18, 0
  %50 = insertvalue { ptr, ptr, i64 } %49, ptr %20, 1
  %51 = insertvalue { ptr, ptr, i64 } %50, i64 0, 2
  %52 = add i64 %16, %42
  %53 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %18, 0
  %54 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, ptr %20, 1
  %55 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %54, i64 %52, 2
  %56 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %55, i64 %48, 3, 0
  %57 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %56, i64 1, 4, 0
  %58 = call <vscale x 8 x i1> @llvm.aarch64.sve.whilelt.nxv8i1.i64(i64 0, i64 %48)
  %59 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %57, 1
  %60 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %57, 2
  %61 = getelementptr float, ptr %59, i64 %60
  %62 = getelementptr float, ptr %61, i64 0
  %63 = call <vscale x 8 x float> @llvm.masked.load.nxv8f32.p0(ptr align 4 %62, <vscale x 8 x i1> %58, <vscale x 8 x float> poison)
  %64 = extractelement <1 x float> %43, i64 0
  %65 = call i64 @llvm.vscale.i64()
  %66 = trunc i64 %65 to i32
  %67 = mul i32 %66, 8
  %68 = call float @llvm.vp.reduce.fadd.nxv8f32(float %64, <vscale x 8 x float> %63, <vscale x 8 x i1> %58, i32 %67)
  %69 = insertelement <1 x float> poison, float %68, i32 0
  %70 = add i64 %42, %36
  br label %41

71:                                               ; preds = %41
  %72 = extractelement <1 x float> %43, i64 0
  %73 = insertelement <1 x float> poison, float %72, i64 0
  %74 = extractvalue { ptr, ptr, i64 } %34, 1
  store <1 x float> %73, ptr %74, align 4
  %75 = load float, ptr %31, align 4
  %76 = sext i32 %7 to i64
  %77 = extractvalue { i64, ptr } %12, 1
  %78 = load ptr, ptr %77, align 8
  %79 = getelementptr ptr, ptr %77, i32 1
  %80 = load ptr, ptr %79, align 8
  %81 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %78, 0
  %82 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %81, ptr %80, 1
  %83 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %82, i64 %76, 2
  %84 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %83, i64 1, 3, 0
  %85 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %84, i64 1, 4, 0
  %86 = getelementptr float, ptr %80, i64 %76
  %87 = getelementptr inbounds nuw float, ptr %86, i64 0
  store float %75, ptr %87, align 4
  call void @free(ptr %26)
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.vscale.i64() #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smin.i64(i64, i64) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 8 x i1> @llvm.aarch64.sve.whilelt.nxv8i1.i64(i64, i64) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <vscale x 8 x float> @llvm.masked.load.nxv8f32.p0(ptr captures(none), <vscale x 8 x i1>, <vscale x 8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.vp.reduce.fadd.nxv8f32(float, <vscale x 8 x float>, <vscale x 8 x i1>, i32) #0

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
