module {
  func.func @sum_reduce_rank2_inner_kernel(%arg0: memref<*xf32> {tt.divisibility = 16 : i32}, %arg1: memref<*xf32> {tt.divisibility = 16 : i32}, %arg2: i32, %arg3: i32, %arg4: i32, %arg5: i32, %arg6: i32, %arg7: i32) {
    %c8192_i32 = arith.constant 8192 : i32
    %cst = arith.constant 0.000000e+00 : f32
    %0 = arith.muli %arg5, %c8192_i32 : i32
    %1 = arith.index_cast %0 : i32 to index
    %reinterpret_cast = memref.reinterpret_cast %arg0 to offset: [%1], sizes: [8192], strides: [1] : memref<*xf32> to memref<8192xf32, strided<[1], offset: ?>>
    %alloc = memref.alloc() : memref<8192xf32>
    memref.copy %reinterpret_cast, %alloc : memref<8192xf32, strided<[1], offset: ?>> to memref<8192xf32>
    %2 = bufferization.to_tensor %alloc restrict writable : memref<8192xf32> to tensor<8192xf32>
    %3 = bufferization.alloc_tensor() : tensor<f32>
    %inserted = tensor.insert %cst into %3[] : tensor<f32>
    %reduced = linalg.reduce ins(%2 : tensor<8192xf32>) outs(%inserted : tensor<f32>) dimensions = [0] 
      (%in: f32, %init: f32) {
        %5 = arith.addf %in, %init : f32
        linalg.yield %5 : f32
      }
    %extracted = tensor.extract %reduced[] : tensor<f32>
    %4 = arith.index_cast %arg5 : i32 to index
    %reinterpret_cast_0 = memref.reinterpret_cast %arg1 to offset: [%4], sizes: [1], strides: [1] : memref<*xf32> to memref<1xf32, strided<[1], offset: ?>>
    affine.store %extracted, %reinterpret_cast_0[0] : memref<1xf32, strided<[1], offset: ?>>
    return
  }
}

