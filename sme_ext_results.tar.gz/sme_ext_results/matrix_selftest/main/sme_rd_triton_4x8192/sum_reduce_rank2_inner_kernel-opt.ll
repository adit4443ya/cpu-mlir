; ModuleID = '/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/matrix_selftest/main/sme_rd_triton_4x8192/sum_reduce_rank2_inner_kernel-llvm-ir.ll'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64"

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @free(ptr allocptr noundef captures(none)) local_unnamed_addr #0

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite, errnomem: write)
declare noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #1

; Function Attrs: nounwind memory(readwrite, target_mem: none)
define void @sum_reduce_rank2_inner_kernel(i64 %0, ptr nofree readonly captures(none) %1, i64 %2, ptr nofree readonly captures(none) %3, i32 %4, i32 %5, i32 %6, i32 %7, i32 %8, i32 %9) local_unnamed_addr #2 {
  %11 = shl i32 %7, 13
  %12 = sext i32 %11 to i64
  %13 = getelementptr i8, ptr %1, i64 8
  %14 = load ptr, ptr %13, align 8
  %15 = tail call dereferenceable_or_null(68) ptr @malloc(i64 68)
  %16 = ptrtoint ptr %15 to i64
  %17 = add i64 %16, 63
  %18 = and i64 %17, -64
  %19 = inttoptr i64 %18 to ptr
  store float 0.000000e+00, ptr %19, align 64
  %20 = tail call i64 @llvm.vscale.i64()
  %21 = shl i64 %20, 3
  %invariant.gep = getelementptr [4 x i8], ptr %14, i64 %12
  %22 = trunc i64 %20 to i32
  %23 = shl i32 %22, 3
  br label %24

24:                                               ; preds = %10, %24
  %25 = phi <1 x float> [ zeroinitializer, %10 ], [ %33, %24 ]
  %26 = phi i64 [ 0, %10 ], [ %34, %24 ]
  %27 = sub i64 8192, %26
  %28 = tail call i64 @llvm.smin.i64(i64 %27, i64 %21)
  %29 = tail call <vscale x 8 x i1> @llvm.aarch64.sve.whilelt.nxv8i1.i64(i64 0, i64 %28)
  %gep = getelementptr [4 x i8], ptr %invariant.gep, i64 %26
  %30 = tail call <vscale x 8 x float> @llvm.masked.load.nxv8f32.p0(ptr align 4 %gep, <vscale x 8 x i1> %29, <vscale x 8 x float> poison)
  %31 = extractelement <1 x float> %25, i64 0
  %32 = tail call float @llvm.vp.reduce.fadd.nxv8f32(float %31, <vscale x 8 x float> %30, <vscale x 8 x i1> %29, i32 %23)
  %33 = insertelement <1 x float> poison, float %32, i64 0
  %34 = add i64 %26, %21
  %35 = icmp slt i64 %34, 8192
  br i1 %35, label %24, label %36

36:                                               ; preds = %24
  store <1 x float> %33, ptr %19, align 64
  %37 = sext i32 %7 to i64
  %38 = getelementptr i8, ptr %3, i64 8
  %39 = load ptr, ptr %38, align 8
  %40 = getelementptr [4 x i8], ptr %39, i64 %37
  store float %32, ptr %40, align 4
  tail call void @free(ptr %15)
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.vscale.i64() #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smin.i64(i64, i64) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 8 x i1> @llvm.aarch64.sve.whilelt.nxv8i1.i64(i64, i64) #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <vscale x 8 x float> @llvm.masked.load.nxv8f32.p0(ptr captures(none), <vscale x 8 x i1>, <vscale x 8 x float>) #5

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.vp.reduce.fadd.nxv8f32(float, <vscale x 8 x float>, <vscale x 8 x i1>, i32) #3

attributes #0 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "target-features"="+sve,+sve2,+sme" }
attributes #1 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite, errnomem: write) "alloc-family"="malloc" "target-features"="+sve,+sve2,+sme" }
attributes #2 = { nounwind memory(readwrite, target_mem: none) "target-features"="+sve,+sve2,+sme" }
attributes #3 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) "target-features"="+sve,+sve2,+sme" }
attributes #4 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) "target-features"="+sve,+sve2,+sme" }
attributes #5 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read) "target-features"="+sve,+sve2,+sme" }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
