
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <chrono>
// From triton_test/utils/dsp/include
#include "common.h"
#include "prof.h"
#include "tensor.h"
// From triton_shared/backend/include
#include "ExecutionEngine/CRunnerUtils.h"
#include "ExecutionEngine/CRunnerUtils.cpp"

extern "C" void _mlir_ciface_SumReduce(void *, MemRefDescriptor<float, 2> *);
const int alignment = 128;


struct FuncResult
{
	MemRefDescriptor<float,1> do0;
};


int main() {

Tensor<float, 2> t0({{64, 8192}, {8192, 1}, alignment}, MemType::HEAP);
MemRefDescriptor<float, 2> *dt0 = t0.toMemRefDesc(); 

FuncResult *r = new FuncResult;

t0.load_from_file("/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/matrix_selftest/main/sme_rd_torch_64x8192/SumReduce_t0.raw");


  int gridX = 1;
  int gridY = 1;
  int gridZ = 1;
  if (gridX * gridY * gridZ > 0) {
    
    for(int x = 0; x < gridX; x++) {
      for(int y = 0; y < gridY; y++) {
        for(int z = 0; z < gridZ; z++) {
          _mlir_ciface_SumReduce(r, dt0);
        }
      }
    }
    
  }
  


Tensor<float, 1> o0(r->do0, MemType::HEAP, alignment);
o0.dump_to_file("/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/matrix_selftest/main/sme_rd_torch_64x8192/SumReduce_o0.raw");

return 0;
}
