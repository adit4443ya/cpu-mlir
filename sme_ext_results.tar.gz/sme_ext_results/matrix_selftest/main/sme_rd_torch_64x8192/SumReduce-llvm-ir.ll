; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target triple = "aarch64"

declare ptr @malloc(i64)

define { ptr, ptr, i64, [1 x i64], [1 x i64] } @SumReduce(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6) {
  %8 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %0, 0
  %9 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %8, ptr %1, 1
  %10 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %9, i64 %2, 2
  %11 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %10, i64 %3, 3, 0
  %12 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, i64 %5, 4, 0
  %13 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %12, i64 %4, 3, 1
  %14 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %13, i64 %6, 4, 1
  %15 = call ptr @malloc(i64 320)
  %16 = ptrtoint ptr %15 to i64
  %17 = add i64 %16, 63
  %18 = urem i64 %17, 64
  %19 = sub i64 %17, %18
  %20 = inttoptr i64 %19 to ptr
  %21 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %15, 0
  %22 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %21, ptr %20, 1
  %23 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %22, i64 0, 2
  %24 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %23, i64 64, 3, 0
  %25 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %24, i64 1, 4, 0
  %26 = call i64 @llvm.vscale.i64()
  %27 = mul i64 %26, 4
  br label %28

28:                                               ; preds = %31, %7
  %29 = phi i64 [ %45, %31 ], [ 0, %7 ]
  %30 = icmp slt i64 %29, 64
  br i1 %30, label %31, label %46

31:                                               ; preds = %28
  %32 = mul nsw i64 %29, -1
  %33 = add i64 %32, 64
  %34 = call i64 @llvm.smin.i64(i64 %33, i64 %27)
  %35 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %15, 0
  %36 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %35, ptr %20, 1
  %37 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %36, i64 %29, 2
  %38 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %37, i64 %34, 3, 0
  %39 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, i64 1, 4, 0
  %40 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %34)
  %41 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %39, 1
  %42 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %39, 2
  %43 = getelementptr float, ptr %41, i64 %42
  %44 = getelementptr float, ptr %43, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> zeroinitializer, ptr align 4 %44, <vscale x 4 x i1> %40)
  %45 = add i64 %29, %27
  br label %28

46:                                               ; preds = %28
  %47 = mul i64 %26, 8
  br label %48

48:                                               ; preds = %99, %46
  %49 = phi i64 [ %105, %99 ], [ 0, %46 ]
  %50 = icmp slt i64 %49, 64
  br i1 %50, label %51, label %106

51:                                               ; preds = %48
  %52 = insertvalue { ptr, ptr, i64 } poison, ptr %15, 0
  %53 = insertvalue { ptr, ptr, i64 } %52, ptr %20, 1
  %54 = insertvalue { ptr, ptr, i64 } %53, i64 %49, 2
  %55 = extractvalue { ptr, ptr, i64 } %54, 1
  %56 = extractvalue { ptr, ptr, i64 } %54, 2
  %57 = getelementptr float, ptr %55, i64 %56
  %58 = load <1 x float>, ptr %57, align 4
  %59 = extractelement <1 x float> %58, i64 0
  %60 = insertelement <1 x float> poison, float %59, i64 0
  br label %61

61:                                               ; preds = %65, %51
  %62 = phi i64 [ %98, %65 ], [ 0, %51 ]
  %63 = phi <1 x float> [ %97, %65 ], [ %60, %51 ]
  %64 = icmp slt i64 %62, 8192
  br i1 %64, label %65, label %99

65:                                               ; preds = %61
  %66 = mul nsw i64 %62, -1
  %67 = add i64 %66, 8192
  %68 = call i64 @llvm.smin.i64(i64 %67, i64 %47)
  %69 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, 0
  %70 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, 1
  %71 = insertvalue { ptr, ptr, i64 } poison, ptr %69, 0
  %72 = insertvalue { ptr, ptr, i64 } %71, ptr %70, 1
  %73 = insertvalue { ptr, ptr, i64 } %72, i64 0, 2
  %74 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, 2
  %75 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, 3, 0
  %76 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, 3, 1
  %77 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, 4, 0
  %78 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, 4, 1
  %79 = mul nsw i64 %49, 8192
  %80 = add i64 %79, %62
  %81 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %69, 0
  %82 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %81, ptr %70, 1
  %83 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %82, i64 %80, 2
  %84 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %83, i64 %68, 3, 0
  %85 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %84, i64 1, 4, 0
  %86 = call <vscale x 8 x i1> @llvm.aarch64.sve.whilelt.nxv8i1.i64(i64 0, i64 %68)
  %87 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %85, 1
  %88 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %85, 2
  %89 = getelementptr float, ptr %87, i64 %88
  %90 = getelementptr float, ptr %89, i64 0
  %91 = call <vscale x 8 x float> @llvm.masked.load.nxv8f32.p0(ptr align 4 %90, <vscale x 8 x i1> %86, <vscale x 8 x float> poison)
  %92 = extractelement <1 x float> %63, i64 0
  %93 = call i64 @llvm.vscale.i64()
  %94 = trunc i64 %93 to i32
  %95 = mul i32 %94, 8
  %96 = call float @llvm.vp.reduce.fadd.nxv8f32(float %92, <vscale x 8 x float> %91, <vscale x 8 x i1> %86, i32 %95)
  %97 = insertelement <1 x float> poison, float %96, i32 0
  %98 = add i64 %62, %47
  br label %61

99:                                               ; preds = %61
  %100 = extractelement <1 x float> %63, i64 0
  %101 = insertelement <1 x float> poison, float %100, i64 0
  %102 = extractvalue { ptr, ptr, i64 } %54, 1
  %103 = extractvalue { ptr, ptr, i64 } %54, 2
  %104 = getelementptr float, ptr %102, i64 %103
  store <1 x float> %101, ptr %104, align 4
  %105 = add i64 %49, 1
  br label %48

106:                                              ; preds = %48
  ret { ptr, ptr, i64, [1 x i64], [1 x i64] } %25
}

define void @_mlir_ciface_SumReduce(ptr %0, ptr %1) {
  %3 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, align 8
  %4 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 0
  %5 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 1
  %6 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 2
  %7 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 3, 0
  %8 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 3, 1
  %9 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 4, 0
  %10 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 4, 1
  %11 = call { ptr, ptr, i64, [1 x i64], [1 x i64] } @SumReduce(ptr %4, ptr %5, i64 %6, i64 %7, i64 %8, i64 %9, i64 %10)
  store { ptr, ptr, i64, [1 x i64], [1 x i64] } %11, ptr %0, align 8
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.vscale.i64() #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smin.i64(i64, i64) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 8 x i1> @llvm.aarch64.sve.whilelt.nxv8i1.i64(i64, i64) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <vscale x 8 x float> @llvm.masked.load.nxv8f32.p0(ptr captures(none), <vscale x 8 x i1>, <vscale x 8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.vp.reduce.fadd.nxv8f32(float, <vscale x 8 x float>, <vscale x 8 x i1>, i32) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64, i64) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float>, ptr captures(none), <vscale x 4 x i1>) #3

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
