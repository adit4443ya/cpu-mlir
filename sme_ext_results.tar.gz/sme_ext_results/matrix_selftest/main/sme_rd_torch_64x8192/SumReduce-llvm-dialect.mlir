module attributes {llvm.target_triple = "aarch64"} {
  llvm.func @malloc(i64) -> !llvm.ptr
  llvm.func @SumReduce(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64) -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> attributes {llvm.emit_c_interface} {
    %0 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.insertvalue %arg0, %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.insertvalue %arg1, %1[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg5, %4[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.mlir.constant(0 : i32) : i32
    %9 = llvm.mlir.poison : vector<1xf32>
    %10 = llvm.mlir.constant(8 : i32) : i32
    %11 = llvm.mlir.zero : i64
    %12 = llvm.mlir.constant(0 : index) : i64
    %13 = llvm.mlir.constant(64 : index) : i64
    %14 = llvm.mlir.constant(dense<0.000000e+00> : vector<[4]xf32>) : vector<[4]xf32>
    %15 = llvm.mlir.constant(1 : index) : i64
    %16 = llvm.mlir.constant(8 : index) : i64
    %17 = llvm.mlir.constant(8192 : index) : i64
    %18 = llvm.mlir.constant(-1 : index) : i64
    %19 = llvm.mlir.constant(4 : index) : i64
    %20 = llvm.mlir.poison : vector<1xf32>
    %21 = llvm.mlir.poison : vector<[8]xf32>
    %22 = llvm.mlir.poison : vector<1xf32>
    %23 = llvm.mlir.constant(64 : index) : i64
    %24 = llvm.mlir.constant(1 : index) : i64
    %25 = llvm.mlir.zero : !llvm.ptr
    %26 = llvm.getelementptr %25[64] : (!llvm.ptr) -> !llvm.ptr, f32
    %27 = llvm.ptrtoint %26 : !llvm.ptr to i64
    %28 = llvm.mlir.constant(64 : index) : i64
    %29 = llvm.add %27, %28 : i64
    %30 = llvm.call @malloc(%29) : (i64) -> !llvm.ptr
    %31 = llvm.ptrtoint %30 : !llvm.ptr to i64
    %32 = llvm.mlir.constant(1 : index) : i64
    %33 = llvm.sub %28, %32 : i64
    %34 = llvm.add %31, %33 : i64
    %35 = llvm.urem %34, %28 : i64
    %36 = llvm.sub %34, %35 : i64
    %37 = llvm.inttoptr %36 : i64 to !llvm.ptr
    %38 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %39 = llvm.insertvalue %30, %38[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %40 = llvm.insertvalue %37, %39[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %41 = llvm.mlir.constant(0 : index) : i64
    %42 = llvm.insertvalue %41, %40[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %43 = llvm.insertvalue %23, %42[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %44 = llvm.insertvalue %24, %43[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %45 = "llvm.intr.vscale"() : () -> i64
    %46 = llvm.mul %45, %19 : i64
    llvm.br ^bb1(%12 : i64)
  ^bb1(%47: i64):  // 2 preds: ^bb0, ^bb2
    %48 = llvm.icmp "slt" %47, %13 : i64
    llvm.cond_br %48, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %49 = llvm.mul %47, %18 overflow<nsw> : i64
    %50 = llvm.add %49, %13 : i64
    %51 = llvm.intr.smin(%50, %46) : (i64, i64) -> i64
    %52 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %53 = llvm.insertvalue %30, %52[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %54 = llvm.insertvalue %37, %53[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %55 = llvm.insertvalue %47, %54[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %56 = llvm.insertvalue %51, %55[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %57 = llvm.mlir.constant(1 : index) : i64
    %58 = llvm.insertvalue %57, %56[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %59 = "arm_sve.intr.whilelt"(%11, %51) : (i64, i64) -> vector<[4]xi1>
    %60 = llvm.extractvalue %58[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %61 = llvm.extractvalue %58[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %62 = llvm.getelementptr %60[%61] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %63 = llvm.getelementptr %62[%12] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    llvm.intr.masked.store %14, %63, %59 {alignment = 4 : i32} : vector<[4]xf32>, vector<[4]xi1> into !llvm.ptr
    %64 = llvm.add %47, %46 : i64
    llvm.br ^bb1(%64 : i64)
  ^bb3:  // pred: ^bb1
    %65 = llvm.mul %45, %16 : i64
    llvm.br ^bb4(%12 : i64)
  ^bb4(%66: i64):  // 2 preds: ^bb3, ^bb8
    %67 = llvm.icmp "slt" %66, %13 : i64
    llvm.cond_br %67, ^bb5, ^bb9
  ^bb5:  // pred: ^bb4
    %68 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64)>
    %69 = llvm.insertvalue %30, %68[0] : !llvm.struct<(ptr, ptr, i64)> 
    %70 = llvm.insertvalue %37, %69[1] : !llvm.struct<(ptr, ptr, i64)> 
    %71 = llvm.insertvalue %66, %70[2] : !llvm.struct<(ptr, ptr, i64)> 
    %72 = llvm.extractvalue %71[1] : !llvm.struct<(ptr, ptr, i64)> 
    %73 = llvm.extractvalue %71[2] : !llvm.struct<(ptr, ptr, i64)> 
    %74 = llvm.getelementptr %72[%73] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %75 = llvm.load %74 {alignment = 4 : i64} : !llvm.ptr -> vector<1xf32>
    %76 = llvm.extractelement %75[%11 : i64] : vector<1xf32>
    %77 = llvm.insertelement %76, %20[%11 : i64] : vector<1xf32>
    llvm.br ^bb6(%12, %77 : i64, vector<1xf32>)
  ^bb6(%78: i64, %79: vector<1xf32>):  // 2 preds: ^bb5, ^bb7
    %80 = llvm.icmp "slt" %78, %17 : i64
    llvm.cond_br %80, ^bb7, ^bb8
  ^bb7:  // pred: ^bb6
    %81 = llvm.mul %78, %18 overflow<nsw> : i64
    %82 = llvm.add %81, %17 : i64
    %83 = llvm.intr.smin(%82, %65) : (i64, i64) -> i64
    %84 = llvm.extractvalue %7[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %85 = llvm.extractvalue %7[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %86 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64)>
    %87 = llvm.insertvalue %84, %86[0] : !llvm.struct<(ptr, ptr, i64)> 
    %88 = llvm.insertvalue %85, %87[1] : !llvm.struct<(ptr, ptr, i64)> 
    %89 = llvm.mlir.constant(0 : index) : i64
    %90 = llvm.insertvalue %89, %88[2] : !llvm.struct<(ptr, ptr, i64)> 
    %91 = llvm.extractvalue %7[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %92 = llvm.extractvalue %7[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %93 = llvm.extractvalue %7[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %94 = llvm.extractvalue %7[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %95 = llvm.extractvalue %7[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %96 = llvm.mlir.constant(8192 : index) : i64
    %97 = llvm.mul %66, %96 overflow<nsw> : i64
    %98 = llvm.add %97, %78 : i64
    %99 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %100 = llvm.insertvalue %84, %99[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %101 = llvm.insertvalue %85, %100[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %102 = llvm.insertvalue %98, %101[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %103 = llvm.insertvalue %83, %102[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %104 = llvm.mlir.constant(1 : index) : i64
    %105 = llvm.insertvalue %104, %103[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %106 = "arm_sve.intr.whilelt"(%11, %83) : (i64, i64) -> vector<[8]xi1>
    %107 = llvm.extractvalue %105[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %108 = llvm.extractvalue %105[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %109 = llvm.getelementptr %107[%108] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %110 = llvm.getelementptr %109[%12] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %111 = llvm.intr.masked.load %110, %106, %21 {alignment = 4 : i32} : (!llvm.ptr, vector<[8]xi1>, vector<[8]xf32>) -> vector<[8]xf32>
    %112 = llvm.extractelement %79[%11 : i64] : vector<1xf32>
    %113 = "llvm.intr.vscale"() : () -> i64
    %114 = llvm.trunc %113 : i64 to i32
    %115 = llvm.mul %114, %10 : i32
    %116 = "llvm.intr.vp.reduce.fadd"(%112, %111, %106, %115) : (f32, vector<[8]xf32>, vector<[8]xi1>, i32) -> f32
    %117 = llvm.insertelement %116, %9[%8 : i32] : vector<1xf32>
    %118 = llvm.add %78, %65 : i64
    llvm.br ^bb6(%118, %117 : i64, vector<1xf32>)
  ^bb8:  // pred: ^bb6
    %119 = llvm.extractelement %79[%11 : i64] : vector<1xf32>
    %120 = llvm.insertelement %119, %22[%11 : i64] : vector<1xf32>
    %121 = llvm.extractvalue %71[1] : !llvm.struct<(ptr, ptr, i64)> 
    %122 = llvm.extractvalue %71[2] : !llvm.struct<(ptr, ptr, i64)> 
    %123 = llvm.getelementptr %121[%122] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    llvm.store %120, %123 {alignment = 4 : i64} : vector<1xf32>, !llvm.ptr
    %124 = llvm.add %66, %15 : i64
    llvm.br ^bb4(%124 : i64)
  ^bb9:  // pred: ^bb4
    llvm.return %44 : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
  }
  llvm.func @_mlir_ciface_SumReduce(%arg0: !llvm.ptr, %arg1: !llvm.ptr) attributes {llvm.emit_c_interface} {
    %0 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.extractvalue %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.extractvalue %0[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.extractvalue %0[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.extractvalue %0[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.extractvalue %0[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.call @SumReduce(%1, %2, %3, %4, %5, %6, %7) : (!llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64) -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    llvm.store %8, %arg0 : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>, !llvm.ptr
    llvm.return
  }
}
