
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <chrono>
// From triton_test/utils/dsp/include
#include "common.h"
#include "prof.h"
#include "tensor.h"
// From triton_shared/backend/include
#include "ExecutionEngine/CRunnerUtils.h"
#include "ExecutionEngine/CRunnerUtils.cpp"

extern "C" void matmul_kernel(int64_t, MemRefDescriptor<float, 2> *, int64_t, MemRefDescriptor<float, 2> *, int64_t, MemRefDescriptor<float, 2> *, int, int, int, int, int, int,  int, int, int, int, int, int);
const int alignment = 128;



int main() {

Tensor<float, 2> t0({{256, 256}, {256, 1}, alignment}, MemType::HEAP);
MemRefDescriptor<float, 2> *dt0 = t0.toMemRefDesc(); 
Tensor<float, 2> t1({{256, 256}, {256, 1}, alignment}, MemType::HEAP);
MemRefDescriptor<float, 2> *dt1 = t1.toMemRefDesc(); 
Tensor<float, 2> t2({{256, 256}, {256, 1}, alignment}, MemType::HEAP);
MemRefDescriptor<float, 2> *dt2 = t2.toMemRefDesc(); 
int S0 = 256; 
int S1 = 256; 
int S2 = 256; 
int S3 = 256; 
int S4 = 256; 
int S5 = 256; 


t0.load_from_file("/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/matrix_selftest/main/sme_mm_256x256x256/matmul_kernel_t0.raw");
t1.load_from_file("/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/matrix_selftest/main/sme_mm_256x256x256/matmul_kernel_t1.raw");
t2.load_from_file("/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/matrix_selftest/main/sme_mm_256x256x256/matmul_kernel_t2.raw");


  int gridX = 32;
  int gridY = 1;
  int gridZ = 1;
  if (gridX * gridY * gridZ > 0) {
    
    for(int x = 0; x < gridX; x++) {
      for(int y = 0; y < gridY; y++) {
        for(int z = 0; z < gridZ; z++) {
          matmul_kernel(2, dt0, 2, dt1, 2, dt2, S0, S1, S2, S3, S4, S5, gridX, gridY, gridZ, x, y, z);
        }
      }
    }
    
  }
  

t0.dump_to_file("/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/matrix_selftest/main/sme_mm_256x256x256/matmul_kernel_o0.raw");
t1.dump_to_file("/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/matrix_selftest/main/sme_mm_256x256x256/matmul_kernel_o1.raw");
t2.dump_to_file("/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/matrix_selftest/main/sme_mm_256x256x256/matmul_kernel_o2.raw");

return 0;
}
