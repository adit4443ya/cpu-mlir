; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target triple = "aarch64"

declare void @free(ptr)

declare ptr @malloc(i64)

define { ptr, ptr, i64, [2 x i64], [2 x i64] } @Softmax(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6) {
  %8 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %0, 0
  %9 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %8, ptr %1, 1
  %10 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %9, i64 %2, 2
  %11 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %10, i64 %3, 3, 0
  %12 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, i64 %5, 4, 0
  %13 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %12, i64 %4, 3, 1
  %14 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %13, i64 %6, 4, 1
  %15 = call ptr @malloc(i64 320)
  %16 = ptrtoint ptr %15 to i64
  %17 = add i64 %16, 63
  %18 = urem i64 %17, 64
  %19 = sub i64 %17, %18
  %20 = inttoptr i64 %19 to ptr
  %21 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %15, 0
  %22 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %21, ptr %20, 1
  %23 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %22, i64 0, 2
  %24 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %23, i64 64, 3, 0
  %25 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %24, i64 1, 3, 1
  %26 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %25, i64 1, 4, 0
  %27 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %26, i64 1, 4, 1
  %28 = call i64 @llvm.vscale.i64()
  %29 = mul i64 %28, 4
  br label %30

30:                                               ; preds = %33, %7
  %31 = phi i64 [ %45, %33 ], [ 0, %7 ]
  %32 = icmp slt i64 %31, 64
  br i1 %32, label %33, label %46

33:                                               ; preds = %30
  %34 = call i64 @llvm.smin.i64(i64 %29, i64 1)
  %35 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %34)
  %36 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %15, 0
  %37 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %36, ptr %20, 1
  %38 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %37, i64 %31, 2
  %39 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, i64 %34, 3, 0
  %40 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %39, i64 1, 4, 0
  %41 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %40, 1
  %42 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %40, 2
  %43 = getelementptr float, ptr %41, i64 %42
  %44 = getelementptr float, ptr %43, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> splat (float -inf), ptr align 4 %44, <vscale x 4 x i1> %35)
  %45 = add i64 %31, 1
  br label %30

46:                                               ; preds = %30
  %47 = mul i64 %28, 8
  br label %48

48:                                               ; preds = %98, %46
  %49 = phi i64 [ %104, %98 ], [ 0, %46 ]
  %50 = icmp slt i64 %49, 64
  br i1 %50, label %51, label %105

51:                                               ; preds = %48
  %52 = insertvalue { ptr, ptr, i64 } poison, ptr %15, 0
  %53 = insertvalue { ptr, ptr, i64 } %52, ptr %20, 1
  %54 = insertvalue { ptr, ptr, i64 } %53, i64 %49, 2
  %55 = extractvalue { ptr, ptr, i64 } %54, 1
  %56 = extractvalue { ptr, ptr, i64 } %54, 2
  %57 = getelementptr float, ptr %55, i64 %56
  %58 = load <1 x float>, ptr %57, align 4
  %59 = extractelement <1 x float> %58, i64 0
  %60 = insertelement <1 x float> poison, float %59, i64 0
  br label %61

61:                                               ; preds = %65, %51
  %62 = phi i64 [ %97, %65 ], [ 0, %51 ]
  %63 = phi <1 x float> [ %96, %65 ], [ %60, %51 ]
  %64 = icmp slt i64 %62, 8192
  br i1 %64, label %65, label %98

65:                                               ; preds = %61
  %66 = mul nsw i64 %62, -1
  %67 = add i64 %66, 8192
  %68 = call i64 @llvm.smin.i64(i64 %67, i64 %47)
  %69 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, 0
  %70 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, 1
  %71 = insertvalue { ptr, ptr, i64 } poison, ptr %69, 0
  %72 = insertvalue { ptr, ptr, i64 } %71, ptr %70, 1
  %73 = insertvalue { ptr, ptr, i64 } %72, i64 0, 2
  %74 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, 2
  %75 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, 3, 0
  %76 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, 3, 1
  %77 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, 4, 0
  %78 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, 4, 1
  %79 = mul nsw i64 %49, 8192
  %80 = add i64 %79, %62
  %81 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %69, 0
  %82 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %81, ptr %70, 1
  %83 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %82, i64 %80, 2
  %84 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %83, i64 %68, 3, 0
  %85 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %84, i64 1, 4, 0
  %86 = call <vscale x 8 x i1> @llvm.aarch64.sve.whilelt.nxv8i1.i64(i64 0, i64 %68)
  %87 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %85, 1
  %88 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %85, 2
  %89 = getelementptr float, ptr %87, i64 %88
  %90 = getelementptr float, ptr %89, i64 0
  %91 = call <vscale x 8 x float> @llvm.masked.load.nxv8f32.p0(ptr align 4 %90, <vscale x 8 x i1> %86, <vscale x 8 x float> poison)
  %92 = extractelement <1 x float> %63, i64 0
  %93 = select <vscale x 8 x i1> %86, <vscale x 8 x float> %91, <vscale x 8 x float> splat (float -1.401300e-45)
  %94 = call float @llvm.vector.reduce.fmaximum.nxv8f32(<vscale x 8 x float> %93)
  %95 = call float @llvm.maximum.f32(float %94, float %92)
  %96 = insertelement <1 x float> poison, float %95, i32 0
  %97 = add i64 %62, %47
  br label %61

98:                                               ; preds = %61
  %99 = extractelement <1 x float> %63, i64 0
  %100 = insertelement <1 x float> poison, float %99, i64 0
  %101 = extractvalue { ptr, ptr, i64 } %54, 1
  %102 = extractvalue { ptr, ptr, i64 } %54, 2
  %103 = getelementptr float, ptr %101, i64 %102
  store <1 x float> %100, ptr %103, align 4
  %104 = add i64 %49, 1
  br label %48

105:                                              ; preds = %48
  %106 = call ptr @malloc(i64 2097216)
  %107 = ptrtoint ptr %106 to i64
  %108 = add i64 %107, 63
  %109 = urem i64 %108, 64
  %110 = sub i64 %108, %109
  %111 = inttoptr i64 %110 to ptr
  %112 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %106, 0
  %113 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %112, ptr %111, 1
  %114 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %113, i64 0, 2
  %115 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %114, i64 64, 3, 0
  %116 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %115, i64 8192, 3, 1
  %117 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %116, i64 8192, 4, 0
  %118 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %117, i64 1, 4, 1
  %119 = sdiv i64 8191, %29
  %120 = add i64 %119, 1
  %121 = sdiv i64 8191, %29
  %122 = add i64 %121, 1
  %123 = mul nsw i64 %122, 64
  %124 = call ptr @malloc(i64 2097216)
  %125 = ptrtoint ptr %124 to i64
  %126 = add i64 %125, 63
  %127 = urem i64 %126, 64
  %128 = sub i64 %126, %127
  %129 = inttoptr i64 %128 to ptr
  %130 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %124, 0
  %131 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %130, ptr %129, 1
  %132 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %131, i64 0, 2
  %133 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %132, i64 64, 3, 0
  %134 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %133, i64 8192, 3, 1
  %135 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %134, i64 8192, 4, 0
  %136 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %135, i64 1, 4, 1
  br label %137

137:                                              ; preds = %140, %105
  %138 = phi i64 [ %234, %140 ], [ 0, %105 ]
  %139 = icmp slt i64 %138, %123
  br i1 %139, label %140, label %235

140:                                              ; preds = %137
  %141 = sdiv i64 %138, %120
  %142 = mul i64 %141, %120
  %143 = icmp ne i64 %138, %142
  %144 = icmp slt i64 %138, 0
  %145 = icmp slt i64 %120, 0
  %146 = icmp ne i1 %144, %145
  %147 = and i1 %143, %146
  %148 = add i64 %141, -1
  %149 = select i1 %147, i64 %148, i64 %141
  %150 = srem i64 %138, %120
  %151 = icmp slt i64 %150, 0
  %152 = add nsw i64 %150, %120
  %153 = select i1 %151, i64 %152, i64 %150
  %154 = mul nsw i64 %29, %153
  %155 = mul nsw i64 %29, %153
  %156 = mul nsw i64 %155, -1
  %157 = add i64 %156, 8192
  %158 = call i64 @llvm.smin.i64(i64 %157, i64 %29)
  %159 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %15, 0
  %160 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %159, ptr %20, 1
  %161 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %160, i64 %149, 2
  %162 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %161, i64 1, 3, 0
  %163 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %162, i64 1, 4, 0
  %164 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %163, i64 1, 3, 1
  %165 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %164, i64 1, 4, 1
  %166 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %158)
  %167 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, 0
  %168 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, 1
  %169 = insertvalue { ptr, ptr, i64 } poison, ptr %167, 0
  %170 = insertvalue { ptr, ptr, i64 } %169, ptr %168, 1
  %171 = insertvalue { ptr, ptr, i64 } %170, i64 0, 2
  %172 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, 2
  %173 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, 3, 0
  %174 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, 3, 1
  %175 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, 4, 0
  %176 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %14, 4, 1
  %177 = mul nsw i64 %149, 8192
  %178 = add i64 %177, %154
  %179 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %167, 0
  %180 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %179, ptr %168, 1
  %181 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %180, i64 %178, 2
  %182 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %181, i64 %158, 3, 0
  %183 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %182, i64 1, 4, 0
  %184 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %183, 1
  %185 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %183, 2
  %186 = getelementptr float, ptr %184, i64 %185
  %187 = getelementptr float, ptr %186, i64 0
  %188 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %187, <vscale x 4 x i1> %166, <vscale x 4 x float> poison)
  %189 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %165, 1
  %190 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %165, 2
  %191 = getelementptr float, ptr %189, i64 %190
  %192 = getelementptr float, ptr %191, i64 0
  %193 = load <1 x float>, ptr %192, align 4
  %194 = extractelement <1 x float> %193, i64 0
  %195 = insertelement <vscale x 4 x float> poison, float %194, i32 0
  %196 = shufflevector <vscale x 4 x float> %195, <vscale x 4 x float> poison, <vscale x 4 x i32> zeroinitializer
  %197 = fsub <vscale x 4 x float> %188, %196
  %198 = fcmp uge <vscale x 4 x float> %197, splat (float -8.780000e+01)
  %199 = select <vscale x 4 x i1> %198, <vscale x 4 x float> %197, <vscale x 4 x float> splat (float -8.780000e+01)
  %200 = fcmp ule <vscale x 4 x float> %199, splat (float 8.880000e+01)
  %201 = select <vscale x 4 x i1> %200, <vscale x 4 x float> %199, <vscale x 4 x float> splat (float 8.880000e+01)
  %202 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %201, <vscale x 4 x float> splat (float f0x3FB8AA3B), <vscale x 4 x float> splat (float 5.000000e-01))
  %203 = call <vscale x 4 x float> @llvm.floor.nxv4f32(<vscale x 4 x float> %202)
  %204 = fcmp uge <vscale x 4 x float> %203, splat (float -1.270000e+02)
  %205 = select <vscale x 4 x i1> %204, <vscale x 4 x float> %203, <vscale x 4 x float> splat (float -1.270000e+02)
  %206 = fcmp ule <vscale x 4 x float> %205, splat (float 1.270000e+02)
  %207 = select <vscale x 4 x i1> %206, <vscale x 4 x float> %205, <vscale x 4 x float> splat (float 1.270000e+02)
  %208 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> splat (float f0xBF318000), <vscale x 4 x float> %207, <vscale x 4 x float> %201)
  %209 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> splat (float f0x395E8083), <vscale x 4 x float> %207, <vscale x 4 x float> %208)
  %210 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %209, <vscale x 4 x float> splat (float f0x39506967), <vscale x 4 x float> splat (float f0x3AB743CE))
  %211 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %210, <vscale x 4 x float> %209, <vscale x 4 x float> splat (float f0x3C088908))
  %212 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %211, <vscale x 4 x float> %209, <vscale x 4 x float> splat (float f0x3D2AA9C1))
  %213 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %212, <vscale x 4 x float> %209, <vscale x 4 x float> splat (float f0x3E2AAAAA))
  %214 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %213, <vscale x 4 x float> %209, <vscale x 4 x float> splat (float 5.000000e-01))
  %215 = fmul <vscale x 4 x float> %209, %209
  %216 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %214, <vscale x 4 x float> %215, <vscale x 4 x float> %209)
  %217 = fadd <vscale x 4 x float> %216, splat (float 1.000000e+00)
  %218 = fptosi <vscale x 4 x float> %207 to <vscale x 4 x i32>
  %219 = add <vscale x 4 x i32> %218, splat (i32 127)
  %220 = shl <vscale x 4 x i32> %219, splat (i32 23)
  %221 = bitcast <vscale x 4 x i32> %220 to <vscale x 4 x float>
  %222 = fmul <vscale x 4 x float> %217, %221
  %223 = mul nsw i64 %149, 8192
  %224 = add i64 %223, %154
  %225 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %124, 0
  %226 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %225, ptr %129, 1
  %227 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %226, i64 %224, 2
  %228 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %227, i64 %158, 3, 0
  %229 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %228, i64 1, 4, 0
  %230 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %229, 1
  %231 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %229, 2
  %232 = getelementptr float, ptr %230, i64 %231
  %233 = getelementptr float, ptr %232, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %222, ptr align 4 %233, <vscale x 4 x i1> %166)
  %234 = add i64 %138, 1
  br label %137

235:                                              ; preds = %238, %137
  %236 = phi i64 [ %250, %238 ], [ 0, %137 ]
  %237 = icmp slt i64 %236, 64
  br i1 %237, label %238, label %251

238:                                              ; preds = %235
  %239 = call i64 @llvm.smin.i64(i64 %29, i64 1)
  %240 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %239)
  %241 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %15, 0
  %242 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %241, ptr %20, 1
  %243 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %242, i64 %236, 2
  %244 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %243, i64 %239, 3, 0
  %245 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %244, i64 1, 4, 0
  %246 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %245, 1
  %247 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %245, 2
  %248 = getelementptr float, ptr %246, i64 %247
  %249 = getelementptr float, ptr %248, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> zeroinitializer, ptr align 4 %249, <vscale x 4 x i1> %240)
  %250 = add i64 %236, 1
  br label %235

251:                                              ; preds = %290, %235
  %252 = phi i64 [ %296, %290 ], [ 0, %235 ]
  %253 = icmp slt i64 %252, 64
  br i1 %253, label %254, label %297

254:                                              ; preds = %251
  %255 = insertvalue { ptr, ptr, i64 } poison, ptr %15, 0
  %256 = insertvalue { ptr, ptr, i64 } %255, ptr %20, 1
  %257 = insertvalue { ptr, ptr, i64 } %256, i64 %252, 2
  %258 = extractvalue { ptr, ptr, i64 } %257, 1
  %259 = extractvalue { ptr, ptr, i64 } %257, 2
  %260 = getelementptr float, ptr %258, i64 %259
  %261 = load <1 x float>, ptr %260, align 4
  %262 = extractelement <1 x float> %261, i64 0
  %263 = insertelement <1 x float> poison, float %262, i64 0
  br label %264

264:                                              ; preds = %268, %254
  %265 = phi i64 [ %289, %268 ], [ 0, %254 ]
  %266 = phi <1 x float> [ %288, %268 ], [ %263, %254 ]
  %267 = icmp slt i64 %265, 8192
  br i1 %267, label %268, label %290

268:                                              ; preds = %264
  %269 = mul nsw i64 %265, -1
  %270 = add i64 %269, 8192
  %271 = call i64 @llvm.smin.i64(i64 %270, i64 %47)
  %272 = mul nsw i64 %252, 8192
  %273 = add i64 %272, %265
  %274 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %124, 0
  %275 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %274, ptr %129, 1
  %276 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %275, i64 %273, 2
  %277 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %276, i64 %271, 3, 0
  %278 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %277, i64 1, 4, 0
  %279 = call <vscale x 8 x i1> @llvm.aarch64.sve.whilelt.nxv8i1.i64(i64 0, i64 %271)
  %280 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %278, 1
  %281 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %278, 2
  %282 = getelementptr float, ptr %280, i64 %281
  %283 = getelementptr float, ptr %282, i64 0
  %284 = call <vscale x 8 x float> @llvm.masked.load.nxv8f32.p0(ptr align 4 %283, <vscale x 8 x i1> %279, <vscale x 8 x float> poison)
  %285 = extractelement <1 x float> %266, i64 0
  %286 = select <vscale x 8 x i1> %279, <vscale x 8 x float> %284, <vscale x 8 x float> zeroinitializer
  %287 = call reassoc float @llvm.vector.reduce.fadd.nxv8f32(float %285, <vscale x 8 x float> %286)
  %288 = insertelement <1 x float> poison, float %287, i32 0
  %289 = add i64 %265, %47
  br label %264

290:                                              ; preds = %264
  %291 = extractelement <1 x float> %266, i64 0
  %292 = insertelement <1 x float> poison, float %291, i64 0
  %293 = extractvalue { ptr, ptr, i64 } %257, 1
  %294 = extractvalue { ptr, ptr, i64 } %257, 2
  %295 = getelementptr float, ptr %293, i64 %294
  store <1 x float> %292, ptr %295, align 4
  %296 = add i64 %252, 1
  br label %251

297:                                              ; preds = %300, %251
  %298 = phi i64 [ %359, %300 ], [ 0, %251 ]
  %299 = icmp slt i64 %298, %123
  br i1 %299, label %300, label %360

300:                                              ; preds = %297
  %301 = sdiv i64 %298, %120
  %302 = mul i64 %301, %120
  %303 = icmp ne i64 %298, %302
  %304 = icmp slt i64 %298, 0
  %305 = icmp slt i64 %120, 0
  %306 = icmp ne i1 %304, %305
  %307 = and i1 %303, %306
  %308 = add i64 %301, -1
  %309 = select i1 %307, i64 %308, i64 %301
  %310 = srem i64 %298, %120
  %311 = icmp slt i64 %310, 0
  %312 = add nsw i64 %310, %120
  %313 = select i1 %311, i64 %312, i64 %310
  %314 = mul nsw i64 %29, %313
  %315 = mul nsw i64 %29, %313
  %316 = mul nsw i64 %315, -1
  %317 = add i64 %316, 8192
  %318 = call i64 @llvm.smin.i64(i64 %317, i64 %29)
  %319 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %15, 0
  %320 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %319, ptr %20, 1
  %321 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %320, i64 %309, 2
  %322 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %321, i64 1, 3, 0
  %323 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %322, i64 1, 4, 0
  %324 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %323, i64 1, 3, 1
  %325 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %324, i64 1, 4, 1
  %326 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %318)
  %327 = mul nsw i64 %309, 8192
  %328 = add i64 %327, %314
  %329 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %124, 0
  %330 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %329, ptr %129, 1
  %331 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %330, i64 %328, 2
  %332 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %331, i64 %318, 3, 0
  %333 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %332, i64 1, 4, 0
  %334 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %333, 1
  %335 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %333, 2
  %336 = getelementptr float, ptr %334, i64 %335
  %337 = getelementptr float, ptr %336, i64 0
  %338 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %337, <vscale x 4 x i1> %326, <vscale x 4 x float> poison)
  %339 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %325, 1
  %340 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %325, 2
  %341 = getelementptr float, ptr %339, i64 %340
  %342 = getelementptr float, ptr %341, i64 0
  %343 = load <1 x float>, ptr %342, align 4
  %344 = extractelement <1 x float> %343, i64 0
  %345 = insertelement <vscale x 4 x float> poison, float %344, i32 0
  %346 = shufflevector <vscale x 4 x float> %345, <vscale x 4 x float> poison, <vscale x 4 x i32> zeroinitializer
  %347 = fdiv <vscale x 4 x float> %338, %346
  %348 = mul nsw i64 %309, 8192
  %349 = add i64 %348, %314
  %350 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %106, 0
  %351 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %350, ptr %111, 1
  %352 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %351, i64 %349, 2
  %353 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %352, i64 %318, 3, 0
  %354 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %353, i64 1, 4, 0
  %355 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %354, 1
  %356 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %354, 2
  %357 = getelementptr float, ptr %355, i64 %356
  %358 = getelementptr float, ptr %357, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %347, ptr align 4 %358, <vscale x 4 x i1> %326)
  %359 = add i64 %298, 1
  br label %297

360:                                              ; preds = %297
  call void @free(ptr %15)
  call void @free(ptr %124)
  ret { ptr, ptr, i64, [2 x i64], [2 x i64] } %118
}

define void @_mlir_ciface_Softmax(ptr %0, ptr %1) {
  %3 = load { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, align 8
  %4 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 0
  %5 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 1
  %6 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 2
  %7 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 3, 0
  %8 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 3, 1
  %9 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 4, 0
  %10 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, 4, 1
  %11 = call { ptr, ptr, i64, [2 x i64], [2 x i64] } @Softmax(ptr %4, ptr %5, i64 %6, i64 %7, i64 %8, i64 %9, i64 %10)
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %11, ptr %0, align 8
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.vscale.i64() #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smin.i64(i64, i64) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64, i64) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr captures(none), <vscale x 4 x i1>, <vscale x 4 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float>, ptr captures(none), <vscale x 4 x i1>) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 8 x i1> @llvm.aarch64.sve.whilelt.nxv8i1.i64(i64, i64) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <vscale x 8 x float> @llvm.masked.load.nxv8f32.p0(ptr captures(none), <vscale x 8 x i1>, <vscale x 8 x float>) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.vector.reduce.fadd.nxv8f32(float, <vscale x 8 x float>) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float>, <vscale x 4 x float>, <vscale x 4 x float>) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x float> @llvm.floor.nxv4f32(<vscale x 4 x float>) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.vector.reduce.fmaximum.nxv8f32(<vscale x 8 x float>) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maximum.f32(float, float) #1

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
