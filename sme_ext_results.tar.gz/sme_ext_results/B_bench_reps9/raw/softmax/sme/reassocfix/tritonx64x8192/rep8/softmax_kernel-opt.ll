; ModuleID = '/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/B_bench_reps9/raw/softmax/sme/reassocfix/tritonx64x8192/rep8/softmax_kernel-llvm-ir.ll'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64"

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @free(ptr allocptr noundef captures(none)) local_unnamed_addr #0

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite, errnomem: write)
declare noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #1

; Function Attrs: nounwind memory(readwrite, target_mem: none)
define void @softmax_kernel(i64 %0, ptr nofree readonly captures(none) %1, i64 %2, ptr nofree readonly captures(none) %3, i32 %4, i32 %5, i32 %6, i32 %7, i32 %8, i32 %9, i32 %10, i32 %11, i32 %12) local_unnamed_addr #2 {
  %14 = mul i32 %10, %4
  %15 = sext i32 %14 to i64
  %16 = getelementptr i8, ptr %3, i64 8
  %17 = load ptr, ptr %16, align 8
  %18 = tail call i32 @llvm.smax.i32(i32 %6, i32 0)
  %19 = tail call i32 @llvm.umin.i32(i32 %18, i32 8192)
  %20 = zext nneg i32 %19 to i64
  %21 = tail call dereferenceable_or_null(32768) ptr @malloc(i64 32768)
  %22 = icmp slt i32 %6, 8192
  br i1 %22, label %25, label %.thread

.thread:                                          ; preds = %13
  %23 = tail call i64 @llvm.vscale.i64()
  %24 = shl i64 %23, 2
  br label %.lr.ph.preheader

25:                                               ; preds = %13
  store <8192 x float> splat (float -inf), ptr %21, align 4
  %26 = tail call i64 @llvm.vscale.i64()
  %27 = shl i64 %26, 2
  %.not = icmp slt i32 %6, 1
  br i1 %.not, label %._crit_edge, label %.lr.ph.preheader

.lr.ph.preheader:                                 ; preds = %.thread, %25
  %28 = phi i64 [ %24, %.thread ], [ %27, %25 ]
  %29 = phi i64 [ %23, %.thread ], [ %26, %25 ]
  %invariant.gep21 = getelementptr [4 x i8], ptr %17, i64 %15
  br label %.lr.ph

.lr.ph:                                           ; preds = %.lr.ph.preheader, %.lr.ph
  %30 = phi i64 [ %36, %.lr.ph ], [ 0, %.lr.ph.preheader ]
  %31 = sub i64 %20, %30
  %32 = tail call i64 @llvm.smin.i64(i64 %28, i64 %31)
  %33 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %32)
  %gep = getelementptr [4 x i8], ptr %invariant.gep21, i64 %30
  %34 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %gep, <vscale x 4 x i1> %33, <vscale x 4 x float> poison)
  %35 = getelementptr [4 x i8], ptr %21, i64 %30
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %34, ptr align 4 %35, <vscale x 4 x i1> %33)
  %36 = add i64 %30, %28
  %37 = icmp slt i64 %36, %20
  br i1 %37, label %.lr.ph, label %._crit_edge

._crit_edge:                                      ; preds = %.lr.ph, %25
  %.not23 = phi i1 [ true, %25 ], [ false, %.lr.ph ]
  %38 = phi i64 [ %27, %25 ], [ %28, %.lr.ph ]
  %39 = phi i64 [ %26, %25 ], [ %29, %.lr.ph ]
  %40 = tail call dereferenceable_or_null(68) ptr @malloc(i64 68)
  %41 = ptrtoint ptr %40 to i64
  %42 = add i64 %41, 63
  %43 = and i64 %42, -64
  %44 = inttoptr i64 %43 to ptr
  %45 = shl i64 %39, 3
  %46 = trunc i64 %39 to i32
  %47 = shl i32 %46, 3
  br label %48

48:                                               ; preds = %._crit_edge, %48
  %49 = phi <1 x float> [ splat (float -inf), %._crit_edge ], [ %58, %48 ]
  %50 = phi i64 [ 0, %._crit_edge ], [ %59, %48 ]
  %51 = sub i64 8192, %50
  %52 = tail call i64 @llvm.smin.i64(i64 %51, i64 %45)
  %53 = tail call <vscale x 8 x i1> @llvm.aarch64.sve.whilelt.nxv8i1.i64(i64 0, i64 %52)
  %54 = getelementptr [4 x i8], ptr %21, i64 %50
  %55 = tail call <vscale x 8 x float> @llvm.masked.load.nxv8f32.p0(ptr align 4 %54, <vscale x 8 x i1> %53, <vscale x 8 x float> poison)
  %56 = extractelement <1 x float> %49, i64 0
  %57 = tail call float @llvm.vp.reduce.fmax.nxv8f32(float %56, <vscale x 8 x float> %55, <vscale x 8 x i1> %53, i32 %47)
  %58 = insertelement <1 x float> poison, float %57, i64 0
  %59 = add i64 %50, %45
  %60 = icmp slt i64 %59, 8192
  br i1 %60, label %48, label %61

61:                                               ; preds = %48
  store <1 x float> %58, ptr %44, align 64
  %62 = tail call dereferenceable_or_null(32832) ptr @malloc(i64 32832)
  %63 = ptrtoint ptr %62 to i64
  %64 = add i64 %63, 63
  %65 = and i64 %64, -64
  %66 = inttoptr i64 %65 to ptr
  %67 = insertelement <vscale x 4 x float> poison, float %57, i64 0
  %68 = shufflevector <vscale x 4 x float> %67, <vscale x 4 x float> poison, <vscale x 4 x i32> zeroinitializer
  br label %69

69:                                               ; preds = %61, %69
  %70 = phi i64 [ 0, %61 ], [ %99, %69 ]
  %71 = sub i64 8192, %70
  %72 = tail call i64 @llvm.smin.i64(i64 %71, i64 %38)
  %73 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %72)
  %74 = getelementptr [4 x i8], ptr %21, i64 %70
  %75 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %74, <vscale x 4 x i1> %73, <vscale x 4 x float> poison)
  %76 = fsub <vscale x 4 x float> %75, %68
  %.inv = fcmp olt <vscale x 4 x float> %76, splat (float -8.780000e+01)
  %77 = select <vscale x 4 x i1> %.inv, <vscale x 4 x float> splat (float -8.780000e+01), <vscale x 4 x float> %76
  %.inv6 = fcmp ogt <vscale x 4 x float> %77, splat (float 8.880000e+01)
  %78 = select <vscale x 4 x i1> %.inv6, <vscale x 4 x float> splat (float 8.880000e+01), <vscale x 4 x float> %77
  %79 = tail call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %78, <vscale x 4 x float> splat (float f0x3FB8AA3B), <vscale x 4 x float> splat (float 5.000000e-01))
  %80 = tail call <vscale x 4 x float> @llvm.floor.nxv4f32(<vscale x 4 x float> %79)
  %.inv7 = fcmp olt <vscale x 4 x float> %80, splat (float -1.270000e+02)
  %81 = select <vscale x 4 x i1> %.inv7, <vscale x 4 x float> splat (float -1.270000e+02), <vscale x 4 x float> %80
  %.inv8 = fcmp ogt <vscale x 4 x float> %81, splat (float 1.270000e+02)
  %82 = select <vscale x 4 x i1> %.inv8, <vscale x 4 x float> splat (float 1.270000e+02), <vscale x 4 x float> %81
  %83 = tail call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %82, <vscale x 4 x float> splat (float f0xBF318000), <vscale x 4 x float> %78)
  %84 = tail call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %82, <vscale x 4 x float> splat (float f0x395E8083), <vscale x 4 x float> %83)
  %85 = tail call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %84, <vscale x 4 x float> splat (float f0x39506967), <vscale x 4 x float> splat (float f0x3AB743CE))
  %86 = tail call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %85, <vscale x 4 x float> %84, <vscale x 4 x float> splat (float f0x3C088908))
  %87 = tail call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %86, <vscale x 4 x float> %84, <vscale x 4 x float> splat (float f0x3D2AA9C1))
  %88 = tail call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %87, <vscale x 4 x float> %84, <vscale x 4 x float> splat (float f0x3E2AAAAA))
  %89 = tail call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %88, <vscale x 4 x float> %84, <vscale x 4 x float> splat (float 5.000000e-01))
  %90 = fmul <vscale x 4 x float> %84, %84
  %91 = tail call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %89, <vscale x 4 x float> %90, <vscale x 4 x float> %84)
  %92 = fadd <vscale x 4 x float> %91, splat (float 1.000000e+00)
  %93 = fptosi <vscale x 4 x float> %82 to <vscale x 4 x i32>
  %94 = shl <vscale x 4 x i32> %93, splat (i32 23)
  %95 = add <vscale x 4 x i32> %94, splat (i32 1065353216)
  %96 = bitcast <vscale x 4 x i32> %95 to <vscale x 4 x float>
  %97 = fmul <vscale x 4 x float> %92, %96
  %98 = getelementptr [4 x i8], ptr %66, i64 %70
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %97, ptr align 4 %98, <vscale x 4 x i1> %73)
  %99 = add i64 %70, %38
  %100 = icmp slt i64 %99, 8192
  br i1 %100, label %69, label %101

101:                                              ; preds = %69
  %102 = tail call dereferenceable_or_null(68) ptr @malloc(i64 68)
  %103 = ptrtoint ptr %102 to i64
  %104 = add i64 %103, 63
  %105 = and i64 %104, -64
  %106 = inttoptr i64 %105 to ptr
  store float 0.000000e+00, ptr %106, align 64
  br label %107

107:                                              ; preds = %101, %107
  %108 = phi <1 x float> [ zeroinitializer, %101 ], [ %117, %107 ]
  %109 = phi i64 [ 0, %101 ], [ %118, %107 ]
  %110 = sub i64 8192, %109
  %111 = tail call i64 @llvm.smin.i64(i64 %110, i64 %45)
  %112 = tail call <vscale x 8 x i1> @llvm.aarch64.sve.whilelt.nxv8i1.i64(i64 0, i64 %111)
  %113 = getelementptr [4 x i8], ptr %66, i64 %109
  %114 = tail call <vscale x 8 x float> @llvm.masked.load.nxv8f32.p0(ptr align 32 %113, <vscale x 8 x i1> %112, <vscale x 8 x float> zeroinitializer)
  %115 = extractelement <1 x float> %108, i64 0
  %116 = tail call reassoc float @llvm.vector.reduce.fadd.nxv8f32(float %115, <vscale x 8 x float> %114)
  %117 = insertelement <1 x float> poison, float %116, i64 0
  %118 = add i64 %109, %45
  %119 = icmp slt i64 %118, 8192
  br i1 %119, label %107, label %120

120:                                              ; preds = %107
  store <1 x float> %117, ptr %106, align 64
  %121 = mul i32 %10, %5
  %122 = sext i32 %121 to i64
  %123 = getelementptr i8, ptr %1, i64 8
  %124 = load ptr, ptr %123, align 8
  %125 = insertelement <vscale x 4 x float> poison, float %116, i64 0
  %126 = shufflevector <vscale x 4 x float> %125, <vscale x 4 x float> poison, <vscale x 4 x i32> zeroinitializer
  %invariant.gep10 = getelementptr [4 x i8], ptr %124, i64 %122
  br i1 %.not23, label %._crit_edge14, label %.lr.ph13

.lr.ph13:                                         ; preds = %120, %.lr.ph13
  %127 = phi i64 [ %134, %.lr.ph13 ], [ 0, %120 ]
  %128 = sub i64 %20, %127
  %129 = tail call i64 @llvm.smin.i64(i64 %38, i64 %128)
  %130 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %129)
  %131 = getelementptr [4 x i8], ptr %66, i64 %127
  %132 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %131, <vscale x 4 x i1> %130, <vscale x 4 x float> poison)
  %133 = fdiv <vscale x 4 x float> %132, %126
  %gep11 = getelementptr [4 x i8], ptr %invariant.gep10, i64 %127
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %133, ptr align 4 %gep11, <vscale x 4 x i1> %130)
  %134 = add i64 %127, %38
  %135 = icmp slt i64 %134, %20
  br i1 %135, label %.lr.ph13, label %._crit_edge14

._crit_edge14:                                    ; preds = %.lr.ph13, %120
  tail call void @free(ptr %21)
  tail call void @free(ptr %40)
  tail call void @free(ptr %62)
  tail call void @free(ptr %102)
  ret void
}

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smin.i64(i64, i64) #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.vscale.i64() #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64, i64) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr captures(none), <vscale x 4 x i1>, <vscale x 4 x float>) #5

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float>, ptr captures(none), <vscale x 4 x i1>) #6

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 8 x i1> @llvm.aarch64.sve.whilelt.nxv8i1.i64(i64, i64) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <vscale x 8 x float> @llvm.masked.load.nxv8f32.p0(ptr captures(none), <vscale x 8 x i1>, <vscale x 8 x float>) #5

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.vector.reduce.fadd.nxv8f32(float, <vscale x 8 x float>) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float>, <vscale x 4 x float>, <vscale x 4 x float>) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x float> @llvm.floor.nxv4f32(<vscale x 4 x float>) #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.vp.reduce.fmax.nxv8f32(float, <vscale x 8 x float>, <vscale x 8 x i1>, i32) #4

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smax.i32(i32, i32) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umin.i32(i32, i32) #7

attributes #0 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "target-features"="+sve,+sve2,+sme" }
attributes #1 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite, errnomem: write) "alloc-family"="malloc" "target-features"="+sve,+sve2,+sme" }
attributes #2 = { nounwind memory(readwrite, target_mem: none) "target-features"="+sve,+sve2,+sme" }
attributes #3 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) "target-features"="+sve,+sve2,+sme" }
attributes #4 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) "target-features"="+sve,+sve2,+sme" }
attributes #5 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read) "target-features"="+sve,+sve2,+sme" }
attributes #6 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write) "target-features"="+sve,+sve2,+sme" }
attributes #7 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
