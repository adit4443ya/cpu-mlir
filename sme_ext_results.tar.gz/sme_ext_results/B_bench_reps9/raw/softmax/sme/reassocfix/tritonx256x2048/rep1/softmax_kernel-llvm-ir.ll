; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target triple = "aarch64"

declare void @free(ptr)

declare ptr @malloc(i64)

define void @softmax_kernel(i64 %0, ptr %1, i64 %2, ptr %3, i32 %4, i32 %5, i32 %6, i32 %7, i32 %8, i32 %9, i32 %10, i32 %11, i32 %12) {
  %14 = insertvalue { i64, ptr } poison, i64 %2, 0
  %15 = insertvalue { i64, ptr } %14, ptr %3, 1
  %16 = insertvalue { i64, ptr } poison, i64 %0, 0
  %17 = insertvalue { i64, ptr } %16, ptr %1, 1
  %18 = mul i32 %10, %4
  %19 = sext i32 %18 to i64
  %20 = extractvalue { i64, ptr } %15, 1
  %21 = load ptr, ptr %20, align 8
  %22 = getelementptr ptr, ptr %20, i32 1
  %23 = load ptr, ptr %22, align 8
  %24 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %21, 0
  %25 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %24, ptr %23, 1
  %26 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %25, i64 %19, 2
  %27 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %26, i64 2048, 3, 0
  %28 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %27, i64 1, 4, 0
  %29 = sext i32 %6 to i64
  %30 = call i64 @llvm.smin.i64(i64 %29, i64 2048)
  %31 = call i64 @llvm.smax.i64(i64 %30, i64 0)
  %32 = call ptr @malloc(i64 8192)
  %33 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %32, 0
  %34 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, ptr %32, 1
  %35 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %34, i64 0, 2
  %36 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %35, i64 2048, 3, 0
  %37 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %36, i64 1, 4, 0
  %38 = icmp slt i64 %31, 2048
  br i1 %38, label %39, label %42

39:                                               ; preds = %13
  %40 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %37, 1
  %41 = getelementptr float, ptr %40, i64 0
  store <2048 x float> splat (float -inf), ptr %41, align 4
  br label %42

42:                                               ; preds = %39, %13
  %43 = call i64 @llvm.vscale.i64()
  %44 = mul i64 %43, 4
  br label %45

45:                                               ; preds = %48, %42
  %46 = phi i64 [ %76, %48 ], [ 0, %42 ]
  %47 = icmp slt i64 %46, %31
  br i1 %47, label %48, label %77

48:                                               ; preds = %45
  %49 = mul nsw i64 %46, -1
  %50 = add i64 %31, %49
  %51 = call i64 @llvm.smin.i64(i64 %44, i64 %50)
  %52 = insertvalue { ptr, ptr, i64 } poison, ptr %21, 0
  %53 = insertvalue { ptr, ptr, i64 } %52, ptr %23, 1
  %54 = insertvalue { ptr, ptr, i64 } %53, i64 0, 2
  %55 = add i64 %19, %46
  %56 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %21, 0
  %57 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %56, ptr %23, 1
  %58 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %57, i64 %55, 2
  %59 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %58, i64 %51, 3, 0
  %60 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %59, i64 1, 4, 0
  %61 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %32, 0
  %62 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %61, ptr %32, 1
  %63 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %62, i64 %46, 2
  %64 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %63, i64 %51, 3, 0
  %65 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %64, i64 1, 4, 0
  %66 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %51)
  %67 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %60, 1
  %68 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %60, 2
  %69 = getelementptr float, ptr %67, i64 %68
  %70 = getelementptr float, ptr %69, i64 0
  %71 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %70, <vscale x 4 x i1> %66, <vscale x 4 x float> poison)
  %72 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %65, 1
  %73 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %65, 2
  %74 = getelementptr float, ptr %72, i64 %73
  %75 = getelementptr float, ptr %74, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %71, ptr align 4 %75, <vscale x 4 x i1> %66)
  %76 = add i64 %46, %44
  br label %45

77:                                               ; preds = %45
  %78 = call ptr @malloc(i64 68)
  %79 = ptrtoint ptr %78 to i64
  %80 = add i64 %79, 63
  %81 = urem i64 %80, 64
  %82 = sub i64 %80, %81
  %83 = inttoptr i64 %82 to ptr
  %84 = insertvalue { ptr, ptr, i64 } poison, ptr %78, 0
  %85 = insertvalue { ptr, ptr, i64 } %84, ptr %83, 1
  %86 = insertvalue { ptr, ptr, i64 } %85, i64 0, 2
  store float -inf, ptr %83, align 4
  %87 = mul i64 %43, 8
  %88 = extractvalue { ptr, ptr, i64 } %86, 1
  %89 = load <1 x float>, ptr %88, align 4
  %90 = extractelement <1 x float> %89, i64 0
  %91 = insertelement <1 x float> poison, float %90, i64 0
  br label %92

92:                                               ; preds = %96, %77
  %93 = phi i64 [ %117, %96 ], [ 0, %77 ]
  %94 = phi <1 x float> [ %116, %96 ], [ %91, %77 ]
  %95 = icmp slt i64 %93, 2048
  br i1 %95, label %96, label %118

96:                                               ; preds = %92
  %97 = mul nsw i64 %93, -1
  %98 = add i64 %97, 2048
  %99 = call i64 @llvm.smin.i64(i64 %98, i64 %87)
  %100 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %32, 0
  %101 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %100, ptr %32, 1
  %102 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %101, i64 %93, 2
  %103 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %102, i64 %99, 3, 0
  %104 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %103, i64 1, 4, 0
  %105 = call <vscale x 8 x i1> @llvm.aarch64.sve.whilelt.nxv8i1.i64(i64 0, i64 %99)
  %106 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %104, 1
  %107 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %104, 2
  %108 = getelementptr float, ptr %106, i64 %107
  %109 = getelementptr float, ptr %108, i64 0
  %110 = call <vscale x 8 x float> @llvm.masked.load.nxv8f32.p0(ptr align 4 %109, <vscale x 8 x i1> %105, <vscale x 8 x float> poison)
  %111 = extractelement <1 x float> %94, i64 0
  %112 = call i64 @llvm.vscale.i64()
  %113 = trunc i64 %112 to i32
  %114 = mul i32 %113, 8
  %115 = call float @llvm.vp.reduce.fmax.nxv8f32(float %111, <vscale x 8 x float> %110, <vscale x 8 x i1> %105, i32 %114)
  %116 = insertelement <1 x float> poison, float %115, i32 0
  %117 = add i64 %93, %87
  br label %92

118:                                              ; preds = %92
  %119 = extractelement <1 x float> %94, i64 0
  %120 = insertelement <1 x float> poison, float %119, i64 0
  %121 = extractvalue { ptr, ptr, i64 } %86, 1
  store <1 x float> %120, ptr %121, align 4
  %122 = load float, ptr %83, align 4
  %123 = call ptr @malloc(i64 8256)
  %124 = ptrtoint ptr %123 to i64
  %125 = add i64 %124, 63
  %126 = urem i64 %125, 64
  %127 = sub i64 %125, %126
  %128 = inttoptr i64 %127 to ptr
  %129 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %123, 0
  %130 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %129, ptr %128, 1
  %131 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %130, i64 0, 2
  %132 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %131, i64 2048, 3, 0
  %133 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %132, i64 1, 4, 0
  %134 = insertelement <vscale x 4 x float> poison, float %122, i32 0
  %135 = shufflevector <vscale x 4 x float> %134, <vscale x 4 x float> poison, <vscale x 4 x i32> zeroinitializer
  br label %136

136:                                              ; preds = %139, %118
  %137 = phi i64 [ %189, %139 ], [ 0, %118 ]
  %138 = icmp slt i64 %137, 2048
  br i1 %138, label %139, label %190

139:                                              ; preds = %136
  %140 = mul nsw i64 %137, -1
  %141 = add i64 %140, 2048
  %142 = call i64 @llvm.smin.i64(i64 %141, i64 %44)
  %143 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %32, 0
  %144 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %143, ptr %32, 1
  %145 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %144, i64 %137, 2
  %146 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %145, i64 %142, 3, 0
  %147 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %146, i64 1, 4, 0
  %148 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %123, 0
  %149 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %148, ptr %128, 1
  %150 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %149, i64 %137, 2
  %151 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %150, i64 %142, 3, 0
  %152 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %151, i64 1, 4, 0
  %153 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %142)
  %154 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %147, 1
  %155 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %147, 2
  %156 = getelementptr float, ptr %154, i64 %155
  %157 = getelementptr float, ptr %156, i64 0
  %158 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %157, <vscale x 4 x i1> %153, <vscale x 4 x float> poison)
  %159 = fsub <vscale x 4 x float> %158, %135
  %160 = fcmp uge <vscale x 4 x float> %159, splat (float -8.780000e+01)
  %161 = select <vscale x 4 x i1> %160, <vscale x 4 x float> %159, <vscale x 4 x float> splat (float -8.780000e+01)
  %162 = fcmp ule <vscale x 4 x float> %161, splat (float 8.880000e+01)
  %163 = select <vscale x 4 x i1> %162, <vscale x 4 x float> %161, <vscale x 4 x float> splat (float 8.880000e+01)
  %164 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %163, <vscale x 4 x float> splat (float f0x3FB8AA3B), <vscale x 4 x float> splat (float 5.000000e-01))
  %165 = call <vscale x 4 x float> @llvm.floor.nxv4f32(<vscale x 4 x float> %164)
  %166 = fcmp uge <vscale x 4 x float> %165, splat (float -1.270000e+02)
  %167 = select <vscale x 4 x i1> %166, <vscale x 4 x float> %165, <vscale x 4 x float> splat (float -1.270000e+02)
  %168 = fcmp ule <vscale x 4 x float> %167, splat (float 1.270000e+02)
  %169 = select <vscale x 4 x i1> %168, <vscale x 4 x float> %167, <vscale x 4 x float> splat (float 1.270000e+02)
  %170 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> splat (float f0xBF318000), <vscale x 4 x float> %169, <vscale x 4 x float> %163)
  %171 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> splat (float f0x395E8083), <vscale x 4 x float> %169, <vscale x 4 x float> %170)
  %172 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %171, <vscale x 4 x float> splat (float f0x39506967), <vscale x 4 x float> splat (float f0x3AB743CE))
  %173 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %172, <vscale x 4 x float> %171, <vscale x 4 x float> splat (float f0x3C088908))
  %174 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %173, <vscale x 4 x float> %171, <vscale x 4 x float> splat (float f0x3D2AA9C1))
  %175 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %174, <vscale x 4 x float> %171, <vscale x 4 x float> splat (float f0x3E2AAAAA))
  %176 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %175, <vscale x 4 x float> %171, <vscale x 4 x float> splat (float 5.000000e-01))
  %177 = fmul <vscale x 4 x float> %171, %171
  %178 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %176, <vscale x 4 x float> %177, <vscale x 4 x float> %171)
  %179 = fadd <vscale x 4 x float> %178, splat (float 1.000000e+00)
  %180 = fptosi <vscale x 4 x float> %169 to <vscale x 4 x i32>
  %181 = add <vscale x 4 x i32> %180, splat (i32 127)
  %182 = shl <vscale x 4 x i32> %181, splat (i32 23)
  %183 = bitcast <vscale x 4 x i32> %182 to <vscale x 4 x float>
  %184 = fmul <vscale x 4 x float> %179, %183
  %185 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %152, 1
  %186 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %152, 2
  %187 = getelementptr float, ptr %185, i64 %186
  %188 = getelementptr float, ptr %187, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %184, ptr align 4 %188, <vscale x 4 x i1> %153)
  %189 = add i64 %137, %44
  br label %136

190:                                              ; preds = %136
  %191 = call ptr @malloc(i64 68)
  %192 = ptrtoint ptr %191 to i64
  %193 = add i64 %192, 63
  %194 = urem i64 %193, 64
  %195 = sub i64 %193, %194
  %196 = inttoptr i64 %195 to ptr
  %197 = insertvalue { ptr, ptr, i64 } poison, ptr %191, 0
  %198 = insertvalue { ptr, ptr, i64 } %197, ptr %196, 1
  %199 = insertvalue { ptr, ptr, i64 } %198, i64 0, 2
  store float 0.000000e+00, ptr %196, align 4
  %200 = extractvalue { ptr, ptr, i64 } %199, 1
  %201 = load <1 x float>, ptr %200, align 4
  %202 = extractelement <1 x float> %201, i64 0
  %203 = insertelement <1 x float> poison, float %202, i64 0
  br label %204

204:                                              ; preds = %208, %190
  %205 = phi i64 [ %227, %208 ], [ 0, %190 ]
  %206 = phi <1 x float> [ %226, %208 ], [ %203, %190 ]
  %207 = icmp slt i64 %205, 2048
  br i1 %207, label %208, label %228

208:                                              ; preds = %204
  %209 = mul nsw i64 %205, -1
  %210 = add i64 %209, 2048
  %211 = call i64 @llvm.smin.i64(i64 %210, i64 %87)
  %212 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %123, 0
  %213 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %212, ptr %128, 1
  %214 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %213, i64 %205, 2
  %215 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %214, i64 %211, 3, 0
  %216 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %215, i64 1, 4, 0
  %217 = call <vscale x 8 x i1> @llvm.aarch64.sve.whilelt.nxv8i1.i64(i64 0, i64 %211)
  %218 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %216, 1
  %219 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %216, 2
  %220 = getelementptr float, ptr %218, i64 %219
  %221 = getelementptr float, ptr %220, i64 0
  %222 = call <vscale x 8 x float> @llvm.masked.load.nxv8f32.p0(ptr align 4 %221, <vscale x 8 x i1> %217, <vscale x 8 x float> poison)
  %223 = extractelement <1 x float> %206, i64 0
  %224 = select <vscale x 8 x i1> %217, <vscale x 8 x float> %222, <vscale x 8 x float> zeroinitializer
  %225 = call reassoc float @llvm.vector.reduce.fadd.nxv8f32(float %223, <vscale x 8 x float> %224)
  %226 = insertelement <1 x float> poison, float %225, i32 0
  %227 = add i64 %205, %87
  br label %204

228:                                              ; preds = %204
  %229 = extractelement <1 x float> %206, i64 0
  %230 = insertelement <1 x float> poison, float %229, i64 0
  %231 = extractvalue { ptr, ptr, i64 } %199, 1
  store <1 x float> %230, ptr %231, align 4
  %232 = load float, ptr %196, align 4
  %233 = mul i32 %10, %5
  %234 = sext i32 %233 to i64
  %235 = extractvalue { i64, ptr } %17, 1
  %236 = load ptr, ptr %235, align 8
  %237 = getelementptr ptr, ptr %235, i32 1
  %238 = load ptr, ptr %237, align 8
  %239 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %236, 0
  %240 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %239, ptr %238, 1
  %241 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %240, i64 %234, 2
  %242 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %241, i64 2048, 3, 0
  %243 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %242, i64 1, 4, 0
  %244 = insertelement <vscale x 4 x float> poison, float %232, i32 0
  %245 = shufflevector <vscale x 4 x float> %244, <vscale x 4 x float> poison, <vscale x 4 x i32> zeroinitializer
  br label %246

246:                                              ; preds = %249, %228
  %247 = phi i64 [ %278, %249 ], [ 0, %228 ]
  %248 = icmp slt i64 %247, %31
  br i1 %248, label %249, label %279

249:                                              ; preds = %246
  %250 = mul nsw i64 %247, -1
  %251 = add i64 %31, %250
  %252 = call i64 @llvm.smin.i64(i64 %44, i64 %251)
  %253 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %123, 0
  %254 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %253, ptr %128, 1
  %255 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %254, i64 %247, 2
  %256 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %255, i64 %252, 3, 0
  %257 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %256, i64 1, 4, 0
  %258 = insertvalue { ptr, ptr, i64 } poison, ptr %236, 0
  %259 = insertvalue { ptr, ptr, i64 } %258, ptr %238, 1
  %260 = insertvalue { ptr, ptr, i64 } %259, i64 0, 2
  %261 = add i64 %234, %247
  %262 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %236, 0
  %263 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %262, ptr %238, 1
  %264 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %263, i64 %261, 2
  %265 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %264, i64 %252, 3, 0
  %266 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %265, i64 1, 4, 0
  %267 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %252)
  %268 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %257, 1
  %269 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %257, 2
  %270 = getelementptr float, ptr %268, i64 %269
  %271 = getelementptr float, ptr %270, i64 0
  %272 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %271, <vscale x 4 x i1> %267, <vscale x 4 x float> poison)
  %273 = fdiv <vscale x 4 x float> %272, %245
  %274 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %266, 1
  %275 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %266, 2
  %276 = getelementptr float, ptr %274, i64 %275
  %277 = getelementptr float, ptr %276, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %273, ptr align 4 %277, <vscale x 4 x i1> %267)
  %278 = add i64 %247, %44
  br label %246

279:                                              ; preds = %246
  call void @free(ptr %32)
  call void @free(ptr %78)
  call void @free(ptr %123)
  call void @free(ptr %191)
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smin.i64(i64, i64) #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smax.i64(i64, i64) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.vscale.i64() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64, i64) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr captures(none), <vscale x 4 x i1>, <vscale x 4 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float>, ptr captures(none), <vscale x 4 x i1>) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 8 x i1> @llvm.aarch64.sve.whilelt.nxv8i1.i64(i64, i64) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <vscale x 8 x float> @llvm.masked.load.nxv8f32.p0(ptr captures(none), <vscale x 8 x i1>, <vscale x 8 x float>) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.vector.reduce.fadd.nxv8f32(float, <vscale x 8 x float>) #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float>, <vscale x 4 x float>, <vscale x 4 x float>) #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x float> @llvm.floor.nxv4f32(<vscale x 4 x float>) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.vp.reduce.fmax.nxv8f32(float, <vscale x 8 x float>, <vscale x 8 x i1>, i32) #1

attributes #0 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
