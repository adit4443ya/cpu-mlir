	.file	"LLVMDialectModule"
	.text
	.globl	softmax_kernel                  // -- Begin function softmax_kernel
	.p2align	2
	.type	softmax_kernel,@function
softmax_kernel:                         // @softmax_kernel
// %bb.0:
	stp	x29, x30, [sp, #-96]!           // 16-byte Folded Spill
	stp	x28, x27, [sp, #16]             // 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             // 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             // 16-byte Folded Spill
	sub	sp, sp, #16
	addvl	sp, sp, #-1
	bic	w8, w6, w6, asr #31
	str	w5, [sp, #12]                   // 4-byte Spill
	addvl	x9, sp, #1
	ldr	w26, [x9, #128]
	ldr	x24, [x3, #8]
	mov	w9, #2048                       // =0x800
	cmp	w8, #2048
	mov	w0, #8192                       // =0x2000
	mov	w23, w6
	mov	w22, w4
	mov	x21, x1
	csel	w25, w8, w9, lt
	bl	malloc
	cmp	w23, #2048
	mov	x19, x0
	b.ge	.LBB0_3
// %bb.1:
	mvni	v0.4s, #127, msl #16
	rdvl	x8, #1
	cmp	w23, #1
	lsr	x20, x8, #4
	cntw	x27
	str	q0, [x19, #8176]
	str	q0, [x19, #8160]
	str	q0, [x19, #8144]
	str	q0, [x19, #8128]
	str	q0, [x19, #8112]
	str	q0, [x19, #8096]
	str	q0, [x19, #8080]
	str	q0, [x19, #8064]
	str	q0, [x19, #8048]
	str	q0, [x19, #8032]
	str	q0, [x19, #8016]
	str	q0, [x19, #8000]
	str	q0, [x19, #7984]
	str	q0, [x19, #7968]
	str	q0, [x19, #7952]
	str	q0, [x19, #7936]
	str	q0, [x19, #7920]
	str	q0, [x19, #7904]
	str	q0, [x19, #7888]
	str	q0, [x19, #7872]
	str	q0, [x19, #7856]
	str	q0, [x19, #7840]
	str	q0, [x19, #7824]
	str	q0, [x19, #7808]
	str	q0, [x19, #7792]
	str	q0, [x19, #7776]
	str	q0, [x19, #7760]
	str	q0, [x19, #7744]
	str	q0, [x19, #7728]
	str	q0, [x19, #7712]
	str	q0, [x19, #7696]
	str	q0, [x19, #7680]
	str	q0, [x19, #7664]
	str	q0, [x19, #7648]
	str	q0, [x19, #7632]
	str	q0, [x19, #7616]
	str	q0, [x19, #7600]
	str	q0, [x19, #7584]
	str	q0, [x19, #7568]
	str	q0, [x19, #7552]
	str	q0, [x19, #7536]
	str	q0, [x19, #7520]
	str	q0, [x19, #7504]
	str	q0, [x19, #7488]
	str	q0, [x19, #7472]
	str	q0, [x19, #7456]
	str	q0, [x19, #7440]
	str	q0, [x19, #7424]
	str	q0, [x19, #7408]
	str	q0, [x19, #7392]
	str	q0, [x19, #7376]
	str	q0, [x19, #7360]
	str	q0, [x19, #7344]
	str	q0, [x19, #7328]
	str	q0, [x19, #7312]
	str	q0, [x19, #7296]
	str	q0, [x19, #7280]
	str	q0, [x19, #7264]
	str	q0, [x19, #7248]
	str	q0, [x19, #7232]
	str	q0, [x19, #7216]
	str	q0, [x19, #7200]
	str	q0, [x19, #7184]
	str	q0, [x19, #7168]
	str	q0, [x19, #7152]
	str	q0, [x19, #7136]
	str	q0, [x19, #7120]
	str	q0, [x19, #7104]
	str	q0, [x19, #7088]
	str	q0, [x19, #7072]
	str	q0, [x19, #7056]
	str	q0, [x19, #7040]
	str	q0, [x19, #7024]
	str	q0, [x19, #7008]
	str	q0, [x19, #6992]
	str	q0, [x19, #6976]
	str	q0, [x19, #6960]
	str	q0, [x19, #6944]
	str	q0, [x19, #6928]
	str	q0, [x19, #6912]
	str	q0, [x19, #6896]
	str	q0, [x19, #6880]
	str	q0, [x19, #6864]
	str	q0, [x19, #6848]
	str	q0, [x19, #6832]
	str	q0, [x19, #6816]
	str	q0, [x19, #6800]
	str	q0, [x19, #6784]
	str	q0, [x19, #6768]
	str	q0, [x19, #6752]
	str	q0, [x19, #6736]
	str	q0, [x19, #6720]
	str	q0, [x19, #6704]
	str	q0, [x19, #6688]
	str	q0, [x19, #6672]
	str	q0, [x19, #6656]
	str	q0, [x19, #6640]
	str	q0, [x19, #6624]
	str	q0, [x19, #6608]
	str	q0, [x19, #6592]
	str	q0, [x19, #6576]
	str	q0, [x19, #6560]
	str	q0, [x19, #6544]
	str	q0, [x19, #6528]
	str	q0, [x19, #6512]
	str	q0, [x19, #6496]
	str	q0, [x19, #6480]
	str	q0, [x19, #6464]
	str	q0, [x19, #6448]
	str	q0, [x19, #6432]
	str	q0, [x19, #6416]
	str	q0, [x19, #6400]
	str	q0, [x19, #6384]
	str	q0, [x19, #6368]
	str	q0, [x19, #6352]
	str	q0, [x19, #6336]
	str	q0, [x19, #6320]
	str	q0, [x19, #6304]
	str	q0, [x19, #6288]
	str	q0, [x19, #6272]
	str	q0, [x19, #6256]
	str	q0, [x19, #6240]
	str	q0, [x19, #6224]
	str	q0, [x19, #6208]
	str	q0, [x19, #6192]
	str	q0, [x19, #6176]
	str	q0, [x19, #6160]
	str	q0, [x19, #6144]
	str	q0, [x19, #6128]
	str	q0, [x19, #6112]
	str	q0, [x19, #6096]
	str	q0, [x19, #6080]
	str	q0, [x19, #6064]
	str	q0, [x19, #6048]
	str	q0, [x19, #6032]
	str	q0, [x19, #6016]
	str	q0, [x19, #6000]
	str	q0, [x19, #5984]
	str	q0, [x19, #5968]
	str	q0, [x19, #5952]
	str	q0, [x19, #5936]
	str	q0, [x19, #5920]
	str	q0, [x19, #5904]
	str	q0, [x19, #5888]
	str	q0, [x19, #5872]
	str	q0, [x19, #5856]
	str	q0, [x19, #5840]
	str	q0, [x19, #5824]
	str	q0, [x19, #5808]
	str	q0, [x19, #5792]
	str	q0, [x19, #5776]
	str	q0, [x19, #5760]
	str	q0, [x19, #5744]
	str	q0, [x19, #5728]
	str	q0, [x19, #5712]
	str	q0, [x19, #5696]
	str	q0, [x19, #5680]
	str	q0, [x19, #5664]
	str	q0, [x19, #5648]
	str	q0, [x19, #5632]
	str	q0, [x19, #5616]
	str	q0, [x19, #5600]
	str	q0, [x19, #5584]
	str	q0, [x19, #5568]
	str	q0, [x19, #5552]
	str	q0, [x19, #5536]
	str	q0, [x19, #5520]
	str	q0, [x19, #5504]
	str	q0, [x19, #5488]
	str	q0, [x19, #5472]
	str	q0, [x19, #5456]
	str	q0, [x19, #5440]
	str	q0, [x19, #5424]
	str	q0, [x19, #5408]
	str	q0, [x19, #5392]
	str	q0, [x19, #5376]
	str	q0, [x19, #5360]
	str	q0, [x19, #5344]
	str	q0, [x19, #5328]
	str	q0, [x19, #5312]
	str	q0, [x19, #5296]
	str	q0, [x19, #5280]
	str	q0, [x19, #5264]
	str	q0, [x19, #5248]
	str	q0, [x19, #5232]
	str	q0, [x19, #5216]
	str	q0, [x19, #5200]
	str	q0, [x19, #5184]
	str	q0, [x19, #5168]
	str	q0, [x19, #5152]
	str	q0, [x19, #5136]
	str	q0, [x19, #5120]
	str	q0, [x19, #5104]
	str	q0, [x19, #5088]
	str	q0, [x19, #5072]
	str	q0, [x19, #5056]
	str	q0, [x19, #5040]
	str	q0, [x19, #5024]
	str	q0, [x19, #5008]
	str	q0, [x19, #4992]
	str	q0, [x19, #4976]
	str	q0, [x19, #4960]
	str	q0, [x19, #4944]
	str	q0, [x19, #4928]
	str	q0, [x19, #4912]
	str	q0, [x19, #4896]
	str	q0, [x19, #4880]
	str	q0, [x19, #4864]
	str	q0, [x19, #4848]
	str	q0, [x19, #4832]
	str	q0, [x19, #4816]
	str	q0, [x19, #4800]
	str	q0, [x19, #4784]
	str	q0, [x19, #4768]
	str	q0, [x19, #4752]
	str	q0, [x19, #4736]
	str	q0, [x19, #4720]
	str	q0, [x19, #4704]
	str	q0, [x19, #4688]
	str	q0, [x19, #4672]
	str	q0, [x19, #4656]
	str	q0, [x19, #4640]
	str	q0, [x19, #4624]
	str	q0, [x19, #4608]
	str	q0, [x19, #4592]
	str	q0, [x19, #4576]
	str	q0, [x19, #4560]
	str	q0, [x19, #4544]
	str	q0, [x19, #4528]
	str	q0, [x19, #4512]
	str	q0, [x19, #4496]
	str	q0, [x19, #4480]
	str	q0, [x19, #4464]
	str	q0, [x19, #4448]
	str	q0, [x19, #4432]
	str	q0, [x19, #4416]
	str	q0, [x19, #4400]
	str	q0, [x19, #4384]
	str	q0, [x19, #4368]
	str	q0, [x19, #4352]
	str	q0, [x19, #4336]
	str	q0, [x19, #4320]
	str	q0, [x19, #4304]
	str	q0, [x19, #4288]
	str	q0, [x19, #4272]
	str	q0, [x19, #4256]
	str	q0, [x19, #4240]
	str	q0, [x19, #4224]
	str	q0, [x19, #4208]
	str	q0, [x19, #4192]
	str	q0, [x19, #4176]
	str	q0, [x19, #4160]
	str	q0, [x19, #4144]
	str	q0, [x19, #4128]
	str	q0, [x19, #4112]
	str	q0, [x19, #4096]
	str	q0, [x19, #4080]
	str	q0, [x19, #4064]
	str	q0, [x19, #4048]
	str	q0, [x19, #4032]
	str	q0, [x19, #4016]
	str	q0, [x19, #4000]
	str	q0, [x19, #3984]
	str	q0, [x19, #3968]
	str	q0, [x19, #3952]
	str	q0, [x19, #3936]
	str	q0, [x19, #3920]
	str	q0, [x19, #3904]
	str	q0, [x19, #3888]
	str	q0, [x19, #3872]
	str	q0, [x19, #3856]
	str	q0, [x19, #3840]
	str	q0, [x19, #3824]
	str	q0, [x19, #3808]
	str	q0, [x19, #3792]
	str	q0, [x19, #3776]
	str	q0, [x19, #3760]
	str	q0, [x19, #3744]
	str	q0, [x19, #3728]
	str	q0, [x19, #3712]
	str	q0, [x19, #3696]
	str	q0, [x19, #3680]
	str	q0, [x19, #3664]
	str	q0, [x19, #3648]
	str	q0, [x19, #3632]
	str	q0, [x19, #3616]
	str	q0, [x19, #3600]
	str	q0, [x19, #3584]
	str	q0, [x19, #3568]
	str	q0, [x19, #3552]
	str	q0, [x19, #3536]
	str	q0, [x19, #3520]
	str	q0, [x19, #3504]
	str	q0, [x19, #3488]
	str	q0, [x19, #3472]
	str	q0, [x19, #3456]
	str	q0, [x19, #3440]
	str	q0, [x19, #3424]
	str	q0, [x19, #3408]
	str	q0, [x19, #3392]
	str	q0, [x19, #3376]
	str	q0, [x19, #3360]
	str	q0, [x19, #3344]
	str	q0, [x19, #3328]
	str	q0, [x19, #3312]
	str	q0, [x19, #3296]
	str	q0, [x19, #3280]
	str	q0, [x19, #3264]
	str	q0, [x19, #3248]
	str	q0, [x19, #3232]
	str	q0, [x19, #3216]
	str	q0, [x19, #3200]
	str	q0, [x19, #3184]
	str	q0, [x19, #3168]
	str	q0, [x19, #3152]
	str	q0, [x19, #3136]
	str	q0, [x19, #3120]
	str	q0, [x19, #3104]
	str	q0, [x19, #3088]
	str	q0, [x19, #3072]
	str	q0, [x19, #3056]
	str	q0, [x19, #3040]
	str	q0, [x19, #3024]
	str	q0, [x19, #3008]
	str	q0, [x19, #2992]
	str	q0, [x19, #2976]
	str	q0, [x19, #2960]
	str	q0, [x19, #2944]
	str	q0, [x19, #2928]
	str	q0, [x19, #2912]
	str	q0, [x19, #2896]
	str	q0, [x19, #2880]
	str	q0, [x19, #2864]
	str	q0, [x19, #2848]
	str	q0, [x19, #2832]
	str	q0, [x19, #2816]
	str	q0, [x19, #2800]
	str	q0, [x19, #2784]
	str	q0, [x19, #2768]
	str	q0, [x19, #2752]
	str	q0, [x19, #2736]
	str	q0, [x19, #2720]
	str	q0, [x19, #2704]
	str	q0, [x19, #2688]
	str	q0, [x19, #2672]
	str	q0, [x19, #2656]
	str	q0, [x19, #2640]
	str	q0, [x19, #2624]
	str	q0, [x19, #2608]
	str	q0, [x19, #2592]
	str	q0, [x19, #2576]
	str	q0, [x19, #2560]
	str	q0, [x19, #2544]
	str	q0, [x19, #2528]
	str	q0, [x19, #2512]
	str	q0, [x19, #2496]
	str	q0, [x19, #2480]
	str	q0, [x19, #2464]
	str	q0, [x19, #2448]
	str	q0, [x19, #2432]
	str	q0, [x19, #2416]
	str	q0, [x19, #2400]
	str	q0, [x19, #2384]
	str	q0, [x19, #2368]
	str	q0, [x19, #2352]
	str	q0, [x19, #2336]
	str	q0, [x19, #2320]
	str	q0, [x19, #2304]
	str	q0, [x19, #2288]
	str	q0, [x19, #2272]
	str	q0, [x19, #2256]
	str	q0, [x19, #2240]
	str	q0, [x19, #2224]
	str	q0, [x19, #2208]
	str	q0, [x19, #2192]
	str	q0, [x19, #2176]
	str	q0, [x19, #2160]
	str	q0, [x19, #2144]
	str	q0, [x19, #2128]
	str	q0, [x19, #2112]
	str	q0, [x19, #2096]
	str	q0, [x19, #2080]
	str	q0, [x19, #2064]
	str	q0, [x19, #2048]
	str	q0, [x19, #2032]
	str	q0, [x19, #2016]
	str	q0, [x19, #2000]
	str	q0, [x19, #1984]
	str	q0, [x19, #1968]
	str	q0, [x19, #1952]
	str	q0, [x19, #1936]
	str	q0, [x19, #1920]
	str	q0, [x19, #1904]
	str	q0, [x19, #1888]
	str	q0, [x19, #1872]
	str	q0, [x19, #1856]
	str	q0, [x19, #1840]
	str	q0, [x19, #1824]
	str	q0, [x19, #1808]
	str	q0, [x19, #1792]
	str	q0, [x19, #1776]
	str	q0, [x19, #1760]
	str	q0, [x19, #1744]
	str	q0, [x19, #1728]
	str	q0, [x19, #1712]
	str	q0, [x19, #1696]
	str	q0, [x19, #1680]
	str	q0, [x19, #1664]
	str	q0, [x19, #1648]
	str	q0, [x19, #1632]
	str	q0, [x19, #1616]
	str	q0, [x19, #1600]
	str	q0, [x19, #1584]
	str	q0, [x19, #1568]
	str	q0, [x19, #1552]
	str	q0, [x19, #1536]
	str	q0, [x19, #1520]
	str	q0, [x19, #1504]
	str	q0, [x19, #1488]
	str	q0, [x19, #1472]
	str	q0, [x19, #1456]
	str	q0, [x19, #1440]
	str	q0, [x19, #1424]
	str	q0, [x19, #1408]
	str	q0, [x19, #1392]
	str	q0, [x19, #1376]
	str	q0, [x19, #1360]
	str	q0, [x19, #1344]
	str	q0, [x19, #1328]
	str	q0, [x19, #1312]
	str	q0, [x19, #1296]
	str	q0, [x19, #1280]
	str	q0, [x19, #1264]
	str	q0, [x19, #1248]
	str	q0, [x19, #1232]
	str	q0, [x19, #1216]
	str	q0, [x19, #1200]
	str	q0, [x19, #1184]
	str	q0, [x19, #1168]
	str	q0, [x19, #1152]
	str	q0, [x19, #1136]
	str	q0, [x19, #1120]
	str	q0, [x19, #1104]
	str	q0, [x19, #1088]
	str	q0, [x19, #1072]
	str	q0, [x19, #1056]
	str	q0, [x19, #1040]
	stp	q0, q0, [x19, #16]
	stp	q0, q0, [x19, #48]
	stp	q0, q0, [x19, #80]
	stp	q0, q0, [x19, #112]
	stp	q0, q0, [x19, #144]
	stp	q0, q0, [x19, #176]
	stp	q0, q0, [x19, #208]
	stp	q0, q0, [x19, #240]
	stp	q0, q0, [x19, #272]
	stp	q0, q0, [x19, #304]
	stp	q0, q0, [x19, #336]
	stp	q0, q0, [x19, #368]
	stp	q0, q0, [x19, #400]
	stp	q0, q0, [x19, #432]
	stp	q0, q0, [x19, #464]
	stp	q0, q0, [x19, #496]
	stp	q0, q0, [x19, #528]
	stp	q0, q0, [x19, #560]
	stp	q0, q0, [x19, #592]
	stp	q0, q0, [x19, #624]
	stp	q0, q0, [x19, #656]
	stp	q0, q0, [x19, #688]
	stp	q0, q0, [x19, #720]
	stp	q0, q0, [x19, #752]
	stp	q0, q0, [x19, #784]
	stp	q0, q0, [x19, #816]
	stp	q0, q0, [x19, #848]
	stp	q0, q0, [x19, #880]
	stp	q0, q0, [x19, #912]
	stp	q0, q0, [x19, #944]
	stp	q0, q0, [x19, #976]
	stp	q0, q0, [x19, #1008]
	str	q0, [x19]
	b.ge	.LBB0_4
// %bb.2:
	mov	w28, #1                         // =0x1
	b	.LBB0_7
.LBB0_3:                                // %.thread
	rdvl	x8, #1
	cntw	x27
	lsr	x20, x8, #4
.LBB0_4:                                // %.lr.ph.preheader
	mul	w9, w26, w22
	mov	x8, xzr
	mov	x10, x25
	sxtw	x9, w9
	add	x9, x24, x9, lsl #2
.LBB0_5:                                // %.lr.ph
                                        // =>This Inner Loop Header: Depth=1
	subs	x11, x10, x27
	csel	x10, x27, x10, gt
	whilelt	p0.s, xzr, x10
	mov	x10, x11
	ld1w	{ z0.s }, p0/z, [x9, x8, lsl #2]
	st1w	{ z0.s }, p0, [x19, x8, lsl #2]
	add	x8, x8, x27
	cmp	x8, x25
	b.lt	.LBB0_5
// %bb.6:
	mov	w28, wzr
.LBB0_7:                                // %._crit_edge
	mov	w0, #68                         // =0x44
	bl	malloc
	lsl	w9, w20, #3
	mov	z0.s, #0xffc00000
	mvni	v3.2s, #127, msl #16
	lsl	x29, x20, #3
	ptrue	p4.s
	mov	x22, x0
	whilelo	p0.h, wzr, w9
	add	x9, x0, #63
	mov	x8, xzr
	and	x9, x9, #0xffffffffffffffc0
	mov	w10, #2048                      // =0x800
.LBB0_8:                                // =>This Inner Loop Header: Depth=1
	subs	x11, x10, x29
	csel	x10, x10, x29, lt
	whilelt	p1.h, xzr, x10
	add	x10, x19, x8, lsl #2
	punpkhi	p2.h, p1.b
	punpklo	p3.h, p1.b
	and	p1.b, p0/z, p0.b, p1.b
	ld1w	{ z1.s }, p2/z, [x10, #1, mul vl]
	mov	x10, x11
	ld1w	{ z2.s }, p3/z, [x19, x8, lsl #2]
	add	x8, x8, x29
	punpkhi	p2.h, p1.b
	cmp	x8, #2048
	punpklo	p1.h, p1.b
	sel	z1.s, p2, z1.s, z0.s
	sel	z2.s, p1, z2.s, z0.s
	fmaxnm	z1.s, p4/m, z1.s, z2.s
	fmaxnmv	s1, p4, z1.s
	fmaxnm	s3, s1, s3
	b.lt	.LBB0_8
// %bb.9:
	mov	w0, #8256                       // =0x2040
	add	x8, sp, #16
	str	s3, [x9]
	str	z3, [x8]                        // 16-byte Folded Spill
	bl	malloc
	mov	w9, #39322                      // =0x999a
	mov	w10, #39322                     // =0x999a
	add	x11, sp, #16
	movk	w9, #49839, lsl #16
	movk	w10, #17073, lsl #16
	ldr	z16, [x11]                      // 16-byte Folded Reload
	mov	z0.s, w9
	mov	w9, #43579                      // =0xaa3b
	mov	z1.s, w10
	movk	w9, #16312, lsl #16
	mov	w10, #-1023541248               // =0xc2fe0000
	mov	z19.s, #0x3f800000
	mov	z2.s, w9
	mov	w9, #1123942400                 // =0x42fe0000
	mov	z3.s, w10
	mov	z4.s, w9
	mov	w9, #32768                      // =0x8000
	mov	w10, #32899                     // =0x8083
	movk	w9, #48945, lsl #16
	movk	w10, #14686, lsl #16
	mov	z16.s, s16
	mov	z5.s, w9
	mov	w9, #26983                      // =0x6967
	mov	z6.s, w10
	movk	w9, #14672, lsl #16
	mov	w10, #35080                     // =0x8908
	fmov	z20.s, #0.50000000
	mov	z7.s, w9
	mov	w9, #17358                      // =0x43ce
	movk	w10, #15368, lsl #16
	movk	w9, #15031, lsl #16
	mov	z18.s, w10
	mov	w10, #43690                     // =0xaaaa
	mov	z17.s, w9
	mov	w9, #43457                      // =0xa9c1
	movk	w10, #15914, lsl #16
	movk	w9, #15658, lsl #16
	mov	z22.s, w10
	ptrue	p2.s
	mov	z21.s, w9
	add	x9, x0, #63
	mov	x23, x0
	mov	x8, xzr
	and	x20, x9, #0xffffffffffffffc0
	mov	w9, #2048                       // =0x800
.LBB0_10:                               // =>This Inner Loop Header: Depth=1
	subs	x10, x9, x27
	csel	x9, x9, x27, lt
	whilelt	p0.s, xzr, x9
	mov	x9, x10
	ld1w	{ z23.s }, p0/z, [x19, x8, lsl #2]
	fsub	z23.s, z23.s, z16.s
	fcmgt	p1.s, p2/z, z0.s, z23.s
	mov	z23.s, p1/m, z0.s
	fcmgt	p1.s, p2/z, z23.s, z1.s
	mov	z23.s, p1/m, z1.s
	movprfx	z24, z20
	fmla	z24.s, p2/m, z23.s, z2.s
	frintm	z24.s, p2/m, z24.s
	fcmgt	p1.s, p2/z, z3.s, z24.s
	mov	z24.s, p1/m, z3.s
	fcmgt	p1.s, p2/z, z24.s, z4.s
	mov	z24.s, p1/m, z4.s
	fmla	z23.s, p2/m, z24.s, z5.s
	fmla	z23.s, p2/m, z24.s, z6.s
	fcvtzs	z24.s, p2/m, z24.s
	movprfx	z25, z17
	fmla	z25.s, p2/m, z23.s, z7.s
	fmul	z26.s, z23.s, z23.s
	lsl	z24.s, z24.s, #23
	add	z24.s, z24.s, z19.s
	fmad	z25.s, p2/m, z23.s, z18.s
	fmad	z25.s, p2/m, z23.s, z21.s
	fmad	z25.s, p2/m, z23.s, z22.s
	fmad	z25.s, p2/m, z23.s, z20.s
	fmla	z23.s, p2/m, z25.s, z26.s
	fadd	z23.s, p2/m, z23.s, #1.0
	fmul	z23.s, z23.s, z24.s
	st1w	{ z23.s }, p0, [x20, x8, lsl #2]
	add	x8, x8, x27
	cmp	x8, #2048
	b.lt	.LBB0_10
// %bb.11:
	mov	w0, #68                         // =0x44
	bl	malloc
	movi	d0, #0000000000000000
	ptrue	p2.s
	add	x9, x0, #63
	mov	x24, x0
	mov	x8, xzr
	and	x9, x9, #0xffffffffffffffc0
	mov	w10, #2048                      // =0x800
	str	wzr, [x9]
.LBB0_12:                               // =>This Inner Loop Header: Depth=1
	subs	x11, x10, x29
	csel	x10, x10, x29, lt
	whilelt	p0.h, xzr, x10
	add	x10, x20, x8, lsl #2
	punpkhi	p1.h, p0.b
	punpklo	p0.h, p0.b
	ld1w	{ z1.s }, p1/z, [x10, #1, mul vl]
	mov	x10, x11
	ld1w	{ z2.s }, p0/z, [x20, x8, lsl #2]
	add	x8, x8, x29
	cmp	x8, #2048
	fadd	z1.s, z2.s, z1.s
	faddv	s1, p2, z1.s
	fadd	s0, s0, s1
	b.lt	.LBB0_12
// %bb.13:
	str	s0, [x9]
	tbnz	w28, #0, .LBB0_16
// %bb.14:                              // %.lr.ph13.preheader
	ldr	w9, [sp, #12]                   // 4-byte Reload
	ldr	x10, [x21, #8]
	mov	z0.s, s0
	mov	x8, xzr
	mul	w9, w26, w9
	add	x9, x10, w9, sxtw #2
	mov	x10, x25
.LBB0_15:                               // %.lr.ph13
                                        // =>This Inner Loop Header: Depth=1
	subs	x11, x10, x27
	csel	x10, x27, x10, gt
	whilelt	p0.s, xzr, x10
	mov	x10, x11
	ld1w	{ z1.s }, p0/z, [x20, x8, lsl #2]
	fdiv	z1.s, p2/m, z1.s, z0.s
	st1w	{ z1.s }, p0, [x9, x8, lsl #2]
	add	x8, x8, x27
	cmp	x8, x25
	b.lt	.LBB0_15
.LBB0_16:                               // %._crit_edge14
	mov	x0, x19
	bl	free
	mov	x0, x22
	bl	free
	mov	x0, x23
	bl	free
	mov	x0, x24
	addvl	sp, sp, #1
	add	sp, sp, #16
	ldp	x20, x19, [sp, #80]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             // 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             // 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             // 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #96             // 16-byte Folded Reload
	b	free
.Lfunc_end0:
	.size	softmax_kernel, .Lfunc_end0-softmax_kernel
                                        // -- End function
	.section	".note.GNU-stack","",@progbits
