module attributes {llvm.target_triple = "aarch64"} {
  llvm.func @free(!llvm.ptr)
  llvm.func @malloc(i64) -> !llvm.ptr
  llvm.func @softmax_kernel(%arg0: i64, %arg1: !llvm.ptr, %arg2: i64, %arg3: !llvm.ptr, %arg4: i32 {tt.divisibility = 16 : i32}, %arg5: i32 {tt.divisibility = 16 : i32}, %arg6: i32 {tt.divisibility = 16 : i32}, %arg7: i32, %arg8: i32, %arg9: i32, %arg10: i32, %arg11: i32, %arg12: i32) {
    %0 = llvm.mlir.poison : !llvm.struct<(i64, ptr)>
    %1 = llvm.insertvalue %arg2, %0[0] : !llvm.struct<(i64, ptr)> 
    %2 = llvm.insertvalue %arg3, %1[1] : !llvm.struct<(i64, ptr)> 
    %3 = llvm.mlir.poison : !llvm.struct<(i64, ptr)>
    %4 = llvm.insertvalue %arg0, %3[0] : !llvm.struct<(i64, ptr)> 
    %5 = llvm.insertvalue %arg1, %4[1] : !llvm.struct<(i64, ptr)> 
    %6 = llvm.mlir.poison : vector<[4]xf32>
    %7 = llvm.mlir.constant(0 : i32) : i32
    %8 = llvm.mlir.poison : vector<1xf32>
    %9 = llvm.mlir.constant(8 : i32) : i32
    %10 = llvm.mlir.zero : i64
    %11 = llvm.mlir.constant(0 : index) : i64
    %12 = llvm.mlir.constant(2048 : index) : i64
    %13 = llvm.mlir.constant(dense<0xFF800000> : vector<2048xf32>) : vector<2048xf32>
    %14 = llvm.mlir.constant(4 : index) : i64
    %15 = llvm.mlir.constant(8 : index) : i64
    %16 = llvm.mlir.constant(dense<0.000000e+00> : vector<[8]xf32>) : vector<[8]xf32>
    %17 = llvm.mlir.constant(-1 : index) : i64
    %18 = llvm.mlir.constant(0xFF800000 : f32) : f32
    %19 = llvm.mlir.constant(0.000000e+00 : f32) : f32
    %20 = llvm.mlir.constant(dense<5.000000e-01> : vector<[4]xf32>) : vector<[4]xf32>
    %21 = llvm.mlir.constant(dense<1.000000e+00> : vector<[4]xf32>) : vector<[4]xf32>
    %22 = llvm.mlir.constant(dense<1.44269502> : vector<[4]xf32>) : vector<[4]xf32>
    %23 = llvm.mlir.constant(dense<-0.693359375> : vector<[4]xf32>) : vector<[4]xf32>
    %24 = llvm.mlir.constant(dense<2.12194442E-4> : vector<[4]xf32>) : vector<[4]xf32>
    %25 = llvm.mlir.constant(dense<1.98756912E-4> : vector<[4]xf32>) : vector<[4]xf32>
    %26 = llvm.mlir.constant(dense<0.00139819994> : vector<[4]xf32>) : vector<[4]xf32>
    %27 = llvm.mlir.constant(dense<0.00833345205> : vector<[4]xf32>) : vector<[4]xf32>
    %28 = llvm.mlir.constant(dense<0.0416657962> : vector<[4]xf32>) : vector<[4]xf32>
    %29 = llvm.mlir.constant(dense<0.166666657> : vector<[4]xf32>) : vector<[4]xf32>
    %30 = llvm.mlir.constant(dense<-8.780000e+01> : vector<[4]xf32>) : vector<[4]xf32>
    %31 = llvm.mlir.constant(dense<8.880000e+01> : vector<[4]xf32>) : vector<[4]xf32>
    %32 = llvm.mlir.constant(dense<-1.270000e+02> : vector<[4]xf32>) : vector<[4]xf32>
    %33 = llvm.mlir.constant(dense<1.270000e+02> : vector<[4]xf32>) : vector<[4]xf32>
    %34 = llvm.mlir.constant(dense<23> : vector<[4]xi32>) : vector<[4]xi32>
    %35 = llvm.mlir.constant(dense<127> : vector<[4]xi32>) : vector<[4]xi32>
    %36 = llvm.mlir.poison : vector<[4]xf32>
    %37 = llvm.mlir.poison : vector<1xf32>
    %38 = llvm.mlir.poison : vector<[8]xf32>
    %39 = llvm.mlir.poison : vector<1xf32>
    %40 = llvm.mul %arg10, %arg4 : i32
    %41 = llvm.sext %40 : i32 to i64
    %42 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %43 = llvm.extractvalue %2[1] : !llvm.struct<(i64, ptr)> 
    %44 = llvm.load %43 : !llvm.ptr -> !llvm.ptr
    %45 = llvm.getelementptr %43[1] : (!llvm.ptr) -> !llvm.ptr, !llvm.ptr
    %46 = llvm.load %45 : !llvm.ptr -> !llvm.ptr
    %47 = llvm.insertvalue %44, %42[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %48 = llvm.insertvalue %46, %47[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %49 = llvm.insertvalue %41, %48[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %50 = llvm.mlir.constant(2048 : index) : i64
    %51 = llvm.insertvalue %50, %49[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %52 = llvm.mlir.constant(1 : index) : i64
    %53 = llvm.insertvalue %52, %51[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %54 = llvm.sext %arg6 : i32 to i64
    %55 = llvm.intr.smin(%54, %12) : (i64, i64) -> i64
    %56 = llvm.intr.smax(%55, %11) : (i64, i64) -> i64
    %57 = llvm.mlir.constant(2048 : index) : i64
    %58 = llvm.mlir.constant(1 : index) : i64
    %59 = llvm.mlir.zero : !llvm.ptr
    %60 = llvm.getelementptr %59[2048] : (!llvm.ptr) -> !llvm.ptr, f32
    %61 = llvm.ptrtoint %60 : !llvm.ptr to i64
    %62 = llvm.call @malloc(%61) : (i64) -> !llvm.ptr
    %63 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %64 = llvm.insertvalue %62, %63[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %65 = llvm.insertvalue %62, %64[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %66 = llvm.mlir.constant(0 : index) : i64
    %67 = llvm.insertvalue %66, %65[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %68 = llvm.insertvalue %57, %67[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %69 = llvm.insertvalue %58, %68[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %70 = llvm.icmp "slt" %56, %12 : i64
    llvm.cond_br %70, ^bb1, ^bb2
  ^bb1:  // pred: ^bb0
    %71 = llvm.extractvalue %69[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %72 = llvm.getelementptr %71[%11] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    llvm.store %13, %72 {alignment = 4 : i64} : vector<2048xf32>, !llvm.ptr
    llvm.br ^bb2
  ^bb2:  // 2 preds: ^bb0, ^bb1
    %73 = "llvm.intr.vscale"() : () -> i64
    %74 = llvm.mul %73, %14 : i64
    llvm.br ^bb3(%11 : i64)
  ^bb3(%75: i64):  // 2 preds: ^bb2, ^bb4
    %76 = llvm.icmp "slt" %75, %56 : i64
    llvm.cond_br %76, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %77 = llvm.mul %75, %17 overflow<nsw> : i64
    %78 = llvm.add %56, %77 : i64
    %79 = llvm.intr.smin(%74, %78) : (i64, i64) -> i64
    %80 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64)>
    %81 = llvm.insertvalue %44, %80[0] : !llvm.struct<(ptr, ptr, i64)> 
    %82 = llvm.insertvalue %46, %81[1] : !llvm.struct<(ptr, ptr, i64)> 
    %83 = llvm.mlir.constant(0 : index) : i64
    %84 = llvm.insertvalue %83, %82[2] : !llvm.struct<(ptr, ptr, i64)> 
    %85 = llvm.add %41, %75 : i64
    %86 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %87 = llvm.insertvalue %44, %86[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %88 = llvm.insertvalue %46, %87[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %89 = llvm.insertvalue %85, %88[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %90 = llvm.insertvalue %79, %89[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %91 = llvm.mlir.constant(1 : index) : i64
    %92 = llvm.insertvalue %91, %90[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %93 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %94 = llvm.insertvalue %62, %93[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %95 = llvm.insertvalue %62, %94[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %96 = llvm.insertvalue %75, %95[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %97 = llvm.insertvalue %79, %96[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %98 = llvm.mlir.constant(1 : index) : i64
    %99 = llvm.insertvalue %98, %97[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %100 = "arm_sve.intr.whilelt"(%10, %79) : (i64, i64) -> vector<[4]xi1>
    %101 = llvm.extractvalue %92[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %102 = llvm.extractvalue %92[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %103 = llvm.getelementptr %101[%102] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %104 = llvm.getelementptr %103[%11] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %105 = llvm.intr.masked.load %104, %100, %36 {alignment = 4 : i32} : (!llvm.ptr, vector<[4]xi1>, vector<[4]xf32>) -> vector<[4]xf32>
    %106 = llvm.extractvalue %99[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %107 = llvm.extractvalue %99[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %108 = llvm.getelementptr %106[%107] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %109 = llvm.getelementptr %108[%11] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    llvm.intr.masked.store %105, %109, %100 {alignment = 4 : i32} : vector<[4]xf32>, vector<[4]xi1> into !llvm.ptr
    %110 = llvm.add %75, %74 : i64
    llvm.br ^bb3(%110 : i64)
  ^bb5:  // pred: ^bb3
    %111 = llvm.mlir.constant(1 : index) : i64
    %112 = llvm.mlir.zero : !llvm.ptr
    %113 = llvm.getelementptr %112[1] : (!llvm.ptr) -> !llvm.ptr, f32
    %114 = llvm.ptrtoint %113 : !llvm.ptr to i64
    %115 = llvm.mlir.constant(64 : index) : i64
    %116 = llvm.add %114, %115 : i64
    %117 = llvm.call @malloc(%116) : (i64) -> !llvm.ptr
    %118 = llvm.ptrtoint %117 : !llvm.ptr to i64
    %119 = llvm.mlir.constant(1 : index) : i64
    %120 = llvm.sub %115, %119 : i64
    %121 = llvm.add %118, %120 : i64
    %122 = llvm.urem %121, %115 : i64
    %123 = llvm.sub %121, %122 : i64
    %124 = llvm.inttoptr %123 : i64 to !llvm.ptr
    %125 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64)>
    %126 = llvm.insertvalue %117, %125[0] : !llvm.struct<(ptr, ptr, i64)> 
    %127 = llvm.insertvalue %124, %126[1] : !llvm.struct<(ptr, ptr, i64)> 
    %128 = llvm.mlir.constant(0 : index) : i64
    %129 = llvm.insertvalue %128, %127[2] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.store %18, %124 : f32, !llvm.ptr
    %130 = llvm.mul %73, %15 : i64
    %131 = llvm.extractvalue %129[1] : !llvm.struct<(ptr, ptr, i64)> 
    %132 = llvm.load %131 {alignment = 4 : i64} : !llvm.ptr -> vector<1xf32>
    %133 = llvm.extractelement %132[%10 : i64] : vector<1xf32>
    %134 = llvm.insertelement %133, %37[%10 : i64] : vector<1xf32>
    llvm.br ^bb6(%11, %134 : i64, vector<1xf32>)
  ^bb6(%135: i64, %136: vector<1xf32>):  // 2 preds: ^bb5, ^bb7
    %137 = llvm.icmp "slt" %135, %12 : i64
    llvm.cond_br %137, ^bb7, ^bb8
  ^bb7:  // pred: ^bb6
    %138 = llvm.mul %135, %17 overflow<nsw> : i64
    %139 = llvm.add %138, %12 : i64
    %140 = llvm.intr.smin(%139, %130) : (i64, i64) -> i64
    %141 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %142 = llvm.insertvalue %62, %141[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %143 = llvm.insertvalue %62, %142[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %144 = llvm.insertvalue %135, %143[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %145 = llvm.insertvalue %140, %144[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %146 = llvm.mlir.constant(1 : index) : i64
    %147 = llvm.insertvalue %146, %145[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %148 = "arm_sve.intr.whilelt"(%10, %140) : (i64, i64) -> vector<[8]xi1>
    %149 = llvm.extractvalue %147[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %150 = llvm.extractvalue %147[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %151 = llvm.getelementptr %149[%150] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %152 = llvm.getelementptr %151[%11] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %153 = llvm.intr.masked.load %152, %148, %38 {alignment = 4 : i32} : (!llvm.ptr, vector<[8]xi1>, vector<[8]xf32>) -> vector<[8]xf32>
    %154 = llvm.extractelement %136[%10 : i64] : vector<1xf32>
    %155 = "llvm.intr.vscale"() : () -> i64
    %156 = llvm.trunc %155 : i64 to i32
    %157 = llvm.mul %156, %9 : i32
    %158 = "llvm.intr.vp.reduce.fmax"(%154, %153, %148, %157) : (f32, vector<[8]xf32>, vector<[8]xi1>, i32) -> f32
    %159 = llvm.insertelement %158, %8[%7 : i32] : vector<1xf32>
    %160 = llvm.add %135, %130 : i64
    llvm.br ^bb6(%160, %159 : i64, vector<1xf32>)
  ^bb8:  // pred: ^bb6
    %161 = llvm.extractelement %136[%10 : i64] : vector<1xf32>
    %162 = llvm.insertelement %161, %39[%10 : i64] : vector<1xf32>
    %163 = llvm.extractvalue %129[1] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.store %162, %163 {alignment = 4 : i64} : vector<1xf32>, !llvm.ptr
    %164 = llvm.load %124 : !llvm.ptr -> f32
    %165 = llvm.mlir.constant(2048 : index) : i64
    %166 = llvm.mlir.constant(1 : index) : i64
    %167 = llvm.mlir.zero : !llvm.ptr
    %168 = llvm.getelementptr %167[2048] : (!llvm.ptr) -> !llvm.ptr, f32
    %169 = llvm.ptrtoint %168 : !llvm.ptr to i64
    %170 = llvm.mlir.constant(64 : index) : i64
    %171 = llvm.add %169, %170 : i64
    %172 = llvm.call @malloc(%171) : (i64) -> !llvm.ptr
    %173 = llvm.ptrtoint %172 : !llvm.ptr to i64
    %174 = llvm.mlir.constant(1 : index) : i64
    %175 = llvm.sub %170, %174 : i64
    %176 = llvm.add %173, %175 : i64
    %177 = llvm.urem %176, %170 : i64
    %178 = llvm.sub %176, %177 : i64
    %179 = llvm.inttoptr %178 : i64 to !llvm.ptr
    %180 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %181 = llvm.insertvalue %172, %180[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %182 = llvm.insertvalue %179, %181[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %183 = llvm.mlir.constant(0 : index) : i64
    %184 = llvm.insertvalue %183, %182[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %185 = llvm.insertvalue %165, %184[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %186 = llvm.insertvalue %166, %185[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %187 = llvm.insertelement %164, %6[%7 : i32] : vector<[4]xf32>
    %188 = llvm.shufflevector %187, %6 [0, 0, 0, 0] : vector<[4]xf32> 
    llvm.br ^bb9(%11 : i64)
  ^bb9(%189: i64):  // 2 preds: ^bb8, ^bb10
    %190 = llvm.icmp "slt" %189, %12 : i64
    llvm.cond_br %190, ^bb10, ^bb11
  ^bb10:  // pred: ^bb9
    %191 = llvm.mul %189, %17 overflow<nsw> : i64
    %192 = llvm.add %191, %12 : i64
    %193 = llvm.intr.smin(%192, %74) : (i64, i64) -> i64
    %194 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %195 = llvm.insertvalue %62, %194[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %196 = llvm.insertvalue %62, %195[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %197 = llvm.insertvalue %189, %196[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %198 = llvm.insertvalue %193, %197[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %199 = llvm.mlir.constant(1 : index) : i64
    %200 = llvm.insertvalue %199, %198[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %201 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %202 = llvm.insertvalue %172, %201[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %203 = llvm.insertvalue %179, %202[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %204 = llvm.insertvalue %189, %203[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %205 = llvm.insertvalue %193, %204[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %206 = llvm.mlir.constant(1 : index) : i64
    %207 = llvm.insertvalue %206, %205[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %208 = "arm_sve.intr.whilelt"(%10, %193) : (i64, i64) -> vector<[4]xi1>
    %209 = llvm.extractvalue %200[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %210 = llvm.extractvalue %200[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %211 = llvm.getelementptr %209[%210] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %212 = llvm.getelementptr %211[%11] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %213 = llvm.intr.masked.load %212, %208, %36 {alignment = 4 : i32} : (!llvm.ptr, vector<[4]xi1>, vector<[4]xf32>) -> vector<[4]xf32>
    %214 = llvm.fsub %213, %188 : vector<[4]xf32>
    %215 = llvm.fcmp "uge" %214, %30 : vector<[4]xf32>
    %216 = llvm.select %215, %214, %30 : vector<[4]xi1>, vector<[4]xf32>
    %217 = llvm.fcmp "ule" %216, %31 : vector<[4]xf32>
    %218 = llvm.select %217, %216, %31 : vector<[4]xi1>, vector<[4]xf32>
    %219 = llvm.intr.fma(%218, %22, %20) : (vector<[4]xf32>, vector<[4]xf32>, vector<[4]xf32>) -> vector<[4]xf32>
    %220 = llvm.intr.floor(%219) : (vector<[4]xf32>) -> vector<[4]xf32>
    %221 = llvm.fcmp "uge" %220, %32 : vector<[4]xf32>
    %222 = llvm.select %221, %220, %32 : vector<[4]xi1>, vector<[4]xf32>
    %223 = llvm.fcmp "ule" %222, %33 : vector<[4]xf32>
    %224 = llvm.select %223, %222, %33 : vector<[4]xi1>, vector<[4]xf32>
    %225 = llvm.intr.fma(%23, %224, %218) : (vector<[4]xf32>, vector<[4]xf32>, vector<[4]xf32>) -> vector<[4]xf32>
    %226 = llvm.intr.fma(%24, %224, %225) : (vector<[4]xf32>, vector<[4]xf32>, vector<[4]xf32>) -> vector<[4]xf32>
    %227 = llvm.intr.fma(%226, %25, %26) : (vector<[4]xf32>, vector<[4]xf32>, vector<[4]xf32>) -> vector<[4]xf32>
    %228 = llvm.intr.fma(%227, %226, %27) : (vector<[4]xf32>, vector<[4]xf32>, vector<[4]xf32>) -> vector<[4]xf32>
    %229 = llvm.intr.fma(%228, %226, %28) : (vector<[4]xf32>, vector<[4]xf32>, vector<[4]xf32>) -> vector<[4]xf32>
    %230 = llvm.intr.fma(%229, %226, %29) : (vector<[4]xf32>, vector<[4]xf32>, vector<[4]xf32>) -> vector<[4]xf32>
    %231 = llvm.intr.fma(%230, %226, %20) : (vector<[4]xf32>, vector<[4]xf32>, vector<[4]xf32>) -> vector<[4]xf32>
    %232 = llvm.fmul %226, %226 : vector<[4]xf32>
    %233 = llvm.intr.fma(%231, %232, %226) : (vector<[4]xf32>, vector<[4]xf32>, vector<[4]xf32>) -> vector<[4]xf32>
    %234 = llvm.fadd %233, %21 : vector<[4]xf32>
    %235 = llvm.fptosi %224 : vector<[4]xf32> to vector<[4]xi32>
    %236 = llvm.add %235, %35 : vector<[4]xi32>
    %237 = llvm.shl %236, %34 : vector<[4]xi32>
    %238 = llvm.bitcast %237 : vector<[4]xi32> to vector<[4]xf32>
    %239 = llvm.fmul %234, %238 : vector<[4]xf32>
    %240 = llvm.extractvalue %207[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %241 = llvm.extractvalue %207[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %242 = llvm.getelementptr %240[%241] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %243 = llvm.getelementptr %242[%11] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    llvm.intr.masked.store %239, %243, %208 {alignment = 4 : i32} : vector<[4]xf32>, vector<[4]xi1> into !llvm.ptr
    %244 = llvm.add %189, %74 : i64
    llvm.br ^bb9(%244 : i64)
  ^bb11:  // pred: ^bb9
    %245 = llvm.mlir.constant(1 : index) : i64
    %246 = llvm.mlir.zero : !llvm.ptr
    %247 = llvm.getelementptr %246[1] : (!llvm.ptr) -> !llvm.ptr, f32
    %248 = llvm.ptrtoint %247 : !llvm.ptr to i64
    %249 = llvm.mlir.constant(64 : index) : i64
    %250 = llvm.add %248, %249 : i64
    %251 = llvm.call @malloc(%250) : (i64) -> !llvm.ptr
    %252 = llvm.ptrtoint %251 : !llvm.ptr to i64
    %253 = llvm.mlir.constant(1 : index) : i64
    %254 = llvm.sub %249, %253 : i64
    %255 = llvm.add %252, %254 : i64
    %256 = llvm.urem %255, %249 : i64
    %257 = llvm.sub %255, %256 : i64
    %258 = llvm.inttoptr %257 : i64 to !llvm.ptr
    %259 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64)>
    %260 = llvm.insertvalue %251, %259[0] : !llvm.struct<(ptr, ptr, i64)> 
    %261 = llvm.insertvalue %258, %260[1] : !llvm.struct<(ptr, ptr, i64)> 
    %262 = llvm.mlir.constant(0 : index) : i64
    %263 = llvm.insertvalue %262, %261[2] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.store %19, %258 : f32, !llvm.ptr
    %264 = llvm.extractvalue %263[1] : !llvm.struct<(ptr, ptr, i64)> 
    %265 = llvm.load %264 {alignment = 4 : i64} : !llvm.ptr -> vector<1xf32>
    %266 = llvm.extractelement %265[%10 : i64] : vector<1xf32>
    %267 = llvm.insertelement %266, %37[%10 : i64] : vector<1xf32>
    llvm.br ^bb12(%11, %267 : i64, vector<1xf32>)
  ^bb12(%268: i64, %269: vector<1xf32>):  // 2 preds: ^bb11, ^bb13
    %270 = llvm.icmp "slt" %268, %12 : i64
    llvm.cond_br %270, ^bb13, ^bb14
  ^bb13:  // pred: ^bb12
    %271 = llvm.mul %268, %17 overflow<nsw> : i64
    %272 = llvm.add %271, %12 : i64
    %273 = llvm.intr.smin(%272, %130) : (i64, i64) -> i64
    %274 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %275 = llvm.insertvalue %172, %274[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %276 = llvm.insertvalue %179, %275[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %277 = llvm.insertvalue %268, %276[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %278 = llvm.insertvalue %273, %277[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %279 = llvm.mlir.constant(1 : index) : i64
    %280 = llvm.insertvalue %279, %278[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %281 = "arm_sve.intr.whilelt"(%10, %273) : (i64, i64) -> vector<[8]xi1>
    %282 = llvm.extractvalue %280[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %283 = llvm.extractvalue %280[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %284 = llvm.getelementptr %282[%283] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %285 = llvm.getelementptr %284[%11] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %286 = llvm.intr.masked.load %285, %281, %38 {alignment = 4 : i32} : (!llvm.ptr, vector<[8]xi1>, vector<[8]xf32>) -> vector<[8]xf32>
    %287 = llvm.extractelement %269[%10 : i64] : vector<1xf32>
    %288 = llvm.select %281, %286, %16 : vector<[8]xi1>, vector<[8]xf32>
    %289 = "llvm.intr.vector.reduce.fadd"(%287, %288) <{fastmathFlags = #llvm.fastmath<reassoc>}> : (f32, vector<[8]xf32>) -> f32
    %290 = llvm.insertelement %289, %8[%7 : i32] : vector<1xf32>
    %291 = llvm.add %268, %130 : i64
    llvm.br ^bb12(%291, %290 : i64, vector<1xf32>)
  ^bb14:  // pred: ^bb12
    %292 = llvm.extractelement %269[%10 : i64] : vector<1xf32>
    %293 = llvm.insertelement %292, %39[%10 : i64] : vector<1xf32>
    %294 = llvm.extractvalue %263[1] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.store %293, %294 {alignment = 4 : i64} : vector<1xf32>, !llvm.ptr
    %295 = llvm.load %258 : !llvm.ptr -> f32
    %296 = llvm.mul %arg10, %arg5 : i32
    %297 = llvm.sext %296 : i32 to i64
    %298 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %299 = llvm.extractvalue %5[1] : !llvm.struct<(i64, ptr)> 
    %300 = llvm.load %299 : !llvm.ptr -> !llvm.ptr
    %301 = llvm.getelementptr %299[1] : (!llvm.ptr) -> !llvm.ptr, !llvm.ptr
    %302 = llvm.load %301 : !llvm.ptr -> !llvm.ptr
    %303 = llvm.insertvalue %300, %298[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %304 = llvm.insertvalue %302, %303[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %305 = llvm.insertvalue %297, %304[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %306 = llvm.mlir.constant(2048 : index) : i64
    %307 = llvm.insertvalue %306, %305[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %308 = llvm.mlir.constant(1 : index) : i64
    %309 = llvm.insertvalue %308, %307[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %310 = llvm.insertelement %295, %6[%7 : i32] : vector<[4]xf32>
    %311 = llvm.shufflevector %310, %6 [0, 0, 0, 0] : vector<[4]xf32> 
    llvm.br ^bb15(%11 : i64)
  ^bb15(%312: i64):  // 2 preds: ^bb14, ^bb16
    %313 = llvm.icmp "slt" %312, %56 : i64
    llvm.cond_br %313, ^bb16, ^bb17
  ^bb16:  // pred: ^bb15
    %314 = llvm.mul %312, %17 overflow<nsw> : i64
    %315 = llvm.add %56, %314 : i64
    %316 = llvm.intr.smin(%74, %315) : (i64, i64) -> i64
    %317 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %318 = llvm.insertvalue %172, %317[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %319 = llvm.insertvalue %179, %318[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %320 = llvm.insertvalue %312, %319[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %321 = llvm.insertvalue %316, %320[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %322 = llvm.mlir.constant(1 : index) : i64
    %323 = llvm.insertvalue %322, %321[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %324 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64)>
    %325 = llvm.insertvalue %300, %324[0] : !llvm.struct<(ptr, ptr, i64)> 
    %326 = llvm.insertvalue %302, %325[1] : !llvm.struct<(ptr, ptr, i64)> 
    %327 = llvm.mlir.constant(0 : index) : i64
    %328 = llvm.insertvalue %327, %326[2] : !llvm.struct<(ptr, ptr, i64)> 
    %329 = llvm.add %297, %312 : i64
    %330 = llvm.mlir.poison : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %331 = llvm.insertvalue %300, %330[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %332 = llvm.insertvalue %302, %331[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %333 = llvm.insertvalue %329, %332[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %334 = llvm.insertvalue %316, %333[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %335 = llvm.mlir.constant(1 : index) : i64
    %336 = llvm.insertvalue %335, %334[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %337 = "arm_sve.intr.whilelt"(%10, %316) : (i64, i64) -> vector<[4]xi1>
    %338 = llvm.extractvalue %323[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %339 = llvm.extractvalue %323[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %340 = llvm.getelementptr %338[%339] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %341 = llvm.getelementptr %340[%11] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %342 = llvm.intr.masked.load %341, %337, %36 {alignment = 4 : i32} : (!llvm.ptr, vector<[4]xi1>, vector<[4]xf32>) -> vector<[4]xf32>
    %343 = llvm.fdiv %342, %311 : vector<[4]xf32>
    %344 = llvm.extractvalue %336[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %345 = llvm.extractvalue %336[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %346 = llvm.getelementptr %344[%345] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %347 = llvm.getelementptr %346[%11] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    llvm.intr.masked.store %343, %347, %337 {alignment = 4 : i32} : vector<[4]xf32>, vector<[4]xi1> into !llvm.ptr
    %348 = llvm.add %312, %74 : i64
    llvm.br ^bb15(%348 : i64)
  ^bb17:  // pred: ^bb15
    llvm.call @free(%62) : (!llvm.ptr) -> ()
    llvm.call @free(%117) : (!llvm.ptr) -> ()
    llvm.call @free(%172) : (!llvm.ptr) -> ()
    llvm.call @free(%251) : (!llvm.ptr) -> ()
    llvm.return
  }
}
