
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <chrono>
// From triton_test/utils/dsp/include
#include "common.h"
#include "prof.h"
#include "tensor.h"
// From triton_shared/backend/include
#include "ExecutionEngine/CRunnerUtils.h"
#include "ExecutionEngine/CRunnerUtils.cpp"

extern "C" void softmax_kernel(int64_t, MemRefDescriptor<float, 2> *, int64_t, MemRefDescriptor<float, 2> *, int, int, int,  int, int, int, int, int, int);
const int alignment = 128;



int main() {

Tensor<float, 2> t0({{64, 8192}, {8192, 1}, alignment}, MemType::HEAP);
MemRefDescriptor<float, 2> *dt0 = t0.toMemRefDesc(); 
Tensor<float, 2> t1({{64, 8192}, {8192, 1}, alignment}, MemType::HEAP);
MemRefDescriptor<float, 2> *dt1 = t1.toMemRefDesc(); 
int S0 = 8192; 
int S1 = 8192; 
int S2 = 8192; 


t0.load_from_file("/data/local/tmp/softmax_kernel/softmax_kernel_t0.raw");
t1.load_from_file("/data/local/tmp/softmax_kernel/softmax_kernel_t1.raw");


  int gridX = 64;
  int gridY = 1;
  int gridZ = 1;
  if (gridX * gridY * gridZ > 0) {
    
    auto start = std::chrono::high_resolution_clock::now();
    for(int b=0;b<20;++b) {

    for(int x = 0; x < gridX; x++) {
      for(int y = 0; y < gridY; y++) {
        for(int z = 0; z < gridZ; z++) {
          softmax_kernel(2, dt0, 2, dt1, S0, S1, S2, gridX, gridY, gridZ, x, y, z);
        }
      }
    }
    
    }
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> duration = end - start;
    FILE *bfile = fopen("/data/local/tmp/softmax_kernel/benchmark.log", "w"); // add error check here!
    fprintf(bfile, "Elapsed time: %.3f ms", duration.count());
    fclose(bfile);

  }
  

t0.dump_to_file("/data/local/tmp/softmax_kernel/softmax_kernel_o0.raw");
t1.dump_to_file("/data/local/tmp/softmax_kernel/softmax_kernel_o1.raw");

return 0;
}
