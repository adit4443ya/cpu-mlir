
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <chrono>
// From triton_test/utils/dsp/include
#include "common.h"
#include "prof.h"
#include "tensor.h"
// From triton_shared/backend/include
#include "ExecutionEngine/CRunnerUtils.h"
#include "ExecutionEngine/CRunnerUtils.cpp"

extern "C" void _mlir_ciface_Softmax(void *, MemRefDescriptor<float, 2> *);
const int alignment = 128;


struct FuncResult
{
	MemRefDescriptor<float,2> do0;
};


int main() {

Tensor<float, 2> t0({{64, 8192}, {8192, 1}, alignment}, MemType::HEAP);
MemRefDescriptor<float, 2> *dt0 = t0.toMemRefDesc(); 

FuncResult *r = new FuncResult;

t0.load_from_file("/data/local/tmp/Softmax/Softmax_t0.raw");


  int gridX = 1;
  int gridY = 1;
  int gridZ = 1;
  if (gridX * gridY * gridZ > 0) {
    
    auto start = std::chrono::high_resolution_clock::now();
    for(int b=0;b<20;++b) {

    for(int x = 0; x < gridX; x++) {
      for(int y = 0; y < gridY; y++) {
        for(int z = 0; z < gridZ; z++) {
          _mlir_ciface_Softmax(r, dt0);
        }
      }
    }
    
    }
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> duration = end - start;
    FILE *bfile = fopen("/data/local/tmp/Softmax/benchmark.log", "w"); // add error check here!
    fprintf(bfile, "Elapsed time: %.3f ms", duration.count());
    fclose(bfile);

  }
  


Tensor<float, 2> o0(r->do0, MemType::HEAP, alignment);
o0.dump_to_file("/data/local/tmp/Softmax/Softmax_o0.raw");

return 0;
}
