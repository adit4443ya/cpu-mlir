; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target triple = "aarch64"

declare void @free(ptr)

declare ptr @malloc(i64)

define void @softmax_kernel(i64 %0, ptr %1, i64 %2, ptr %3, i32 %4, i32 %5, i32 %6, i32 %7, i32 %8, i32 %9, i32 %10, i32 %11, i32 %12) {
  %14 = insertvalue { i64, ptr } poison, i64 %2, 0
  %15 = insertvalue { i64, ptr } %14, ptr %3, 1
  %16 = insertvalue { i64, ptr } poison, i64 %0, 0
  %17 = insertvalue { i64, ptr } %16, ptr %1, 1
  %18 = mul i32 %10, %4
  %19 = sext i32 %18 to i64
  %20 = extractvalue { i64, ptr } %15, 1
  %21 = load ptr, ptr %20, align 8
  %22 = getelementptr ptr, ptr %20, i32 1
  %23 = load ptr, ptr %22, align 8
  %24 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %21, 0
  %25 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %24, ptr %23, 1
  %26 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %25, i64 %19, 2
  %27 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %26, i64 8192, 3, 0
  %28 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %27, i64 1, 4, 0
  %29 = sext i32 %6 to i64
  %30 = call i64 @llvm.smin.i64(i64 %29, i64 8192)
  %31 = call i64 @llvm.smax.i64(i64 %30, i64 0)
  %32 = call ptr @malloc(i64 32768)
  %33 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %32, 0
  %34 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, ptr %32, 1
  %35 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %34, i64 0, 2
  %36 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %35, i64 8192, 3, 0
  %37 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %36, i64 1, 4, 0
  %38 = icmp slt i64 %31, 8192
  br i1 %38, label %39, label %42

39:                                               ; preds = %13
  %40 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %37, 1
  %41 = getelementptr float, ptr %40, i64 0
  store <8192 x float> splat (float -inf), ptr %41, align 4
  br label %42

42:                                               ; preds = %39, %13
  %43 = call i64 @llvm.vscale.i64()
  %44 = mul i64 %43, 4
  br label %45

45:                                               ; preds = %48, %42
  %46 = phi i64 [ %76, %48 ], [ 0, %42 ]
  %47 = icmp slt i64 %46, %31
  br i1 %47, label %48, label %77

48:                                               ; preds = %45
  %49 = mul nsw i64 %46, -1
  %50 = add i64 %31, %49
  %51 = call i64 @llvm.smin.i64(i64 %44, i64 %50)
  %52 = insertvalue { ptr, ptr, i64 } poison, ptr %21, 0
  %53 = insertvalue { ptr, ptr, i64 } %52, ptr %23, 1
  %54 = insertvalue { ptr, ptr, i64 } %53, i64 0, 2
  %55 = add i64 %19, %46
  %56 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %21, 0
  %57 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %56, ptr %23, 1
  %58 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %57, i64 %55, 2
  %59 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %58, i64 %51, 3, 0
  %60 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %59, i64 1, 4, 0
  %61 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %32, 0
  %62 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %61, ptr %32, 1
  %63 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %62, i64 %46, 2
  %64 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %63, i64 %51, 3, 0
  %65 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %64, i64 1, 4, 0
  %66 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %51)
  %67 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %60, 1
  %68 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %60, 2
  %69 = getelementptr float, ptr %67, i64 %68
  %70 = getelementptr float, ptr %69, i64 0
  %71 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %70, <vscale x 4 x i1> %66, <vscale x 4 x float> poison)
  %72 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %65, 1
  %73 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %65, 2
  %74 = getelementptr float, ptr %72, i64 %73
  %75 = getelementptr float, ptr %74, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %71, ptr align 4 %75, <vscale x 4 x i1> %66)
  %76 = add i64 %46, %44
  br label %45

77:                                               ; preds = %45
  %78 = call ptr @malloc(i64 68)
  %79 = ptrtoint ptr %78 to i64
  %80 = add i64 %79, 63
  %81 = urem i64 %80, 64
  %82 = sub i64 %80, %81
  %83 = inttoptr i64 %82 to ptr
  %84 = insertvalue { ptr, ptr, i64 } poison, ptr %78, 0
  %85 = insertvalue { ptr, ptr, i64 } %84, ptr %83, 1
  %86 = insertvalue { ptr, ptr, i64 } %85, i64 0, 2
  store float -inf, ptr %83, align 4
  %87 = mul i64 %43, 8
  %88 = extractvalue { ptr, ptr, i64 } %86, 1
  %89 = load <1 x float>, ptr %88, align 4
  %90 = extractelement <1 x float> %89, i64 0
  %91 = insertelement <1 x float> poison, float %90, i64 0
  br label %92

92:                                               ; preds = %96, %77
  %93 = phi i64 [ %117, %96 ], [ 0, %77 ]
  %94 = phi <1 x float> [ %116, %96 ], [ %91, %77 ]
  %95 = icmp slt i64 %93, 8192
  br i1 %95, label %96, label %118

96:                                               ; preds = %92
  %97 = mul nsw i64 %93, -1
  %98 = add i64 %97, 8192
  %99 = call i64 @llvm.smin.i64(i64 %98, i64 %87)
  %100 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %32, 0
  %101 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %100, ptr %32, 1
  %102 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %101, i64 %93, 2
  %103 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %102, i64 %99, 3, 0
  %104 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %103, i64 1, 4, 0
  %105 = call <vscale x 8 x i1> @llvm.aarch64.sve.whilelt.nxv8i1.i64(i64 0, i64 %99)
  %106 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %104, 1
  %107 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %104, 2
  %108 = getelementptr float, ptr %106, i64 %107
  %109 = getelementptr float, ptr %108, i64 0
  %110 = call <vscale x 8 x float> @llvm.masked.load.nxv8f32.p0(ptr align 4 %109, <vscale x 8 x i1> %105, <vscale x 8 x float> poison)
  %111 = extractelement <1 x float> %94, i64 0
  %112 = call i64 @llvm.vscale.i64()
  %113 = trunc i64 %112 to i32
  %114 = mul i32 %113, 8
  %115 = call float @llvm.vp.reduce.fmax.nxv8f32(float %111, <vscale x 8 x float> %110, <vscale x 8 x i1> %105, i32 %114)
  %116 = insertelement <1 x float> poison, float %115, i32 0
  %117 = add i64 %93, %87
  br label %92

118:                                              ; preds = %92
  %119 = extractelement <1 x float> %94, i64 0
  %120 = insertelement <1 x float> poison, float %119, i64 0
  %121 = extractvalue { ptr, ptr, i64 } %86, 1
  store <1 x float> %120, ptr %121, align 4
  %122 = load float, ptr %83, align 4
  %123 = call ptr @malloc(i64 32832)
  %124 = ptrtoint ptr %123 to i64
  %125 = add i64 %124, 63
  %126 = urem i64 %125, 64
  %127 = sub i64 %125, %126
  %128 = inttoptr i64 %127 to ptr
  %129 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %123, 0
  %130 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %129, ptr %128, 1
  %131 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %130, i64 0, 2
  %132 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %131, i64 8192, 3, 0
  %133 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %132, i64 1, 4, 0
  %134 = insertelement <vscale x 4 x float> poison, float %122, i32 0
  %135 = shufflevector <vscale x 4 x float> %134, <vscale x 4 x float> poison, <vscale x 4 x i32> zeroinitializer
  br label %136

136:                                              ; preds = %139, %118
  %137 = phi i64 [ %189, %139 ], [ 0, %118 ]
  %138 = icmp slt i64 %137, 8192
  br i1 %138, label %139, label %190

139:                                              ; preds = %136
  %140 = mul nsw i64 %137, -1
  %141 = add i64 %140, 8192
  %142 = call i64 @llvm.smin.i64(i64 %141, i64 %44)
  %143 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %32, 0
  %144 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %143, ptr %32, 1
  %145 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %144, i64 %137, 2
  %146 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %145, i64 %142, 3, 0
  %147 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %146, i64 1, 4, 0
  %148 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %123, 0
  %149 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %148, ptr %128, 1
  %150 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %149, i64 %137, 2
  %151 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %150, i64 %142, 3, 0
  %152 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %151, i64 1, 4, 0
  %153 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %142)
  %154 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %147, 1
  %155 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %147, 2
  %156 = getelementptr float, ptr %154, i64 %155
  %157 = getelementptr float, ptr %156, i64 0
  %158 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %157, <vscale x 4 x i1> %153, <vscale x 4 x float> poison)
  %159 = fsub <vscale x 4 x float> %158, %135
  %160 = fcmp uge <vscale x 4 x float> %159, splat (float -8.780000e+01)
  %161 = select <vscale x 4 x i1> %160, <vscale x 4 x float> %159, <vscale x 4 x float> splat (float -8.780000e+01)
  %162 = fcmp ule <vscale x 4 x float> %161, splat (float 8.880000e+01)
  %163 = select <vscale x 4 x i1> %162, <vscale x 4 x float> %161, <vscale x 4 x float> splat (float 8.880000e+01)
  %164 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %163, <vscale x 4 x float> splat (float f0x3FB8AA3B), <vscale x 4 x float> splat (float 5.000000e-01))
  %165 = call <vscale x 4 x float> @llvm.floor.nxv4f32(<vscale x 4 x float> %164)
  %166 = fcmp uge <vscale x 4 x float> %165, splat (float -1.270000e+02)
  %167 = select <vscale x 4 x i1> %166, <vscale x 4 x float> %165, <vscale x 4 x float> splat (float -1.270000e+02)
  %168 = fcmp ule <vscale x 4 x float> %167, splat (float 1.270000e+02)
  %169 = select <vscale x 4 x i1> %168, <vscale x 4 x float> %167, <vscale x 4 x float> splat (float 1.270000e+02)
  %170 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> splat (float f0xBF318000), <vscale x 4 x float> %169, <vscale x 4 x float> %163)
  %171 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> splat (float f0x395E8083), <vscale x 4 x float> %169, <vscale x 4 x float> %170)
  %172 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %171, <vscale x 4 x float> splat (float f0x39506967), <vscale x 4 x float> splat (float f0x3AB743CE))
  %173 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %172, <vscale x 4 x float> %171, <vscale x 4 x float> splat (float f0x3C088908))
  %174 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %173, <vscale x 4 x float> %171, <vscale x 4 x float> splat (float f0x3D2AA9C1))
  %175 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %174, <vscale x 4 x float> %171, <vscale x 4 x float> splat (float f0x3E2AAAAA))
  %176 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %175, <vscale x 4 x float> %171, <vscale x 4 x float> splat (float 5.000000e-01))
  %177 = fmul <vscale x 4 x float> %171, %171
  %178 = call <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float> %176, <vscale x 4 x float> %177, <vscale x 4 x float> %171)
  %179 = fadd <vscale x 4 x float> %178, splat (float 1.000000e+00)
  %180 = fptosi <vscale x 4 x float> %169 to <vscale x 4 x i32>
  %181 = add <vscale x 4 x i32> %180, splat (i32 127)
  %182 = shl <vscale x 4 x i32> %181, splat (i32 23)
  %183 = bitcast <vscale x 4 x i32> %182 to <vscale x 4 x float>
  %184 = fmul <vscale x 4 x float> %179, %183
  %185 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %152, 1
  %186 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %152, 2
  %187 = getelementptr float, ptr %185, i64 %186
  %188 = getelementptr float, ptr %187, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %184, ptr align 4 %188, <vscale x 4 x i1> %153)
  %189 = add i64 %137, %44
  br label %136

190:                                              ; preds = %136
  %191 = call ptr @malloc(i64 68)
  %192 = ptrtoint ptr %191 to i64
  %193 = add i64 %192, 63
  %194 = urem i64 %193, 64
  %195 = sub i64 %193, %194
  %196 = inttoptr i64 %195 to ptr
  %197 = insertvalue { ptr, ptr, i64 } poison, ptr %191, 0
  %198 = insertvalue { ptr, ptr, i64 } %197, ptr %196, 1
  %199 = insertvalue { ptr, ptr, i64 } %198, i64 0, 2
  store float 0.000000e+00, ptr %196, align 4
  %200 = extractvalue { ptr, ptr, i64 } %199, 1
  %201 = load <1 x float>, ptr %200, align 4
  %202 = extractelement <1 x float> %201, i64 0
  %203 = insertelement <1 x float> poison, float %202, i64 0
  %204 = mul i64 %43, 32
  br label %205

205:                                              ; preds = %308, %190
  %206 = phi i64 [ %310, %308 ], [ 0, %190 ]
  %207 = phi <1 x float> [ %232, %308 ], [ %203, %190 ]
  %208 = phi <1 x float> [ %257, %308 ], [ zeroinitializer, %190 ]
  %209 = phi <1 x float> [ %283, %308 ], [ zeroinitializer, %190 ]
  %210 = phi <1 x float> [ %309, %308 ], [ zeroinitializer, %190 ]
  %211 = icmp slt i64 %206, 8192
  br i1 %211, label %212, label %311

212:                                              ; preds = %205
  %213 = mul nsw i64 %206, -1
  %214 = add i64 %213, 8192
  %215 = call i64 @llvm.smin.i64(i64 %214, i64 %87)
  %216 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %123, 0
  %217 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %216, ptr %128, 1
  %218 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %217, i64 %206, 2
  %219 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %218, i64 %215, 3, 0
  %220 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %219, i64 1, 4, 0
  %221 = call <vscale x 8 x i1> @llvm.aarch64.sve.whilelt.nxv8i1.i64(i64 0, i64 %215)
  %222 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %220, 1
  %223 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %220, 2
  %224 = getelementptr float, ptr %222, i64 %223
  %225 = getelementptr float, ptr %224, i64 0
  %226 = call <vscale x 8 x float> @llvm.masked.load.nxv8f32.p0(ptr align 4 %225, <vscale x 8 x i1> %221, <vscale x 8 x float> poison)
  %227 = extractelement <1 x float> %207, i64 0
  %228 = call i64 @llvm.vscale.i64()
  %229 = trunc i64 %228 to i32
  %230 = mul i32 %229, 8
  %231 = call float @llvm.vp.reduce.fadd.nxv8f32(float %227, <vscale x 8 x float> %226, <vscale x 8 x i1> %221, i32 %230)
  %232 = insertelement <1 x float> poison, float %231, i32 0
  %233 = add i64 %206, %87
  %234 = icmp slt i64 %233, 8192
  br i1 %234, label %235, label %256

235:                                              ; preds = %212
  %236 = mul nsw i64 %233, -1
  %237 = add i64 %236, 8192
  %238 = call i64 @llvm.smin.i64(i64 %237, i64 %87)
  %239 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %123, 0
  %240 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %239, ptr %128, 1
  %241 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %240, i64 %233, 2
  %242 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %241, i64 %238, 3, 0
  %243 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %242, i64 1, 4, 0
  %244 = call <vscale x 8 x i1> @llvm.aarch64.sve.whilelt.nxv8i1.i64(i64 0, i64 %238)
  %245 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %243, 1
  %246 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %243, 2
  %247 = getelementptr float, ptr %245, i64 %246
  %248 = getelementptr float, ptr %247, i64 0
  %249 = call <vscale x 8 x float> @llvm.masked.load.nxv8f32.p0(ptr align 4 %248, <vscale x 8 x i1> %244, <vscale x 8 x float> poison)
  %250 = extractelement <1 x float> %208, i64 0
  %251 = call i64 @llvm.vscale.i64()
  %252 = trunc i64 %251 to i32
  %253 = mul i32 %252, 8
  %254 = call float @llvm.vp.reduce.fadd.nxv8f32(float %250, <vscale x 8 x float> %249, <vscale x 8 x i1> %244, i32 %253)
  %255 = insertelement <1 x float> poison, float %254, i32 0
  br label %256

256:                                              ; preds = %235, %212
  %257 = phi <1 x float> [ %255, %235 ], [ %208, %212 ]
  %258 = mul i64 %43, 16
  %259 = add i64 %206, %258
  %260 = icmp slt i64 %259, 8192
  br i1 %260, label %261, label %282

261:                                              ; preds = %256
  %262 = mul nsw i64 %259, -1
  %263 = add i64 %262, 8192
  %264 = call i64 @llvm.smin.i64(i64 %263, i64 %87)
  %265 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %123, 0
  %266 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %265, ptr %128, 1
  %267 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %266, i64 %259, 2
  %268 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %267, i64 %264, 3, 0
  %269 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %268, i64 1, 4, 0
  %270 = call <vscale x 8 x i1> @llvm.aarch64.sve.whilelt.nxv8i1.i64(i64 0, i64 %264)
  %271 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %269, 1
  %272 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %269, 2
  %273 = getelementptr float, ptr %271, i64 %272
  %274 = getelementptr float, ptr %273, i64 0
  %275 = call <vscale x 8 x float> @llvm.masked.load.nxv8f32.p0(ptr align 4 %274, <vscale x 8 x i1> %270, <vscale x 8 x float> poison)
  %276 = extractelement <1 x float> %209, i64 0
  %277 = call i64 @llvm.vscale.i64()
  %278 = trunc i64 %277 to i32
  %279 = mul i32 %278, 8
  %280 = call float @llvm.vp.reduce.fadd.nxv8f32(float %276, <vscale x 8 x float> %275, <vscale x 8 x i1> %270, i32 %279)
  %281 = insertelement <1 x float> poison, float %280, i32 0
  br label %282

282:                                              ; preds = %261, %256
  %283 = phi <1 x float> [ %281, %261 ], [ %209, %256 ]
  %284 = mul i64 %43, 24
  %285 = add i64 %206, %284
  %286 = icmp slt i64 %285, 8192
  br i1 %286, label %287, label %308

287:                                              ; preds = %282
  %288 = mul nsw i64 %285, -1
  %289 = add i64 %288, 8192
  %290 = call i64 @llvm.smin.i64(i64 %289, i64 %87)
  %291 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %123, 0
  %292 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %291, ptr %128, 1
  %293 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %292, i64 %285, 2
  %294 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %293, i64 %290, 3, 0
  %295 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %294, i64 1, 4, 0
  %296 = call <vscale x 8 x i1> @llvm.aarch64.sve.whilelt.nxv8i1.i64(i64 0, i64 %290)
  %297 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %295, 1
  %298 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %295, 2
  %299 = getelementptr float, ptr %297, i64 %298
  %300 = getelementptr float, ptr %299, i64 0
  %301 = call <vscale x 8 x float> @llvm.masked.load.nxv8f32.p0(ptr align 4 %300, <vscale x 8 x i1> %296, <vscale x 8 x float> poison)
  %302 = extractelement <1 x float> %210, i64 0
  %303 = call i64 @llvm.vscale.i64()
  %304 = trunc i64 %303 to i32
  %305 = mul i32 %304, 8
  %306 = call float @llvm.vp.reduce.fadd.nxv8f32(float %302, <vscale x 8 x float> %301, <vscale x 8 x i1> %296, i32 %305)
  %307 = insertelement <1 x float> poison, float %306, i32 0
  br label %308

308:                                              ; preds = %287, %282
  %309 = phi <1 x float> [ %307, %287 ], [ %210, %282 ]
  %310 = add i64 %206, %204
  br label %205

311:                                              ; preds = %205
  %312 = fadd reassoc <1 x float> %207, %208
  %313 = fadd reassoc <1 x float> %312, %209
  %314 = fadd reassoc <1 x float> %313, %210
  %315 = extractelement <1 x float> %314, i64 0
  %316 = insertelement <1 x float> poison, float %315, i64 0
  %317 = extractvalue { ptr, ptr, i64 } %199, 1
  store <1 x float> %316, ptr %317, align 4
  %318 = load float, ptr %196, align 4
  %319 = mul i32 %10, %5
  %320 = sext i32 %319 to i64
  %321 = extractvalue { i64, ptr } %17, 1
  %322 = load ptr, ptr %321, align 8
  %323 = getelementptr ptr, ptr %321, i32 1
  %324 = load ptr, ptr %323, align 8
  %325 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %322, 0
  %326 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %325, ptr %324, 1
  %327 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %326, i64 %320, 2
  %328 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %327, i64 8192, 3, 0
  %329 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %328, i64 1, 4, 0
  %330 = insertelement <vscale x 4 x float> poison, float %318, i32 0
  %331 = shufflevector <vscale x 4 x float> %330, <vscale x 4 x float> poison, <vscale x 4 x i32> zeroinitializer
  br label %332

332:                                              ; preds = %335, %311
  %333 = phi i64 [ %364, %335 ], [ 0, %311 ]
  %334 = icmp slt i64 %333, %31
  br i1 %334, label %335, label %365

335:                                              ; preds = %332
  %336 = mul nsw i64 %333, -1
  %337 = add i64 %31, %336
  %338 = call i64 @llvm.smin.i64(i64 %44, i64 %337)
  %339 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %123, 0
  %340 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %339, ptr %128, 1
  %341 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %340, i64 %333, 2
  %342 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %341, i64 %338, 3, 0
  %343 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %342, i64 1, 4, 0
  %344 = insertvalue { ptr, ptr, i64 } poison, ptr %322, 0
  %345 = insertvalue { ptr, ptr, i64 } %344, ptr %324, 1
  %346 = insertvalue { ptr, ptr, i64 } %345, i64 0, 2
  %347 = add i64 %320, %333
  %348 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %322, 0
  %349 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %348, ptr %324, 1
  %350 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %349, i64 %347, 2
  %351 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %350, i64 %338, 3, 0
  %352 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %351, i64 1, 4, 0
  %353 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %338)
  %354 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %343, 1
  %355 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %343, 2
  %356 = getelementptr float, ptr %354, i64 %355
  %357 = getelementptr float, ptr %356, i64 0
  %358 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %357, <vscale x 4 x i1> %353, <vscale x 4 x float> poison)
  %359 = fdiv <vscale x 4 x float> %358, %331
  %360 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %352, 1
  %361 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %352, 2
  %362 = getelementptr float, ptr %360, i64 %361
  %363 = getelementptr float, ptr %362, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %359, ptr align 4 %363, <vscale x 4 x i1> %353)
  %364 = add i64 %333, %44
  br label %332

365:                                              ; preds = %332
  call void @free(ptr %32)
  call void @free(ptr %78)
  call void @free(ptr %123)
  call void @free(ptr %191)
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smin.i64(i64, i64) #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smax.i64(i64, i64) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.vscale.i64() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64, i64) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr captures(none), <vscale x 4 x i1>, <vscale x 4 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float>, ptr captures(none), <vscale x 4 x i1>) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 8 x i1> @llvm.aarch64.sve.whilelt.nxv8i1.i64(i64, i64) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <vscale x 8 x float> @llvm.masked.load.nxv8f32.p0(ptr captures(none), <vscale x 8 x i1>, <vscale x 8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.vp.reduce.fadd.nxv8f32(float, <vscale x 8 x float>, <vscale x 8 x i1>, i32) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x float> @llvm.fma.nxv4f32(<vscale x 4 x float>, <vscale x 4 x float>, <vscale x 4 x float>) #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x float> @llvm.floor.nxv4f32(<vscale x 4 x float>) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.vp.reduce.fmax.nxv8f32(float, <vscale x 8 x float>, <vscale x 8 x i1>, i32) #1

attributes #0 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
