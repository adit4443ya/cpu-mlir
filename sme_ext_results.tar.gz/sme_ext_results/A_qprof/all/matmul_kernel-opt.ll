; ModuleID = '/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/A_qprof/all/matmul_kernel-llvm-ir.ll'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64"

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @free(ptr allocptr noundef captures(none)) local_unnamed_addr #0

declare void @memrefCopy(i64, ptr, ptr) local_unnamed_addr #1

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite, errnomem: write)
declare noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #2

define void @matmul_kernel(i64 %0, ptr nofree readonly captures(none) %1, i64 %2, ptr nofree readonly captures(none) %3, i64 %4, ptr nofree readonly captures(none) %5, i32 %6, i32 %7, i32 %8, i32 %9, i32 %10, i32 %11, i32 %12, i32 %13, i32 %14, i32 %15, i32 %16, i32 %17) local_unnamed_addr #1 {
  %19 = tail call dereferenceable_or_null(8256) ptr @malloc(i64 8256)
  %20 = ptrtoint ptr %19 to i64
  %21 = add i64 %20, 63
  %22 = and i64 %21, -64
  %23 = inttoptr i64 %22 to ptr
  %24 = tail call i64 @llvm.vscale.i64()
  %25 = shl i64 %24, 2
  %26 = sdiv i64 63, %25
  %27 = add nsw i64 %26, 1
  %28 = shl nsw i64 %27, 5
  %29 = icmp sgt i64 %26, -1
  br i1 %29, label %.lr.ph, label %._crit_edge

.lr.ph:                                           ; preds = %18, %.lr.ph
  %30 = phi i64 [ %39, %.lr.ph ], [ 0, %18 ]
  %.frozen = freeze i64 %30
  %.frozen57 = freeze i64 %27
  %31 = udiv i64 %.frozen, %.frozen57
  %32 = mul i64 %31, %.frozen57
  %.decomposed = sub i64 %.frozen, %32
  %33 = mul nsw i64 %.decomposed, %25
  %34 = sub i64 64, %33
  %35 = tail call i64 @llvm.smin.i64(i64 %34, i64 %25)
  %36 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %35)
  %.idx40 = shl i64 %31, 8
  %37 = getelementptr i8, ptr %23, i64 %.idx40
  %38 = getelementptr [4 x i8], ptr %37, i64 %33
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> zeroinitializer, ptr align 16 %38, <vscale x 4 x i1> %36)
  %39 = add nuw nsw i64 %30, 1
  %exitcond.not = icmp eq i64 %39, %28
  br i1 %exitcond.not, label %._crit_edge, label %.lr.ph

._crit_edge:                                      ; preds = %.lr.ph, %18
  %40 = add i32 %6, 31
  %41 = sdiv i32 %40, 32
  %42 = add i32 %7, 63
  %43 = sdiv i32 %42, 64
  %44 = shl nsw i32 %43, 3
  %.frozen58 = freeze i32 %15
  %.frozen59 = freeze i32 %44
  %45 = sdiv i32 %.frozen58, %.frozen59
  %46 = shl i32 %45, 3
  %47 = sub i32 %41, %46
  %48 = tail call i32 @llvm.smin.i32(i32 %47, i32 8)
  %49 = srem i32 %15, %48
  %50 = mul i32 %45, %.frozen59
  %.decomposed60 = sub i32 %.frozen58, %50
  %51 = sdiv i32 %.decomposed60, %48
  %52 = tail call dereferenceable_or_null(8256) ptr @malloc(i64 8256)
  %53 = ptrtoint ptr %52 to i64
  %54 = add i64 %53, 63
  %55 = and i64 %54, -64
  %56 = inttoptr i64 %55 to ptr
  %57 = sdiv i64 31, %25
  %58 = add nsw i64 %57, 1
  %59 = shl nsw i64 %58, 6
  %60 = icmp sgt i64 %57, -1
  br i1 %60, label %.lr.ph42, label %._crit_edge43

.lr.ph42:                                         ; preds = %._crit_edge
  %61 = shl nuw nsw i64 %58, 5
  %.rhs.trunc = trunc i64 %58 to i16
  br label %62

62:                                               ; preds = %.lr.ph42, %62
  %63 = phi i64 [ 0, %.lr.ph42 ], [ %79, %62 ]
  %.frozen61 = freeze i64 %63
  %.frozen62 = freeze i64 %61
  %64 = udiv i64 %.frozen61, %.frozen62
  %65 = mul i64 %64, %.frozen62
  %.decomposed63 = sub i64 %.frozen61, %65
  %.lhs.trunc = trunc i64 %.decomposed63 to i16
  %66 = udiv i16 %.lhs.trunc, %.rhs.trunc
  %.zext = zext i16 %66 to i64
  %67 = urem i64 %63, %58
  %68 = mul nsw i64 %67, %25
  %69 = sub i64 32, %68
  %70 = tail call i64 @llvm.smin.i64(i64 %69, i64 %25)
  %71 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %70)
  %.idx36 = shl nuw nsw i64 %.zext, 8
  %72 = getelementptr i8, ptr %23, i64 %.idx36
  %.idx37 = shl i64 %64, 7
  %73 = getelementptr i8, ptr %72, i64 %.idx37
  %74 = getelementptr [4 x i8], ptr %73, i64 %68
  %75 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 16 %74, <vscale x 4 x i1> %71, <vscale x 4 x float> poison)
  %.idx38 = shl i64 %64, 12
  %76 = getelementptr i8, ptr %56, i64 %.idx38
  %.idx39 = shl nuw nsw i64 %.zext, 7
  %77 = getelementptr i8, ptr %76, i64 %.idx39
  %78 = getelementptr [4 x i8], ptr %77, i64 %68
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %75, ptr align 16 %78, <vscale x 4 x i1> %71)
  %79 = add nuw nsw i64 %63, 1
  %exitcond49.not = icmp eq i64 %79, %59
  br i1 %exitcond49.not, label %._crit_edge43, label %62

._crit_edge43:                                    ; preds = %62, %._crit_edge
  %80 = tail call dereferenceable_or_null(2112) ptr @malloc(i64 2112)
  %81 = ptrtoint ptr %80 to i64
  %82 = add i64 %81, 63
  %83 = and i64 %82, -64
  %84 = inttoptr i64 %83 to ptr
  %85 = tail call dereferenceable_or_null(4160) ptr @malloc(i64 4160)
  %86 = ptrtoint ptr %85 to i64
  %87 = add i64 %86, 63
  %88 = and i64 %87, -64
  %89 = inttoptr i64 %88 to ptr
  %90 = tail call dereferenceable_or_null(2048) ptr @malloc(i64 2048)
  %91 = tail call dereferenceable_or_null(4096) ptr @malloc(i64 4096)
  tail call fastcc void @matmul_kernel_sme_0(i32 %51, i32 %7, ptr %3, i32 %10, i32 %9, i32 %6, ptr %1, i32 %8, ptr %90, ptr %91, ptr %84, ptr %89, ptr %56, i32 %45, i32 %49)
  %92 = tail call dereferenceable_or_null(8256) ptr @malloc(i64 8256)
  %93 = ptrtoint ptr %92 to i64
  %94 = add i64 %93, 63
  %95 = and i64 %94, -64
  %96 = inttoptr i64 %95 to ptr
  br i1 %60, label %.lr.ph45, label %.preheader

.lr.ph45:                                         ; preds = %._crit_edge43
  %97 = shl nuw nsw i64 %58, 1
  %.rhs.trunc55 = trunc i64 %58 to i8
  br label %98

.preheader:                                       ; preds = %98, %._crit_edge43
  br i1 %29, label %.lr.ph46, label %._crit_edge47

98:                                               ; preds = %.lr.ph45, %98
  %99 = phi i64 [ 0, %.lr.ph45 ], [ %115, %98 ]
  %.frozen64 = freeze i64 %99
  %.frozen65 = freeze i64 %97
  %100 = udiv i64 %.frozen64, %.frozen65
  %101 = mul i64 %100, %.frozen65
  %.decomposed66 = sub i64 %.frozen64, %101
  %.lhs.trunc54 = trunc i64 %.decomposed66 to i8
  %102 = udiv i8 %.lhs.trunc54, %.rhs.trunc55
  %.zext56 = zext i8 %102 to i64
  %103 = urem i64 %99, %58
  %104 = mul nsw i64 %103, %25
  %105 = sub i64 32, %104
  %106 = tail call i64 @llvm.smin.i64(i64 %105, i64 %25)
  %107 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %106)
  %.idx = shl nuw nsw i64 %.zext56, 12
  %108 = getelementptr i8, ptr %56, i64 %.idx
  %.idx33 = shl i64 %100, 7
  %109 = getelementptr i8, ptr %108, i64 %.idx33
  %110 = getelementptr [4 x i8], ptr %109, i64 %104
  %111 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 16 %110, <vscale x 4 x i1> %107, <vscale x 4 x float> poison)
  %.idx34 = shl i64 %100, 8
  %112 = getelementptr i8, ptr %96, i64 %.idx34
  %.idx35 = shl nuw nsw i64 %.zext56, 7
  %113 = getelementptr i8, ptr %112, i64 %.idx35
  %114 = getelementptr [4 x i8], ptr %113, i64 %104
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %111, ptr align 16 %114, <vscale x 4 x i1> %107)
  %115 = add nuw nsw i64 %99, 1
  %exitcond51.not = icmp eq i64 %115, %59
  br i1 %exitcond51.not, label %.preheader, label %98

.lr.ph46:                                         ; preds = %.preheader, %.lr.ph46
  %116 = phi i64 [ %128, %.lr.ph46 ], [ 0, %.preheader ]
  %.frozen67 = freeze i64 %116
  %.frozen68 = freeze i64 %27
  %117 = udiv i64 %.frozen67, %.frozen68
  %118 = mul i64 %117, %.frozen68
  %.decomposed69 = sub i64 %.frozen67, %118
  %119 = mul nsw i64 %.decomposed69, %25
  %120 = sub i64 64, %119
  %121 = tail call i64 @llvm.smin.i64(i64 %120, i64 %25)
  %122 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %121)
  %123 = shl nsw i64 %117, 6
  %124 = add i64 %123, %119
  %125 = getelementptr [4 x i8], ptr %96, i64 %124
  %126 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 16 %125, <vscale x 4 x i1> %122, <vscale x 4 x float> poison)
  %127 = getelementptr [4 x i8], ptr %23, i64 %124
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %126, ptr align 16 %127, <vscale x 4 x i1> %122)
  %128 = add nuw nsw i64 %116, 1
  %exitcond53.not = icmp eq i64 %128, %28
  br i1 %exitcond53.not, label %._crit_edge47, label %.lr.ph46

._crit_edge47:                                    ; preds = %.lr.ph46, %.preheader
  %129 = sext i32 %7 to i64
  %130 = sext i32 %6 to i64
  %131 = shl i32 %51, 6
  %132 = sext i32 %131 to i64
  %133 = add i32 %46, %49
  %134 = shl i32 %133, 5
  %135 = sext i32 %134 to i64
  %136 = sext i32 %11 to i64
  %137 = mul nsw i64 %135, %136
  %138 = add nsw i64 %137, %132
  %139 = add nsw i64 %135, 32
  %140 = tail call i64 @llvm.smin.i64(i64 %139, i64 %130)
  %141 = tail call i64 @llvm.smax.i64(i64 %140, i64 %135)
  %142 = sub nsw i64 %141, %135
  %143 = add nsw i64 %132, 64
  %144 = tail call i64 @llvm.smin.i64(i64 %143, i64 %129)
  %145 = tail call i64 @llvm.smax.i64(i64 %144, i64 %132)
  %146 = sub nsw i64 %145, %132
  %147 = tail call i64 @llvm.smin.i64(i64 %142, i64 32)
  %148 = tail call i64 @llvm.smin.i64(i64 %146, i64 64)
  %149 = load <2 x ptr>, ptr %5, align 8
  %150 = tail call ptr @llvm.stacksave.p0()
  %151 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, align 8
  store ptr %19, ptr %151, align 8
  %.repack6 = getelementptr inbounds nuw i8, ptr %151, i64 8
  store ptr %23, ptr %.repack6, align 8
  %.repack8 = getelementptr inbounds nuw i8, ptr %151, i64 16
  store i64 0, ptr %.repack8, align 8
  %.repack10 = getelementptr inbounds nuw i8, ptr %151, i64 24
  store i64 %147, ptr %.repack10, align 8
  %.repack10.repack14 = getelementptr inbounds nuw i8, ptr %151, i64 32
  store i64 %148, ptr %.repack10.repack14, align 8
  %.repack12 = getelementptr inbounds nuw i8, ptr %151, i64 40
  store <2 x i64> <i64 64, i64 1>, ptr %.repack12, align 8
  %152 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, align 16
  store <2 x ptr> %149, ptr %152, align 16
  %.repack19 = getelementptr inbounds nuw i8, ptr %152, i64 16
  store i64 %138, ptr %.repack19, align 16
  %.repack21 = getelementptr inbounds nuw i8, ptr %152, i64 24
  store i64 %147, ptr %.repack21, align 8
  %.repack21.repack25 = getelementptr inbounds nuw i8, ptr %152, i64 32
  store i64 %148, ptr %.repack21.repack25, align 16
  %.repack23 = getelementptr inbounds nuw i8, ptr %152, i64 40
  store i64 %136, ptr %.repack23, align 8
  %.repack23.repack27 = getelementptr inbounds nuw i8, ptr %152, i64 48
  store i64 1, ptr %.repack23.repack27, align 16
  %153 = alloca { i64, ptr }, align 8
  store i64 2, ptr %153, align 8
  %.repack29 = getelementptr inbounds nuw i8, ptr %153, i64 8
  store ptr %151, ptr %.repack29, align 8
  %154 = alloca { i64, ptr }, align 8
  store i64 2, ptr %154, align 8
  %.repack31 = getelementptr inbounds nuw i8, ptr %154, i64 8
  store ptr %152, ptr %.repack31, align 8
  call void @memrefCopy(i64 4, ptr nonnull %153, ptr nonnull %154)
  call void @llvm.stackrestore.p0(ptr %150)
  call void @free(ptr %19)
  call void @free(ptr %52)
  call void @free(ptr %80)
  call void @free(ptr %85)
  call void @free(ptr %90)
  call void @free(ptr %91)
  call void @free(ptr %92)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: readwrite)
define internal fastcc void @matmul_kernel_sme_0(i32 range(i32 -268435455, 268435456) %0, i32 %1, ptr nofree readonly captures(none) %2, i32 %3, i32 %4, i32 %5, ptr nofree readonly captures(none) %6, i32 %7, ptr nofree captures(none) %8, ptr nofree captures(none) %9, ptr nofree captures(none) %10, ptr nofree captures(none) %11, ptr %12, i32 %13, i32 range(i32 -2147483647, -2147483648) %14) unnamed_addr #3 {
  %16 = shl i32 %0, 6
  %17 = sext i32 %16 to i64
  %18 = sext i32 %1 to i64
  %19 = sext i32 %3 to i64
  %20 = sext i32 %4 to i64
  %21 = sext i32 %5 to i64
  %22 = mul nsw i64 %21, %20
  %23 = tail call i64 @llvm.vscale.i64()
  %24 = shl i64 %23, 2
  %25 = shl i64 %23, 3
  %26 = sdiv i64 31, %25
  %27 = add nsw i64 %26, 1
  %28 = mul nsw i64 %27, %27
  %29 = shl i32 %3, 4
  %30 = sext i32 %29 to i64
  %31 = add i32 %7, 15
  %32 = sdiv i32 %31, 16
  %33 = icmp sgt i32 %31, 15
  br i1 %33, label %.lr.ph50, label %._crit_edge51

.lr.ph50:                                         ; preds = %15
  %34 = shl i32 %14, 5
  %35 = shl i32 %13, 8
  %36 = add i32 %34, %35
  %37 = sext i32 %36 to i64
  %38 = mul nsw i64 %37, %20
  %39 = shl nuw nsw i64 %28, 1
  %40 = getelementptr i8, ptr %2, i64 8
  %41 = getelementptr i8, ptr %6, i64 8
  %42 = tail call i64 @llvm.smin.i64(i64 %24, i64 1)
  %43 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %42)
  %44 = icmp sgt i64 %24, 0
  %invariant.gep43 = getelementptr [4 x i8], ptr %12, i64 %24
  %.not = icmp eq i64 %27, 0
  %umax = tail call i64 @llvm.umax.i64(i64 %39, i64 1)
  br label %45

45:                                               ; preds = %.lr.ph50, %._crit_edge48
  %indvars.iv = phi i32 [ %7, %.lr.ph50 ], [ %indvars.iv.next, %._crit_edge48 ]
  %46 = phi i64 [ 0, %.lr.ph50 ], [ %398, %._crit_edge48 ]
  %47 = phi i64 [ %38, %.lr.ph50 ], [ %397, %._crit_edge48 ]
  %48 = phi i32 [ 0, %.lr.ph50 ], [ %399, %._crit_edge48 ]
  %smax59 = tail call i32 @llvm.smax.i32(i32 %indvars.iv, i32 0)
  %49 = tail call i32 @llvm.umin.i32(i32 %smax59, i32 16)
  %umin60 = zext nneg i32 %49 to i64
  %50 = add nsw i64 %46, %17
  %51 = srem i64 %50, %18
  %52 = sub i64 %50, %51
  %53 = add nsw i64 %51, 64
  %54 = tail call i64 @llvm.smin.i64(i64 %53, i64 %18)
  %55 = sub nsw i64 %54, %51
  %56 = sub nsw i64 0, %55
  %57 = load ptr, ptr %40, align 8
  %.neg = add nsw i64 %55, -64
  %58 = srem i64 %47, %20
  %59 = sub i64 %22, %47
  %60 = add i64 %59, %58
  %61 = sdiv i64 %60, %20
  %62 = tail call i64 @llvm.smin.i64(i64 %61, i64 32)
  %63 = load ptr, ptr %41, align 8
  %64 = sub i64 32, %62
  %65 = shl nuw nsw i32 %48, 4
  %66 = sub nsw i32 %7, %65
  %67 = tail call i32 @llvm.smax.i32(i32 %66, i32 0)
  %68 = tail call i32 @llvm.umin.i32(i32 %67, i32 16)
  %69 = zext nneg i32 %68 to i64
  %70 = icmp slt i32 %66, 16
  br i1 %70, label %.preheader11.preheader, label %.loopexit17

.preheader11.preheader:                           ; preds = %45
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(2048) %8, i8 0, i64 2048, i1 false)
  br label %.loopexit17

.loopexit17:                                      ; preds = %.preheader11.preheader, %45
  %71 = icmp slt i32 %66, 1
  %72 = sub nsw i64 0, %69
  %73 = add nsw i64 %69, -1
  %74 = select i1 %71, i64 %72, i64 %73
  %75 = sdiv i64 %74, %24
  %76 = sub nsw i64 0, %75
  %77 = add nsw i64 %75, 1
  %78 = select i1 %71, i64 %76, i64 %77
  %79 = mul nsw i64 %78, %62
  %80 = icmp sgt i64 %79, 0
  br i1 %80, label %.lr.ph, label %._crit_edge

.lr.ph:                                           ; preds = %.loopexit17
  %81 = icmp slt i64 %78, 0
  %82 = getelementptr [4 x i8], ptr %63, i64 %47
  br label %83

83:                                               ; preds = %.lr.ph, %83
  %84 = phi i64 [ 0, %.lr.ph ], [ %102, %83 ]
  %.frozen = freeze i64 %84
  %.frozen6 = freeze i64 %78
  %85 = sdiv i64 %.frozen, %.frozen6
  %86 = mul i64 %85, %78
  %87 = icmp ne i64 %84, %86
  %88 = and i1 %81, %87
  %89 = sext i1 %88 to i64
  %90 = add i64 %85, %89
  %91 = mul i64 %85, %.frozen6
  %.decomposed = sub i64 %.frozen, %91
  %92 = mul nsw i64 %.decomposed, %24
  %93 = sub i64 %69, %92
  %94 = tail call i64 @llvm.smin.i64(i64 %93, i64 %24)
  %95 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %94)
  %96 = mul nsw i64 %90, %20
  %97 = getelementptr [4 x i8], ptr %82, i64 %96
  %98 = getelementptr [4 x i8], ptr %97, i64 %92
  %99 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %98, <vscale x 4 x i1> %95, <vscale x 4 x float> poison)
  %.idx30 = shl i64 %90, 6
  %100 = getelementptr i8, ptr %8, i64 %.idx30
  %101 = getelementptr [4 x i8], ptr %100, i64 %92
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %99, ptr align 4 %101, <vscale x 4 x i1> %95)
  %102 = add nuw nsw i64 %84, 1
  %exitcond.not = icmp eq i64 %102, %79
  br i1 %exitcond.not, label %._crit_edge, label %83

._crit_edge:                                      ; preds = %83, %.loopexit17
  %103 = mul nsw i64 %78, %64
  %104 = icmp sgt i64 %103, 0
  br i1 %104, label %.lr.ph21, label %._crit_edge22

.lr.ph21:                                         ; preds = %._crit_edge
  %105 = icmp slt i64 %78, 0
  %106 = getelementptr [4 x i8], ptr %63, i64 %58
  br label %107

107:                                              ; preds = %.lr.ph21, %107
  %108 = phi i64 [ 0, %.lr.ph21 ], [ %127, %107 ]
  %.frozen7 = freeze i64 %108
  %.frozen8 = freeze i64 %78
  %109 = sdiv i64 %.frozen7, %.frozen8
  %110 = mul i64 %109, %78
  %111 = icmp ne i64 %108, %110
  %112 = and i1 %105, %111
  %113 = sext i1 %112 to i64
  %114 = add i64 %109, %113
  %115 = mul i64 %109, %.frozen8
  %.decomposed9 = sub i64 %.frozen7, %115
  %116 = mul nsw i64 %.decomposed9, %24
  %117 = sub i64 %69, %116
  %118 = tail call i64 @llvm.smin.i64(i64 %117, i64 %24)
  %119 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %118)
  %120 = mul nsw i64 %114, %20
  %121 = getelementptr [4 x i8], ptr %106, i64 %120
  %122 = getelementptr [4 x i8], ptr %121, i64 %116
  %123 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %122, <vscale x 4 x i1> %119, <vscale x 4 x float> poison)
  %124 = add i64 %114, %62
  %.idx29 = shl i64 %124, 6
  %125 = getelementptr i8, ptr %8, i64 %.idx29
  %126 = getelementptr [4 x i8], ptr %125, i64 %116
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %123, ptr align 4 %126, <vscale x 4 x i1> %119)
  %127 = add nuw nsw i64 %108, 1
  %exitcond57.not = icmp eq i64 %127, %103
  br i1 %exitcond57.not, label %._crit_edge22, label %107

._crit_edge22:                                    ; preds = %107, %._crit_edge
  br i1 %70, label %.preheader10.preheader, label %.loopexit

.preheader10.preheader:                           ; preds = %._crit_edge22
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(4096) %9, i8 0, i64 4096, i1 false)
  br label %.loopexit

.loopexit:                                        ; preds = %.preheader10.preheader, %._crit_edge22
  %128 = icmp slt i64 %55, 1
  %129 = add nsw i64 %55, -1
  %130 = select i1 %128, i64 %56, i64 %129
  %131 = sdiv i64 %130, %24
  %132 = sub nsw i64 0, %131
  %133 = add nsw i64 %131, 1
  %134 = select i1 %128, i64 %132, i64 %133
  %135 = mul nsw i64 %134, %69
  %136 = icmp sgt i64 %135, 0
  br i1 %136, label %.lr.ph24, label %._crit_edge25

.lr.ph24:                                         ; preds = %.loopexit
  %137 = icmp slt i64 %134, 0
  %138 = getelementptr [4 x i8], ptr %57, i64 %50
  %139 = mul nsw i64 %134, %umin60
  br label %140

140:                                              ; preds = %.lr.ph24, %140
  %141 = phi i64 [ 0, %.lr.ph24 ], [ %159, %140 ]
  %.frozen10 = freeze i64 %141
  %.frozen11 = freeze i64 %134
  %142 = sdiv i64 %.frozen10, %.frozen11
  %143 = mul i64 %142, %134
  %144 = icmp ne i64 %141, %143
  %145 = and i1 %137, %144
  %146 = sext i1 %145 to i64
  %147 = add i64 %142, %146
  %148 = mul i64 %142, %.frozen11
  %.decomposed12 = sub i64 %.frozen10, %148
  %149 = mul nsw i64 %.decomposed12, %24
  %150 = sub i64 %55, %149
  %151 = tail call i64 @llvm.smin.i64(i64 %150, i64 %24)
  %152 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %151)
  %153 = mul nsw i64 %147, %19
  %154 = getelementptr [4 x i8], ptr %138, i64 %153
  %155 = getelementptr [4 x i8], ptr %154, i64 %149
  %156 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %155, <vscale x 4 x i1> %152, <vscale x 4 x float> poison)
  %.idx27 = shl i64 %147, 8
  %157 = getelementptr i8, ptr %9, i64 %.idx27
  %158 = getelementptr [4 x i8], ptr %157, i64 %149
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %156, ptr align 4 %158, <vscale x 4 x i1> %152)
  %159 = add nuw nsw i64 %141, 1
  %exitcond58.not = icmp eq i64 %159, %139
  br i1 %exitcond58.not, label %._crit_edge25, label %140

._crit_edge25:                                    ; preds = %140, %.loopexit
  %160 = icmp sgt i64 %55, 63
  %161 = sub nsw i64 63, %55
  %162 = select i1 %160, i64 %.neg, i64 %161
  %163 = sdiv i64 %162, %24
  %164 = sub nsw i64 0, %163
  %165 = add nsw i64 %163, 1
  %166 = select i1 %160, i64 %164, i64 %165
  %167 = mul nsw i64 %166, %69
  %168 = icmp sgt i64 %167, 0
  br i1 %168, label %.lr.ph27, label %.preheader14.preheader

.lr.ph27:                                         ; preds = %._crit_edge25
  %169 = icmp slt i64 %166, 0
  %170 = getelementptr [4 x i8], ptr %57, i64 %52
  %171 = getelementptr [4 x i8], ptr %9, i64 %55
  %172 = mul nsw i64 %166, %umin60
  br label %173

173:                                              ; preds = %.lr.ph27, %173
  %174 = phi i64 [ 0, %.lr.ph27 ], [ %193, %173 ]
  %.frozen13 = freeze i64 %174
  %.frozen14 = freeze i64 %166
  %175 = sdiv i64 %.frozen13, %.frozen14
  %176 = mul i64 %175, %166
  %177 = icmp ne i64 %174, %176
  %178 = and i1 %169, %177
  %179 = sext i1 %178 to i64
  %180 = add i64 %175, %179
  %181 = mul i64 %175, %.frozen14
  %.decomposed15 = sub i64 %.frozen13, %181
  %182 = mul nsw i64 %.decomposed15, %24
  %183 = add i64 %55, %182
  %184 = sub i64 64, %183
  %185 = tail call i64 @llvm.smin.i64(i64 %184, i64 %24)
  %186 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %185)
  %187 = mul nsw i64 %180, %19
  %188 = getelementptr [4 x i8], ptr %170, i64 %187
  %189 = getelementptr [4 x i8], ptr %188, i64 %182
  %190 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %189, <vscale x 4 x i1> %186, <vscale x 4 x float> poison)
  %.idx26 = shl i64 %180, 8
  %191 = getelementptr i8, ptr %171, i64 %.idx26
  %192 = getelementptr [4 x i8], ptr %191, i64 %182
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %190, ptr align 4 %192, <vscale x 4 x i1> %186)
  %193 = add nuw nsw i64 %174, 1
  %exitcond61.not = icmp eq i64 %193, %172
  br i1 %exitcond61.not, label %.preheader14.preheader, label %173

.preheader14.preheader:                           ; preds = %173, %._crit_edge25
  br label %.preheader14

.preheader14:                                     ; preds = %.preheader14.preheader, %.preheader14
  %194 = phi i64 [ %201, %.preheader14 ], [ 0, %.preheader14.preheader ]
  %195 = lshr i64 %194, 5
  %196 = shl nuw nsw i64 %194, 6
  %.idx25 = and i64 %196, 1984
  %197 = getelementptr i8, ptr %8, i64 %.idx25
  %198 = getelementptr [4 x i8], ptr %197, i64 %195
  %199 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %198, <vscale x 4 x i1> %43, <vscale x 4 x float> poison)
  %200 = getelementptr [4 x i8], ptr %10, i64 %194
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %199, ptr align 4 %200, <vscale x 4 x i1> %43)
  %201 = add nuw nsw i64 %194, 1
  %exitcond62.not = icmp eq i64 %201, 512
  br i1 %exitcond62.not, label %.preheader13, label %.preheader14

.preheader12:                                     ; preds = %._crit_edge32
  br i1 %.not, label %._crit_edge48, label %.lr.ph47

.preheader13:                                     ; preds = %.preheader14, %._crit_edge32
  %202 = phi i64 [ %223, %._crit_edge32 ], [ 0, %.preheader14 ]
  %203 = lshr i64 %202, 5
  %204 = and i64 %203, 15
  %205 = and i64 %202, 31
  br i1 %44, label %.lr.ph31, label %._crit_edge32

.lr.ph31:                                         ; preds = %.preheader13
  %206 = lshr i64 %202, 4
  %207 = and i64 %206, 32
  %invariant.gep = getelementptr [4 x i8], ptr %9, i64 %207
  %invariant.gep28 = getelementptr [4 x i8], ptr %invariant.gep, i64 %205
  %.idx23 = shl nuw nsw i64 %204, 8
  %gep29 = getelementptr i8, ptr %invariant.gep28, i64 %.idx23
  br label %208

208:                                              ; preds = %.lr.ph31, %216
  %209 = phi <vscale x 4 x float> [ poison, %.lr.ph31 ], [ %217, %216 ]
  %210 = phi i64 [ 0, %.lr.ph31 ], [ %218, %216 ]
  %211 = extractelement <vscale x 4 x i1> %43, i64 %210
  br i1 %211, label %212, label %216

212:                                              ; preds = %208
  %.idx24 = shl nuw nsw i64 %210, 8
  %213 = getelementptr inbounds nuw i8, ptr %gep29, i64 %.idx24
  %214 = load float, ptr %213, align 4
  %215 = insertelement <vscale x 4 x float> %209, float %214, i64 %210
  br label %216

216:                                              ; preds = %212, %208
  %217 = phi <vscale x 4 x float> [ %215, %212 ], [ %209, %208 ]
  %218 = add nuw nsw i64 %210, 1
  %exitcond63.not = icmp eq i64 %218, %24
  br i1 %exitcond63.not, label %._crit_edge32, label %208

._crit_edge32:                                    ; preds = %216, %.preheader13
  %.lcssa = phi <vscale x 4 x float> [ poison, %.preheader13 ], [ %217, %216 ]
  %219 = and i64 %202, 512
  %220 = getelementptr [4 x i8], ptr %11, i64 %219
  %.idx22 = shl nuw nsw i64 %204, 7
  %221 = getelementptr i8, ptr %220, i64 %.idx22
  %222 = getelementptr [4 x i8], ptr %221, i64 %205
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %.lcssa, ptr align 4 %222, <vscale x 4 x i1> %43)
  %223 = add nuw nsw i64 %202, 1
  %exitcond64.not = icmp eq i64 %223, 1024
  br i1 %exitcond64.not, label %.preheader12, label %.preheader13

.lr.ph47:                                         ; preds = %.preheader12, %._crit_edge42
  %224 = phi i64 [ %396, %._crit_edge42 ], [ 0, %.preheader12 ]
  %.frozen16 = freeze i64 %224
  %.frozen17 = freeze i64 %28
  %225 = udiv i64 %.frozen16, %.frozen17
  %226 = mul i64 %225, %.frozen17
  %.decomposed18 = sub i64 %.frozen16, %226
  %227 = sdiv i64 %.decomposed18, %27
  %228 = srem i64 %224, %27
  %229 = mul nsw i64 %228, %25
  %230 = mul nsw i64 %227, %25
  %231 = shl nsw i64 %225, 10
  %232 = shl nsw i64 %230, 5
  %233 = add i64 %232, %231
  %234 = add i64 %233, %229
  br i1 %44, label %.lr.ph34, label %.preheader6

.lr.ph34:                                         ; preds = %.lr.ph47
  %235 = getelementptr [4 x i8], ptr %12, i64 %234
  br label %236

.lr.ph35:                                         ; preds = %236
  %gep44 = getelementptr [4 x i8], ptr %invariant.gep43, i64 %234
  br label %242

236:                                              ; preds = %.lr.ph34, %236
  %237 = phi i64 [ 0, %.lr.ph34 ], [ %240, %236 ]
  %.idx21 = shl i64 %237, 7
  %238 = getelementptr i8, ptr %235, i64 %.idx21
  %239 = trunc i64 %237 to i32
  tail call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %238, i32 0, i32 %239)
  %240 = add nuw nsw i64 %237, 1
  %exitcond65.not = icmp eq i64 %240, %24
  br i1 %exitcond65.not, label %.lr.ph35, label %236

.lr.ph37:                                         ; preds = %242
  %241 = getelementptr [4 x i8], ptr %12, i64 %234
  br label %246

242:                                              ; preds = %.lr.ph35, %242
  %243 = phi i64 [ 0, %.lr.ph35 ], [ %245, %242 ]
  %.idx20 = shl i64 %243, 7
  %gep = getelementptr i8, ptr %gep44, i64 %.idx20
  %244 = trunc i64 %243 to i32
  tail call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %gep, i32 1, i32 %244)
  %245 = add nuw nsw i64 %243, 1
  %exitcond66.not = icmp eq i64 %245, %24
  br i1 %exitcond66.not, label %.lr.ph37, label %242

.lr.ph38:                                         ; preds = %246
  %gep46 = getelementptr [4 x i8], ptr %invariant.gep43, i64 %234
  br label %381

246:                                              ; preds = %.lr.ph37, %246
  %247 = phi i64 [ 0, %.lr.ph37 ], [ %251, %246 ]
  %248 = add nuw i64 %247, %24
  %.idx19 = shl i64 %248, 7
  %249 = getelementptr i8, ptr %241, i64 %.idx19
  %250 = trunc i64 %247 to i32
  tail call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %249, i32 2, i32 %250)
  %251 = add nuw nsw i64 %247, 1
  %exitcond67.not = icmp eq i64 %251, %24
  br i1 %exitcond67.not, label %.lr.ph38, label %246

.preheader6:                                      ; preds = %381, %.lr.ph47
  %252 = getelementptr [4 x i8], ptr %10, i64 %230
  %.idx = shl i64 %225, 11
  %253 = getelementptr i8, ptr %11, i64 %.idx
  %254 = getelementptr [4 x i8], ptr %253, i64 %229
  %255 = load <vscale x 8 x float>, ptr %252, align 4
  %256 = load <vscale x 8 x float>, ptr %254, align 4
  %257 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %255, i64 0)
  %258 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %256, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %257, <vscale x 4 x float> %258)
  %259 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %256, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %257, <vscale x 4 x float> %259)
  %260 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %255, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %260, <vscale x 4 x float> %258)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %260, <vscale x 4 x float> %259)
  %261 = getelementptr i8, ptr %252, i64 128
  %262 = load <vscale x 8 x float>, ptr %261, align 4
  %263 = getelementptr i8, ptr %254, i64 128
  %264 = load <vscale x 8 x float>, ptr %263, align 4
  %265 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %262, i64 0)
  %266 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %264, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %265, <vscale x 4 x float> %266)
  %267 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %264, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %265, <vscale x 4 x float> %267)
  %268 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %262, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %268, <vscale x 4 x float> %266)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %268, <vscale x 4 x float> %267)
  %269 = getelementptr i8, ptr %252, i64 256
  %270 = load <vscale x 8 x float>, ptr %269, align 4
  %271 = getelementptr i8, ptr %254, i64 256
  %272 = load <vscale x 8 x float>, ptr %271, align 4
  %273 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %270, i64 0)
  %274 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %272, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %273, <vscale x 4 x float> %274)
  %275 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %272, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %273, <vscale x 4 x float> %275)
  %276 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %270, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %276, <vscale x 4 x float> %274)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %276, <vscale x 4 x float> %275)
  %277 = getelementptr i8, ptr %252, i64 384
  %278 = load <vscale x 8 x float>, ptr %277, align 4
  %279 = getelementptr i8, ptr %254, i64 384
  %280 = load <vscale x 8 x float>, ptr %279, align 4
  %281 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %278, i64 0)
  %282 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %280, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %281, <vscale x 4 x float> %282)
  %283 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %280, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %281, <vscale x 4 x float> %283)
  %284 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %278, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %284, <vscale x 4 x float> %282)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %284, <vscale x 4 x float> %283)
  %285 = getelementptr i8, ptr %252, i64 512
  %286 = load <vscale x 8 x float>, ptr %285, align 4
  %287 = getelementptr i8, ptr %254, i64 512
  %288 = load <vscale x 8 x float>, ptr %287, align 4
  %289 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %286, i64 0)
  %290 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %288, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %289, <vscale x 4 x float> %290)
  %291 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %288, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %289, <vscale x 4 x float> %291)
  %292 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %286, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %292, <vscale x 4 x float> %290)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %292, <vscale x 4 x float> %291)
  %293 = getelementptr i8, ptr %252, i64 640
  %294 = load <vscale x 8 x float>, ptr %293, align 4
  %295 = getelementptr i8, ptr %254, i64 640
  %296 = load <vscale x 8 x float>, ptr %295, align 4
  %297 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %294, i64 0)
  %298 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %296, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %297, <vscale x 4 x float> %298)
  %299 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %296, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %297, <vscale x 4 x float> %299)
  %300 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %294, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %300, <vscale x 4 x float> %298)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %300, <vscale x 4 x float> %299)
  %301 = getelementptr i8, ptr %252, i64 768
  %302 = load <vscale x 8 x float>, ptr %301, align 4
  %303 = getelementptr i8, ptr %254, i64 768
  %304 = load <vscale x 8 x float>, ptr %303, align 4
  %305 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %302, i64 0)
  %306 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %304, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %305, <vscale x 4 x float> %306)
  %307 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %304, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %305, <vscale x 4 x float> %307)
  %308 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %302, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %308, <vscale x 4 x float> %306)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %308, <vscale x 4 x float> %307)
  %309 = getelementptr i8, ptr %252, i64 896
  %310 = load <vscale x 8 x float>, ptr %309, align 4
  %311 = getelementptr i8, ptr %254, i64 896
  %312 = load <vscale x 8 x float>, ptr %311, align 4
  %313 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %310, i64 0)
  %314 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %312, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %313, <vscale x 4 x float> %314)
  %315 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %312, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %313, <vscale x 4 x float> %315)
  %316 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %310, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %316, <vscale x 4 x float> %314)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %316, <vscale x 4 x float> %315)
  %317 = getelementptr i8, ptr %252, i64 1024
  %318 = load <vscale x 8 x float>, ptr %317, align 4
  %319 = getelementptr i8, ptr %254, i64 1024
  %320 = load <vscale x 8 x float>, ptr %319, align 4
  %321 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %318, i64 0)
  %322 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %320, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %321, <vscale x 4 x float> %322)
  %323 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %320, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %321, <vscale x 4 x float> %323)
  %324 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %318, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %324, <vscale x 4 x float> %322)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %324, <vscale x 4 x float> %323)
  %325 = getelementptr i8, ptr %252, i64 1152
  %326 = load <vscale x 8 x float>, ptr %325, align 4
  %327 = getelementptr i8, ptr %254, i64 1152
  %328 = load <vscale x 8 x float>, ptr %327, align 4
  %329 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %326, i64 0)
  %330 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %328, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %329, <vscale x 4 x float> %330)
  %331 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %328, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %329, <vscale x 4 x float> %331)
  %332 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %326, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %332, <vscale x 4 x float> %330)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %332, <vscale x 4 x float> %331)
  %333 = getelementptr i8, ptr %252, i64 1280
  %334 = load <vscale x 8 x float>, ptr %333, align 4
  %335 = getelementptr i8, ptr %254, i64 1280
  %336 = load <vscale x 8 x float>, ptr %335, align 4
  %337 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %334, i64 0)
  %338 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %336, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %337, <vscale x 4 x float> %338)
  %339 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %336, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %337, <vscale x 4 x float> %339)
  %340 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %334, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %340, <vscale x 4 x float> %338)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %340, <vscale x 4 x float> %339)
  %341 = getelementptr i8, ptr %252, i64 1408
  %342 = load <vscale x 8 x float>, ptr %341, align 4
  %343 = getelementptr i8, ptr %254, i64 1408
  %344 = load <vscale x 8 x float>, ptr %343, align 4
  %345 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %342, i64 0)
  %346 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %344, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %345, <vscale x 4 x float> %346)
  %347 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %344, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %345, <vscale x 4 x float> %347)
  %348 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %342, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %348, <vscale x 4 x float> %346)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %348, <vscale x 4 x float> %347)
  %349 = getelementptr i8, ptr %252, i64 1536
  %350 = load <vscale x 8 x float>, ptr %349, align 4
  %351 = getelementptr i8, ptr %254, i64 1536
  %352 = load <vscale x 8 x float>, ptr %351, align 4
  %353 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %350, i64 0)
  %354 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %352, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %353, <vscale x 4 x float> %354)
  %355 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %352, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %353, <vscale x 4 x float> %355)
  %356 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %350, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %356, <vscale x 4 x float> %354)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %356, <vscale x 4 x float> %355)
  %357 = getelementptr i8, ptr %252, i64 1664
  %358 = load <vscale x 8 x float>, ptr %357, align 4
  %359 = getelementptr i8, ptr %254, i64 1664
  %360 = load <vscale x 8 x float>, ptr %359, align 4
  %361 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %358, i64 0)
  %362 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %360, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %361, <vscale x 4 x float> %362)
  %363 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %360, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %361, <vscale x 4 x float> %363)
  %364 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %358, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %364, <vscale x 4 x float> %362)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %364, <vscale x 4 x float> %363)
  %365 = getelementptr i8, ptr %252, i64 1792
  %366 = load <vscale x 8 x float>, ptr %365, align 4
  %367 = getelementptr i8, ptr %254, i64 1792
  %368 = load <vscale x 8 x float>, ptr %367, align 4
  %369 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %366, i64 0)
  %370 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %368, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %369, <vscale x 4 x float> %370)
  %371 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %368, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %369, <vscale x 4 x float> %371)
  %372 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %366, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %372, <vscale x 4 x float> %370)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %372, <vscale x 4 x float> %371)
  %373 = getelementptr i8, ptr %252, i64 1920
  %374 = load <vscale x 8 x float>, ptr %373, align 4
  %375 = getelementptr i8, ptr %254, i64 1920
  %376 = load <vscale x 8 x float>, ptr %375, align 4
  %377 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %374, i64 0)
  %378 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %376, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %377, <vscale x 4 x float> %378)
  %379 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %376, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %377, <vscale x 4 x float> %379)
  %380 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %374, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %380, <vscale x 4 x float> %378)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %380, <vscale x 4 x float> %379)
  br i1 %44, label %.lr.ph41, label %._crit_edge42

381:                                              ; preds = %.lr.ph38, %381
  %382 = phi i64 [ 0, %.lr.ph38 ], [ %385, %381 ]
  %383 = add nuw i64 %382, %24
  %.idx18 = shl i64 %383, 7
  %gep40 = getelementptr i8, ptr %gep46, i64 %.idx18
  %384 = trunc i64 %382 to i32
  tail call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %gep40, i32 3, i32 %384)
  %385 = add nuw nsw i64 %382, 1
  %exitcond68.not = icmp eq i64 %385, %24
  br i1 %exitcond68.not, label %.preheader6, label %381

.lr.ph41:                                         ; preds = %.preheader6
  %386 = getelementptr [4 x i8], ptr %12, i64 %234
  br label %387

387:                                              ; preds = %.lr.ph41, %387
  %388 = phi i64 [ 0, %.lr.ph41 ], [ %395, %387 ]
  %.idx1 = shl i64 %388, 7
  %389 = getelementptr i8, ptr %386, i64 %.idx1
  %390 = trunc i64 %388 to i32
  tail call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %389, i32 0, i32 %390)
  %391 = getelementptr [4 x i8], ptr %389, i64 %24
  tail call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %391, i32 1, i32 %390)
  %392 = add nuw i64 %388, %24
  %.idx2 = shl i64 %392, 7
  %393 = getelementptr i8, ptr %386, i64 %.idx2
  tail call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %393, i32 2, i32 %390)
  %394 = getelementptr [4 x i8], ptr %393, i64 %24
  tail call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %394, i32 3, i32 %390)
  %395 = add nuw nsw i64 %388, 1
  %exitcond70.not = icmp eq i64 %395, %24
  br i1 %exitcond70.not, label %._crit_edge42, label %387

._crit_edge42:                                    ; preds = %387, %.preheader6
  %396 = add nuw nsw i64 %224, 1
  %exitcond71.not = icmp eq i64 %396, %umax
  br i1 %exitcond71.not, label %._crit_edge48, label %.lr.ph47

._crit_edge48:                                    ; preds = %._crit_edge42, %.preheader12
  %397 = add nsw i64 %47, 16
  %398 = add i64 %46, %30
  %399 = add nuw nsw i32 %48, 1
  %indvars.iv.next = add i32 %indvars.iv, -16
  %exitcond72.not = icmp eq i32 %399, %32
  br i1 %exitcond72.not, label %._crit_edge51, label %45

._crit_edge51:                                    ; preds = %._crit_edge48, %15
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.vscale.i64() #4

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smin.i32(i32, i32) #5

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smin.i64(i64, i64) #5

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smax.i64(i64, i64) #5

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare ptr @llvm.stacksave.p0() #6

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.stackrestore.p0(ptr) #6

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64, i64) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr captures(none), <vscale x 4 x i1>, <vscale x 4 x float>) #7

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float>, ptr captures(none), <vscale x 4 x i1>) #8

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite)
declare void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1>, ptr, i32 immarg, i32) #9

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float>, i64 immarg) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(target_mem1: readwrite)
declare void @llvm.aarch64.sme.mopa.nxv4f32(i32 immarg, <vscale x 4 x i1>, <vscale x 4 x i1>, <vscale x 4 x float>, <vscale x 4 x float>) #10

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite)
declare void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1>, ptr, i32 immarg, i32) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smax.i32(i32, i32) #11

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umin.i32(i32, i32) #11

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umax.i64(i64, i64) #11

attributes #0 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "target-features"="+sve,+sve2,+sme" }
attributes #1 = { "target-features"="+sve,+sve2,+sme" }
attributes #2 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite, errnomem: write) "alloc-family"="malloc" "target-features"="+sve,+sve2,+sme" }
attributes #3 = { nofree norecurse nosync nounwind memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: readwrite) "aarch64_new_za" "aarch64_pstate_sm_enabled" "target-features"="+sve,+sve2,+sme" }
attributes #4 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) "target-features"="+sve,+sve2,+sme" }
attributes #5 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) "target-features"="+sve,+sve2,+sme" }
attributes #6 = { mustprogress nocallback nofree nosync nounwind willreturn "target-features"="+sve,+sve2,+sme" }
attributes #7 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read) "target-features"="+sve,+sve2,+sme" }
attributes #8 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write) "target-features"="+sve,+sve2,+sme" }
attributes #9 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite) "target-features"="+sve,+sve2,+sme" }
attributes #10 = { mustprogress nocallback nofree nosync nounwind willreturn memory(target_mem1: readwrite) "target-features"="+sve,+sve2,+sme" }
attributes #11 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #12 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
