; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target triple = "aarch64"

declare void @free(ptr)

declare void @memrefCopy(i64, ptr, ptr)

declare ptr @malloc(i64)

define void @matmul_kernel(i64 %0, ptr %1, i64 %2, ptr %3, i64 %4, ptr %5, i32 %6, i32 %7, i32 %8, i32 %9, i32 %10, i32 %11, i32 %12, i32 %13, i32 %14, i32 %15, i32 %16, i32 %17) {
  %19 = insertvalue { i64, ptr } poison, i64 %4, 0
  %20 = insertvalue { i64, ptr } %19, ptr %5, 1
  %21 = insertvalue { i64, ptr } poison, i64 %0, 0
  %22 = insertvalue { i64, ptr } %21, ptr %1, 1
  %23 = insertvalue { i64, ptr } poison, i64 %2, 0
  %24 = insertvalue { i64, ptr } %23, ptr %3, 1
  %25 = call ptr @malloc(i64 8256)
  %26 = ptrtoint ptr %25 to i64
  %27 = add i64 %26, 63
  %28 = urem i64 %27, 64
  %29 = sub i64 %27, %28
  %30 = inttoptr i64 %29 to ptr
  %31 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %25, 0
  %32 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %31, ptr %30, 1
  %33 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %32, i64 0, 2
  %34 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %33, i64 32, 3, 0
  %35 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %34, i64 64, 3, 1
  %36 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %35, i64 64, 4, 0
  %37 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %36, i64 1, 4, 1
  %38 = call i64 @llvm.vscale.i64()
  %39 = mul i64 %38, 4
  %40 = sdiv i64 63, %39
  %41 = add i64 %40, 1
  %42 = sdiv i64 63, %39
  %43 = add i64 %42, 1
  %44 = mul nsw i64 %43, 32
  br label %45

45:                                               ; preds = %48, %18
  %46 = phi i64 [ %79, %48 ], [ 0, %18 ]
  %47 = icmp slt i64 %46, %44
  br i1 %47, label %48, label %80

48:                                               ; preds = %45
  %49 = sdiv i64 %46, %41
  %50 = mul i64 %49, %41
  %51 = icmp ne i64 %46, %50
  %52 = icmp slt i64 %46, 0
  %53 = icmp slt i64 %41, 0
  %54 = icmp ne i1 %52, %53
  %55 = and i1 %51, %54
  %56 = add i64 %49, -1
  %57 = select i1 %55, i64 %56, i64 %49
  %58 = srem i64 %46, %41
  %59 = icmp slt i64 %58, 0
  %60 = add nsw i64 %58, %41
  %61 = select i1 %59, i64 %60, i64 %58
  %62 = mul nsw i64 %39, %61
  %63 = mul nsw i64 %39, %61
  %64 = mul nsw i64 %63, -1
  %65 = add i64 %64, 64
  %66 = call i64 @llvm.smin.i64(i64 %65, i64 %39)
  %67 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %66)
  %68 = mul nsw i64 %57, 64
  %69 = add i64 %68, %62
  %70 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %25, 0
  %71 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %70, ptr %30, 1
  %72 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %71, i64 %69, 2
  %73 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %72, i64 %66, 3, 0
  %74 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %73, i64 1, 4, 0
  %75 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %74, 1
  %76 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %74, 2
  %77 = getelementptr float, ptr %75, i64 %76
  %78 = getelementptr float, ptr %77, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> zeroinitializer, ptr align 4 %78, <vscale x 4 x i1> %67)
  %79 = add i64 %46, 1
  br label %45

80:                                               ; preds = %45
  %81 = add i32 %6, 31
  %82 = sdiv i32 %81, 32
  %83 = add i32 %7, 63
  %84 = sdiv i32 %83, 64
  %85 = mul i32 %84, 8
  %86 = sdiv i32 %15, %85
  %87 = mul i32 %86, 8
  %88 = sub i32 %82, %87
  %89 = call i32 @llvm.smin.i32(i32 %88, i32 8)
  %90 = srem i32 %15, %89
  %91 = add i32 %87, %90
  %92 = srem i32 %15, %85
  %93 = sdiv i32 %92, %89
  %94 = mul i32 %91, 32
  %95 = sext i32 %94 to i64
  %96 = mul i32 %93, 64
  %97 = sext i32 %96 to i64
  %98 = sext i32 %6 to i64
  %99 = sext i32 %7 to i64
  %100 = call ptr @malloc(i64 8256)
  %101 = ptrtoint ptr %100 to i64
  %102 = add i64 %101, 63
  %103 = urem i64 %102, 64
  %104 = sub i64 %102, %103
  %105 = inttoptr i64 %104 to ptr
  %106 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %100, 0
  %107 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %106, ptr %105, 1
  %108 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %107, i64 0, 2
  %109 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %108, i64 1, 3, 0
  %110 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %109, i64 2, 3, 1
  %111 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %110, i64 32, 3, 2
  %112 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %111, i64 32, 3, 3
  %113 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %112, i64 2048, 4, 0
  %114 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %113, i64 1024, 4, 1
  %115 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, i64 32, 4, 2
  %116 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %115, i64 1, 4, 3
  %117 = sdiv i64 31, %39
  %118 = add i64 %117, 1
  %119 = sdiv i64 31, %39
  %120 = add i64 %119, 1
  %121 = mul nsw i64 %120, 64
  br label %122

122:                                              ; preds = %125, %80
  %123 = phi i64 [ %178, %125 ], [ 0, %80 ]
  %124 = icmp slt i64 %123, %121
  br i1 %124, label %125, label %179

125:                                              ; preds = %122
  %126 = mul nuw nsw i64 %118, 32
  %127 = sdiv i64 %123, %126
  %128 = mul i64 %127, %126
  %129 = icmp ne i64 %123, %128
  %130 = icmp slt i64 %123, 0
  %131 = icmp slt i64 %126, 0
  %132 = icmp ne i1 %130, %131
  %133 = and i1 %129, %132
  %134 = add i64 %127, -1
  %135 = select i1 %133, i64 %134, i64 %127
  %136 = srem i64 %123, %126
  %137 = icmp slt i64 %136, 0
  %138 = add nsw i64 %136, %126
  %139 = select i1 %137, i64 %138, i64 %136
  %140 = sdiv i64 %139, %118
  %141 = srem i64 %123, %118
  %142 = icmp slt i64 %141, 0
  %143 = add nsw i64 %141, %118
  %144 = select i1 %142, i64 %143, i64 %141
  %145 = mul nsw i64 %39, %144
  %146 = mul nsw i64 %39, %144
  %147 = mul nsw i64 %146, -1
  %148 = add i64 %147, 32
  %149 = call i64 @llvm.smin.i64(i64 %148, i64 %39)
  %150 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %149)
  %151 = mul nsw i64 %140, 64
  %152 = mul nsw i64 %135, 32
  %153 = add i64 %151, %152
  %154 = add i64 %153, %145
  %155 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %25, 0
  %156 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %155, ptr %30, 1
  %157 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %156, i64 %154, 2
  %158 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %157, i64 %149, 3, 0
  %159 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %158, i64 1, 4, 0
  %160 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %159, 1
  %161 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %159, 2
  %162 = getelementptr float, ptr %160, i64 %161
  %163 = getelementptr float, ptr %162, i64 0
  %164 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %163, <vscale x 4 x i1> %150, <vscale x 4 x float> poison)
  %165 = mul nsw i64 %135, 1024
  %166 = mul nsw i64 %140, 32
  %167 = add i64 %165, %166
  %168 = add i64 %167, %145
  %169 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %100, 0
  %170 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %169, ptr %105, 1
  %171 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %170, i64 %168, 2
  %172 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %171, i64 %149, 3, 0
  %173 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %172, i64 1, 4, 0
  %174 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %173, 1
  %175 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %173, 2
  %176 = getelementptr float, ptr %174, i64 %175
  %177 = getelementptr float, ptr %176, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %164, ptr align 4 %177, <vscale x 4 x i1> %150)
  %178 = add i64 %123, 1
  br label %122

179:                                              ; preds = %122
  %180 = call ptr @malloc(i64 2112)
  %181 = ptrtoint ptr %180 to i64
  %182 = add i64 %181, 63
  %183 = urem i64 %182, 64
  %184 = sub i64 %182, %183
  %185 = inttoptr i64 %184 to ptr
  %186 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %180, 0
  %187 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %186, ptr %185, 1
  %188 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %187, i64 0, 2
  %189 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %188, i64 1, 3, 0
  %190 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %189, i64 16, 3, 1
  %191 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %190, i64 32, 3, 2
  %192 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %191, i64 1, 3, 3
  %193 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %192, i64 512, 4, 0
  %194 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %193, i64 32, 4, 1
  %195 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %194, i64 1, 4, 2
  %196 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %195, i64 1, 4, 3
  %197 = call ptr @malloc(i64 4160)
  %198 = ptrtoint ptr %197 to i64
  %199 = add i64 %198, 63
  %200 = urem i64 %199, 64
  %201 = sub i64 %199, %200
  %202 = inttoptr i64 %201 to ptr
  %203 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %197, 0
  %204 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %203, ptr %202, 1
  %205 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %204, i64 0, 2
  %206 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %205, i64 2, 3, 0
  %207 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %206, i64 16, 3, 1
  %208 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %207, i64 32, 3, 2
  %209 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %208, i64 1, 3, 3
  %210 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %209, i64 512, 4, 0
  %211 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %210, i64 32, 4, 1
  %212 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %211, i64 1, 4, 2
  %213 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %212, i64 1, 4, 3
  %214 = call ptr @malloc(i64 2048)
  %215 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %214, 0
  %216 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %215, ptr %214, 1
  %217 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %216, i64 0, 2
  %218 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %217, i64 32, 3, 0
  %219 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %218, i64 16, 3, 1
  %220 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %219, i64 16, 4, 0
  %221 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %220, i64 1, 4, 1
  %222 = call ptr @malloc(i64 4096)
  %223 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %222, 0
  %224 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %223, ptr %222, 1
  %225 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %224, i64 0, 2
  %226 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %225, i64 16, 3, 0
  %227 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %226, i64 64, 3, 1
  %228 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %227, i64 64, 4, 0
  %229 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %228, i64 1, 4, 1
  %230 = call { i64, i64 } @matmul_kernel_sme_0(i32 %93, i32 %7, i64 %2, ptr %3, i32 %10, i32 %9, i32 %6, i64 %0, ptr %1, i32 %8, ptr %214, ptr %214, i64 0, i64 32, i64 16, i64 16, i64 1, ptr %222, ptr %222, i64 0, i64 16, i64 64, i64 64, i64 1, ptr %180, ptr %185, i64 0, i64 1, i64 16, i64 32, i64 1, i64 512, i64 32, i64 1, i64 1, ptr %197, ptr %202, i64 0, i64 2, i64 16, i64 32, i64 1, i64 512, i64 32, i64 1, i64 1, ptr %100, ptr %105, i64 0, i64 1, i64 2, i64 32, i64 32, i64 2048, i64 1024, i64 32, i64 1, i32 %86, i32 %90)
  %231 = extractvalue { i64, i64 } %230, 0
  %232 = extractvalue { i64, i64 } %230, 1
  %233 = call ptr @malloc(i64 8256)
  %234 = ptrtoint ptr %233 to i64
  %235 = add i64 %234, 63
  %236 = urem i64 %235, 64
  %237 = sub i64 %235, %236
  %238 = inttoptr i64 %237 to ptr
  %239 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %233, 0
  %240 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %239, ptr %238, 1
  %241 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %240, i64 0, 2
  %242 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %241, i64 1, 3, 0
  %243 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %242, i64 32, 3, 1
  %244 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %243, i64 2, 3, 2
  %245 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %244, i64 32, 3, 3
  %246 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %245, i64 2048, 4, 0
  %247 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %246, i64 64, 4, 1
  %248 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %247, i64 32, 4, 2
  %249 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %248, i64 1, 4, 3
  br label %250

250:                                              ; preds = %253, %179
  %251 = phi i64 [ %306, %253 ], [ 0, %179 ]
  %252 = icmp slt i64 %251, %121
  br i1 %252, label %253, label %307

253:                                              ; preds = %250
  %254 = mul nuw nsw i64 %118, 2
  %255 = sdiv i64 %251, %254
  %256 = mul i64 %255, %254
  %257 = icmp ne i64 %251, %256
  %258 = icmp slt i64 %251, 0
  %259 = icmp slt i64 %254, 0
  %260 = icmp ne i1 %258, %259
  %261 = and i1 %257, %260
  %262 = add i64 %255, -1
  %263 = select i1 %261, i64 %262, i64 %255
  %264 = srem i64 %251, %254
  %265 = icmp slt i64 %264, 0
  %266 = add nsw i64 %264, %254
  %267 = select i1 %265, i64 %266, i64 %264
  %268 = sdiv i64 %267, %118
  %269 = srem i64 %251, %118
  %270 = icmp slt i64 %269, 0
  %271 = add nsw i64 %269, %118
  %272 = select i1 %270, i64 %271, i64 %269
  %273 = mul nsw i64 %39, %272
  %274 = mul nsw i64 %39, %272
  %275 = mul nsw i64 %274, -1
  %276 = add i64 %275, 32
  %277 = call i64 @llvm.smin.i64(i64 %276, i64 %39)
  %278 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %277)
  %279 = mul nsw i64 %268, 1024
  %280 = mul nsw i64 %263, 32
  %281 = add i64 %279, %280
  %282 = add i64 %281, %273
  %283 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %100, 0
  %284 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %283, ptr %105, 1
  %285 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %284, i64 %282, 2
  %286 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %285, i64 %277, 3, 0
  %287 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %286, i64 1, 4, 0
  %288 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %287, 1
  %289 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %287, 2
  %290 = getelementptr float, ptr %288, i64 %289
  %291 = getelementptr float, ptr %290, i64 0
  %292 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %291, <vscale x 4 x i1> %278, <vscale x 4 x float> poison)
  %293 = mul nsw i64 %263, 64
  %294 = mul nsw i64 %268, 32
  %295 = add i64 %293, %294
  %296 = add i64 %295, %273
  %297 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %233, 0
  %298 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %297, ptr %238, 1
  %299 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %298, i64 %296, 2
  %300 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %299, i64 %277, 3, 0
  %301 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %300, i64 1, 4, 0
  %302 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %301, 1
  %303 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %301, 2
  %304 = getelementptr float, ptr %302, i64 %303
  %305 = getelementptr float, ptr %304, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %292, ptr align 4 %305, <vscale x 4 x i1> %278)
  %306 = add i64 %251, 1
  br label %250

307:                                              ; preds = %250
  br label %308

308:                                              ; preds = %311, %307
  %309 = phi i64 [ %354, %311 ], [ 0, %307 ]
  %310 = icmp slt i64 %309, %44
  br i1 %310, label %311, label %355

311:                                              ; preds = %308
  %312 = sdiv i64 %309, %41
  %313 = mul i64 %312, %41
  %314 = icmp ne i64 %309, %313
  %315 = icmp slt i64 %309, 0
  %316 = icmp slt i64 %41, 0
  %317 = icmp ne i1 %315, %316
  %318 = and i1 %314, %317
  %319 = add i64 %312, -1
  %320 = select i1 %318, i64 %319, i64 %312
  %321 = srem i64 %309, %41
  %322 = icmp slt i64 %321, 0
  %323 = add nsw i64 %321, %41
  %324 = select i1 %322, i64 %323, i64 %321
  %325 = mul nsw i64 %39, %324
  %326 = mul nsw i64 %39, %324
  %327 = mul nsw i64 %326, -1
  %328 = add i64 %327, 64
  %329 = call i64 @llvm.smin.i64(i64 %328, i64 %39)
  %330 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %329)
  %331 = mul nsw i64 %320, 64
  %332 = add i64 %331, %325
  %333 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %233, 0
  %334 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %333, ptr %238, 1
  %335 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %334, i64 %332, 2
  %336 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %335, i64 %329, 3, 0
  %337 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %336, i64 1, 4, 0
  %338 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %337, 1
  %339 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %337, 2
  %340 = getelementptr float, ptr %338, i64 %339
  %341 = getelementptr float, ptr %340, i64 0
  %342 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %341, <vscale x 4 x i1> %330, <vscale x 4 x float> poison)
  %343 = mul nsw i64 %320, 64
  %344 = add i64 %343, %325
  %345 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %25, 0
  %346 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %345, ptr %30, 1
  %347 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %346, i64 %344, 2
  %348 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %347, i64 %329, 3, 0
  %349 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %348, i64 1, 4, 0
  %350 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %349, 1
  %351 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %349, 2
  %352 = getelementptr float, ptr %350, i64 %351
  %353 = getelementptr float, ptr %352, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %342, ptr align 4 %353, <vscale x 4 x i1> %330)
  %354 = add i64 %309, 1
  br label %308

355:                                              ; preds = %308
  %356 = sext i32 %11 to i64
  %357 = mul i64 %95, %356
  %358 = add i64 %357, %97
  %359 = add i64 %95, 32
  %360 = call i64 @llvm.smin.i64(i64 %359, i64 %98)
  %361 = call i64 @llvm.smax.i64(i64 %360, i64 %95)
  %362 = sub i64 %361, %95
  %363 = add i64 %97, 64
  %364 = call i64 @llvm.smin.i64(i64 %363, i64 %99)
  %365 = call i64 @llvm.smax.i64(i64 %364, i64 %97)
  %366 = sub i64 %365, %97
  %367 = call i64 @llvm.smin.i64(i64 %362, i64 32)
  %368 = call i64 @llvm.smin.i64(i64 %366, i64 64)
  %369 = extractvalue { i64, ptr } %20, 1
  %370 = load ptr, ptr %369, align 8
  %371 = getelementptr ptr, ptr %369, i32 1
  %372 = load ptr, ptr %371, align 8
  %373 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %370, 0
  %374 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %373, ptr %372, 1
  %375 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %374, i64 %358, 2
  %376 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %375, i64 32, 3, 0
  %377 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %376, i64 %356, 4, 0
  %378 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %377, i64 64, 3, 1
  %379 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %378, i64 1, 4, 1
  %380 = insertvalue { ptr, ptr, i64 } poison, ptr %370, 0
  %381 = insertvalue { ptr, ptr, i64 } %380, ptr %372, 1
  %382 = insertvalue { ptr, ptr, i64 } %381, i64 0, 2
  %383 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %370, 0
  %384 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %383, ptr %372, 1
  %385 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %384, i64 %358, 2
  %386 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %385, i64 %367, 3, 0
  %387 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %386, i64 %356, 4, 0
  %388 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %387, i64 %368, 3, 1
  %389 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %388, i64 1, 4, 1
  %390 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %25, 0
  %391 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %390, ptr %30, 1
  %392 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %391, i64 0, 2
  %393 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %392, i64 %367, 3, 0
  %394 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %393, i64 64, 4, 0
  %395 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %394, i64 %368, 3, 1
  %396 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %395, i64 1, 4, 1
  %397 = call ptr @llvm.stacksave.p0()
  %398 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %396, ptr %398, align 8
  %399 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %398, 1
  %400 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %389, ptr %400, align 8
  %401 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %400, 1
  %402 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %399, ptr %402, align 8
  %403 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %401, ptr %403, align 8
  call void @memrefCopy(i64 4, ptr %402, ptr %403)
  call void @llvm.stackrestore.p0(ptr %397)
  call void @free(ptr %25)
  call void @free(ptr %100)
  call void @free(ptr %180)
  call void @free(ptr %197)
  call void @free(ptr %214)
  call void @free(ptr %222)
  call void @free(ptr %233)
  ret void
}

define internal { i64, i64 } @matmul_kernel_sme_0(i32 %0, i32 %1, i64 %2, ptr %3, i32 %4, i32 %5, i32 %6, i64 %7, ptr %8, i32 %9, ptr %10, ptr %11, i64 %12, i64 %13, i64 %14, i64 %15, i64 %16, ptr %17, ptr %18, i64 %19, i64 %20, i64 %21, i64 %22, i64 %23, ptr %24, ptr %25, i64 %26, i64 %27, i64 %28, i64 %29, i64 %30, i64 %31, i64 %32, i64 %33, i64 %34, ptr %35, ptr %36, i64 %37, i64 %38, i64 %39, i64 %40, i64 %41, i64 %42, i64 %43, i64 %44, i64 %45, ptr %46, ptr %47, i64 %48, i64 %49, i64 %50, i64 %51, i64 %52, i64 %53, i64 %54, i64 %55, i64 %56, i32 %57, i32 %58) #0 {
  %60 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %46, 0
  %61 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %60, ptr %47, 1
  %62 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %61, i64 %48, 2
  %63 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %62, i64 %49, 3, 0
  %64 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %63, i64 %53, 4, 0
  %65 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %64, i64 %50, 3, 1
  %66 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %65, i64 %54, 4, 1
  %67 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %66, i64 %51, 3, 2
  %68 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, i64 %55, 4, 2
  %69 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %68, i64 %52, 3, 3
  %70 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %69, i64 %56, 4, 3
  %71 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %35, 0
  %72 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %71, ptr %36, 1
  %73 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %72, i64 %37, 2
  %74 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %73, i64 %38, 3, 0
  %75 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, i64 %42, 4, 0
  %76 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %75, i64 %39, 3, 1
  %77 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %76, i64 %43, 4, 1
  %78 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %77, i64 %40, 3, 2
  %79 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, i64 %44, 4, 2
  %80 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %79, i64 %41, 3, 3
  %81 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %80, i64 %45, 4, 3
  %82 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %24, 0
  %83 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %82, ptr %25, 1
  %84 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %83, i64 %26, 2
  %85 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %84, i64 %27, 3, 0
  %86 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, i64 %31, 4, 0
  %87 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %86, i64 %28, 3, 1
  %88 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %87, i64 %32, 4, 1
  %89 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %88, i64 %29, 3, 2
  %90 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %89, i64 %33, 4, 2
  %91 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %90, i64 %30, 3, 3
  %92 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %91, i64 %34, 4, 3
  %93 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %17, 0
  %94 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %93, ptr %18, 1
  %95 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %94, i64 %19, 2
  %96 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %95, i64 %20, 3, 0
  %97 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %96, i64 %22, 4, 0
  %98 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %97, i64 %21, 3, 1
  %99 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %98, i64 %23, 4, 1
  %100 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %10, 0
  %101 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %100, ptr %11, 1
  %102 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %101, i64 %12, 2
  %103 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %102, i64 %13, 3, 0
  %104 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %103, i64 %15, 4, 0
  %105 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %104, i64 %14, 3, 1
  %106 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %105, i64 %16, 4, 1
  %107 = insertvalue { i64, ptr } poison, i64 %7, 0
  %108 = insertvalue { i64, ptr } %107, ptr %8, 1
  %109 = insertvalue { i64, ptr } poison, i64 %2, 0
  %110 = insertvalue { i64, ptr } %109, ptr %3, 1
  %111 = mul i32 %0, 64
  %112 = sext i32 %111 to i64
  %113 = sext i32 %1 to i64
  %114 = sext i32 %4 to i64
  %115 = sext i32 %5 to i64
  %116 = sext i32 %6 to i64
  %117 = mul i64 %116, %115
  %118 = call i64 @llvm.vscale.i64()
  %119 = mul i64 %118, 4
  %120 = mul i64 %118, 8
  %121 = sdiv i64 31, %120
  %122 = add i64 %121, 1
  %123 = sdiv i64 31, %120
  %124 = add i64 %123, 1
  %125 = sdiv i64 31, %120
  %126 = add i64 %125, 1
  %127 = mul nsw i64 %124, %126
  %128 = mul nsw i64 %127, 2
  %129 = mul i32 %4, 16
  %130 = sext i32 %129 to i64
  %131 = add i32 %9, 15
  %132 = sdiv i32 %131, 16
  %133 = mul i32 %57, 8
  %134 = add i32 %133, %58
  %135 = mul i32 %134, 32
  %136 = sext i32 %135 to i64
  %137 = mul i64 %136, %115
  br label %138

138:                                              ; preds = %895, %59
  %139 = phi i32 [ %898, %895 ], [ 0, %59 ]
  %140 = phi i64 [ %896, %895 ], [ %137, %59 ]
  %141 = phi i64 [ %897, %895 ], [ 0, %59 ]
  %142 = icmp slt i32 %139, %132
  br i1 %142, label %143, label %899

143:                                              ; preds = %138
  %144 = add i64 %141, %112
  %145 = srem i64 %144, %113
  %146 = sub i64 %144, %145
  %147 = add i64 %145, 64
  %148 = call i64 @llvm.smin.i64(i64 %147, i64 %113)
  %149 = sub i64 %148, %145
  %150 = extractvalue { i64, ptr } %110, 1
  %151 = load ptr, ptr %150, align 8
  %152 = getelementptr ptr, ptr %150, i32 1
  %153 = load ptr, ptr %152, align 8
  %154 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %151, 0
  %155 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %154, ptr %153, 1
  %156 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %155, i64 %144, 2
  %157 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %156, i64 16, 3, 0
  %158 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %157, i64 %114, 4, 0
  %159 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %158, i64 %149, 3, 1
  %160 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %159, i64 1, 4, 1
  %161 = sub i64 64, %149
  %162 = extractvalue { i64, ptr } %110, 1
  %163 = load ptr, ptr %162, align 8
  %164 = getelementptr ptr, ptr %162, i32 1
  %165 = load ptr, ptr %164, align 8
  %166 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %163, 0
  %167 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %166, ptr %165, 1
  %168 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %167, i64 %146, 2
  %169 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %168, i64 16, 3, 0
  %170 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %169, i64 %114, 4, 0
  %171 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %170, i64 %161, 3, 1
  %172 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %171, i64 1, 4, 1
  %173 = srem i64 %140, %115
  %174 = add i64 %117, %173
  %175 = sub i64 %174, %140
  %176 = sdiv i64 %175, %115
  %177 = call i64 @llvm.smin.i64(i64 %176, i64 32)
  %178 = extractvalue { i64, ptr } %108, 1
  %179 = load ptr, ptr %178, align 8
  %180 = getelementptr ptr, ptr %178, i32 1
  %181 = load ptr, ptr %180, align 8
  %182 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %179, 0
  %183 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %182, ptr %181, 1
  %184 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %183, i64 %140, 2
  %185 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %184, i64 %177, 3, 0
  %186 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %185, i64 %115, 4, 0
  %187 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %186, i64 16, 3, 1
  %188 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %187, i64 1, 4, 1
  %189 = sub i64 32, %177
  %190 = extractvalue { i64, ptr } %108, 1
  %191 = load ptr, ptr %190, align 8
  %192 = getelementptr ptr, ptr %190, i32 1
  %193 = load ptr, ptr %192, align 8
  %194 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %191, 0
  %195 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %194, ptr %193, 1
  %196 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %195, i64 %173, 2
  %197 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %196, i64 %189, 3, 0
  %198 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %197, i64 %115, 4, 0
  %199 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %198, i64 16, 3, 1
  %200 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %199, i64 1, 4, 1
  %201 = mul i32 %139, 16
  %202 = sub i32 %9, %201
  %203 = sext i32 %202 to i64
  %204 = call i64 @llvm.smin.i64(i64 %203, i64 16)
  %205 = call i64 @llvm.smax.i64(i64 %204, i64 0)
  %206 = icmp slt i64 %205, 16
  br i1 %206, label %207, label %221

207:                                              ; preds = %219, %143
  %208 = phi i64 [ %220, %219 ], [ 0, %143 ]
  %209 = icmp slt i64 %208, 32
  br i1 %209, label %210, label %221

210:                                              ; preds = %213, %207
  %211 = phi i64 [ %218, %213 ], [ 0, %207 ]
  %212 = icmp slt i64 %211, 16
  br i1 %212, label %213, label %219

213:                                              ; preds = %210
  %214 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %106, 1
  %215 = mul nuw nsw i64 %208, 16
  %216 = add nuw nsw i64 %215, %211
  %217 = getelementptr inbounds nuw float, ptr %214, i64 %216
  store float 0.000000e+00, ptr %217, align 4
  %218 = add i64 %211, 1
  br label %210

219:                                              ; preds = %210
  %220 = add i64 %208, 1
  br label %207

221:                                              ; preds = %207, %143
  %222 = icmp sle i64 %205, 0
  %223 = sub i64 0, %205
  %224 = sub i64 %205, 1
  %225 = select i1 %222, i64 %223, i64 %224
  %226 = sdiv i64 %225, %119
  %227 = sub i64 0, %226
  %228 = add i64 %226, 1
  %229 = select i1 %222, i64 %227, i64 %228
  %230 = icmp sle i64 %205, 0
  %231 = sub i64 0, %205
  %232 = sub i64 %205, 1
  %233 = select i1 %230, i64 %231, i64 %232
  %234 = sdiv i64 %233, %119
  %235 = sub i64 0, %234
  %236 = add i64 %234, 1
  %237 = select i1 %230, i64 %235, i64 %236
  %238 = mul nsw i64 %177, %237
  br label %239

239:                                              ; preds = %242, %221
  %240 = phi i64 [ %299, %242 ], [ 0, %221 ]
  %241 = icmp slt i64 %240, %238
  br i1 %241, label %242, label %300

242:                                              ; preds = %239
  %243 = sdiv i64 %240, %229
  %244 = mul i64 %243, %229
  %245 = icmp ne i64 %240, %244
  %246 = icmp slt i64 %240, 0
  %247 = icmp slt i64 %229, 0
  %248 = icmp ne i1 %246, %247
  %249 = and i1 %245, %248
  %250 = add i64 %243, -1
  %251 = select i1 %249, i64 %250, i64 %243
  %252 = srem i64 %240, %229
  %253 = icmp slt i64 %252, 0
  %254 = add nsw i64 %252, %229
  %255 = select i1 %253, i64 %254, i64 %252
  %256 = mul nsw i64 %119, %255
  %257 = mul nsw i64 %119, %255
  %258 = mul nsw i64 %257, -1
  %259 = add i64 %205, %258
  %260 = call i64 @llvm.smin.i64(i64 %259, i64 %119)
  %261 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %260)
  %262 = insertvalue { ptr, ptr, i64 } poison, ptr %179, 0
  %263 = insertvalue { ptr, ptr, i64 } %262, ptr %181, 1
  %264 = insertvalue { ptr, ptr, i64 } %263, i64 0, 2
  %265 = mul nsw i64 %251, %115
  %266 = add i64 %140, %265
  %267 = add i64 %266, %256
  %268 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %179, 0
  %269 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %268, ptr %181, 1
  %270 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %269, i64 %267, 2
  %271 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %270, i64 %260, 3, 0
  %272 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %271, i64 1, 4, 0
  %273 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %272, 1
  %274 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %272, 2
  %275 = getelementptr float, ptr %273, i64 %274
  %276 = getelementptr float, ptr %275, i64 0
  %277 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %276, <vscale x 4 x i1> %261, <vscale x 4 x float> poison)
  %278 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %106, 0
  %279 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %106, 1
  %280 = insertvalue { ptr, ptr, i64 } poison, ptr %278, 0
  %281 = insertvalue { ptr, ptr, i64 } %280, ptr %279, 1
  %282 = insertvalue { ptr, ptr, i64 } %281, i64 0, 2
  %283 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %106, 2
  %284 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %106, 3, 0
  %285 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %106, 3, 1
  %286 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %106, 4, 0
  %287 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %106, 4, 1
  %288 = mul nsw i64 %251, 16
  %289 = add i64 %288, %256
  %290 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %278, 0
  %291 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %290, ptr %279, 1
  %292 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %291, i64 %289, 2
  %293 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %292, i64 %260, 3, 0
  %294 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %293, i64 1, 4, 0
  %295 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %294, 1
  %296 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %294, 2
  %297 = getelementptr float, ptr %295, i64 %296
  %298 = getelementptr float, ptr %297, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %277, ptr align 4 %298, <vscale x 4 x i1> %261)
  %299 = add i64 %240, 1
  br label %239

300:                                              ; preds = %239
  %301 = icmp sle i64 %205, 0
  %302 = sub i64 0, %205
  %303 = sub i64 %205, 1
  %304 = select i1 %301, i64 %302, i64 %303
  %305 = sdiv i64 %304, %119
  %306 = sub i64 0, %305
  %307 = add i64 %305, 1
  %308 = select i1 %301, i64 %306, i64 %307
  %309 = mul nsw i64 %189, %308
  br label %310

310:                                              ; preds = %313, %300
  %311 = phi i64 [ %372, %313 ], [ 0, %300 ]
  %312 = icmp slt i64 %311, %309
  br i1 %312, label %313, label %373

313:                                              ; preds = %310
  %314 = sdiv i64 %311, %229
  %315 = mul i64 %314, %229
  %316 = icmp ne i64 %311, %315
  %317 = icmp slt i64 %311, 0
  %318 = icmp slt i64 %229, 0
  %319 = icmp ne i1 %317, %318
  %320 = and i1 %316, %319
  %321 = add i64 %314, -1
  %322 = select i1 %320, i64 %321, i64 %314
  %323 = srem i64 %311, %229
  %324 = icmp slt i64 %323, 0
  %325 = add nsw i64 %323, %229
  %326 = select i1 %324, i64 %325, i64 %323
  %327 = mul nsw i64 %119, %326
  %328 = mul nsw i64 %119, %326
  %329 = mul nsw i64 %328, -1
  %330 = add i64 %205, %329
  %331 = call i64 @llvm.smin.i64(i64 %330, i64 %119)
  %332 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %331)
  %333 = insertvalue { ptr, ptr, i64 } poison, ptr %191, 0
  %334 = insertvalue { ptr, ptr, i64 } %333, ptr %193, 1
  %335 = insertvalue { ptr, ptr, i64 } %334, i64 0, 2
  %336 = mul nsw i64 %322, %115
  %337 = add i64 %173, %336
  %338 = add i64 %337, %327
  %339 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %191, 0
  %340 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %339, ptr %193, 1
  %341 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %340, i64 %338, 2
  %342 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %341, i64 %331, 3, 0
  %343 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %342, i64 1, 4, 0
  %344 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %343, 1
  %345 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %343, 2
  %346 = getelementptr float, ptr %344, i64 %345
  %347 = getelementptr float, ptr %346, i64 0
  %348 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %347, <vscale x 4 x i1> %332, <vscale x 4 x float> poison)
  %349 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %106, 0
  %350 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %106, 1
  %351 = insertvalue { ptr, ptr, i64 } poison, ptr %349, 0
  %352 = insertvalue { ptr, ptr, i64 } %351, ptr %350, 1
  %353 = insertvalue { ptr, ptr, i64 } %352, i64 0, 2
  %354 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %106, 2
  %355 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %106, 3, 0
  %356 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %106, 3, 1
  %357 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %106, 4, 0
  %358 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %106, 4, 1
  %359 = mul nsw i64 %177, 16
  %360 = mul nsw i64 %322, 16
  %361 = add i64 %359, %360
  %362 = add i64 %361, %327
  %363 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %349, 0
  %364 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %363, ptr %350, 1
  %365 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %364, i64 %362, 2
  %366 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %365, i64 %331, 3, 0
  %367 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %366, i64 1, 4, 0
  %368 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %367, 1
  %369 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %367, 2
  %370 = getelementptr float, ptr %368, i64 %369
  %371 = getelementptr float, ptr %370, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %348, ptr align 4 %371, <vscale x 4 x i1> %332)
  %372 = add i64 %311, 1
  br label %310

373:                                              ; preds = %310
  br i1 %206, label %374, label %388

374:                                              ; preds = %386, %373
  %375 = phi i64 [ %387, %386 ], [ 0, %373 ]
  %376 = icmp slt i64 %375, 16
  br i1 %376, label %377, label %388

377:                                              ; preds = %380, %374
  %378 = phi i64 [ %385, %380 ], [ 0, %374 ]
  %379 = icmp slt i64 %378, 64
  br i1 %379, label %380, label %386

380:                                              ; preds = %377
  %381 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %99, 1
  %382 = mul nuw nsw i64 %375, 64
  %383 = add nuw nsw i64 %382, %378
  %384 = getelementptr inbounds nuw float, ptr %381, i64 %383
  store float 0.000000e+00, ptr %384, align 4
  %385 = add i64 %378, 1
  br label %377

386:                                              ; preds = %377
  %387 = add i64 %375, 1
  br label %374

388:                                              ; preds = %374, %373
  %389 = icmp sle i64 %149, 0
  %390 = sub i64 0, %149
  %391 = sub i64 %149, 1
  %392 = select i1 %389, i64 %390, i64 %391
  %393 = sdiv i64 %392, %119
  %394 = sub i64 0, %393
  %395 = add i64 %393, 1
  %396 = select i1 %389, i64 %394, i64 %395
  %397 = icmp sle i64 %149, 0
  %398 = sub i64 0, %149
  %399 = sub i64 %149, 1
  %400 = select i1 %397, i64 %398, i64 %399
  %401 = sdiv i64 %400, %119
  %402 = sub i64 0, %401
  %403 = add i64 %401, 1
  %404 = select i1 %397, i64 %402, i64 %403
  %405 = mul nsw i64 %205, %404
  br label %406

406:                                              ; preds = %409, %388
  %407 = phi i64 [ %466, %409 ], [ 0, %388 ]
  %408 = icmp slt i64 %407, %405
  br i1 %408, label %409, label %467

409:                                              ; preds = %406
  %410 = sdiv i64 %407, %396
  %411 = mul i64 %410, %396
  %412 = icmp ne i64 %407, %411
  %413 = icmp slt i64 %407, 0
  %414 = icmp slt i64 %396, 0
  %415 = icmp ne i1 %413, %414
  %416 = and i1 %412, %415
  %417 = add i64 %410, -1
  %418 = select i1 %416, i64 %417, i64 %410
  %419 = srem i64 %407, %396
  %420 = icmp slt i64 %419, 0
  %421 = add nsw i64 %419, %396
  %422 = select i1 %420, i64 %421, i64 %419
  %423 = mul nsw i64 %119, %422
  %424 = mul nsw i64 %119, %422
  %425 = mul nsw i64 %424, -1
  %426 = add i64 %149, %425
  %427 = call i64 @llvm.smin.i64(i64 %426, i64 %119)
  %428 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %427)
  %429 = insertvalue { ptr, ptr, i64 } poison, ptr %151, 0
  %430 = insertvalue { ptr, ptr, i64 } %429, ptr %153, 1
  %431 = insertvalue { ptr, ptr, i64 } %430, i64 0, 2
  %432 = mul nsw i64 %418, %114
  %433 = add i64 %144, %432
  %434 = add i64 %433, %423
  %435 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %151, 0
  %436 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %435, ptr %153, 1
  %437 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %436, i64 %434, 2
  %438 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %437, i64 %427, 3, 0
  %439 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %438, i64 1, 4, 0
  %440 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %439, 1
  %441 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %439, 2
  %442 = getelementptr float, ptr %440, i64 %441
  %443 = getelementptr float, ptr %442, i64 0
  %444 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %443, <vscale x 4 x i1> %428, <vscale x 4 x float> poison)
  %445 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %99, 0
  %446 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %99, 1
  %447 = insertvalue { ptr, ptr, i64 } poison, ptr %445, 0
  %448 = insertvalue { ptr, ptr, i64 } %447, ptr %446, 1
  %449 = insertvalue { ptr, ptr, i64 } %448, i64 0, 2
  %450 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %99, 2
  %451 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %99, 3, 0
  %452 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %99, 3, 1
  %453 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %99, 4, 0
  %454 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %99, 4, 1
  %455 = mul nsw i64 %418, 64
  %456 = add i64 %455, %423
  %457 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %445, 0
  %458 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %457, ptr %446, 1
  %459 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %458, i64 %456, 2
  %460 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %459, i64 %427, 3, 0
  %461 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %460, i64 1, 4, 0
  %462 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %461, 1
  %463 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %461, 2
  %464 = getelementptr float, ptr %462, i64 %463
  %465 = getelementptr float, ptr %464, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %444, ptr align 4 %465, <vscale x 4 x i1> %428)
  %466 = add i64 %407, 1
  br label %406

467:                                              ; preds = %406
  %468 = icmp sle i64 %161, 0
  %469 = sub i64 0, %161
  %470 = sub i64 %161, 1
  %471 = select i1 %468, i64 %469, i64 %470
  %472 = sdiv i64 %471, %119
  %473 = sub i64 0, %472
  %474 = add i64 %472, 1
  %475 = select i1 %468, i64 %473, i64 %474
  %476 = icmp sle i64 %161, 0
  %477 = sub i64 0, %161
  %478 = sub i64 %161, 1
  %479 = select i1 %476, i64 %477, i64 %478
  %480 = sdiv i64 %479, %119
  %481 = sub i64 0, %480
  %482 = add i64 %480, 1
  %483 = select i1 %476, i64 %481, i64 %482
  %484 = mul nsw i64 %205, %483
  br label %485

485:                                              ; preds = %488, %467
  %486 = phi i64 [ %546, %488 ], [ 0, %467 ]
  %487 = icmp slt i64 %486, %484
  br i1 %487, label %488, label %547

488:                                              ; preds = %485
  %489 = sdiv i64 %486, %475
  %490 = mul i64 %489, %475
  %491 = icmp ne i64 %486, %490
  %492 = icmp slt i64 %486, 0
  %493 = icmp slt i64 %475, 0
  %494 = icmp ne i1 %492, %493
  %495 = and i1 %491, %494
  %496 = add i64 %489, -1
  %497 = select i1 %495, i64 %496, i64 %489
  %498 = srem i64 %486, %475
  %499 = icmp slt i64 %498, 0
  %500 = add nsw i64 %498, %475
  %501 = select i1 %499, i64 %500, i64 %498
  %502 = mul nsw i64 %119, %501
  %503 = mul nsw i64 %119, %501
  %504 = mul nsw i64 %503, -1
  %505 = add i64 %161, %504
  %506 = call i64 @llvm.smin.i64(i64 %505, i64 %119)
  %507 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %506)
  %508 = insertvalue { ptr, ptr, i64 } poison, ptr %163, 0
  %509 = insertvalue { ptr, ptr, i64 } %508, ptr %165, 1
  %510 = insertvalue { ptr, ptr, i64 } %509, i64 0, 2
  %511 = mul nsw i64 %497, %114
  %512 = add i64 %146, %511
  %513 = add i64 %512, %502
  %514 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %163, 0
  %515 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %514, ptr %165, 1
  %516 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %515, i64 %513, 2
  %517 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %516, i64 %506, 3, 0
  %518 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %517, i64 1, 4, 0
  %519 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %518, 1
  %520 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %518, 2
  %521 = getelementptr float, ptr %519, i64 %520
  %522 = getelementptr float, ptr %521, i64 0
  %523 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %522, <vscale x 4 x i1> %507, <vscale x 4 x float> poison)
  %524 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %99, 0
  %525 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %99, 1
  %526 = insertvalue { ptr, ptr, i64 } poison, ptr %524, 0
  %527 = insertvalue { ptr, ptr, i64 } %526, ptr %525, 1
  %528 = insertvalue { ptr, ptr, i64 } %527, i64 0, 2
  %529 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %99, 2
  %530 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %99, 3, 0
  %531 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %99, 3, 1
  %532 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %99, 4, 0
  %533 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %99, 4, 1
  %534 = mul nsw i64 %497, 64
  %535 = add i64 %149, %534
  %536 = add i64 %535, %502
  %537 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %524, 0
  %538 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %537, ptr %525, 1
  %539 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %538, i64 %536, 2
  %540 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %539, i64 %506, 3, 0
  %541 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %540, i64 1, 4, 0
  %542 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %541, 1
  %543 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %541, 2
  %544 = getelementptr float, ptr %542, i64 %543
  %545 = getelementptr float, ptr %544, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %523, ptr align 4 %545, <vscale x 4 x i1> %507)
  %546 = add i64 %486, 1
  br label %485

547:                                              ; preds = %485
  br label %548

548:                                              ; preds = %551, %547
  %549 = phi i64 [ %613, %551 ], [ 0, %547 ]
  %550 = icmp slt i64 %549, 512
  br i1 %550, label %551, label %614

551:                                              ; preds = %548
  %552 = sdiv i64 %549, 32
  %553 = mul i64 %552, 32
  %554 = icmp ne i64 %549, %553
  %555 = icmp slt i64 %549, 0
  %556 = icmp ne i1 %555, false
  %557 = and i1 %554, %556
  %558 = add i64 %552, -1
  %559 = select i1 %557, i64 %558, i64 %552
  %560 = srem i64 %549, 32
  %561 = icmp slt i64 %560, 0
  %562 = add nsw i64 %560, 32
  %563 = select i1 %561, i64 %562, i64 %560
  %564 = call i64 @llvm.smin.i64(i64 %119, i64 1)
  %565 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %564)
  %566 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %106, 0
  %567 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %106, 1
  %568 = insertvalue { ptr, ptr, i64 } poison, ptr %566, 0
  %569 = insertvalue { ptr, ptr, i64 } %568, ptr %567, 1
  %570 = insertvalue { ptr, ptr, i64 } %569, i64 0, 2
  %571 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %106, 2
  %572 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %106, 3, 0
  %573 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %106, 3, 1
  %574 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %106, 4, 0
  %575 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %106, 4, 1
  %576 = mul nsw i64 %563, 16
  %577 = add i64 %576, %559
  %578 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %566, 0
  %579 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %578, ptr %567, 1
  %580 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %579, i64 %577, 2
  %581 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %580, i64 %564, 3, 0
  %582 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %581, i64 1, 4, 0
  %583 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %582, 1
  %584 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %582, 2
  %585 = getelementptr float, ptr %583, i64 %584
  %586 = getelementptr float, ptr %585, i64 0
  %587 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %586, <vscale x 4 x i1> %565, <vscale x 4 x float> poison)
  %588 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %92, 0
  %589 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %92, 1
  %590 = insertvalue { ptr, ptr, i64 } poison, ptr %588, 0
  %591 = insertvalue { ptr, ptr, i64 } %590, ptr %589, 1
  %592 = insertvalue { ptr, ptr, i64 } %591, i64 0, 2
  %593 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %92, 2
  %594 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %92, 3, 0
  %595 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %92, 3, 1
  %596 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %92, 3, 2
  %597 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %92, 3, 3
  %598 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %92, 4, 0
  %599 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %92, 4, 1
  %600 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %92, 4, 2
  %601 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %92, 4, 3
  %602 = mul nsw i64 %559, 32
  %603 = add i64 %602, %563
  %604 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %588, 0
  %605 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %604, ptr %589, 1
  %606 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %605, i64 %603, 2
  %607 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %606, i64 %564, 3, 0
  %608 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %607, i64 1, 4, 0
  %609 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %608, 1
  %610 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %608, 2
  %611 = getelementptr float, ptr %609, i64 %610
  %612 = getelementptr float, ptr %611, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %587, ptr align 4 %612, <vscale x 4 x i1> %565)
  %613 = add i64 %549, 1
  br label %548

614:                                              ; preds = %548
  br label %615

615:                                              ; preds = %672, %614
  %616 = phi i64 [ %700, %672 ], [ 0, %614 ]
  %617 = icmp slt i64 %616, 1024
  br i1 %617, label %618, label %701

618:                                              ; preds = %615
  %619 = sdiv i64 %616, 512
  %620 = mul i64 %619, 512
  %621 = icmp ne i64 %616, %620
  %622 = icmp slt i64 %616, 0
  %623 = icmp ne i1 %622, false
  %624 = and i1 %621, %623
  %625 = add i64 %619, -1
  %626 = select i1 %624, i64 %625, i64 %619
  %627 = srem i64 %616, 512
  %628 = icmp slt i64 %627, 0
  %629 = add nsw i64 %627, 512
  %630 = select i1 %628, i64 %629, i64 %627
  %631 = sdiv i64 %630, 32
  %632 = srem i64 %616, 32
  %633 = icmp slt i64 %632, 0
  %634 = add nsw i64 %632, 32
  %635 = select i1 %633, i64 %634, i64 %632
  %636 = call i64 @llvm.smin.i64(i64 %119, i64 1)
  %637 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %636)
  %638 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %99, 0
  %639 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %99, 1
  %640 = insertvalue { ptr, ptr, i64 } poison, ptr %638, 0
  %641 = insertvalue { ptr, ptr, i64 } %640, ptr %639, 1
  %642 = insertvalue { ptr, ptr, i64 } %641, i64 0, 2
  %643 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %99, 2
  %644 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %99, 3, 0
  %645 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %99, 3, 1
  %646 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %99, 4, 0
  %647 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %99, 4, 1
  %648 = mul nsw i64 %631, 64
  %649 = mul nsw i64 %626, 32
  %650 = add i64 %648, %649
  %651 = add i64 %650, %635
  %652 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %638, 0
  %653 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %652, ptr %639, 1
  %654 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %653, i64 %651, 2
  %655 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %654, i64 %636, 3, 0
  %656 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %655, i64 64, 4, 0
  br label %657

657:                                              ; preds = %669, %618
  %658 = phi i64 [ %671, %669 ], [ 0, %618 ]
  %659 = phi <vscale x 4 x float> [ %670, %669 ], [ poison, %618 ]
  %660 = icmp slt i64 %658, %119
  br i1 %660, label %661, label %672

661:                                              ; preds = %657
  %662 = extractelement <vscale x 4 x i1> %637, i64 %658
  br i1 %662, label %663, label %669

663:                                              ; preds = %661
  %664 = getelementptr float, ptr %639, i64 %651
  %665 = mul nuw nsw i64 %658, 64
  %666 = getelementptr inbounds nuw float, ptr %664, i64 %665
  %667 = load float, ptr %666, align 4
  %668 = insertelement <vscale x 4 x float> %659, float %667, i64 %658
  br label %669

669:                                              ; preds = %663, %661
  %670 = phi <vscale x 4 x float> [ %668, %663 ], [ %659, %661 ]
  %671 = add i64 %658, 1
  br label %657

672:                                              ; preds = %657
  %673 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %81, 0
  %674 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %81, 1
  %675 = insertvalue { ptr, ptr, i64 } poison, ptr %673, 0
  %676 = insertvalue { ptr, ptr, i64 } %675, ptr %674, 1
  %677 = insertvalue { ptr, ptr, i64 } %676, i64 0, 2
  %678 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %81, 2
  %679 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %81, 3, 0
  %680 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %81, 3, 1
  %681 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %81, 3, 2
  %682 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %81, 3, 3
  %683 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %81, 4, 0
  %684 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %81, 4, 1
  %685 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %81, 4, 2
  %686 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %81, 4, 3
  %687 = mul nsw i64 %626, 512
  %688 = mul nsw i64 %631, 32
  %689 = add i64 %687, %688
  %690 = add i64 %689, %635
  %691 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %673, 0
  %692 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %691, ptr %674, 1
  %693 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %692, i64 %690, 2
  %694 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %693, i64 %636, 3, 0
  %695 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %694, i64 1, 4, 0
  %696 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %695, 1
  %697 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %695, 2
  %698 = getelementptr float, ptr %696, i64 %697
  %699 = getelementptr float, ptr %698, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %659, ptr align 4 %699, <vscale x 4 x i1> %637)
  %700 = add i64 %616, 1
  br label %615

701:                                              ; preds = %893, %615
  %702 = phi i64 [ %894, %893 ], [ 0, %615 ]
  %703 = icmp slt i64 %702, %128
  br i1 %703, label %704, label %895

704:                                              ; preds = %701
  %705 = mul nuw nsw i64 %122, %122
  %706 = sdiv i64 %702, %705
  %707 = mul i64 %706, %705
  %708 = icmp ne i64 %702, %707
  %709 = icmp slt i64 %702, 0
  %710 = icmp slt i64 %705, 0
  %711 = icmp ne i1 %709, %710
  %712 = and i1 %708, %711
  %713 = add i64 %706, -1
  %714 = select i1 %712, i64 %713, i64 %706
  %715 = srem i64 %702, %705
  %716 = icmp slt i64 %715, 0
  %717 = add nsw i64 %715, %705
  %718 = select i1 %716, i64 %717, i64 %715
  %719 = sdiv i64 %718, %122
  %720 = srem i64 %702, %122
  %721 = icmp slt i64 %720, 0
  %722 = add nsw i64 %720, %122
  %723 = select i1 %721, i64 %722, i64 %720
  %724 = mul nsw i64 %120, %723
  %725 = mul nsw i64 %120, %719
  %726 = mul nsw i64 %120, %719
  %727 = mul nsw i64 %726, -1
  %728 = add i64 %727, 32
  %729 = call i64 @llvm.smin.i64(i64 %728, i64 %120)
  %730 = mul nsw i64 %120, %723
  %731 = mul nsw i64 %730, -1
  %732 = add i64 %731, 32
  %733 = call i64 @llvm.smin.i64(i64 %732, i64 %120)
  %734 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %70, 0
  %735 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %70, 1
  %736 = insertvalue { ptr, ptr, i64 } poison, ptr %734, 0
  %737 = insertvalue { ptr, ptr, i64 } %736, ptr %735, 1
  %738 = insertvalue { ptr, ptr, i64 } %737, i64 0, 2
  %739 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %70, 2
  %740 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %70, 3, 0
  %741 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %70, 3, 1
  %742 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %70, 3, 2
  %743 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %70, 3, 3
  %744 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %70, 4, 0
  %745 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %70, 4, 1
  %746 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %70, 4, 2
  %747 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %70, 4, 3
  %748 = mul nsw i64 %714, 1024
  %749 = mul nsw i64 %725, 32
  %750 = add i64 %748, %749
  %751 = add i64 %750, %724
  %752 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %734, 0
  %753 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %752, ptr %735, 1
  %754 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %753, i64 %751, 2
  %755 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %754, i64 %729, 3, 0
  %756 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %755, i64 32, 4, 0
  %757 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %756, i64 %733, 3, 1
  %758 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %757, i64 1, 4, 1
  br label %759

759:                                              ; preds = %762, %704
  %760 = phi i64 [ %770, %762 ], [ 0, %704 ]
  %761 = icmp slt i64 %760, %119
  br i1 %761, label %762, label %771

762:                                              ; preds = %759
  %763 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %758, 1
  %764 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %758, 2
  %765 = getelementptr float, ptr %763, i64 %764
  %766 = mul i64 %760, 32
  %767 = add i64 %766, 0
  %768 = getelementptr float, ptr %765, i64 %767
  %769 = trunc i64 %760 to i32
  call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %768, i32 0, i32 %769)
  %770 = add i64 %760, 1
  br label %759

771:                                              ; preds = %759
  br label %772

772:                                              ; preds = %775, %771
  %773 = phi i64 [ %783, %775 ], [ 0, %771 ]
  %774 = icmp slt i64 %773, %119
  br i1 %774, label %775, label %784

775:                                              ; preds = %772
  %776 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %758, 1
  %777 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %758, 2
  %778 = getelementptr float, ptr %776, i64 %777
  %779 = mul i64 %773, 32
  %780 = add i64 %779, %119
  %781 = getelementptr float, ptr %778, i64 %780
  %782 = trunc i64 %773 to i32
  call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %781, i32 1, i32 %782)
  %783 = add i64 %773, 1
  br label %772

784:                                              ; preds = %787, %772
  %785 = phi i64 [ %796, %787 ], [ 0, %772 ]
  %786 = icmp slt i64 %785, %119
  br i1 %786, label %787, label %797

787:                                              ; preds = %784
  %788 = add i64 %119, %785
  %789 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %758, 1
  %790 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %758, 2
  %791 = getelementptr float, ptr %789, i64 %790
  %792 = mul i64 %788, 32
  %793 = add i64 %792, 0
  %794 = getelementptr float, ptr %791, i64 %793
  %795 = trunc i64 %785 to i32
  call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %794, i32 2, i32 %795)
  %796 = add i64 %785, 1
  br label %784

797:                                              ; preds = %800, %784
  %798 = phi i64 [ %809, %800 ], [ 0, %784 ]
  %799 = icmp slt i64 %798, %119
  br i1 %799, label %800, label %810

800:                                              ; preds = %797
  %801 = add i64 %119, %798
  %802 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %758, 1
  %803 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %758, 2
  %804 = getelementptr float, ptr %802, i64 %803
  %805 = mul i64 %801, 32
  %806 = add i64 %805, %119
  %807 = getelementptr float, ptr %804, i64 %806
  %808 = trunc i64 %798 to i32
  call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %807, i32 3, i32 %808)
  %809 = add i64 %798, 1
  br label %797

810:                                              ; preds = %813, %797
  %811 = phi i64 [ %872, %813 ], [ 0, %797 ]
  %812 = icmp slt i64 %811, 16
  br i1 %812, label %813, label %873

813:                                              ; preds = %810
  %814 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %92, 0
  %815 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %92, 1
  %816 = insertvalue { ptr, ptr, i64 } poison, ptr %814, 0
  %817 = insertvalue { ptr, ptr, i64 } %816, ptr %815, 1
  %818 = insertvalue { ptr, ptr, i64 } %817, i64 0, 2
  %819 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %92, 2
  %820 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %92, 3, 0
  %821 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %92, 3, 1
  %822 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %92, 3, 2
  %823 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %92, 3, 3
  %824 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %92, 4, 0
  %825 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %92, 4, 1
  %826 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %92, 4, 2
  %827 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %92, 4, 3
  %828 = mul nsw i64 %811, 32
  %829 = add i64 %725, %828
  %830 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %814, 0
  %831 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %830, ptr %815, 1
  %832 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %831, i64 %829, 2
  %833 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %832, i64 %729, 3, 0
  %834 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %833, i64 1, 4, 0
  %835 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %834, 1
  %836 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %834, 2
  %837 = getelementptr float, ptr %835, i64 %836
  %838 = getelementptr float, ptr %837, i64 0
  %839 = load <vscale x 8 x float>, ptr %838, align 4
  %840 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %81, 0
  %841 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %81, 1
  %842 = insertvalue { ptr, ptr, i64 } poison, ptr %840, 0
  %843 = insertvalue { ptr, ptr, i64 } %842, ptr %841, 1
  %844 = insertvalue { ptr, ptr, i64 } %843, i64 0, 2
  %845 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %81, 2
  %846 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %81, 3, 0
  %847 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %81, 3, 1
  %848 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %81, 3, 2
  %849 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %81, 3, 3
  %850 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %81, 4, 0
  %851 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %81, 4, 1
  %852 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %81, 4, 2
  %853 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %81, 4, 3
  %854 = mul nsw i64 %714, 512
  %855 = add i64 %854, %724
  %856 = mul nsw i64 %811, 32
  %857 = add i64 %855, %856
  %858 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %840, 0
  %859 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %858, ptr %841, 1
  %860 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %859, i64 %857, 2
  %861 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %860, i64 %733, 3, 0
  %862 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %861, i64 1, 4, 0
  %863 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %862, 1
  %864 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %862, 2
  %865 = getelementptr float, ptr %863, i64 %864
  %866 = getelementptr float, ptr %865, i64 0
  %867 = load <vscale x 8 x float>, ptr %866, align 4
  %868 = call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %839, i64 0)
  %869 = call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %867, i64 0)
  call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %868, <vscale x 4 x float> %869)
  %870 = call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %867, i64 4)
  call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %868, <vscale x 4 x float> %870)
  %871 = call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %839, i64 4)
  call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %871, <vscale x 4 x float> %869)
  call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %871, <vscale x 4 x float> %870)
  %872 = add i64 %811, 1
  br label %810

873:                                              ; preds = %876, %810
  %874 = phi i64 [ %892, %876 ], [ 0, %810 ]
  %875 = icmp slt i64 %874, %119
  br i1 %875, label %876, label %893

876:                                              ; preds = %873
  %877 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %758, 1
  %878 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %758, 2
  %879 = getelementptr float, ptr %877, i64 %878
  %880 = mul i64 %874, 32
  %881 = add i64 %880, 0
  %882 = getelementptr float, ptr %879, i64 %881
  %883 = trunc i64 %874 to i32
  call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %882, i32 0, i32 %883)
  %884 = add i64 %880, %119
  %885 = getelementptr float, ptr %879, i64 %884
  call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %885, i32 1, i32 %883)
  %886 = add i64 %119, %874
  %887 = mul i64 %886, 32
  %888 = add i64 %887, 0
  %889 = getelementptr float, ptr %879, i64 %888
  call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %889, i32 2, i32 %883)
  %890 = add i64 %887, %119
  %891 = getelementptr float, ptr %879, i64 %890
  call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %891, i32 3, i32 %883)
  %892 = add i64 %874, 1
  br label %873

893:                                              ; preds = %873
  %894 = add i64 %702, 1
  br label %701

895:                                              ; preds = %701
  %896 = add i64 %140, 16
  %897 = add i64 %141, %130
  %898 = add i32 %139, 1
  br label %138

899:                                              ; preds = %138
  %900 = insertvalue { i64, i64 } poison, i64 %140, 0
  %901 = insertvalue { i64, i64 } %900, i64 %141, 1
  ret { i64, i64 } %901
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.vscale.i64() #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smin.i32(i32, i32) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smin.i64(i64, i64) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smax.i64(i64, i64) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare ptr @llvm.stacksave.p0() #3

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare void @llvm.stackrestore.p0(ptr) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64, i64) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr captures(none), <vscale x 4 x i1>, <vscale x 4 x float>) #4

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float>, ptr captures(none), <vscale x 4 x i1>) #5

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite)
declare void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1>, ptr, i32 immarg, i32) #6

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float>, i64 immarg) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(target_mem1: readwrite)
declare void @llvm.aarch64.sme.mopa.nxv4f32(i32 immarg, <vscale x 4 x i1>, <vscale x 4 x i1>, <vscale x 4 x float>, <vscale x 4 x float>) #7

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite)
declare void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1>, ptr, i32 immarg, i32) #6

attributes #0 = { "aarch64_new_za" "aarch64_pstate_sm_enabled" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nosync nounwind willreturn }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite) }
attributes #7 = { nocallback nofree nosync nounwind willreturn memory(target_mem1: readwrite) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
