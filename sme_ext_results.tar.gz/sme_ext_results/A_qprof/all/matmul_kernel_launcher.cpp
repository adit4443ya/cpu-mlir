
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <chrono>
// From triton_test/utils/dsp/include
#include "common.h"
#include "prof.h"
#include "tensor.h"
// From triton_shared/backend/include
#include "ExecutionEngine/CRunnerUtils.h"
#include "ExecutionEngine/CRunnerUtils.cpp"

extern "C" void matmul_kernel(int64_t, MemRefDescriptor<float, 2> *, int64_t, MemRefDescriptor<float, 2> *, int64_t, MemRefDescriptor<float, 2> *, int, int, int, int, int, int,  int, int, int, int, int, int);
const int alignment = 128;



int main() {

Tensor<float, 2> t0({{179, 167}, {167, 1}, alignment}, MemType::HEAP);
MemRefDescriptor<float, 2> *dt0 = t0.toMemRefDesc(); 
Tensor<float, 2> t1({{167, 321}, {321, 1}, alignment}, MemType::HEAP);
MemRefDescriptor<float, 2> *dt1 = t1.toMemRefDesc(); 
Tensor<float, 2> t2({{179, 321}, {321, 1}, alignment}, MemType::HEAP);
MemRefDescriptor<float, 2> *dt2 = t2.toMemRefDesc(); 
int S0 = 179; 
int S1 = 321; 
int S2 = 167; 
int S3 = 167; 
int S4 = 321; 
int S5 = 321; 


t0.load_from_file("/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/A_qprof/all/matmul_kernel_t0.raw");
t1.load_from_file("/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/A_qprof/all/matmul_kernel_t1.raw");
t2.load_from_file("/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/A_qprof/all/matmul_kernel_t2.raw");


  int gridX = 36;
  int gridY = 1;
  int gridZ = 1;
  if (gridX * gridY * gridZ > 0) {
    
    for(int x = 0; x < gridX; x++) {
      for(int y = 0; y < gridY; y++) {
        for(int z = 0; z < gridZ; z++) {
          matmul_kernel(2, dt0, 2, dt1, 2, dt2, S0, S1, S2, S3, S4, S5, gridX, gridY, gridZ, x, y, z);
        }
      }
    }
    
  }
  

t0.dump_to_file("/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/A_qprof/all/matmul_kernel_o0.raw");
t1.dump_to_file("/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/A_qprof/all/matmul_kernel_o1.raw");
t2.dump_to_file("/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/A_qprof/all/matmul_kernel_o2.raw");

return 0;
}
