	.file	"LLVMDialectModule"
	.text
	.globl	matmul_kernel                   // -- Begin function matmul_kernel
	.p2align	2
	.type	matmul_kernel,@function
matmul_kernel:                          // @matmul_kernel
	.cfi_startproc
// %bb.0:
	stp	d15, d14, [sp, #-176]!          // 16-byte Folded Spill
	.cfi_def_cfa_offset 176
	cntd	x9
	stp	d13, d12, [sp, #16]             // 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             // 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             // 16-byte Folded Spill
	str	x9, [sp, #80]                   // 8-byte Spill
	stp	x28, x27, [sp, #96]             // 16-byte Folded Spill
	stp	x26, x25, [sp, #112]            // 16-byte Folded Spill
	stp	x24, x23, [sp, #128]            // 16-byte Folded Spill
	stp	x22, x21, [sp, #144]            // 16-byte Folded Spill
	stp	x20, x19, [sp, #160]            // 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 112
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	.cfi_offset vg, -96
	.cfi_offset w30, -104
	.cfi_offset w29, -112
	.cfi_offset b8, -120
	.cfi_offset b9, -128
	.cfi_offset b10, -136
	.cfi_offset b11, -144
	.cfi_offset b12, -152
	.cfi_offset b13, -160
	.cfi_offset b14, -168
	.cfi_offset b15, -176
	sub	sp, sp, #144
	ldr	w9, [x29, #128]
	ldr	w8, [x29, #120]
	mov	w0, #8256                       // =0x2040
	ldr	w21, [x29, #168]
	mov	w22, w7
	mov	w23, w6
	stp	w9, w8, [x29, #-192]            // 8-byte Folded Spill
	ldr	w8, [x29, #112]
	stur	x5, [x29, #-88]                 // 8-byte Folded Spill
	stur	x3, [x29, #-168]                // 8-byte Folded Spill
	stur	w8, [x29, #-172]                // 4-byte Folded Spill
	stur	x1, [x29, #-184]                // 8-byte Folded Spill
	bl	malloc
	cntw	x25
	mov	w8, #63                         // =0x3f
	stur	x0, [x29, #-80]                 // 8-byte Folded Spill
	sdiv	x9, x8, x25
	add	x8, x0, #63
	and	x20, x8, #0xffffffffffffffc0
	add	x26, x9, #1
	stur	x9, [x29, #-128]                // 8-byte Folded Spill
	lsl	x27, x26, #5
	tbnz	x9, #63, .LBB0_3
// %bb.1:                               // %.lr.ph.preheader
	movi	v0.2d, #0000000000000000
	mov	x8, xzr
	mov	w9, #64                         // =0x40
.LBB0_2:                                // %.lr.ph
                                        // =>This Inner Loop Header: Depth=1
	udiv	x10, x8, x26
	msub	x11, x10, x26, x8
	add	x10, x20, x10, lsl #8
	add	x8, x8, #1
	mul	x11, x11, x25
	sub	x12, x9, x11
	cmp	x12, x25
	csel	x12, x12, x25, lt
	whilelt	p0.s, xzr, x12
	cmp	x27, x8
	st1w	{ z0.s }, p0, [x10, x11, lsl #2]
	b.ne	.LBB0_2
.LBB0_3:                                // %._crit_edge
	adds	w8, w23, #31
	add	w9, w23, #62
	add	w10, w22, #126
	csel	w8, w9, w8, mi
	adds	w9, w22, #63
	mov	w0, #8256                       // =0x2040
	csel	w9, w10, w9, mi
	asr	w8, w8, #5
	stur	x23, [x29, #-112]               // 8-byte Folded Spill
	asr	w9, w9, #6
	stur	x22, [x29, #-96]                // 8-byte Folded Spill
	lsl	w9, w9, #3
	sdiv	w11, w21, w9
	lsl	w10, w11, #3
	msub	w9, w11, w9, w21
	stur	w11, [x29, #-144]               // 4-byte Folded Spill
	sub	w8, w8, w10
	stur	w10, [x29, #-156]               // 4-byte Folded Spill
	mov	w10, #8                         // =0x8
	cmp	w8, #8
	csel	w8, w8, w10, lt
	sdiv	w10, w21, w8
	sdiv	w9, w9, w8
	msub	w8, w10, w8, w21
	stp	w8, w9, [x29, #24]              // 8-byte Folded Spill
	bl	malloc
	mov	w8, #31                         // =0x1f
	stur	x0, [x29, #-104]                // 8-byte Folded Spill
	sdiv	x9, x8, x25
	add	x8, x0, #63
	and	x28, x8, #0xffffffffffffffc0
	add	x21, x9, #1
	stur	x9, [x29, #-200]                // 8-byte Folded Spill
	lsl	x23, x21, #6
	tbnz	x9, #63, .LBB0_6
// %bb.4:                               // %.lr.ph42
	lsl	x9, x21, #5
	mov	x8, xzr
	and	w10, w21, #0xffff
	mov	w11, #32                        // =0x20
.LBB0_5:                                // =>This Inner Loop Header: Depth=1
	udiv	x12, x8, x9
	udiv	x13, x8, x21
	msub	w14, w12, w9, w8
	and	w14, w14, #0xffff
	msub	x13, x13, x21, x8
	udiv	w14, w14, w10
	add	x8, x8, #1
	mul	x13, x13, x25
	add	x16, x20, x14, lsl #8
	sub	x15, x11, x13
	cmp	x15, x25
	csel	x15, x15, x25, lt
	whilelt	p0.s, xzr, x15
	add	x15, x16, x12, lsl #7
	add	x12, x28, x12, lsl #12
	cmp	x23, x8
	ld1w	{ z0.s }, p0/z, [x15, x13, lsl #2]
	add	x12, x12, x14, lsl #7
	st1w	{ z0.s }, p0, [x12, x13, lsl #2]
	b.ne	.LBB0_5
.LBB0_6:                                // %._crit_edge43
	mov	w0, #2112                       // =0x840
	bl	malloc
	add	x8, x0, #63
	stur	x0, [x29, #-120]                // 8-byte Folded Spill
	mov	w0, #4160                       // =0x1040
	and	x8, x8, #0xffffffffffffffc0
	stur	x8, [x29, #-152]                // 8-byte Folded Spill
	bl	malloc
	stur	x0, [x29, #-136]                // 8-byte Folded Spill
	add	x8, x0, #63
	mov	w0, #2048                       // =0x800
	and	x24, x8, #0xffffffffffffffc0
	bl	malloc
	mov	x22, x0
	mov	w0, #4096                       // =0x1000
	bl	malloc
	sub	sp, sp, #64
	ldr	w8, [x29, #24]                  // 4-byte Reload
	stp	x24, x28, [sp, #24]
	str	x0, [sp, #8]
	str	w8, [sp, #48]
	ldur	w8, [x29, #-144]                // 4-byte Folded Reload
	stur	x22, [x29, #-144]               // 8-byte Folded Spill
	str	w8, [sp, #40]
	ldur	x8, [x29, #-152]                // 8-byte Folded Reload
	stur	x0, [x29, #-152]                // 8-byte Folded Spill
	str	x8, [sp, #16]
	str	x22, [sp]
	smstart	sm
	ldur	x22, [x29, #-96]                // 8-byte Folded Reload
	ldur	x24, [x29, #-112]               // 8-byte Folded Reload
	ldr	w0, [x29, #28]                  // 4-byte Reload
	ldp	w3, w4, [x29, #-192]            // 8-byte Folded Reload
	ldur	x2, [x29, #-168]                // 8-byte Folded Reload
	mov	w1, w22
	mov	w5, w24
	ldur	x6, [x29, #-184]                // 8-byte Folded Reload
	ldur	w7, [x29, #-172]                // 4-byte Folded Reload
	bl	matmul_kernel_sme_0
	add	sp, sp, #64
	smstop	sm
	mov	w0, #8256                       // =0x2040
	bl	malloc
	add	x8, x0, #63
	ldur	x9, [x29, #-200]                // 8-byte Folded Reload
	stur	x0, [x29, #-168]                // 8-byte Folded Spill
	and	x8, x8, #0xffffffffffffffc0
	tbnz	x9, #63, .LBB0_9
// %bb.7:                               // %.lr.ph45
	lsl	x10, x21, #1
	mov	x9, xzr
	and	w11, w21, #0xff
	mov	w12, #32                        // =0x20
.LBB0_8:                                // =>This Inner Loop Header: Depth=1
	udiv	x13, x9, x10
	udiv	x14, x9, x21
	msub	w15, w13, w10, w9
	and	w15, w15, #0xff
	msub	x14, x14, x21, x9
	udiv	w15, w15, w11
	add	x9, x9, #1
	mul	x14, x14, x25
	add	x17, x28, x15, lsl #12
	sub	x16, x12, x14
	cmp	x16, x25
	csel	x16, x16, x25, lt
	whilelt	p0.s, xzr, x16
	add	x16, x17, x13, lsl #7
	add	x13, x8, x13, lsl #8
	cmp	x23, x9
	ld1w	{ z0.s }, p0/z, [x16, x14, lsl #2]
	add	x13, x13, x15, lsl #7
	st1w	{ z0.s }, p0, [x13, x14, lsl #2]
	b.ne	.LBB0_8
.LBB0_9:                                // %.preheader
	ldr	w9, [x29, #136]
	ldur	x10, [x29, #-128]               // 8-byte Folded Reload
	tbnz	x10, #63, .LBB0_12
// %bb.10:                              // %.lr.ph46.preheader
	mov	x10, xzr
	mov	w11, #64                        // =0x40
.LBB0_11:                               // %.lr.ph46
                                        // =>This Inner Loop Header: Depth=1
	udiv	x12, x10, x26
	msub	x13, x12, x26, x10
	add	x10, x10, #1
	mul	x13, x13, x25
	sub	x14, x11, x13
	add	x12, x13, x12, lsl #6
	cmp	x14, x25
	csel	x14, x14, x25, lt
	whilelt	p0.s, xzr, x14
	cmp	x27, x10
	ld1w	{ z0.s }, p0/z, [x8, x12, lsl #2]
	st1w	{ z0.s }, p0, [x20, x12, lsl #2]
	b.ne	.LBB0_11
.LBB0_12:                               // %._crit_edge47
	ldp	w10, w12, [x29, #24]            // 8-byte Folded Reload
	ldur	w8, [x29, #-156]                // 4-byte Folded Reload
	sxtw	x11, w24
	sxtw	x14, w22
	mov	x21, sp
	add	w8, w8, w10
	lsl	w12, w12, #6
	lsl	w8, w8, #5
	sxtw	x12, w12
	sxtw	x10, w8
	smaddl	x8, w8, w9, x12
	sxtw	x9, w9
	add	x13, x10, #32
	cmp	x13, x11
	csel	x11, x13, x11, lt
	add	x13, x12, #64
	cmp	x11, x10
	csel	x11, x11, x10, gt
	cmp	x13, x14
	csel	x13, x13, x14, lt
	sub	x10, x11, x10
	cmp	x13, x12
	csel	x11, x13, x12, gt
	cmp	x10, #32
	mov	w13, #32                        // =0x20
	sub	x11, x11, x12
	csel	x10, x10, x13, lt
	mov	w12, #64                        // =0x40
	ldp	x13, x22, [x29, #-88]           // 16-byte Folded Reload
	cmp	x11, #64
	csel	x11, x11, x12, lt
	mov	x12, sp
	ldr	q0, [x13]
	sub	x13, x12, #64
	mov	sp, x13
	mov	x14, #-63                       // =0xffffffffffffffc1
	stp	x22, x20, [x12, #-64]
	index	z1.d, #0, x14
	stp	xzr, x10, [x12, #-48]
	stur	x11, [x12, #-32]
	add	z1.d, z1.d, #64                 // =0x40
	stur	q1, [x12, #-24]
	mov	x12, sp
	sub	x14, x12, #64
	mov	sp, x14
	stp	x8, x10, [x12, #-48]
	mov	w8, #1                          // =0x1
	stur	x8, [x12, #-16]
	mov	x8, sp
	sub	x1, x8, #16
	stur	q0, [x12, #-64]
	stp	x11, x9, [x12, #-32]
	mov	sp, x1
	mov	w9, #2                          // =0x2
	stp	x9, x13, [x8, #-16]
	mov	x8, sp
	sub	x2, x8, #16
	mov	sp, x2
	mov	w0, #4                          // =0x4
	stp	x9, x14, [x8, #-16]
	bl	memrefCopy
	mov	sp, x21
	mov	x0, x22
	bl	free
	ldur	x0, [x29, #-104]                // 8-byte Folded Reload
	bl	free
	ldur	x0, [x29, #-120]                // 8-byte Folded Reload
	bl	free
	ldur	x0, [x29, #-136]                // 8-byte Folded Reload
	bl	free
	ldur	x0, [x29, #-144]                // 8-byte Folded Reload
	bl	free
	ldur	x0, [x29, #-152]                // 8-byte Folded Reload
	bl	free
	ldur	x0, [x29, #-168]                // 8-byte Folded Reload
	bl	free
	sub	sp, x29, #64
	.cfi_def_cfa wsp, 176
	ldp	x20, x19, [sp, #160]            // 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            // 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            // 16-byte Folded Reload
	ldp	x26, x25, [sp, #112]            // 16-byte Folded Reload
	ldp	x28, x27, [sp, #96]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #64]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               // 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             // 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             // 16-byte Folded Reload
	ldp	d15, d14, [sp], #176            // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore vg
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	.cfi_restore b12
	.cfi_restore b13
	.cfi_restore b14
	.cfi_restore b15
	ret
.Lfunc_end0:
	.size	matmul_kernel, .Lfunc_end0-matmul_kernel
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function matmul_kernel_sme_0
	.type	matmul_kernel_sme_0,@function
matmul_kernel_sme_0:                    // @matmul_kernel_sme_0
// %bb.0:
	stp	x29, x30, [sp, #-96]!           // 16-byte Folded Spill
	stp	x28, x27, [sp, #16]             // 16-byte Folded Spill
	mov	x29, sp
	stp	x26, x25, [sp, #32]             // 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             // 16-byte Folded Spill
	sub	sp, sp, #2272
	addvl	sp, sp, #-2
	rdsvl	x8, #1
	mov	x9, sp
	mov	x19, sp
	msub	x9, x8, x8, x9
	mov	sp, x9
	stp	x9, x8, [x19, #208]
	mrs	x8, TPIDR2_EL0
	cbz	x8, .LBB1_2
// %bb.1:
	bl	__arm_tpidr2_save
	msr	TPIDR2_EL0, xzr
	zero	{za}
.LBB1_2:
	smstart	za
	adds	w8, w7, #15
	add	w9, w7, #30
	stp	x2, x6, [x19, #96]              // 16-byte Folded Spill
	csel	w11, w9, w8, mi
	cmp	w8, #16
	str	w7, [x19, #116]                 // 4-byte Spill
	b.lt	.LBB1_49
// %bb.3:                               // %.lr.ph50
	cnth	x6
	mov	w8, #31                         // =0x1f
	ldr	w10, [x29, #144]
	sdiv	x12, x8, x6
	sxtw	x13, w1
	cntw	x26
	asr	w11, w11, #4
	ldr	w8, [x29, #136]
	cmp	x26, #1
	ldp	x21, x7, [x29, #120]
	str	x13, [x19, #72]                 // 8-byte Spill
	smull	x13, w5, w4
	lsl	w10, w10, #5
	str	w11, [x19, #52]                 // 4-byte Spill
	csinc	x11, x26, xzr, lt
	sxtw	x25, w4
	lsl	w9, w0, #6
	whilelt	p2.s, xzr, x11
	add	w8, w10, w8, lsl #8
	index	z4.s, #0, #1
	str	x13, [x19, #56]                 // 8-byte Spill
	lsl	w13, w3, #4
	mov	x20, x7
	ldp	x30, x22, [x29, #104]
	incb	x20
	mov	z5.s, p2/z, #1                  // =0x1
	smull	x16, w25, w8
	ldr	x24, [x29, #96]
	sxtw	x0, w3
	ptrue	p1.s
	sxtw	x11, w9
	sxtw	x9, w13
	mov	x18, xzr
	mov	w2, wzr
	mov	x3, #32                         // =0x20
	mov	x4, #64                         // =0x40
	mov	x5, #96                         // =0x60
	sub	x8, x29, #1024
	stp	x9, x11, [x19, #24]             // 16-byte Folded Spill
	stp	x30, x7, [x19, #80]             // 16-byte Folded Spill
	str	x0, [x19, #64]                  // 8-byte Spill
	str	p2, [x29, #-1, mul vl]          // 2-byte Spill
	add	x27, x12, #1
	str	z5, [x8, #-2, mul vl]           // 16-byte Folded Spill
	mul	x28, x27, x27
	str	x20, [x19, #40]                 // 8-byte Spill
	lsl	x10, x28, #1
	cmp	x10, #1
	csinc	x23, x10, xzr, hi
	ldr	w10, [x19, #116]                // 4-byte Reload
	str	x23, [x19, #16]                 // 8-byte Spill
	b	.LBB1_5
.LBB1_4:                                // %._crit_edge48
                                        //   in Loop: Header=BB1_5 Depth=1
	ldr	w8, [x19, #52]                  // 4-byte Reload
	add	w2, w2, #1
	ldr	x16, [x19, #200]                // 8-byte Reload
	ldr	w10, [x19, #172]                // 4-byte Reload
	cmp	w2, w8
	ldr	x8, [x19, #24]                  // 8-byte Reload
	add	x16, x16, #16
	sub	w10, w10, #16
	add	x18, x18, x8
	b.eq	.LBB1_49
.LBB1_5:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB1_11 Depth 2
                                        //     Child Loop BB1_14 Depth 2
                                        //     Child Loop BB1_21 Depth 2
                                        //     Child Loop BB1_24 Depth 2
                                        //     Child Loop BB1_26 Depth 2
                                        //     Child Loop BB1_29 Depth 2
                                        //       Child Loop BB1_32 Depth 3
                                        //     Child Loop BB1_37 Depth 2
                                        //       Child Loop BB1_39 Depth 3
                                        //       Child Loop BB1_41 Depth 3
                                        //       Child Loop BB1_43 Depth 3
                                        //       Child Loop BB1_45 Depth 3
                                        //       Child Loop BB1_48 Depth 3
	sdiv	x8, x16, x25
	ldr	x9, [x19, #32]                  // 8-byte Reload
	ldr	x11, [x19, #72]                 // 8-byte Reload
	str	w10, [x19, #172]                // 4-byte Spill
	add	x13, x18, x9
	str	x16, [x19, #200]                // 8-byte Spill
	str	x18, [x19, #176]                // 8-byte Spill
	sdiv	x9, x13, x11
	mul	x12, x8, x25
	ldr	x8, [x19, #56]                  // 8-byte Reload
	sub	x8, x8, x12
	stp	x12, x13, [x19, #120]           // 16-byte Folded Spill
	sdiv	x8, x8, x25
	mul	x12, x9, x11
	bic	w9, w10, w10, asr #31
	ldr	w10, [x19, #116]                // 4-byte Reload
	cmp	x9, #16
	str	x12, [x19, #136]                // 8-byte Spill
	sub	x12, x13, x12
	sub	w13, w10, w2, lsl #4
	str	x12, [x19, #152]                // 8-byte Spill
	add	x10, x12, #64
	mov	w12, #16                        // =0x10
	csel	x17, x9, x12, lo
	cmp	x10, x11
	bic	w9, w13, w13, asr #31
	csel	x10, x10, x11, lt
	str	x17, [x19, #160]                // 8-byte Spill
	str	x10, [x19, #144]                // 8-byte Spill
	ldr	x10, [x19, #96]                 // 8-byte Reload
	ldr	x11, [x10, #8]
	mov	w10, #32                        // =0x20
	cmp	x8, #32
	csel	x23, x8, x10, lt
	ldr	x8, [x19, #104]                 // 8-byte Reload
	cmp	w9, #16
	csel	w20, w9, w12, lt
	cmp	w13, #15
	ldr	x8, [x8, #8]
	stp	x8, x11, [x19, #184]            // 16-byte Folded Spill
	b.gt	.LBB1_9
// %bb.6:                               // %.preheader11.preheader
                                        //   in Loop: Header=BB1_5 Depth=1
	add	x8, x19, #208
	mov	x0, x24
	mov	w1, wzr
	msr	TPIDR2_EL0, x8
	stp	w13, w2, [x19, #8]              // 8-byte Folded Spill
	mov	w2, #2048                       // =0x800
	bl	__arm_sc_memset
	sub	x8, x29, #1024
	index	z4.s, #0, #1
	ldr	p2, [x29, #-1, mul vl]          // 2-byte Reload
	ldp	w13, w2, [x19, #8]              // 8-byte Folded Reload
	ldr	z5, [x8, #-2, mul vl]           // 16-byte Folded Reload
	ldp	x30, x7, [x19, #80]             // 16-byte Folded Reload
	ptrue	p1.s
	mov	x5, #96                         // =0x60
	mov	x4, #64                         // =0x40
	mov	x3, #32                         // =0x20
	cnth	x6
	smstart	za
	mrs	x8, TPIDR2_EL0
	add	x0, x19, #208
	cbnz	x8, .LBB1_8
// %bb.7:                               // %.preheader11.preheader
                                        //   in Loop: Header=BB1_5 Depth=1
	bl	__arm_tpidr2_restore
.LBB1_8:                                // %.preheader11.preheader
                                        //   in Loop: Header=BB1_5 Depth=1
	ldr	x17, [x19, #160]                // 8-byte Reload
	ldr	x16, [x19, #200]                // 8-byte Reload
	ldr	x0, [x19, #64]                  // 8-byte Reload
	ldr	x18, [x19, #176]                // 8-byte Reload
	msr	TPIDR2_EL0, xzr
.LBB1_9:                                // %.loopexit17
                                        //   in Loop: Header=BB1_5 Depth=1
	sub	x8, x20, #1
	cmp	w13, #1
	mov	w1, w13
	csneg	x8, x8, x20, ge
	cmp	w13, #1
	sdiv	x8, x8, x26
	neg	x9, x8
	csinc	x8, x9, x8, lt
	mul	x9, x8, x23
	cmp	x9, #1
	b.lt	.LBB1_12
// %bb.10:                              // %.lr.ph
                                        //   in Loop: Header=BB1_5 Depth=1
	ldr	x10, [x19, #184]                // 8-byte Reload
	mov	x11, xzr
	add	x10, x10, x16, lsl #2
.LBB1_11:                               //   Parent Loop BB1_5 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	sdiv	x12, x11, x8
	cmp	x8, #0
	cset	w14, mi
	mul	x13, x12, x8
	subs	x13, x11, x13
	add	x11, x11, #1
	mul	x13, x13, x26
	csel	w14, wzr, w14, eq
	sub	x12, x12, x14
	mul	x14, x12, x25
	add	x12, x24, x12, lsl #6
	sub	x15, x20, x13
	cmp	x15, x26
	csel	x15, x15, x26, lt
	add	x14, x10, x14, lsl #2
	whilelt	p0.s, xzr, x15
	cmp	x9, x11
	ld1w	{ z0.s }, p0/z, [x14, x13, lsl #2]
	st1w	{ z0.s }, p0, [x12, x13, lsl #2]
	b.ne	.LBB1_11
.LBB1_12:                               // %._crit_edge
                                        //   in Loop: Header=BB1_5 Depth=1
	mov	w9, #32                         // =0x20
	sub	x9, x9, x23
	mul	x9, x8, x9
	cmp	x9, #1
	b.lt	.LBB1_15
// %bb.13:                              // %.lr.ph21
                                        //   in Loop: Header=BB1_5 Depth=1
	ldr	x10, [x19, #120]                // 8-byte Reload
	ldr	x11, [x19, #184]                // 8-byte Reload
	sub	x10, x16, x10
	add	x10, x11, x10, lsl #2
	mov	x11, xzr
.LBB1_14:                               //   Parent Loop BB1_5 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	sdiv	x12, x11, x8
	cmp	x8, #0
	cset	w14, mi
	mul	x13, x12, x8
	subs	x13, x11, x13
	add	x11, x11, #1
	mul	x13, x13, x26
	csel	w14, wzr, w14, eq
	sub	x12, x12, x14
	mul	x14, x12, x25
	add	x12, x12, x23
	add	x12, x24, x12, lsl #6
	sub	x15, x20, x13
	cmp	x15, x26
	csel	x15, x15, x26, lt
	add	x14, x10, x14, lsl #2
	whilelt	p0.s, xzr, x15
	cmp	x9, x11
	ld1w	{ z0.s }, p0/z, [x14, x13, lsl #2]
	st1w	{ z0.s }, p0, [x12, x13, lsl #2]
	b.ne	.LBB1_14
.LBB1_15:                               // %._crit_edge22
                                        //   in Loop: Header=BB1_5 Depth=1
	cmp	w1, #15
	b.gt	.LBB1_19
// %bb.16:                              // %.preheader10.preheader
                                        //   in Loop: Header=BB1_5 Depth=1
	add	x8, x19, #208
	mov	x0, x30
	mov	w1, wzr
	mov	w23, w2
	mov	w2, #4096                       // =0x1000
	msr	TPIDR2_EL0, x8
	bl	__arm_sc_memset
	sub	x8, x29, #1024
	index	z4.s, #0, #1
	ldr	p2, [x29, #-1, mul vl]          // 2-byte Reload
	ldr	z5, [x8, #-2, mul vl]           // 16-byte Folded Reload
	ldp	x30, x7, [x19, #80]             // 16-byte Folded Reload
	ptrue	p1.s
	mov	x5, #96                         // =0x60
	mov	x4, #64                         // =0x40
	mov	x3, #32                         // =0x20
	cnth	x6
	mov	w2, w23
	smstart	za
	mrs	x8, TPIDR2_EL0
	add	x0, x19, #208
	cbnz	x8, .LBB1_18
// %bb.17:                              // %.preheader10.preheader
                                        //   in Loop: Header=BB1_5 Depth=1
	bl	__arm_tpidr2_restore
.LBB1_18:                               // %.preheader10.preheader
                                        //   in Loop: Header=BB1_5 Depth=1
	ldr	x17, [x19, #160]                // 8-byte Reload
	ldr	x0, [x19, #64]                  // 8-byte Reload
	ldr	x18, [x19, #176]                // 8-byte Reload
	msr	TPIDR2_EL0, xzr
.LBB1_19:                               // %.loopexit
                                        //   in Loop: Header=BB1_5 Depth=1
	ldp	x9, x8, [x19, #144]             // 16-byte Folded Reload
	sub	x8, x9, x8
	neg	x9, x8
	subs	x10, x8, #1
	csel	x9, x9, x10, lt
	cmp	x8, #1
	sdiv	x9, x9, x26
	neg	x10, x9
	csinc	x9, x10, x9, lt
	mul	x10, x9, x20
	cmp	x10, #1
	b.lt	.LBB1_22
// %bb.20:                              // %.lr.ph24
                                        //   in Loop: Header=BB1_5 Depth=1
	mul	x10, x9, x17
	ldr	x11, [x19, #192]                // 8-byte Reload
	ldr	x12, [x19, #128]                // 8-byte Reload
	add	x11, x11, x12, lsl #2
	mov	x12, xzr
.LBB1_21:                               //   Parent Loop BB1_5 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	sdiv	x13, x12, x9
	cmp	x9, #0
	cset	w15, mi
	mul	x14, x13, x9
	subs	x14, x12, x14
	add	x12, x12, #1
	mul	x14, x14, x26
	csel	w15, wzr, w15, eq
	sub	x13, x13, x15
	mul	x15, x13, x0
	add	x13, x30, x13, lsl #8
	sub	x16, x8, x14
	cmp	x16, x26
	csel	x16, x16, x26, lt
	add	x15, x11, x15, lsl #2
	whilelt	p0.s, xzr, x16
	cmp	x10, x12
	ld1w	{ z0.s }, p0/z, [x15, x14, lsl #2]
	st1w	{ z0.s }, p0, [x13, x14, lsl #2]
	b.ne	.LBB1_21
.LBB1_22:                               // %._crit_edge25
                                        //   in Loop: Header=BB1_5 Depth=1
	mov	w10, #63                        // =0x3f
	sub	x9, x8, #64
	cmp	x8, #63
	sub	x10, x10, x8
	ldr	x23, [x19, #16]                 // 8-byte Reload
	csel	x9, x9, x10, gt
	cmp	x8, #63
	sdiv	x9, x9, x26
	neg	x10, x9
	csinc	x9, x10, x9, gt
	mul	x10, x9, x20
	cmp	x10, #1
	b.lt	.LBB1_25
// %bb.23:                              // %.lr.ph27
                                        //   in Loop: Header=BB1_5 Depth=1
	mul	x11, x9, x17
	ldr	x12, [x19, #136]                // 8-byte Reload
	ldr	x13, [x19, #192]                // 8-byte Reload
	mov	w14, #64                        // =0x40
	mov	x10, xzr
	add	x12, x13, x12, lsl #2
	add	x13, x30, x8, lsl #2
	sub	x8, x14, x8
.LBB1_24:                               //   Parent Loop BB1_5 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	sdiv	x14, x10, x9
	cmp	x9, #0
	cset	w16, mi
	mul	x15, x14, x9
	subs	x15, x10, x15
	add	x10, x10, #1
	mul	x15, x15, x26
	csel	w16, wzr, w16, eq
	sub	x14, x14, x16
	mul	x16, x14, x0
	add	x14, x13, x14, lsl #8
	sub	x17, x8, x15
	cmp	x17, x26
	csel	x17, x17, x26, lt
	add	x16, x12, x16, lsl #2
	whilelt	p0.s, xzr, x17
	cmp	x11, x10
	ld1w	{ z0.s }, p0/z, [x16, x15, lsl #2]
	st1w	{ z0.s }, p0, [x14, x15, lsl #2]
	b.ne	.LBB1_24
.LBB1_25:                               // %.preheader14.preheader
                                        //   in Loop: Header=BB1_5 Depth=1
	ldr	x20, [x19, #40]                 // 8-byte Reload
	mov	x8, xzr
	mov	x9, xzr
	mov	x16, #128                       // =0x80
	mov	x17, #160                       // =0xa0
.LBB1_26:                               // %.preheader14
                                        //   Parent Loop BB1_5 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	and	x10, x8, #0x7c0
	lsr	x11, x9, #5
	add	x8, x8, #64
	add	x10, x24, x10
	add	x10, x10, x11, lsl #2
	ld1w	{ z0.s }, p2/z, [x10]
	st1w	{ z0.s }, p2, [x22, x9, lsl #2]
	add	x9, x9, #1
	cmp	x9, #512
	b.ne	.LBB1_26
// %bb.27:                              // %.preheader13.preheader
                                        //   in Loop: Header=BB1_5 Depth=1
	mov	x8, xzr
	b	.LBB1_29
.LBB1_28:                               // %._crit_edge32
                                        //   in Loop: Header=BB1_29 Depth=2
	and	x10, x8, #0x200
	and	x11, x8, #0x1f
	add	x8, x8, #1
	add	x10, x21, x10, lsl #2
	cmp	x8, #1024
	add	x9, x10, x9, lsl #7
	st1w	{ z0.s }, p2, [x9, x11, lsl #2]
	b.eq	.LBB1_34
.LBB1_29:                               // %.preheader13
                                        //   Parent Loop BB1_5 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB1_32 Depth 3
	ubfx	x9, x8, #5, #4
	cmp	x26, #1
                                        // implicit-def: $z0
	b.lt	.LBB1_28
// %bb.30:                              // %.lr.ph31
                                        //   in Loop: Header=BB1_29 Depth=2
	lsl	x11, x9, #8
	lsr	x12, x8, #9
	mov	x10, xzr
                                        // implicit-def: $z0
	add	x11, x11, x12, lsl #7
	bfi	x11, x8, #2, #5
	add	x11, x30, x11
	b	.LBB1_32
.LBB1_31:                               //   in Loop: Header=BB1_32 Depth=3
	add	x10, x10, #1
	add	x11, x11, #256
	mov	x12, x10
	decw	x12
	cbz	x12, .LBB1_28
.LBB1_32:                               //   Parent Loop BB1_5 Depth=1
                                        //     Parent Loop BB1_29 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	whilels	p0.s, xzr, x10
	lastb	w12, p0, z5.s
	tbz	w12, #0, .LBB1_31
// %bb.33:                              //   in Loop: Header=BB1_32 Depth=3
	mov	z1.s, w10
	cmpeq	p0.s, p1/z, z4.s, z1.s
	ldr	s1, [x11]
	mov	z0.s, p0/m, s1
	b	.LBB1_31
.LBB1_34:                               // %.preheader12
                                        //   in Loop: Header=BB1_5 Depth=1
	cbz	x27, .LBB1_4
// %bb.35:                              // %.lr.ph47.preheader
                                        //   in Loop: Header=BB1_5 Depth=1
	mov	x8, xzr
	b	.LBB1_37
.LBB1_36:                               // %._crit_edge42
                                        //   in Loop: Header=BB1_37 Depth=2
	add	x8, x8, #1
	cmp	x8, x23
	b.eq	.LBB1_4
.LBB1_37:                               // %.lr.ph47
                                        //   Parent Loop BB1_5 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB1_39 Depth 3
                                        //       Child Loop BB1_41 Depth 3
                                        //       Child Loop BB1_43 Depth 3
                                        //       Child Loop BB1_45 Depth 3
                                        //       Child Loop BB1_48 Depth 3
	udiv	x10, x8, x28
	cmp	x26, #1
	msub	x11, x10, x28, x8
	sdiv	x9, x8, x27
	sdiv	x11, x11, x27
	msub	x9, x9, x27, x8
	mul	x12, x9, x6
	mul	x13, x11, x6
	lsl	x9, x13, #5
	add	x9, x9, x10, lsl #10
	add	x11, x9, x12
	add	x9, x7, x11, lsl #2
	b.lt	.LBB1_46
// %bb.38:                              // %.lr.ph34
                                        //   in Loop: Header=BB1_37 Depth=2
	mov	x14, xzr
.LBB1_39:                               //   Parent Loop BB1_5 Depth=1
                                        //     Parent Loop BB1_37 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	add	x15, x9, x14, lsl #7
	ld1w	{za0h.s[w14, 0]}, p1/z, [x15]
	add	x14, x14, #1
	mov	x15, x14
	decw	x15
	cbnz	x15, .LBB1_39
// %bb.40:                              // %.lr.ph35
                                        //   in Loop: Header=BB1_37 Depth=2
	add	x11, x20, x11, lsl #2
	mov	x14, xzr
.LBB1_41:                               //   Parent Loop BB1_5 Depth=1
                                        //     Parent Loop BB1_37 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	add	x15, x11, x14, lsl #7
	ld1w	{za1h.s[w14, 0]}, p1/z, [x15]
	add	x14, x14, #1
	mov	x15, x14
	decw	x15
	cbnz	x15, .LBB1_41
// %bb.42:                              // %.lr.ph37
                                        //   in Loop: Header=BB1_37 Depth=2
	mov	x14, xzr
.LBB1_43:                               //   Parent Loop BB1_5 Depth=1
                                        //     Parent Loop BB1_37 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	mov	x15, x14
	incw	x15
	add	x15, x9, x15, lsl #7
	ld1w	{za2h.s[w14, 0]}, p1/z, [x15]
	add	x14, x14, #1
	cmp	x14, x26
	b.ne	.LBB1_43
// %bb.44:                              // %.lr.ph38
                                        //   in Loop: Header=BB1_37 Depth=2
	mov	x14, xzr
.LBB1_45:                               //   Parent Loop BB1_5 Depth=1
                                        //     Parent Loop BB1_37 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	mov	x15, x14
	incw	x15
	add	x15, x11, x15, lsl #7
	ld1w	{za3h.s[w14, 0]}, p1/z, [x15]
	add	x14, x14, #1
	cmp	x14, x26
	b.ne	.LBB1_45
.LBB1_46:                               // %.preheader6
                                        //   in Loop: Header=BB1_37 Depth=2
	add	x14, x21, x10, lsl #11
	add	x11, x22, x13, lsl #2
	ld1w	{ z0.s }, p1/z, [x22, x13, lsl #2]
	cmp	x26, #0
	add	x10, x14, x12, lsl #2
	ld1w	{ z1.s }, p1/z, [x14, x12, lsl #2]
	ldr	z2, [x11, #1, mul vl]
	add	x12, x11, #128
	mov	x14, #192                       // =0xc0
	ldr	z3, [x10, #1, mul vl]
	add	x13, x10, #128
	fmopa	za0.s, p1/m, p1/m, z0.s, z1.s
	fmopa	za1.s, p1/m, p1/m, z0.s, z3.s
	fmopa	za2.s, p1/m, p1/m, z2.s, z1.s
	fmopa	za3.s, p1/m, p1/m, z2.s, z3.s
	ld1w	{ z0.s }, p1/z, [x11, x3, lsl #2]
	ldr	z1, [x13, #1, mul vl]
	ld1w	{ z2.s }, p1/z, [x10, x3, lsl #2]
	ldr	z3, [x12, #1, mul vl]
	add	x12, x11, #256
	add	x13, x10, #256
	fmopa	za0.s, p1/m, p1/m, z0.s, z2.s
	fmopa	za1.s, p1/m, p1/m, z0.s, z1.s
	fmopa	za2.s, p1/m, p1/m, z3.s, z2.s
	fmopa	za3.s, p1/m, p1/m, z3.s, z1.s
	ldr	z0, [x12, #1, mul vl]
	ld1w	{ z1.s }, p1/z, [x11, x4, lsl #2]
	ldr	z2, [x13, #1, mul vl]
	ld1w	{ z3.s }, p1/z, [x10, x4, lsl #2]
	add	x12, x11, #384
	add	x13, x10, #384
	fmopa	za0.s, p1/m, p1/m, z1.s, z3.s
	fmopa	za1.s, p1/m, p1/m, z1.s, z2.s
	fmopa	za2.s, p1/m, p1/m, z0.s, z3.s
	fmopa	za3.s, p1/m, p1/m, z0.s, z2.s
	ld1w	{ z0.s }, p1/z, [x11, x5, lsl #2]
	ld1w	{ z1.s }, p1/z, [x10, x5, lsl #2]
	ldr	z2, [x12, #1, mul vl]
	ldr	z3, [x13, #1, mul vl]
	add	x12, x11, #512
	add	x13, x10, #512
	fmopa	za0.s, p1/m, p1/m, z0.s, z1.s
	fmopa	za1.s, p1/m, p1/m, z0.s, z3.s
	fmopa	za2.s, p1/m, p1/m, z2.s, z1.s
	fmopa	za3.s, p1/m, p1/m, z2.s, z3.s
	ld1w	{ z0.s }, p1/z, [x11, x16, lsl #2]
	ldr	z1, [x13, #1, mul vl]
	ld1w	{ z2.s }, p1/z, [x10, x16, lsl #2]
	ldr	z3, [x12, #1, mul vl]
	add	x12, x11, #640
	add	x13, x10, #640
	fmopa	za0.s, p1/m, p1/m, z0.s, z2.s
	fmopa	za1.s, p1/m, p1/m, z0.s, z1.s
	fmopa	za2.s, p1/m, p1/m, z3.s, z2.s
	fmopa	za3.s, p1/m, p1/m, z3.s, z1.s
	ldr	z0, [x12, #1, mul vl]
	ld1w	{ z1.s }, p1/z, [x11, x17, lsl #2]
	ldr	z2, [x13, #1, mul vl]
	ld1w	{ z3.s }, p1/z, [x10, x17, lsl #2]
	add	x12, x11, #768
	add	x13, x10, #768
	fmopa	za0.s, p1/m, p1/m, z1.s, z3.s
	fmopa	za1.s, p1/m, p1/m, z1.s, z2.s
	fmopa	za2.s, p1/m, p1/m, z0.s, z3.s
	fmopa	za3.s, p1/m, p1/m, z0.s, z2.s
	ld1w	{ z0.s }, p1/z, [x11, x14, lsl #2]
	ld1w	{ z1.s }, p1/z, [x10, x14, lsl #2]
	ldr	z2, [x12, #1, mul vl]
	ldr	z3, [x13, #1, mul vl]
	add	x12, x11, #896
	add	x13, x10, #896
	mov	x14, #224                       // =0xe0
	fmopa	za0.s, p1/m, p1/m, z0.s, z1.s
	fmopa	za1.s, p1/m, p1/m, z0.s, z3.s
	fmopa	za2.s, p1/m, p1/m, z2.s, z1.s
	fmopa	za3.s, p1/m, p1/m, z2.s, z3.s
	ld1w	{ z0.s }, p1/z, [x11, x14, lsl #2]
	ldr	z1, [x13, #1, mul vl]
	ld1w	{ z2.s }, p1/z, [x10, x14, lsl #2]
	ldr	z3, [x12, #1, mul vl]
	add	x12, x11, #1024
	add	x13, x10, #1024
	mov	x14, #288                       // =0x120
	fmopa	za0.s, p1/m, p1/m, z0.s, z2.s
	fmopa	za1.s, p1/m, p1/m, z0.s, z1.s
	fmopa	za2.s, p1/m, p1/m, z3.s, z2.s
	fmopa	za3.s, p1/m, p1/m, z3.s, z1.s
	ldr	z0, [x12, #1, mul vl]
	mov	x12, #256                       // =0x100
	ldr	z2, [x13, #1, mul vl]
	add	x13, x10, #1152
	ld1w	{ z1.s }, p1/z, [x11, x12, lsl #2]
	ld1w	{ z3.s }, p1/z, [x10, x12, lsl #2]
	add	x12, x11, #1152
	fmopa	za0.s, p1/m, p1/m, z1.s, z3.s
	fmopa	za1.s, p1/m, p1/m, z1.s, z2.s
	fmopa	za2.s, p1/m, p1/m, z0.s, z3.s
	fmopa	za3.s, p1/m, p1/m, z0.s, z2.s
	ld1w	{ z0.s }, p1/z, [x11, x14, lsl #2]
	ld1w	{ z1.s }, p1/z, [x10, x14, lsl #2]
	ldr	z2, [x12, #1, mul vl]
	ldr	z3, [x13, #1, mul vl]
	add	x12, x11, #1280
	add	x13, x10, #1280
	mov	x14, #320                       // =0x140
	fmopa	za0.s, p1/m, p1/m, z0.s, z1.s
	fmopa	za1.s, p1/m, p1/m, z0.s, z3.s
	fmopa	za2.s, p1/m, p1/m, z2.s, z1.s
	fmopa	za3.s, p1/m, p1/m, z2.s, z3.s
	ld1w	{ z0.s }, p1/z, [x11, x14, lsl #2]
	ldr	z1, [x13, #1, mul vl]
	ld1w	{ z2.s }, p1/z, [x10, x14, lsl #2]
	ldr	z3, [x12, #1, mul vl]
	add	x12, x11, #1408
	add	x13, x10, #1408
	mov	x14, #448                       // =0x1c0
	fmopa	za0.s, p1/m, p1/m, z0.s, z2.s
	fmopa	za1.s, p1/m, p1/m, z0.s, z1.s
	fmopa	za2.s, p1/m, p1/m, z3.s, z2.s
	fmopa	za3.s, p1/m, p1/m, z3.s, z1.s
	ldr	z0, [x12, #1, mul vl]
	mov	x12, #352                       // =0x160
	ldr	z2, [x13, #1, mul vl]
	mov	x13, #384                       // =0x180
	ld1w	{ z1.s }, p1/z, [x11, x12, lsl #2]
	ld1w	{ z3.s }, p1/z, [x10, x12, lsl #2]
	add	x12, x11, #1536
	fmopa	za0.s, p1/m, p1/m, z1.s, z3.s
	fmopa	za1.s, p1/m, p1/m, z1.s, z2.s
	fmopa	za2.s, p1/m, p1/m, z0.s, z3.s
	fmopa	za3.s, p1/m, p1/m, z0.s, z2.s
	ldr	z0, [x12, #1, mul vl]
	add	x12, x10, #1536
	ld1w	{ z1.s }, p1/z, [x11, x13, lsl #2]
	ldr	z2, [x12, #1, mul vl]
	ld1w	{ z3.s }, p1/z, [x10, x13, lsl #2]
	add	x12, x11, #1664
	mov	x13, #416                       // =0x1a0
	fmopa	za0.s, p1/m, p1/m, z1.s, z3.s
	fmopa	za1.s, p1/m, p1/m, z1.s, z2.s
	fmopa	za2.s, p1/m, p1/m, z0.s, z3.s
	fmopa	za3.s, p1/m, p1/m, z0.s, z2.s
	ldr	z0, [x12, #1, mul vl]
	add	x12, x10, #1664
	ld1w	{ z1.s }, p1/z, [x11, x13, lsl #2]
	ldr	z2, [x12, #1, mul vl]
	ld1w	{ z3.s }, p1/z, [x10, x13, lsl #2]
	add	x12, x11, #1792
	add	x13, x10, #1792
	fmopa	za0.s, p1/m, p1/m, z1.s, z3.s
	fmopa	za1.s, p1/m, p1/m, z1.s, z2.s
	fmopa	za2.s, p1/m, p1/m, z0.s, z3.s
	fmopa	za3.s, p1/m, p1/m, z0.s, z2.s
	ld1w	{ z0.s }, p1/z, [x11, x14, lsl #2]
	ldr	z1, [x13, #1, mul vl]
	ld1w	{ z2.s }, p1/z, [x10, x14, lsl #2]
	ldr	z3, [x12, #1, mul vl]
	mov	x13, #480                       // =0x1e0
	add	x12, x11, #1920
	fmopa	za0.s, p1/m, p1/m, z0.s, z2.s
	fmopa	za1.s, p1/m, p1/m, z0.s, z1.s
	fmopa	za2.s, p1/m, p1/m, z3.s, z2.s
	fmopa	za3.s, p1/m, p1/m, z3.s, z1.s
	ld1w	{ z0.s }, p1/z, [x11, x13, lsl #2]
	add	x11, x10, #1920
	ld1w	{ z1.s }, p1/z, [x10, x13, lsl #2]
	ldr	z2, [x12, #1, mul vl]
	ldr	z3, [x11, #1, mul vl]
	fmopa	za0.s, p1/m, p1/m, z0.s, z1.s
	fmopa	za1.s, p1/m, p1/m, z0.s, z3.s
	fmopa	za2.s, p1/m, p1/m, z2.s, z1.s
	fmopa	za3.s, p1/m, p1/m, z2.s, z3.s
	b.le	.LBB1_36
// %bb.47:                              // %.lr.ph41
                                        //   in Loop: Header=BB1_37 Depth=2
	mov	x12, xzr
.LBB1_48:                               //   Parent Loop BB1_5 Depth=1
                                        //     Parent Loop BB1_37 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	add	x10, x9, x12, lsl #7
	mov	x11, x12
	incw	x11
	st1w	{za0h.s[w12, 0]}, p1, [x10]
	incb	x10
	add	x11, x9, x11, lsl #7
	st1w	{za1h.s[w12, 0]}, p1, [x10]
	st1w	{za2h.s[w12, 0]}, p1, [x11]
	incb	x11
	st1w	{za3h.s[w12, 0]}, p1, [x11]
	add	x12, x12, #1
	cmp	x12, x26
	b.ne	.LBB1_48
	b	.LBB1_36
.LBB1_49:                               // %._crit_edge51
	smstop	za
	mov	sp, x29
	ldp	x20, x19, [sp, #80]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             // 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             // 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             // 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #96             // 16-byte Folded Reload
	ret
.Lfunc_end1:
	.size	matmul_kernel_sme_0, .Lfunc_end1-matmul_kernel_sme_0
                                        // -- End function
	.section	".note.GNU-stack","",@progbits
