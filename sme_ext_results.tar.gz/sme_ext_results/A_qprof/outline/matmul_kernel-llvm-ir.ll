; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target triple = "aarch64"

declare void @free(ptr)

declare void @memrefCopy(i64, ptr, ptr)

declare ptr @malloc(i64)

define void @matmul_kernel(i64 %0, ptr %1, i64 %2, ptr %3, i64 %4, ptr %5, i32 %6, i32 %7, i32 %8, i32 %9, i32 %10, i32 %11, i32 %12, i32 %13, i32 %14, i32 %15, i32 %16, i32 %17) {
  %19 = insertvalue { i64, ptr } poison, i64 %4, 0
  %20 = insertvalue { i64, ptr } %19, ptr %5, 1
  %21 = insertvalue { i64, ptr } poison, i64 %0, 0
  %22 = insertvalue { i64, ptr } %21, ptr %1, 1
  %23 = insertvalue { i64, ptr } poison, i64 %2, 0
  %24 = insertvalue { i64, ptr } %23, ptr %3, 1
  %25 = call ptr @malloc(i64 8256)
  %26 = ptrtoint ptr %25 to i64
  %27 = add i64 %26, 63
  %28 = urem i64 %27, 64
  %29 = sub i64 %27, %28
  %30 = inttoptr i64 %29 to ptr
  %31 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %25, 0
  %32 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %31, ptr %30, 1
  %33 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %32, i64 0, 2
  %34 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %33, i64 32, 3, 0
  %35 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %34, i64 64, 3, 1
  %36 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %35, i64 64, 4, 0
  %37 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %36, i64 1, 4, 1
  %38 = call i64 @llvm.vscale.i64()
  %39 = mul i64 %38, 4
  %40 = sdiv i64 63, %39
  %41 = add i64 %40, 1
  %42 = sdiv i64 63, %39
  %43 = add i64 %42, 1
  %44 = mul nsw i64 %43, 32
  br label %45

45:                                               ; preds = %48, %18
  %46 = phi i64 [ %79, %48 ], [ 0, %18 ]
  %47 = icmp slt i64 %46, %44
  br i1 %47, label %48, label %80

48:                                               ; preds = %45
  %49 = sdiv i64 %46, %41
  %50 = mul i64 %49, %41
  %51 = icmp ne i64 %46, %50
  %52 = icmp slt i64 %46, 0
  %53 = icmp slt i64 %41, 0
  %54 = icmp ne i1 %52, %53
  %55 = and i1 %51, %54
  %56 = add i64 %49, -1
  %57 = select i1 %55, i64 %56, i64 %49
  %58 = srem i64 %46, %41
  %59 = icmp slt i64 %58, 0
  %60 = add nsw i64 %58, %41
  %61 = select i1 %59, i64 %60, i64 %58
  %62 = mul nsw i64 %39, %61
  %63 = mul nsw i64 %39, %61
  %64 = mul nsw i64 %63, -1
  %65 = add i64 %64, 64
  %66 = call i64 @llvm.smin.i64(i64 %65, i64 %39)
  %67 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %66)
  %68 = mul nsw i64 %57, 64
  %69 = add i64 %68, %62
  %70 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %25, 0
  %71 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %70, ptr %30, 1
  %72 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %71, i64 %69, 2
  %73 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %72, i64 %66, 3, 0
  %74 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %73, i64 1, 4, 0
  %75 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %74, 1
  %76 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %74, 2
  %77 = getelementptr float, ptr %75, i64 %76
  %78 = getelementptr float, ptr %77, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> zeroinitializer, ptr align 4 %78, <vscale x 4 x i1> %67)
  %79 = add i64 %46, 1
  br label %45

80:                                               ; preds = %45
  %81 = add i32 %6, 31
  %82 = sdiv i32 %81, 32
  %83 = add i32 %7, 63
  %84 = sdiv i32 %83, 64
  %85 = mul i32 %84, 8
  %86 = sdiv i32 %15, %85
  %87 = mul i32 %86, 8
  %88 = sub i32 %82, %87
  %89 = call i32 @llvm.smin.i32(i32 %88, i32 8)
  %90 = srem i32 %15, %89
  %91 = add i32 %87, %90
  %92 = srem i32 %15, %85
  %93 = sdiv i32 %92, %89
  %94 = mul i32 %91, 32
  %95 = sext i32 %94 to i64
  %96 = mul i32 %93, 64
  %97 = sext i32 %96 to i64
  %98 = sext i32 %6 to i64
  %99 = sext i32 %7 to i64
  %100 = call ptr @malloc(i64 2112)
  %101 = ptrtoint ptr %100 to i64
  %102 = add i64 %101, 63
  %103 = urem i64 %102, 64
  %104 = sub i64 %102, %103
  %105 = inttoptr i64 %104 to ptr
  %106 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %100, 0
  %107 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %106, ptr %105, 1
  %108 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %107, i64 0, 2
  %109 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %108, i64 1, 3, 0
  %110 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %109, i64 16, 3, 1
  %111 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %110, i64 32, 3, 2
  %112 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %111, i64 1, 3, 3
  %113 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %112, i64 512, 4, 0
  %114 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %113, i64 32, 4, 1
  %115 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, i64 1, 4, 2
  %116 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %115, i64 1, 4, 3
  %117 = call ptr @malloc(i64 4160)
  %118 = ptrtoint ptr %117 to i64
  %119 = add i64 %118, 63
  %120 = urem i64 %119, 64
  %121 = sub i64 %119, %120
  %122 = inttoptr i64 %121 to ptr
  %123 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %117, 0
  %124 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %123, ptr %122, 1
  %125 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %124, i64 0, 2
  %126 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %125, i64 2, 3, 0
  %127 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %126, i64 16, 3, 1
  %128 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %127, i64 32, 3, 2
  %129 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %128, i64 1, 3, 3
  %130 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %129, i64 512, 4, 0
  %131 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %130, i64 32, 4, 1
  %132 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %131, i64 1, 4, 2
  %133 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %132, i64 1, 4, 3
  %134 = call ptr @malloc(i64 8256)
  %135 = ptrtoint ptr %134 to i64
  %136 = add i64 %135, 63
  %137 = urem i64 %136, 64
  %138 = sub i64 %136, %137
  %139 = inttoptr i64 %138 to ptr
  %140 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %134, 0
  %141 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %140, ptr %139, 1
  %142 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %141, i64 0, 2
  %143 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %142, i64 1, 3, 0
  %144 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %143, i64 2, 3, 1
  %145 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %144, i64 32, 3, 2
  %146 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %145, i64 32, 3, 3
  %147 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %146, i64 2048, 4, 0
  %148 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %147, i64 1024, 4, 1
  %149 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %148, i64 32, 4, 2
  %150 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %149, i64 1, 4, 3
  %151 = call ptr @malloc(i64 8256)
  %152 = ptrtoint ptr %151 to i64
  %153 = add i64 %152, 63
  %154 = urem i64 %153, 64
  %155 = sub i64 %153, %154
  %156 = inttoptr i64 %155 to ptr
  %157 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %151, 0
  %158 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %157, ptr %156, 1
  %159 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %158, i64 0, 2
  %160 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %159, i64 1, 3, 0
  %161 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %160, i64 32, 3, 1
  %162 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %161, i64 2, 3, 2
  %163 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %162, i64 32, 3, 3
  %164 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %163, i64 2048, 4, 0
  %165 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %164, i64 64, 4, 1
  %166 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %165, i64 32, 4, 2
  %167 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %166, i64 1, 4, 3
  %168 = call { i64, i64 } @matmul_kernel_sme_0(i32 %93, i32 %7, i64 %2, ptr %3, i32 %10, i32 %9, i32 %6, i64 %0, ptr %1, i32 %8, ptr %100, ptr %105, i64 0, i64 1, i64 16, i64 32, i64 1, i64 512, i64 32, i64 1, i64 1, ptr %117, ptr %122, i64 0, i64 2, i64 16, i64 32, i64 1, i64 512, i64 32, i64 1, i64 1, ptr %25, ptr %30, i64 0, i64 32, i64 64, i64 64, i64 1, ptr %134, ptr %139, i64 0, i64 1, i64 2, i64 32, i64 32, i64 2048, i64 1024, i64 32, i64 1, ptr %151, ptr %156, i64 0, i64 1, i64 32, i64 2, i64 32, i64 2048, i64 64, i64 32, i64 1, i32 %86, i32 %90)
  %169 = extractvalue { i64, i64 } %168, 0
  %170 = extractvalue { i64, i64 } %168, 1
  %171 = sext i32 %11 to i64
  %172 = mul i64 %95, %171
  %173 = add i64 %172, %97
  %174 = add i64 %95, 32
  %175 = call i64 @llvm.smin.i64(i64 %174, i64 %98)
  %176 = call i64 @llvm.smax.i64(i64 %175, i64 %95)
  %177 = sub i64 %176, %95
  %178 = add i64 %97, 64
  %179 = call i64 @llvm.smin.i64(i64 %178, i64 %99)
  %180 = call i64 @llvm.smax.i64(i64 %179, i64 %97)
  %181 = sub i64 %180, %97
  %182 = call i64 @llvm.smin.i64(i64 %177, i64 32)
  %183 = call i64 @llvm.smin.i64(i64 %181, i64 64)
  %184 = extractvalue { i64, ptr } %20, 1
  %185 = load ptr, ptr %184, align 8
  %186 = getelementptr ptr, ptr %184, i32 1
  %187 = load ptr, ptr %186, align 8
  %188 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %185, 0
  %189 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %188, ptr %187, 1
  %190 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %189, i64 %173, 2
  %191 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %190, i64 32, 3, 0
  %192 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %191, i64 %171, 4, 0
  %193 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %192, i64 64, 3, 1
  %194 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %193, i64 1, 4, 1
  %195 = insertvalue { ptr, ptr, i64 } poison, ptr %185, 0
  %196 = insertvalue { ptr, ptr, i64 } %195, ptr %187, 1
  %197 = insertvalue { ptr, ptr, i64 } %196, i64 0, 2
  %198 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %185, 0
  %199 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %198, ptr %187, 1
  %200 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %199, i64 %173, 2
  %201 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %200, i64 %182, 3, 0
  %202 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %201, i64 %171, 4, 0
  %203 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %202, i64 %183, 3, 1
  %204 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %203, i64 1, 4, 1
  %205 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %25, 0
  %206 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %205, ptr %30, 1
  %207 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %206, i64 0, 2
  %208 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %207, i64 %182, 3, 0
  %209 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %208, i64 64, 4, 0
  %210 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %209, i64 %183, 3, 1
  %211 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %210, i64 1, 4, 1
  %212 = call ptr @llvm.stacksave.p0()
  %213 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %211, ptr %213, align 8
  %214 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %213, 1
  %215 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %204, ptr %215, align 8
  %216 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %215, 1
  %217 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %214, ptr %217, align 8
  %218 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %216, ptr %218, align 8
  call void @memrefCopy(i64 4, ptr %217, ptr %218)
  call void @llvm.stackrestore.p0(ptr %212)
  call void @free(ptr %25)
  call void @free(ptr %100)
  call void @free(ptr %117)
  call void @free(ptr %134)
  call void @free(ptr %151)
  ret void
}

define internal { i64, i64 } @matmul_kernel_sme_0(i32 %0, i32 %1, i64 %2, ptr %3, i32 %4, i32 %5, i32 %6, i64 %7, ptr %8, i32 %9, ptr %10, ptr %11, i64 %12, i64 %13, i64 %14, i64 %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20, ptr %21, ptr %22, i64 %23, i64 %24, i64 %25, i64 %26, i64 %27, i64 %28, i64 %29, i64 %30, i64 %31, ptr %32, ptr %33, i64 %34, i64 %35, i64 %36, i64 %37, i64 %38, ptr %39, ptr %40, i64 %41, i64 %42, i64 %43, i64 %44, i64 %45, i64 %46, i64 %47, i64 %48, i64 %49, ptr %50, ptr %51, i64 %52, i64 %53, i64 %54, i64 %55, i64 %56, i64 %57, i64 %58, i64 %59, i64 %60, i32 %61, i32 %62) #0 {
  %64 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %50, 0
  %65 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %64, ptr %51, 1
  %66 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %65, i64 %52, 2
  %67 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %66, i64 %53, 3, 0
  %68 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, i64 %57, 4, 0
  %69 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %68, i64 %54, 3, 1
  %70 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %69, i64 %58, 4, 1
  %71 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %70, i64 %55, 3, 2
  %72 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %71, i64 %59, 4, 2
  %73 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %72, i64 %56, 3, 3
  %74 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %73, i64 %60, 4, 3
  %75 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %39, 0
  %76 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %75, ptr %40, 1
  %77 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %76, i64 %41, 2
  %78 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %77, i64 %42, 3, 0
  %79 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, i64 %46, 4, 0
  %80 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %79, i64 %43, 3, 1
  %81 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %80, i64 %47, 4, 1
  %82 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %81, i64 %44, 3, 2
  %83 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %82, i64 %48, 4, 2
  %84 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %83, i64 %45, 3, 3
  %85 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %84, i64 %49, 4, 3
  %86 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %32, 0
  %87 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %86, ptr %33, 1
  %88 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %87, i64 %34, 2
  %89 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %88, i64 %35, 3, 0
  %90 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %89, i64 %37, 4, 0
  %91 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %90, i64 %36, 3, 1
  %92 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %91, i64 %38, 4, 1
  %93 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %21, 0
  %94 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %93, ptr %22, 1
  %95 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %94, i64 %23, 2
  %96 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %95, i64 %24, 3, 0
  %97 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %96, i64 %28, 4, 0
  %98 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %97, i64 %25, 3, 1
  %99 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %98, i64 %29, 4, 1
  %100 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %99, i64 %26, 3, 2
  %101 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %100, i64 %30, 4, 2
  %102 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %101, i64 %27, 3, 3
  %103 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %102, i64 %31, 4, 3
  %104 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %10, 0
  %105 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %104, ptr %11, 1
  %106 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %105, i64 %12, 2
  %107 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %106, i64 %13, 3, 0
  %108 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %107, i64 %17, 4, 0
  %109 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %108, i64 %14, 3, 1
  %110 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %109, i64 %18, 4, 1
  %111 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %110, i64 %15, 3, 2
  %112 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %111, i64 %19, 4, 2
  %113 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %112, i64 %16, 3, 3
  %114 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %113, i64 %20, 4, 3
  %115 = insertvalue { i64, ptr } poison, i64 %7, 0
  %116 = insertvalue { i64, ptr } %115, ptr %8, 1
  %117 = insertvalue { i64, ptr } poison, i64 %2, 0
  %118 = insertvalue { i64, ptr } %117, ptr %3, 1
  %119 = mul i32 %0, 64
  %120 = sext i32 %119 to i64
  %121 = sext i32 %1 to i64
  %122 = sext i32 %4 to i64
  %123 = sext i32 %5 to i64
  %124 = sext i32 %6 to i64
  %125 = mul i64 %124, %123
  %126 = call i64 @llvm.vscale.i64()
  %127 = mul i64 %126, 4
  %128 = sdiv i64 31, %127
  %129 = add i64 %128, 1
  %130 = sdiv i64 31, %127
  %131 = add i64 %130, 1
  %132 = mul nsw i64 %131, 64
  %133 = mul i64 %126, 8
  %134 = sdiv i64 31, %133
  %135 = add i64 %134, 1
  %136 = sdiv i64 31, %133
  %137 = add i64 %136, 1
  %138 = sdiv i64 31, %133
  %139 = add i64 %138, 1
  %140 = mul nsw i64 %137, %139
  %141 = mul nsw i64 %140, 2
  %142 = sdiv i64 63, %127
  %143 = add i64 %142, 1
  %144 = sdiv i64 63, %127
  %145 = add i64 %144, 1
  %146 = mul nsw i64 %145, 32
  %147 = mul i32 %4, 16
  %148 = sext i32 %147 to i64
  %149 = add i32 %9, 15
  %150 = sdiv i32 %149, 16
  %151 = mul i32 %61, 8
  %152 = add i32 %151, %62
  %153 = mul i32 %152, 32
  %154 = sext i32 %153 to i64
  %155 = mul i64 %154, %123
  br label %156

156:                                              ; preds = %1106, %63
  %157 = phi i32 [ %1109, %1106 ], [ 0, %63 ]
  %158 = phi i64 [ %1107, %1106 ], [ %155, %63 ]
  %159 = phi i64 [ %1108, %1106 ], [ 0, %63 ]
  %160 = icmp slt i32 %157, %150
  br i1 %160, label %161, label %1110

161:                                              ; preds = %156
  %162 = add i64 %159, %120
  %163 = srem i64 %162, %121
  %164 = sub i64 %162, %163
  %165 = add i64 %163, 64
  %166 = call i64 @llvm.smin.i64(i64 %165, i64 %121)
  %167 = sub i64 %166, %163
  %168 = extractvalue { i64, ptr } %118, 1
  %169 = load ptr, ptr %168, align 8
  %170 = getelementptr ptr, ptr %168, i32 1
  %171 = load ptr, ptr %170, align 8
  %172 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %169, 0
  %173 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %172, ptr %171, 1
  %174 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %173, i64 %162, 2
  %175 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %174, i64 16, 3, 0
  %176 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %175, i64 %122, 4, 0
  %177 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %176, i64 %167, 3, 1
  %178 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %177, i64 1, 4, 1
  %179 = sub i64 64, %167
  %180 = extractvalue { i64, ptr } %118, 1
  %181 = load ptr, ptr %180, align 8
  %182 = getelementptr ptr, ptr %180, i32 1
  %183 = load ptr, ptr %182, align 8
  %184 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %181, 0
  %185 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %184, ptr %183, 1
  %186 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %185, i64 %164, 2
  %187 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %186, i64 16, 3, 0
  %188 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %187, i64 %122, 4, 0
  %189 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %188, i64 %179, 3, 1
  %190 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %189, i64 1, 4, 1
  %191 = srem i64 %158, %123
  %192 = add i64 %125, %191
  %193 = sub i64 %192, %158
  %194 = sdiv i64 %193, %123
  %195 = call i64 @llvm.smin.i64(i64 %194, i64 32)
  %196 = extractvalue { i64, ptr } %116, 1
  %197 = load ptr, ptr %196, align 8
  %198 = getelementptr ptr, ptr %196, i32 1
  %199 = load ptr, ptr %198, align 8
  %200 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %197, 0
  %201 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %200, ptr %199, 1
  %202 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %201, i64 %158, 2
  %203 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %202, i64 %195, 3, 0
  %204 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %203, i64 %123, 4, 0
  %205 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %204, i64 16, 3, 1
  %206 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %205, i64 1, 4, 1
  %207 = sub i64 32, %195
  %208 = extractvalue { i64, ptr } %116, 1
  %209 = load ptr, ptr %208, align 8
  %210 = getelementptr ptr, ptr %208, i32 1
  %211 = load ptr, ptr %210, align 8
  %212 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %209, 0
  %213 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %212, ptr %211, 1
  %214 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %213, i64 %191, 2
  %215 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %214, i64 %207, 3, 0
  %216 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %215, i64 %123, 4, 0
  %217 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %216, i64 16, 3, 1
  %218 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %217, i64 1, 4, 1
  %219 = mul i32 %157, 16
  %220 = sub i32 %9, %219
  %221 = sext i32 %220 to i64
  %222 = call i64 @llvm.smin.i64(i64 %221, i64 16)
  %223 = call i64 @llvm.smax.i64(i64 %222, i64 0)
  %224 = call ptr @malloc(i64 2048)
  %225 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %224, 0
  %226 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %225, ptr %224, 1
  %227 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %226, i64 0, 2
  %228 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %227, i64 32, 3, 0
  %229 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %228, i64 16, 3, 1
  %230 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %229, i64 16, 4, 0
  %231 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %230, i64 1, 4, 1
  %232 = icmp slt i64 %223, 16
  br i1 %232, label %233, label %246

233:                                              ; preds = %244, %161
  %234 = phi i64 [ %245, %244 ], [ 0, %161 ]
  %235 = icmp slt i64 %234, 32
  br i1 %235, label %236, label %246

236:                                              ; preds = %239, %233
  %237 = phi i64 [ %243, %239 ], [ 0, %233 ]
  %238 = icmp slt i64 %237, 16
  br i1 %238, label %239, label %244

239:                                              ; preds = %236
  %240 = mul nuw nsw i64 %234, 16
  %241 = add nuw nsw i64 %240, %237
  %242 = getelementptr inbounds nuw float, ptr %224, i64 %241
  store float 0.000000e+00, ptr %242, align 4
  %243 = add i64 %237, 1
  br label %236

244:                                              ; preds = %236
  %245 = add i64 %234, 1
  br label %233

246:                                              ; preds = %233, %161
  %247 = icmp sle i64 %223, 0
  %248 = sub i64 0, %223
  %249 = sub i64 %223, 1
  %250 = select i1 %247, i64 %248, i64 %249
  %251 = sdiv i64 %250, %127
  %252 = sub i64 0, %251
  %253 = add i64 %251, 1
  %254 = select i1 %247, i64 %252, i64 %253
  %255 = icmp sle i64 %223, 0
  %256 = sub i64 0, %223
  %257 = sub i64 %223, 1
  %258 = select i1 %255, i64 %256, i64 %257
  %259 = sdiv i64 %258, %127
  %260 = sub i64 0, %259
  %261 = add i64 %259, 1
  %262 = select i1 %255, i64 %260, i64 %261
  %263 = mul nsw i64 %195, %262
  br label %264

264:                                              ; preds = %267, %246
  %265 = phi i64 [ %314, %267 ], [ 0, %246 ]
  %266 = icmp slt i64 %265, %263
  br i1 %266, label %267, label %315

267:                                              ; preds = %264
  %268 = sdiv i64 %265, %254
  %269 = mul i64 %268, %254
  %270 = icmp ne i64 %265, %269
  %271 = icmp slt i64 %265, 0
  %272 = icmp slt i64 %254, 0
  %273 = icmp ne i1 %271, %272
  %274 = and i1 %270, %273
  %275 = add i64 %268, -1
  %276 = select i1 %274, i64 %275, i64 %268
  %277 = srem i64 %265, %254
  %278 = icmp slt i64 %277, 0
  %279 = add nsw i64 %277, %254
  %280 = select i1 %278, i64 %279, i64 %277
  %281 = mul nsw i64 %127, %280
  %282 = mul nsw i64 %127, %280
  %283 = mul nsw i64 %282, -1
  %284 = add i64 %223, %283
  %285 = call i64 @llvm.smin.i64(i64 %284, i64 %127)
  %286 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %285)
  %287 = insertvalue { ptr, ptr, i64 } poison, ptr %197, 0
  %288 = insertvalue { ptr, ptr, i64 } %287, ptr %199, 1
  %289 = insertvalue { ptr, ptr, i64 } %288, i64 0, 2
  %290 = mul nsw i64 %276, %123
  %291 = add i64 %158, %290
  %292 = add i64 %291, %281
  %293 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %197, 0
  %294 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %293, ptr %199, 1
  %295 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %294, i64 %292, 2
  %296 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %295, i64 %285, 3, 0
  %297 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %296, i64 1, 4, 0
  %298 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %297, 1
  %299 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %297, 2
  %300 = getelementptr float, ptr %298, i64 %299
  %301 = getelementptr float, ptr %300, i64 0
  %302 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %301, <vscale x 4 x i1> %286, <vscale x 4 x float> poison)
  %303 = mul nsw i64 %276, 16
  %304 = add i64 %303, %281
  %305 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %224, 0
  %306 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %305, ptr %224, 1
  %307 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %306, i64 %304, 2
  %308 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %307, i64 %285, 3, 0
  %309 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %308, i64 1, 4, 0
  %310 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %309, 1
  %311 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %309, 2
  %312 = getelementptr float, ptr %310, i64 %311
  %313 = getelementptr float, ptr %312, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %302, ptr align 4 %313, <vscale x 4 x i1> %286)
  %314 = add i64 %265, 1
  br label %264

315:                                              ; preds = %264
  %316 = icmp sle i64 %223, 0
  %317 = sub i64 0, %223
  %318 = sub i64 %223, 1
  %319 = select i1 %316, i64 %317, i64 %318
  %320 = sdiv i64 %319, %127
  %321 = sub i64 0, %320
  %322 = add i64 %320, 1
  %323 = select i1 %316, i64 %321, i64 %322
  %324 = mul nsw i64 %207, %323
  br label %325

325:                                              ; preds = %328, %315
  %326 = phi i64 [ %377, %328 ], [ 0, %315 ]
  %327 = icmp slt i64 %326, %324
  br i1 %327, label %328, label %378

328:                                              ; preds = %325
  %329 = sdiv i64 %326, %254
  %330 = mul i64 %329, %254
  %331 = icmp ne i64 %326, %330
  %332 = icmp slt i64 %326, 0
  %333 = icmp slt i64 %254, 0
  %334 = icmp ne i1 %332, %333
  %335 = and i1 %331, %334
  %336 = add i64 %329, -1
  %337 = select i1 %335, i64 %336, i64 %329
  %338 = srem i64 %326, %254
  %339 = icmp slt i64 %338, 0
  %340 = add nsw i64 %338, %254
  %341 = select i1 %339, i64 %340, i64 %338
  %342 = mul nsw i64 %127, %341
  %343 = mul nsw i64 %127, %341
  %344 = mul nsw i64 %343, -1
  %345 = add i64 %223, %344
  %346 = call i64 @llvm.smin.i64(i64 %345, i64 %127)
  %347 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %346)
  %348 = insertvalue { ptr, ptr, i64 } poison, ptr %209, 0
  %349 = insertvalue { ptr, ptr, i64 } %348, ptr %211, 1
  %350 = insertvalue { ptr, ptr, i64 } %349, i64 0, 2
  %351 = mul nsw i64 %337, %123
  %352 = add i64 %191, %351
  %353 = add i64 %352, %342
  %354 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %209, 0
  %355 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %354, ptr %211, 1
  %356 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %355, i64 %353, 2
  %357 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %356, i64 %346, 3, 0
  %358 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %357, i64 1, 4, 0
  %359 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %358, 1
  %360 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %358, 2
  %361 = getelementptr float, ptr %359, i64 %360
  %362 = getelementptr float, ptr %361, i64 0
  %363 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %362, <vscale x 4 x i1> %347, <vscale x 4 x float> poison)
  %364 = mul nsw i64 %195, 16
  %365 = mul nsw i64 %337, 16
  %366 = add i64 %364, %365
  %367 = add i64 %366, %342
  %368 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %224, 0
  %369 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %368, ptr %224, 1
  %370 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %369, i64 %367, 2
  %371 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %370, i64 %346, 3, 0
  %372 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %371, i64 1, 4, 0
  %373 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %372, 1
  %374 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %372, 2
  %375 = getelementptr float, ptr %373, i64 %374
  %376 = getelementptr float, ptr %375, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %363, ptr align 4 %376, <vscale x 4 x i1> %347)
  %377 = add i64 %326, 1
  br label %325

378:                                              ; preds = %325
  %379 = call ptr @malloc(i64 4096)
  %380 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %379, 0
  %381 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %380, ptr %379, 1
  %382 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %381, i64 0, 2
  %383 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %382, i64 16, 3, 0
  %384 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %383, i64 64, 3, 1
  %385 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %384, i64 64, 4, 0
  %386 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %385, i64 1, 4, 1
  br i1 %232, label %387, label %400

387:                                              ; preds = %398, %378
  %388 = phi i64 [ %399, %398 ], [ 0, %378 ]
  %389 = icmp slt i64 %388, 16
  br i1 %389, label %390, label %400

390:                                              ; preds = %393, %387
  %391 = phi i64 [ %397, %393 ], [ 0, %387 ]
  %392 = icmp slt i64 %391, 64
  br i1 %392, label %393, label %398

393:                                              ; preds = %390
  %394 = mul nuw nsw i64 %388, 64
  %395 = add nuw nsw i64 %394, %391
  %396 = getelementptr inbounds nuw float, ptr %379, i64 %395
  store float 0.000000e+00, ptr %396, align 4
  %397 = add i64 %391, 1
  br label %390

398:                                              ; preds = %390
  %399 = add i64 %388, 1
  br label %387

400:                                              ; preds = %387, %378
  %401 = icmp sle i64 %167, 0
  %402 = sub i64 0, %167
  %403 = sub i64 %167, 1
  %404 = select i1 %401, i64 %402, i64 %403
  %405 = sdiv i64 %404, %127
  %406 = sub i64 0, %405
  %407 = add i64 %405, 1
  %408 = select i1 %401, i64 %406, i64 %407
  %409 = icmp sle i64 %167, 0
  %410 = sub i64 0, %167
  %411 = sub i64 %167, 1
  %412 = select i1 %409, i64 %410, i64 %411
  %413 = sdiv i64 %412, %127
  %414 = sub i64 0, %413
  %415 = add i64 %413, 1
  %416 = select i1 %409, i64 %414, i64 %415
  %417 = mul nsw i64 %223, %416
  br label %418

418:                                              ; preds = %421, %400
  %419 = phi i64 [ %468, %421 ], [ 0, %400 ]
  %420 = icmp slt i64 %419, %417
  br i1 %420, label %421, label %469

421:                                              ; preds = %418
  %422 = sdiv i64 %419, %408
  %423 = mul i64 %422, %408
  %424 = icmp ne i64 %419, %423
  %425 = icmp slt i64 %419, 0
  %426 = icmp slt i64 %408, 0
  %427 = icmp ne i1 %425, %426
  %428 = and i1 %424, %427
  %429 = add i64 %422, -1
  %430 = select i1 %428, i64 %429, i64 %422
  %431 = srem i64 %419, %408
  %432 = icmp slt i64 %431, 0
  %433 = add nsw i64 %431, %408
  %434 = select i1 %432, i64 %433, i64 %431
  %435 = mul nsw i64 %127, %434
  %436 = mul nsw i64 %127, %434
  %437 = mul nsw i64 %436, -1
  %438 = add i64 %167, %437
  %439 = call i64 @llvm.smin.i64(i64 %438, i64 %127)
  %440 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %439)
  %441 = insertvalue { ptr, ptr, i64 } poison, ptr %169, 0
  %442 = insertvalue { ptr, ptr, i64 } %441, ptr %171, 1
  %443 = insertvalue { ptr, ptr, i64 } %442, i64 0, 2
  %444 = mul nsw i64 %430, %122
  %445 = add i64 %162, %444
  %446 = add i64 %445, %435
  %447 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %169, 0
  %448 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %447, ptr %171, 1
  %449 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %448, i64 %446, 2
  %450 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %449, i64 %439, 3, 0
  %451 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %450, i64 1, 4, 0
  %452 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %451, 1
  %453 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %451, 2
  %454 = getelementptr float, ptr %452, i64 %453
  %455 = getelementptr float, ptr %454, i64 0
  %456 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %455, <vscale x 4 x i1> %440, <vscale x 4 x float> poison)
  %457 = mul nsw i64 %430, 64
  %458 = add i64 %457, %435
  %459 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %379, 0
  %460 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %459, ptr %379, 1
  %461 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %460, i64 %458, 2
  %462 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %461, i64 %439, 3, 0
  %463 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %462, i64 1, 4, 0
  %464 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %463, 1
  %465 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %463, 2
  %466 = getelementptr float, ptr %464, i64 %465
  %467 = getelementptr float, ptr %466, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %456, ptr align 4 %467, <vscale x 4 x i1> %440)
  %468 = add i64 %419, 1
  br label %418

469:                                              ; preds = %418
  %470 = icmp sle i64 %179, 0
  %471 = sub i64 0, %179
  %472 = sub i64 %179, 1
  %473 = select i1 %470, i64 %471, i64 %472
  %474 = sdiv i64 %473, %127
  %475 = sub i64 0, %474
  %476 = add i64 %474, 1
  %477 = select i1 %470, i64 %475, i64 %476
  %478 = icmp sle i64 %179, 0
  %479 = sub i64 0, %179
  %480 = sub i64 %179, 1
  %481 = select i1 %478, i64 %479, i64 %480
  %482 = sdiv i64 %481, %127
  %483 = sub i64 0, %482
  %484 = add i64 %482, 1
  %485 = select i1 %478, i64 %483, i64 %484
  %486 = mul nsw i64 %223, %485
  br label %487

487:                                              ; preds = %490, %469
  %488 = phi i64 [ %538, %490 ], [ 0, %469 ]
  %489 = icmp slt i64 %488, %486
  br i1 %489, label %490, label %539

490:                                              ; preds = %487
  %491 = sdiv i64 %488, %477
  %492 = mul i64 %491, %477
  %493 = icmp ne i64 %488, %492
  %494 = icmp slt i64 %488, 0
  %495 = icmp slt i64 %477, 0
  %496 = icmp ne i1 %494, %495
  %497 = and i1 %493, %496
  %498 = add i64 %491, -1
  %499 = select i1 %497, i64 %498, i64 %491
  %500 = srem i64 %488, %477
  %501 = icmp slt i64 %500, 0
  %502 = add nsw i64 %500, %477
  %503 = select i1 %501, i64 %502, i64 %500
  %504 = mul nsw i64 %127, %503
  %505 = mul nsw i64 %127, %503
  %506 = mul nsw i64 %505, -1
  %507 = add i64 %179, %506
  %508 = call i64 @llvm.smin.i64(i64 %507, i64 %127)
  %509 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %508)
  %510 = insertvalue { ptr, ptr, i64 } poison, ptr %181, 0
  %511 = insertvalue { ptr, ptr, i64 } %510, ptr %183, 1
  %512 = insertvalue { ptr, ptr, i64 } %511, i64 0, 2
  %513 = mul nsw i64 %499, %122
  %514 = add i64 %164, %513
  %515 = add i64 %514, %504
  %516 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %181, 0
  %517 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %516, ptr %183, 1
  %518 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %517, i64 %515, 2
  %519 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %518, i64 %508, 3, 0
  %520 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %519, i64 1, 4, 0
  %521 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %520, 1
  %522 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %520, 2
  %523 = getelementptr float, ptr %521, i64 %522
  %524 = getelementptr float, ptr %523, i64 0
  %525 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %524, <vscale x 4 x i1> %509, <vscale x 4 x float> poison)
  %526 = mul nsw i64 %499, 64
  %527 = add i64 %167, %526
  %528 = add i64 %527, %504
  %529 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %379, 0
  %530 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %529, ptr %379, 1
  %531 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %530, i64 %528, 2
  %532 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %531, i64 %508, 3, 0
  %533 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %532, i64 1, 4, 0
  %534 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %533, 1
  %535 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %533, 2
  %536 = getelementptr float, ptr %534, i64 %535
  %537 = getelementptr float, ptr %536, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %525, ptr align 4 %537, <vscale x 4 x i1> %509)
  %538 = add i64 %488, 1
  br label %487

539:                                              ; preds = %487
  br label %540

540:                                              ; preds = %543, %539
  %541 = phi i64 [ %595, %543 ], [ 0, %539 ]
  %542 = icmp slt i64 %541, 512
  br i1 %542, label %543, label %596

543:                                              ; preds = %540
  %544 = sdiv i64 %541, 32
  %545 = mul i64 %544, 32
  %546 = icmp ne i64 %541, %545
  %547 = icmp slt i64 %541, 0
  %548 = icmp ne i1 %547, false
  %549 = and i1 %546, %548
  %550 = add i64 %544, -1
  %551 = select i1 %549, i64 %550, i64 %544
  %552 = srem i64 %541, 32
  %553 = icmp slt i64 %552, 0
  %554 = add nsw i64 %552, 32
  %555 = select i1 %553, i64 %554, i64 %552
  %556 = call i64 @llvm.smin.i64(i64 %127, i64 1)
  %557 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %556)
  %558 = mul nsw i64 %555, 16
  %559 = add i64 %558, %551
  %560 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %224, 0
  %561 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %560, ptr %224, 1
  %562 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %561, i64 %559, 2
  %563 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %562, i64 %556, 3, 0
  %564 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %563, i64 1, 4, 0
  %565 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %564, 1
  %566 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %564, 2
  %567 = getelementptr float, ptr %565, i64 %566
  %568 = getelementptr float, ptr %567, i64 0
  %569 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %568, <vscale x 4 x i1> %557, <vscale x 4 x float> poison)
  %570 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, 0
  %571 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, 1
  %572 = insertvalue { ptr, ptr, i64 } poison, ptr %570, 0
  %573 = insertvalue { ptr, ptr, i64 } %572, ptr %571, 1
  %574 = insertvalue { ptr, ptr, i64 } %573, i64 0, 2
  %575 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, 2
  %576 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, 3, 0
  %577 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, 3, 1
  %578 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, 3, 2
  %579 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, 3, 3
  %580 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, 4, 0
  %581 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, 4, 1
  %582 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, 4, 2
  %583 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, 4, 3
  %584 = mul nsw i64 %551, 32
  %585 = add i64 %584, %555
  %586 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %570, 0
  %587 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %586, ptr %571, 1
  %588 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %587, i64 %585, 2
  %589 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %588, i64 %556, 3, 0
  %590 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %589, i64 1, 4, 0
  %591 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %590, 1
  %592 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %590, 2
  %593 = getelementptr float, ptr %591, i64 %592
  %594 = getelementptr float, ptr %593, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %569, ptr align 4 %594, <vscale x 4 x i1> %557)
  %595 = add i64 %541, 1
  br label %540

596:                                              ; preds = %540
  br label %597

597:                                              ; preds = %644, %596
  %598 = phi i64 [ %672, %644 ], [ 0, %596 ]
  %599 = icmp slt i64 %598, 1024
  br i1 %599, label %600, label %673

600:                                              ; preds = %597
  %601 = sdiv i64 %598, 512
  %602 = mul i64 %601, 512
  %603 = icmp ne i64 %598, %602
  %604 = icmp slt i64 %598, 0
  %605 = icmp ne i1 %604, false
  %606 = and i1 %603, %605
  %607 = add i64 %601, -1
  %608 = select i1 %606, i64 %607, i64 %601
  %609 = srem i64 %598, 512
  %610 = icmp slt i64 %609, 0
  %611 = add nsw i64 %609, 512
  %612 = select i1 %610, i64 %611, i64 %609
  %613 = sdiv i64 %612, 32
  %614 = srem i64 %598, 32
  %615 = icmp slt i64 %614, 0
  %616 = add nsw i64 %614, 32
  %617 = select i1 %615, i64 %616, i64 %614
  %618 = call i64 @llvm.smin.i64(i64 %127, i64 1)
  %619 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %618)
  %620 = mul nsw i64 %613, 64
  %621 = mul nsw i64 %608, 32
  %622 = add i64 %620, %621
  %623 = add i64 %622, %617
  %624 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %379, 0
  %625 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %624, ptr %379, 1
  %626 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %625, i64 %623, 2
  %627 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %626, i64 %618, 3, 0
  %628 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %627, i64 64, 4, 0
  br label %629

629:                                              ; preds = %641, %600
  %630 = phi i64 [ %643, %641 ], [ 0, %600 ]
  %631 = phi <vscale x 4 x float> [ %642, %641 ], [ poison, %600 ]
  %632 = icmp slt i64 %630, %127
  br i1 %632, label %633, label %644

633:                                              ; preds = %629
  %634 = extractelement <vscale x 4 x i1> %619, i64 %630
  br i1 %634, label %635, label %641

635:                                              ; preds = %633
  %636 = getelementptr float, ptr %379, i64 %623
  %637 = mul nuw nsw i64 %630, 64
  %638 = getelementptr inbounds nuw float, ptr %636, i64 %637
  %639 = load float, ptr %638, align 4
  %640 = insertelement <vscale x 4 x float> %631, float %639, i64 %630
  br label %641

641:                                              ; preds = %635, %633
  %642 = phi <vscale x 4 x float> [ %640, %635 ], [ %631, %633 ]
  %643 = add i64 %630, 1
  br label %629

644:                                              ; preds = %629
  %645 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %103, 0
  %646 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %103, 1
  %647 = insertvalue { ptr, ptr, i64 } poison, ptr %645, 0
  %648 = insertvalue { ptr, ptr, i64 } %647, ptr %646, 1
  %649 = insertvalue { ptr, ptr, i64 } %648, i64 0, 2
  %650 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %103, 2
  %651 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %103, 3, 0
  %652 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %103, 3, 1
  %653 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %103, 3, 2
  %654 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %103, 3, 3
  %655 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %103, 4, 0
  %656 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %103, 4, 1
  %657 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %103, 4, 2
  %658 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %103, 4, 3
  %659 = mul nsw i64 %608, 512
  %660 = mul nsw i64 %613, 32
  %661 = add i64 %659, %660
  %662 = add i64 %661, %617
  %663 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %645, 0
  %664 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %663, ptr %646, 1
  %665 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %664, i64 %662, 2
  %666 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %665, i64 %618, 3, 0
  %667 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %666, i64 1, 4, 0
  %668 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %667, 1
  %669 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %667, 2
  %670 = getelementptr float, ptr %668, i64 %669
  %671 = getelementptr float, ptr %670, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %631, ptr align 4 %671, <vscale x 4 x i1> %619)
  %672 = add i64 %598, 1
  br label %597

673:                                              ; preds = %597
  br label %674

674:                                              ; preds = %677, %673
  %675 = phi i64 [ %754, %677 ], [ 0, %673 ]
  %676 = icmp slt i64 %675, %132
  br i1 %676, label %677, label %755

677:                                              ; preds = %674
  %678 = mul nuw nsw i64 %129, 32
  %679 = sdiv i64 %675, %678
  %680 = mul i64 %679, %678
  %681 = icmp ne i64 %675, %680
  %682 = icmp slt i64 %675, 0
  %683 = icmp slt i64 %678, 0
  %684 = icmp ne i1 %682, %683
  %685 = and i1 %681, %684
  %686 = add i64 %679, -1
  %687 = select i1 %685, i64 %686, i64 %679
  %688 = srem i64 %675, %678
  %689 = icmp slt i64 %688, 0
  %690 = add nsw i64 %688, %678
  %691 = select i1 %689, i64 %690, i64 %688
  %692 = sdiv i64 %691, %129
  %693 = srem i64 %675, %129
  %694 = icmp slt i64 %693, 0
  %695 = add nsw i64 %693, %129
  %696 = select i1 %694, i64 %695, i64 %693
  %697 = mul nsw i64 %127, %696
  %698 = mul nsw i64 %127, %696
  %699 = mul nsw i64 %698, -1
  %700 = add i64 %699, 32
  %701 = call i64 @llvm.smin.i64(i64 %700, i64 %127)
  %702 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %701)
  %703 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %92, 0
  %704 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %92, 1
  %705 = insertvalue { ptr, ptr, i64 } poison, ptr %703, 0
  %706 = insertvalue { ptr, ptr, i64 } %705, ptr %704, 1
  %707 = insertvalue { ptr, ptr, i64 } %706, i64 0, 2
  %708 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %92, 2
  %709 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %92, 3, 0
  %710 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %92, 3, 1
  %711 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %92, 4, 0
  %712 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %92, 4, 1
  %713 = mul nsw i64 %692, 64
  %714 = mul nsw i64 %687, 32
  %715 = add i64 %713, %714
  %716 = add i64 %715, %697
  %717 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %703, 0
  %718 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %717, ptr %704, 1
  %719 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %718, i64 %716, 2
  %720 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %719, i64 %701, 3, 0
  %721 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %720, i64 1, 4, 0
  %722 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %721, 1
  %723 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %721, 2
  %724 = getelementptr float, ptr %722, i64 %723
  %725 = getelementptr float, ptr %724, i64 0
  %726 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %725, <vscale x 4 x i1> %702, <vscale x 4 x float> poison)
  %727 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 0
  %728 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 1
  %729 = insertvalue { ptr, ptr, i64 } poison, ptr %727, 0
  %730 = insertvalue { ptr, ptr, i64 } %729, ptr %728, 1
  %731 = insertvalue { ptr, ptr, i64 } %730, i64 0, 2
  %732 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 2
  %733 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 3, 0
  %734 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 3, 1
  %735 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 3, 2
  %736 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 3, 3
  %737 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 4, 0
  %738 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 4, 1
  %739 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 4, 2
  %740 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 4, 3
  %741 = mul nsw i64 %687, 1024
  %742 = mul nsw i64 %692, 32
  %743 = add i64 %741, %742
  %744 = add i64 %743, %697
  %745 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %727, 0
  %746 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %745, ptr %728, 1
  %747 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %746, i64 %744, 2
  %748 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %747, i64 %701, 3, 0
  %749 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %748, i64 1, 4, 0
  %750 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %749, 1
  %751 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %749, 2
  %752 = getelementptr float, ptr %750, i64 %751
  %753 = getelementptr float, ptr %752, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %726, ptr align 4 %753, <vscale x 4 x i1> %702)
  %754 = add i64 %675, 1
  br label %674

755:                                              ; preds = %947, %674
  %756 = phi i64 [ %948, %947 ], [ 0, %674 ]
  %757 = icmp slt i64 %756, %141
  br i1 %757, label %758, label %949

758:                                              ; preds = %755
  %759 = mul nuw nsw i64 %135, %135
  %760 = sdiv i64 %756, %759
  %761 = mul i64 %760, %759
  %762 = icmp ne i64 %756, %761
  %763 = icmp slt i64 %756, 0
  %764 = icmp slt i64 %759, 0
  %765 = icmp ne i1 %763, %764
  %766 = and i1 %762, %765
  %767 = add i64 %760, -1
  %768 = select i1 %766, i64 %767, i64 %760
  %769 = srem i64 %756, %759
  %770 = icmp slt i64 %769, 0
  %771 = add nsw i64 %769, %759
  %772 = select i1 %770, i64 %771, i64 %769
  %773 = sdiv i64 %772, %135
  %774 = srem i64 %756, %135
  %775 = icmp slt i64 %774, 0
  %776 = add nsw i64 %774, %135
  %777 = select i1 %775, i64 %776, i64 %774
  %778 = mul nsw i64 %133, %777
  %779 = mul nsw i64 %133, %773
  %780 = mul nsw i64 %133, %773
  %781 = mul nsw i64 %780, -1
  %782 = add i64 %781, 32
  %783 = call i64 @llvm.smin.i64(i64 %782, i64 %133)
  %784 = mul nsw i64 %133, %777
  %785 = mul nsw i64 %784, -1
  %786 = add i64 %785, 32
  %787 = call i64 @llvm.smin.i64(i64 %786, i64 %133)
  %788 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 0
  %789 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 1
  %790 = insertvalue { ptr, ptr, i64 } poison, ptr %788, 0
  %791 = insertvalue { ptr, ptr, i64 } %790, ptr %789, 1
  %792 = insertvalue { ptr, ptr, i64 } %791, i64 0, 2
  %793 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 2
  %794 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 3, 0
  %795 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 3, 1
  %796 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 3, 2
  %797 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 3, 3
  %798 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 4, 0
  %799 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 4, 1
  %800 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 4, 2
  %801 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 4, 3
  %802 = mul nsw i64 %768, 1024
  %803 = mul nsw i64 %779, 32
  %804 = add i64 %802, %803
  %805 = add i64 %804, %778
  %806 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %788, 0
  %807 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %806, ptr %789, 1
  %808 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %807, i64 %805, 2
  %809 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %808, i64 %783, 3, 0
  %810 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %809, i64 32, 4, 0
  %811 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %810, i64 %787, 3, 1
  %812 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %811, i64 1, 4, 1
  br label %813

813:                                              ; preds = %816, %758
  %814 = phi i64 [ %824, %816 ], [ 0, %758 ]
  %815 = icmp slt i64 %814, %127
  br i1 %815, label %816, label %825

816:                                              ; preds = %813
  %817 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %812, 1
  %818 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %812, 2
  %819 = getelementptr float, ptr %817, i64 %818
  %820 = mul i64 %814, 32
  %821 = add i64 %820, 0
  %822 = getelementptr float, ptr %819, i64 %821
  %823 = trunc i64 %814 to i32
  call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %822, i32 0, i32 %823)
  %824 = add i64 %814, 1
  br label %813

825:                                              ; preds = %813
  br label %826

826:                                              ; preds = %829, %825
  %827 = phi i64 [ %837, %829 ], [ 0, %825 ]
  %828 = icmp slt i64 %827, %127
  br i1 %828, label %829, label %838

829:                                              ; preds = %826
  %830 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %812, 1
  %831 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %812, 2
  %832 = getelementptr float, ptr %830, i64 %831
  %833 = mul i64 %827, 32
  %834 = add i64 %833, %127
  %835 = getelementptr float, ptr %832, i64 %834
  %836 = trunc i64 %827 to i32
  call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %835, i32 1, i32 %836)
  %837 = add i64 %827, 1
  br label %826

838:                                              ; preds = %841, %826
  %839 = phi i64 [ %850, %841 ], [ 0, %826 ]
  %840 = icmp slt i64 %839, %127
  br i1 %840, label %841, label %851

841:                                              ; preds = %838
  %842 = add i64 %127, %839
  %843 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %812, 1
  %844 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %812, 2
  %845 = getelementptr float, ptr %843, i64 %844
  %846 = mul i64 %842, 32
  %847 = add i64 %846, 0
  %848 = getelementptr float, ptr %845, i64 %847
  %849 = trunc i64 %839 to i32
  call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %848, i32 2, i32 %849)
  %850 = add i64 %839, 1
  br label %838

851:                                              ; preds = %854, %838
  %852 = phi i64 [ %863, %854 ], [ 0, %838 ]
  %853 = icmp slt i64 %852, %127
  br i1 %853, label %854, label %864

854:                                              ; preds = %851
  %855 = add i64 %127, %852
  %856 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %812, 1
  %857 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %812, 2
  %858 = getelementptr float, ptr %856, i64 %857
  %859 = mul i64 %855, 32
  %860 = add i64 %859, %127
  %861 = getelementptr float, ptr %858, i64 %860
  %862 = trunc i64 %852 to i32
  call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %861, i32 3, i32 %862)
  %863 = add i64 %852, 1
  br label %851

864:                                              ; preds = %867, %851
  %865 = phi i64 [ %926, %867 ], [ 0, %851 ]
  %866 = icmp slt i64 %865, 16
  br i1 %866, label %867, label %927

867:                                              ; preds = %864
  %868 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, 0
  %869 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, 1
  %870 = insertvalue { ptr, ptr, i64 } poison, ptr %868, 0
  %871 = insertvalue { ptr, ptr, i64 } %870, ptr %869, 1
  %872 = insertvalue { ptr, ptr, i64 } %871, i64 0, 2
  %873 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, 2
  %874 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, 3, 0
  %875 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, 3, 1
  %876 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, 3, 2
  %877 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, 3, 3
  %878 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, 4, 0
  %879 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, 4, 1
  %880 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, 4, 2
  %881 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, 4, 3
  %882 = mul nsw i64 %865, 32
  %883 = add i64 %779, %882
  %884 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %868, 0
  %885 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %884, ptr %869, 1
  %886 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %885, i64 %883, 2
  %887 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %886, i64 %783, 3, 0
  %888 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %887, i64 1, 4, 0
  %889 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %888, 1
  %890 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %888, 2
  %891 = getelementptr float, ptr %889, i64 %890
  %892 = getelementptr float, ptr %891, i64 0
  %893 = load <vscale x 8 x float>, ptr %892, align 4
  %894 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %103, 0
  %895 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %103, 1
  %896 = insertvalue { ptr, ptr, i64 } poison, ptr %894, 0
  %897 = insertvalue { ptr, ptr, i64 } %896, ptr %895, 1
  %898 = insertvalue { ptr, ptr, i64 } %897, i64 0, 2
  %899 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %103, 2
  %900 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %103, 3, 0
  %901 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %103, 3, 1
  %902 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %103, 3, 2
  %903 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %103, 3, 3
  %904 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %103, 4, 0
  %905 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %103, 4, 1
  %906 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %103, 4, 2
  %907 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %103, 4, 3
  %908 = mul nsw i64 %768, 512
  %909 = add i64 %908, %778
  %910 = mul nsw i64 %865, 32
  %911 = add i64 %909, %910
  %912 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %894, 0
  %913 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %912, ptr %895, 1
  %914 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %913, i64 %911, 2
  %915 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %914, i64 %787, 3, 0
  %916 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %915, i64 1, 4, 0
  %917 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %916, 1
  %918 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %916, 2
  %919 = getelementptr float, ptr %917, i64 %918
  %920 = getelementptr float, ptr %919, i64 0
  %921 = load <vscale x 8 x float>, ptr %920, align 4
  %922 = call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %893, i64 0)
  %923 = call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %921, i64 0)
  call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %922, <vscale x 4 x float> %923)
  %924 = call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %921, i64 4)
  call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %922, <vscale x 4 x float> %924)
  %925 = call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %893, i64 4)
  call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %925, <vscale x 4 x float> %923)
  call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %925, <vscale x 4 x float> %924)
  %926 = add i64 %865, 1
  br label %864

927:                                              ; preds = %930, %864
  %928 = phi i64 [ %946, %930 ], [ 0, %864 ]
  %929 = icmp slt i64 %928, %127
  br i1 %929, label %930, label %947

930:                                              ; preds = %927
  %931 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %812, 1
  %932 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %812, 2
  %933 = getelementptr float, ptr %931, i64 %932
  %934 = mul i64 %928, 32
  %935 = add i64 %934, 0
  %936 = getelementptr float, ptr %933, i64 %935
  %937 = trunc i64 %928 to i32
  call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %936, i32 0, i32 %937)
  %938 = add i64 %934, %127
  %939 = getelementptr float, ptr %933, i64 %938
  call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %939, i32 1, i32 %937)
  %940 = add i64 %127, %928
  %941 = mul i64 %940, 32
  %942 = add i64 %941, 0
  %943 = getelementptr float, ptr %933, i64 %942
  call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %943, i32 2, i32 %937)
  %944 = add i64 %941, %127
  %945 = getelementptr float, ptr %933, i64 %944
  call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %945, i32 3, i32 %937)
  %946 = add i64 %928, 1
  br label %927

947:                                              ; preds = %927
  %948 = add i64 %756, 1
  br label %755

949:                                              ; preds = %952, %755
  %950 = phi i64 [ %1033, %952 ], [ 0, %755 ]
  %951 = icmp slt i64 %950, %132
  br i1 %951, label %952, label %1034

952:                                              ; preds = %949
  %953 = mul nuw nsw i64 %129, 2
  %954 = sdiv i64 %950, %953
  %955 = mul i64 %954, %953
  %956 = icmp ne i64 %950, %955
  %957 = icmp slt i64 %950, 0
  %958 = icmp slt i64 %953, 0
  %959 = icmp ne i1 %957, %958
  %960 = and i1 %956, %959
  %961 = add i64 %954, -1
  %962 = select i1 %960, i64 %961, i64 %954
  %963 = srem i64 %950, %953
  %964 = icmp slt i64 %963, 0
  %965 = add nsw i64 %963, %953
  %966 = select i1 %964, i64 %965, i64 %963
  %967 = sdiv i64 %966, %129
  %968 = srem i64 %950, %129
  %969 = icmp slt i64 %968, 0
  %970 = add nsw i64 %968, %129
  %971 = select i1 %969, i64 %970, i64 %968
  %972 = mul nsw i64 %127, %971
  %973 = mul nsw i64 %127, %971
  %974 = mul nsw i64 %973, -1
  %975 = add i64 %974, 32
  %976 = call i64 @llvm.smin.i64(i64 %975, i64 %127)
  %977 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %976)
  %978 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 0
  %979 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 1
  %980 = insertvalue { ptr, ptr, i64 } poison, ptr %978, 0
  %981 = insertvalue { ptr, ptr, i64 } %980, ptr %979, 1
  %982 = insertvalue { ptr, ptr, i64 } %981, i64 0, 2
  %983 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 2
  %984 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 3, 0
  %985 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 3, 1
  %986 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 3, 2
  %987 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 3, 3
  %988 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 4, 0
  %989 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 4, 1
  %990 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 4, 2
  %991 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %85, 4, 3
  %992 = mul nsw i64 %967, 1024
  %993 = mul nsw i64 %962, 32
  %994 = add i64 %992, %993
  %995 = add i64 %994, %972
  %996 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %978, 0
  %997 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %996, ptr %979, 1
  %998 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %997, i64 %995, 2
  %999 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %998, i64 %976, 3, 0
  %1000 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %999, i64 1, 4, 0
  %1001 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %1000, 1
  %1002 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %1000, 2
  %1003 = getelementptr float, ptr %1001, i64 %1002
  %1004 = getelementptr float, ptr %1003, i64 0
  %1005 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %1004, <vscale x 4 x i1> %977, <vscale x 4 x float> poison)
  %1006 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, 0
  %1007 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, 1
  %1008 = insertvalue { ptr, ptr, i64 } poison, ptr %1006, 0
  %1009 = insertvalue { ptr, ptr, i64 } %1008, ptr %1007, 1
  %1010 = insertvalue { ptr, ptr, i64 } %1009, i64 0, 2
  %1011 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, 2
  %1012 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, 3, 0
  %1013 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, 3, 1
  %1014 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, 3, 2
  %1015 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, 3, 3
  %1016 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, 4, 0
  %1017 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, 4, 1
  %1018 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, 4, 2
  %1019 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, 4, 3
  %1020 = mul nsw i64 %962, 64
  %1021 = mul nsw i64 %967, 32
  %1022 = add i64 %1020, %1021
  %1023 = add i64 %1022, %972
  %1024 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %1006, 0
  %1025 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %1024, ptr %1007, 1
  %1026 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %1025, i64 %1023, 2
  %1027 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %1026, i64 %976, 3, 0
  %1028 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %1027, i64 1, 4, 0
  %1029 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %1028, 1
  %1030 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %1028, 2
  %1031 = getelementptr float, ptr %1029, i64 %1030
  %1032 = getelementptr float, ptr %1031, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %1005, ptr align 4 %1032, <vscale x 4 x i1> %977)
  %1033 = add i64 %950, 1
  br label %949

1034:                                             ; preds = %949
  br label %1035

1035:                                             ; preds = %1038, %1034
  %1036 = phi i64 [ %1105, %1038 ], [ 0, %1034 ]
  %1037 = icmp slt i64 %1036, %146
  br i1 %1037, label %1038, label %1106

1038:                                             ; preds = %1035
  %1039 = sdiv i64 %1036, %143
  %1040 = mul i64 %1039, %143
  %1041 = icmp ne i64 %1036, %1040
  %1042 = icmp slt i64 %1036, 0
  %1043 = icmp slt i64 %143, 0
  %1044 = icmp ne i1 %1042, %1043
  %1045 = and i1 %1041, %1044
  %1046 = add i64 %1039, -1
  %1047 = select i1 %1045, i64 %1046, i64 %1039
  %1048 = srem i64 %1036, %143
  %1049 = icmp slt i64 %1048, 0
  %1050 = add nsw i64 %1048, %143
  %1051 = select i1 %1049, i64 %1050, i64 %1048
  %1052 = mul nsw i64 %127, %1051
  %1053 = mul nsw i64 %127, %1051
  %1054 = mul nsw i64 %1053, -1
  %1055 = add i64 %1054, 64
  %1056 = call i64 @llvm.smin.i64(i64 %1055, i64 %127)
  %1057 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %1056)
  %1058 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, 0
  %1059 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, 1
  %1060 = insertvalue { ptr, ptr, i64 } poison, ptr %1058, 0
  %1061 = insertvalue { ptr, ptr, i64 } %1060, ptr %1059, 1
  %1062 = insertvalue { ptr, ptr, i64 } %1061, i64 0, 2
  %1063 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, 2
  %1064 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, 3, 0
  %1065 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, 3, 1
  %1066 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, 3, 2
  %1067 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, 3, 3
  %1068 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, 4, 0
  %1069 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, 4, 1
  %1070 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, 4, 2
  %1071 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, 4, 3
  %1072 = mul nsw i64 %1047, 64
  %1073 = add i64 %1072, %1052
  %1074 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %1058, 0
  %1075 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %1074, ptr %1059, 1
  %1076 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %1075, i64 %1073, 2
  %1077 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %1076, i64 %1056, 3, 0
  %1078 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %1077, i64 1, 4, 0
  %1079 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %1078, 1
  %1080 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %1078, 2
  %1081 = getelementptr float, ptr %1079, i64 %1080
  %1082 = getelementptr float, ptr %1081, i64 0
  %1083 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %1082, <vscale x 4 x i1> %1057, <vscale x 4 x float> poison)
  %1084 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %92, 0
  %1085 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %92, 1
  %1086 = insertvalue { ptr, ptr, i64 } poison, ptr %1084, 0
  %1087 = insertvalue { ptr, ptr, i64 } %1086, ptr %1085, 1
  %1088 = insertvalue { ptr, ptr, i64 } %1087, i64 0, 2
  %1089 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %92, 2
  %1090 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %92, 3, 0
  %1091 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %92, 3, 1
  %1092 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %92, 4, 0
  %1093 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %92, 4, 1
  %1094 = mul nsw i64 %1047, 64
  %1095 = add i64 %1094, %1052
  %1096 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %1084, 0
  %1097 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %1096, ptr %1085, 1
  %1098 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %1097, i64 %1095, 2
  %1099 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %1098, i64 %1056, 3, 0
  %1100 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %1099, i64 1, 4, 0
  %1101 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %1100, 1
  %1102 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %1100, 2
  %1103 = getelementptr float, ptr %1101, i64 %1102
  %1104 = getelementptr float, ptr %1103, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %1083, ptr align 4 %1104, <vscale x 4 x i1> %1057)
  %1105 = add i64 %1036, 1
  br label %1035

1106:                                             ; preds = %1035
  %1107 = add i64 %158, 16
  %1108 = add i64 %159, %148
  call void @free(ptr %224)
  call void @free(ptr %379)
  %1109 = add i32 %157, 1
  br label %156

1110:                                             ; preds = %156
  %1111 = insertvalue { i64, i64 } poison, i64 %158, 0
  %1112 = insertvalue { i64, i64 } %1111, i64 %159, 1
  ret { i64, i64 } %1112
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.vscale.i64() #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smin.i32(i32, i32) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smin.i64(i64, i64) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smax.i64(i64, i64) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare ptr @llvm.stacksave.p0() #3

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare void @llvm.stackrestore.p0(ptr) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64, i64) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float>, ptr captures(none), <vscale x 4 x i1>) #4

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr captures(none), <vscale x 4 x i1>, <vscale x 4 x float>) #5

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite)
declare void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1>, ptr, i32 immarg, i32) #6

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float>, i64 immarg) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(target_mem1: readwrite)
declare void @llvm.aarch64.sme.mopa.nxv4f32(i32 immarg, <vscale x 4 x i1>, <vscale x 4 x i1>, <vscale x 4 x float>, <vscale x 4 x float>) #7

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite)
declare void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1>, ptr, i32 immarg, i32) #6

attributes #0 = { "aarch64_new_za" "aarch64_pstate_sm_enabled" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nosync nounwind willreturn }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite) }
attributes #7 = { nocallback nofree nosync nounwind willreturn memory(target_mem1: readwrite) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
