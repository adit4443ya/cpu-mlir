; ModuleID = '/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/A_qprof/outline/matmul_kernel-llvm-ir.ll'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64"

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @free(ptr allocptr noundef captures(none)) local_unnamed_addr #0

declare void @memrefCopy(i64, ptr, ptr) local_unnamed_addr #1

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite, errnomem: write)
declare noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #2

define void @matmul_kernel(i64 %0, ptr nofree readonly captures(none) %1, i64 %2, ptr nofree readonly captures(none) %3, i64 %4, ptr nofree readonly captures(none) %5, i32 %6, i32 %7, i32 %8, i32 %9, i32 %10, i32 %11, i32 %12, i32 %13, i32 %14, i32 %15, i32 %16, i32 %17) local_unnamed_addr #1 {
  %19 = tail call dereferenceable_or_null(8256) ptr @malloc(i64 8256)
  %20 = ptrtoint ptr %19 to i64
  %21 = add i64 %20, 63
  %22 = and i64 %21, -64
  %23 = inttoptr i64 %22 to ptr
  %24 = tail call i64 @llvm.vscale.i64()
  %25 = shl i64 %24, 2
  %26 = sdiv i64 63, %25
  %27 = add nsw i64 %26, 1
  %28 = icmp sgt i64 %26, -1
  br i1 %28, label %.lr.ph, label %._crit_edge

.lr.ph:                                           ; preds = %18
  %29 = shl nuw nsw i64 %27, 5
  br label %30

30:                                               ; preds = %.lr.ph, %30
  %31 = phi i64 [ 0, %.lr.ph ], [ %40, %30 ]
  %.frozen = freeze i64 %31
  %.frozen28 = freeze i64 %27
  %32 = udiv i64 %.frozen, %.frozen28
  %33 = mul i64 %32, %.frozen28
  %.decomposed = sub i64 %.frozen, %33
  %34 = mul nsw i64 %.decomposed, %25
  %35 = sub i64 64, %34
  %36 = tail call i64 @llvm.smin.i64(i64 %35, i64 %25)
  %37 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %36)
  %.idx = shl i64 %32, 8
  %38 = getelementptr i8, ptr %23, i64 %.idx
  %39 = getelementptr [4 x i8], ptr %38, i64 %34
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> zeroinitializer, ptr align 16 %39, <vscale x 4 x i1> %37)
  %40 = add nuw nsw i64 %31, 1
  %exitcond.not = icmp eq i64 %40, %29
  br i1 %exitcond.not, label %._crit_edge, label %30

._crit_edge:                                      ; preds = %30, %18
  %41 = add i32 %6, 31
  %42 = sdiv i32 %41, 32
  %43 = add i32 %7, 63
  %44 = sdiv i32 %43, 64
  %45 = shl nsw i32 %44, 3
  %.frozen29 = freeze i32 %15
  %.frozen30 = freeze i32 %45
  %46 = sdiv i32 %.frozen29, %.frozen30
  %47 = shl i32 %46, 3
  %48 = sub i32 %42, %47
  %49 = tail call i32 @llvm.smin.i32(i32 %48, i32 8)
  %50 = srem i32 %15, %49
  %51 = add i32 %47, %50
  %52 = mul i32 %46, %.frozen30
  %.decomposed31 = sub i32 %.frozen29, %52
  %53 = sdiv i32 %.decomposed31, %49
  %54 = shl i32 %51, 5
  %55 = sext i32 %54 to i64
  %56 = shl i32 %53, 6
  %57 = sext i32 %56 to i64
  %58 = sext i32 %6 to i64
  %59 = sext i32 %7 to i64
  %60 = tail call dereferenceable_or_null(2112) ptr @malloc(i64 2112)
  %61 = ptrtoint ptr %60 to i64
  %62 = add i64 %61, 63
  %63 = and i64 %62, -64
  %64 = inttoptr i64 %63 to ptr
  %65 = tail call dereferenceable_or_null(4160) ptr @malloc(i64 4160)
  %66 = ptrtoint ptr %65 to i64
  %67 = add i64 %66, 63
  %68 = and i64 %67, -64
  %69 = inttoptr i64 %68 to ptr
  %70 = tail call dereferenceable_or_null(8256) ptr @malloc(i64 8256)
  %71 = ptrtoint ptr %70 to i64
  %72 = add i64 %71, 63
  %73 = and i64 %72, -64
  %74 = inttoptr i64 %73 to ptr
  %75 = tail call dereferenceable_or_null(8256) ptr @malloc(i64 8256)
  %76 = ptrtoint ptr %75 to i64
  %77 = add i64 %76, 63
  %78 = and i64 %77, -64
  %79 = inttoptr i64 %78 to ptr
  tail call fastcc void @matmul_kernel_sme_0(i32 %53, i32 %7, ptr %3, i32 %10, i32 %9, i32 %6, ptr %1, i32 %8, ptr %64, ptr %69, ptr %23, ptr %74, ptr %79, i32 %46, i32 %50)
  %80 = sext i32 %11 to i64
  %81 = mul nsw i64 %55, %80
  %82 = add nsw i64 %81, %57
  %83 = add nsw i64 %55, 32
  %84 = tail call i64 @llvm.smin.i64(i64 %83, i64 %58)
  %85 = tail call i64 @llvm.smax.i64(i64 %84, i64 %55)
  %86 = sub nsw i64 %85, %55
  %87 = add nsw i64 %57, 64
  %88 = tail call i64 @llvm.smin.i64(i64 %87, i64 %59)
  %89 = tail call i64 @llvm.smax.i64(i64 %88, i64 %57)
  %90 = sub nsw i64 %89, %57
  %91 = tail call i64 @llvm.smin.i64(i64 %86, i64 32)
  %92 = tail call i64 @llvm.smin.i64(i64 %90, i64 64)
  %93 = load <2 x ptr>, ptr %5, align 8
  %94 = tail call ptr @llvm.stacksave.p0()
  %95 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, align 8
  store ptr %19, ptr %95, align 8
  %.repack1 = getelementptr inbounds nuw i8, ptr %95, i64 8
  store ptr %23, ptr %.repack1, align 8
  %.repack3 = getelementptr inbounds nuw i8, ptr %95, i64 16
  store i64 0, ptr %.repack3, align 8
  %.repack5 = getelementptr inbounds nuw i8, ptr %95, i64 24
  store i64 %91, ptr %.repack5, align 8
  %.repack5.repack9 = getelementptr inbounds nuw i8, ptr %95, i64 32
  store i64 %92, ptr %.repack5.repack9, align 8
  %.repack7 = getelementptr inbounds nuw i8, ptr %95, i64 40
  store <2 x i64> <i64 64, i64 1>, ptr %.repack7, align 8
  %96 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, align 16
  store <2 x ptr> %93, ptr %96, align 16
  %.repack14 = getelementptr inbounds nuw i8, ptr %96, i64 16
  store i64 %82, ptr %.repack14, align 16
  %.repack16 = getelementptr inbounds nuw i8, ptr %96, i64 24
  store i64 %91, ptr %.repack16, align 8
  %.repack16.repack20 = getelementptr inbounds nuw i8, ptr %96, i64 32
  store i64 %92, ptr %.repack16.repack20, align 16
  %.repack18 = getelementptr inbounds nuw i8, ptr %96, i64 40
  store i64 %80, ptr %.repack18, align 8
  %.repack18.repack22 = getelementptr inbounds nuw i8, ptr %96, i64 48
  store i64 1, ptr %.repack18.repack22, align 16
  %97 = alloca { i64, ptr }, align 8
  store i64 2, ptr %97, align 8
  %.repack24 = getelementptr inbounds nuw i8, ptr %97, i64 8
  store ptr %95, ptr %.repack24, align 8
  %98 = alloca { i64, ptr }, align 8
  store i64 2, ptr %98, align 8
  %.repack26 = getelementptr inbounds nuw i8, ptr %98, i64 8
  store ptr %96, ptr %.repack26, align 8
  call void @memrefCopy(i64 4, ptr nonnull %97, ptr nonnull %98)
  call void @llvm.stackrestore.p0(ptr %94)
  call void @free(ptr %19)
  call void @free(ptr %60)
  call void @free(ptr %65)
  call void @free(ptr %70)
  call void @free(ptr %75)
  ret void
}

; Function Attrs: nounwind memory(readwrite, target_mem0: none)
define internal fastcc void @matmul_kernel_sme_0(i32 range(i32 -268435455, 268435456) %0, i32 %1, ptr nofree readonly captures(none) %2, i32 %3, i32 %4, i32 %5, ptr nofree readonly captures(none) %6, i32 %7, ptr nofree captures(none) %8, ptr nofree captures(none) %9, ptr nofree captures(none) %10, ptr %11, ptr nofree captures(none) %12, i32 %13, i32 range(i32 -2147483647, -2147483648) %14) unnamed_addr #3 {
  %16 = shl i32 %0, 6
  %17 = sext i32 %16 to i64
  %18 = sext i32 %1 to i64
  %19 = sext i32 %3 to i64
  %20 = sext i32 %4 to i64
  %21 = sext i32 %5 to i64
  %22 = mul nsw i64 %21, %20
  %23 = tail call i64 @llvm.vscale.i64()
  %24 = shl i64 %23, 2
  %25 = sdiv i64 31, %24
  %26 = add nsw i64 %25, 1
  %27 = shl i64 %23, 3
  %28 = sdiv i64 31, %27
  %29 = add nsw i64 %28, 1
  %30 = mul nsw i64 %29, %29
  %31 = sdiv i64 63, %24
  %32 = add nsw i64 %31, 1
  %33 = shl i32 %3, 4
  %34 = sext i32 %33 to i64
  %35 = add i32 %7, 15
  %36 = sdiv i32 %35, 16
  %37 = icmp sgt i32 %35, 15
  br i1 %37, label %.lr.ph56, label %._crit_edge57

.lr.ph56:                                         ; preds = %15
  %38 = shl i32 %14, 5
  %39 = shl i32 %13, 8
  %40 = add i32 %38, %39
  %41 = sext i32 %40 to i64
  %42 = mul nsw i64 %41, %20
  %43 = shl nsw i64 %32, 5
  %44 = shl nuw nsw i64 %30, 1
  %45 = shl nsw i64 %26, 6
  %46 = getelementptr i8, ptr %2, i64 8
  %47 = getelementptr i8, ptr %6, i64 8
  %48 = tail call i64 @llvm.smin.i64(i64 %24, i64 1)
  %49 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %48)
  %50 = icmp sgt i64 %24, 0
  %51 = icmp sgt i64 %25, -1
  %52 = shl nuw nsw i64 %26, 5
  %invariant.gep47 = getelementptr [4 x i8], ptr %11, i64 %24
  %.not = icmp eq i64 %29, 0
  %53 = shl nuw nsw i64 %26, 1
  %54 = icmp sgt i64 %31, -1
  %55 = icmp slt i64 %31, -1
  %smax71 = tail call i64 @llvm.smax.i64(i64 %45, i64 1)
  %umax = tail call i64 @llvm.umax.i64(i64 %44, i64 1)
  %smax82 = tail call i64 @llvm.smax.i64(i64 %43, i64 1)
  br label %56

56:                                               ; preds = %.lr.ph56, %._crit_edge54
  %indvars.iv = phi i32 [ %7, %.lr.ph56 ], [ %indvars.iv.next, %._crit_edge54 ]
  %57 = phi i64 [ 0, %.lr.ph56 ], [ %463, %._crit_edge54 ]
  %58 = phi i64 [ %42, %.lr.ph56 ], [ %462, %._crit_edge54 ]
  %59 = phi i32 [ 0, %.lr.ph56 ], [ %464, %._crit_edge54 ]
  %smax65 = tail call i32 @llvm.smax.i32(i32 %indvars.iv, i32 0)
  %60 = tail call i32 @llvm.umin.i32(i32 %smax65, i32 16)
  %umin66 = zext nneg i32 %60 to i64
  %61 = add nsw i64 %57, %17
  %62 = srem i64 %61, %18
  %63 = sub i64 %61, %62
  %64 = add nsw i64 %62, 64
  %65 = tail call i64 @llvm.smin.i64(i64 %64, i64 %18)
  %66 = sub nsw i64 %65, %62
  %67 = sub nsw i64 0, %66
  %68 = load ptr, ptr %46, align 8
  %.neg = add nsw i64 %66, -64
  %69 = srem i64 %58, %20
  %70 = sub i64 %22, %58
  %71 = add i64 %70, %69
  %72 = sdiv i64 %71, %20
  %73 = tail call i64 @llvm.smin.i64(i64 %72, i64 32)
  %74 = load ptr, ptr %47, align 8
  %75 = sub i64 32, %73
  %76 = shl nuw nsw i32 %59, 4
  %77 = sub nsw i32 %7, %76
  %78 = tail call i32 @llvm.smax.i32(i32 %77, i32 0)
  %79 = tail call i32 @llvm.umin.i32(i32 %78, i32 16)
  %80 = zext nneg i32 %79 to i64
  %81 = tail call dereferenceable_or_null(2048) ptr @malloc(i64 2048)
  %82 = icmp slt i32 %77, 16
  br i1 %82, label %.preheader11.preheader, label %.loopexit20

.preheader11.preheader:                           ; preds = %56
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(2048) %81, i8 0, i64 2048, i1 false)
  br label %.loopexit20

.loopexit20:                                      ; preds = %.preheader11.preheader, %56
  %83 = icmp slt i32 %77, 1
  %84 = sub nsw i64 0, %80
  %85 = add nsw i64 %80, -1
  %86 = select i1 %83, i64 %84, i64 %85
  %87 = sdiv i64 %86, %24
  %88 = sub nsw i64 0, %87
  %89 = add nsw i64 %87, 1
  %90 = select i1 %83, i64 %88, i64 %89
  %91 = mul nsw i64 %90, %73
  %92 = icmp sgt i64 %91, 0
  br i1 %92, label %.lr.ph, label %._crit_edge

.lr.ph:                                           ; preds = %.loopexit20
  %93 = icmp slt i64 %90, 0
  %94 = getelementptr [4 x i8], ptr %74, i64 %58
  br label %95

95:                                               ; preds = %.lr.ph, %95
  %96 = phi i64 [ 0, %.lr.ph ], [ %114, %95 ]
  %.frozen = freeze i64 %96
  %.frozen6 = freeze i64 %90
  %97 = sdiv i64 %.frozen, %.frozen6
  %98 = mul i64 %97, %90
  %99 = icmp ne i64 %96, %98
  %100 = and i1 %93, %99
  %101 = sext i1 %100 to i64
  %102 = add i64 %97, %101
  %103 = mul i64 %97, %.frozen6
  %.decomposed = sub i64 %.frozen, %103
  %104 = mul nsw i64 %.decomposed, %24
  %105 = sub i64 %80, %104
  %106 = tail call i64 @llvm.smin.i64(i64 %105, i64 %24)
  %107 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %106)
  %108 = mul nsw i64 %102, %20
  %109 = getelementptr [4 x i8], ptr %94, i64 %108
  %110 = getelementptr [4 x i8], ptr %109, i64 %104
  %111 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %110, <vscale x 4 x i1> %107, <vscale x 4 x float> poison)
  %.idx41 = shl i64 %102, 6
  %112 = getelementptr i8, ptr %81, i64 %.idx41
  %113 = getelementptr [4 x i8], ptr %112, i64 %104
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %111, ptr align 4 %113, <vscale x 4 x i1> %107)
  %114 = add nuw nsw i64 %96, 1
  %exitcond.not = icmp eq i64 %114, %91
  br i1 %exitcond.not, label %._crit_edge, label %95

._crit_edge:                                      ; preds = %95, %.loopexit20
  %115 = mul nsw i64 %90, %75
  %116 = icmp sgt i64 %115, 0
  br i1 %116, label %.lr.ph24, label %._crit_edge25

.lr.ph24:                                         ; preds = %._crit_edge
  %117 = icmp slt i64 %90, 0
  %118 = getelementptr [4 x i8], ptr %74, i64 %69
  br label %119

119:                                              ; preds = %.lr.ph24, %119
  %120 = phi i64 [ 0, %.lr.ph24 ], [ %139, %119 ]
  %.frozen7 = freeze i64 %120
  %.frozen8 = freeze i64 %90
  %121 = sdiv i64 %.frozen7, %.frozen8
  %122 = mul i64 %121, %90
  %123 = icmp ne i64 %120, %122
  %124 = and i1 %117, %123
  %125 = sext i1 %124 to i64
  %126 = add i64 %121, %125
  %127 = mul i64 %121, %.frozen8
  %.decomposed9 = sub i64 %.frozen7, %127
  %128 = mul nsw i64 %.decomposed9, %24
  %129 = sub i64 %80, %128
  %130 = tail call i64 @llvm.smin.i64(i64 %129, i64 %24)
  %131 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %130)
  %132 = mul nsw i64 %126, %20
  %133 = getelementptr [4 x i8], ptr %118, i64 %132
  %134 = getelementptr [4 x i8], ptr %133, i64 %128
  %135 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %134, <vscale x 4 x i1> %131, <vscale x 4 x float> poison)
  %136 = add i64 %126, %73
  %.idx40 = shl i64 %136, 6
  %137 = getelementptr i8, ptr %81, i64 %.idx40
  %138 = getelementptr [4 x i8], ptr %137, i64 %128
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %135, ptr align 4 %138, <vscale x 4 x i1> %131)
  %139 = add nuw nsw i64 %120, 1
  %exitcond63.not = icmp eq i64 %139, %115
  br i1 %exitcond63.not, label %._crit_edge25, label %119

._crit_edge25:                                    ; preds = %119, %._crit_edge
  %140 = tail call dereferenceable_or_null(4096) ptr @malloc(i64 4096)
  br i1 %82, label %.preheader10.preheader, label %.loopexit

.preheader10.preheader:                           ; preds = %._crit_edge25
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(4096) %140, i8 0, i64 4096, i1 false)
  br label %.loopexit

.loopexit:                                        ; preds = %.preheader10.preheader, %._crit_edge25
  %141 = icmp slt i64 %66, 1
  %142 = add nsw i64 %66, -1
  %143 = select i1 %141, i64 %67, i64 %142
  %144 = sdiv i64 %143, %24
  %145 = sub nsw i64 0, %144
  %146 = add nsw i64 %144, 1
  %147 = select i1 %141, i64 %145, i64 %146
  %148 = mul nsw i64 %147, %80
  %149 = icmp sgt i64 %148, 0
  br i1 %149, label %.lr.ph27, label %._crit_edge28

.lr.ph27:                                         ; preds = %.loopexit
  %150 = icmp slt i64 %147, 0
  %151 = getelementptr [4 x i8], ptr %68, i64 %61
  %152 = mul nsw i64 %147, %umin66
  br label %153

153:                                              ; preds = %.lr.ph27, %153
  %154 = phi i64 [ 0, %.lr.ph27 ], [ %172, %153 ]
  %.frozen10 = freeze i64 %154
  %.frozen11 = freeze i64 %147
  %155 = sdiv i64 %.frozen10, %.frozen11
  %156 = mul i64 %155, %147
  %157 = icmp ne i64 %154, %156
  %158 = and i1 %150, %157
  %159 = sext i1 %158 to i64
  %160 = add i64 %155, %159
  %161 = mul i64 %155, %.frozen11
  %.decomposed12 = sub i64 %.frozen10, %161
  %162 = mul nsw i64 %.decomposed12, %24
  %163 = sub i64 %66, %162
  %164 = tail call i64 @llvm.smin.i64(i64 %163, i64 %24)
  %165 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %164)
  %166 = mul nsw i64 %160, %19
  %167 = getelementptr [4 x i8], ptr %151, i64 %166
  %168 = getelementptr [4 x i8], ptr %167, i64 %162
  %169 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %168, <vscale x 4 x i1> %165, <vscale x 4 x float> poison)
  %.idx38 = shl i64 %160, 8
  %170 = getelementptr i8, ptr %140, i64 %.idx38
  %171 = getelementptr [4 x i8], ptr %170, i64 %162
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %169, ptr align 4 %171, <vscale x 4 x i1> %165)
  %172 = add nuw nsw i64 %154, 1
  %exitcond64.not = icmp eq i64 %172, %152
  br i1 %exitcond64.not, label %._crit_edge28, label %153

._crit_edge28:                                    ; preds = %153, %.loopexit
  %173 = icmp sgt i64 %66, 63
  %174 = sub nsw i64 63, %66
  %175 = select i1 %173, i64 %.neg, i64 %174
  %176 = sdiv i64 %175, %24
  %177 = sub nsw i64 0, %176
  %178 = add nsw i64 %176, 1
  %179 = select i1 %173, i64 %177, i64 %178
  %180 = mul nsw i64 %179, %80
  %181 = icmp sgt i64 %180, 0
  br i1 %181, label %.lr.ph30, label %.preheader17.preheader

.lr.ph30:                                         ; preds = %._crit_edge28
  %182 = icmp slt i64 %179, 0
  %183 = getelementptr [4 x i8], ptr %68, i64 %63
  %184 = getelementptr [4 x i8], ptr %140, i64 %66
  %185 = mul nsw i64 %179, %umin66
  br label %186

186:                                              ; preds = %.lr.ph30, %186
  %187 = phi i64 [ 0, %.lr.ph30 ], [ %206, %186 ]
  %.frozen13 = freeze i64 %187
  %.frozen14 = freeze i64 %179
  %188 = sdiv i64 %.frozen13, %.frozen14
  %189 = mul i64 %188, %179
  %190 = icmp ne i64 %187, %189
  %191 = and i1 %182, %190
  %192 = sext i1 %191 to i64
  %193 = add i64 %188, %192
  %194 = mul i64 %188, %.frozen14
  %.decomposed15 = sub i64 %.frozen13, %194
  %195 = mul nsw i64 %.decomposed15, %24
  %196 = add i64 %66, %195
  %197 = sub i64 64, %196
  %198 = tail call i64 @llvm.smin.i64(i64 %197, i64 %24)
  %199 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %198)
  %200 = mul nsw i64 %193, %19
  %201 = getelementptr [4 x i8], ptr %183, i64 %200
  %202 = getelementptr [4 x i8], ptr %201, i64 %195
  %203 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %202, <vscale x 4 x i1> %199, <vscale x 4 x float> poison)
  %.idx37 = shl i64 %193, 8
  %204 = getelementptr i8, ptr %184, i64 %.idx37
  %205 = getelementptr [4 x i8], ptr %204, i64 %195
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %203, ptr align 4 %205, <vscale x 4 x i1> %199)
  %206 = add nuw nsw i64 %187, 1
  %exitcond67.not = icmp eq i64 %206, %185
  br i1 %exitcond67.not, label %.preheader17.preheader, label %186

.preheader17.preheader:                           ; preds = %186, %._crit_edge28
  br label %.preheader17

.preheader17:                                     ; preds = %.preheader17.preheader, %.preheader17
  %207 = phi i64 [ %214, %.preheader17 ], [ 0, %.preheader17.preheader ]
  %208 = lshr i64 %207, 5
  %209 = shl nuw nsw i64 %207, 6
  %.idx36 = and i64 %209, 1984
  %210 = getelementptr i8, ptr %81, i64 %.idx36
  %211 = getelementptr [4 x i8], ptr %210, i64 %208
  %212 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %211, <vscale x 4 x i1> %49, <vscale x 4 x float> poison)
  %213 = getelementptr [4 x i8], ptr %8, i64 %207
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %212, ptr align 4 %213, <vscale x 4 x i1> %49)
  %214 = add nuw nsw i64 %207, 1
  %exitcond68.not = icmp eq i64 %214, 512
  br i1 %exitcond68.not, label %.preheader16, label %.preheader17

.preheader15:                                     ; preds = %._crit_edge35
  br i1 %51, label %.lr.ph36, label %.preheader14

.preheader16:                                     ; preds = %.preheader17, %._crit_edge35
  %215 = phi i64 [ %236, %._crit_edge35 ], [ 0, %.preheader17 ]
  %216 = lshr i64 %215, 5
  %217 = and i64 %216, 15
  %218 = and i64 %215, 31
  br i1 %50, label %.lr.ph34, label %._crit_edge35

.lr.ph34:                                         ; preds = %.preheader16
  %219 = lshr i64 %215, 4
  %220 = and i64 %219, 32
  %invariant.gep = getelementptr [4 x i8], ptr %140, i64 %220
  %invariant.gep31 = getelementptr [4 x i8], ptr %invariant.gep, i64 %218
  %.idx34 = shl nuw nsw i64 %217, 8
  %gep32 = getelementptr i8, ptr %invariant.gep31, i64 %.idx34
  br label %221

221:                                              ; preds = %.lr.ph34, %229
  %222 = phi <vscale x 4 x float> [ poison, %.lr.ph34 ], [ %230, %229 ]
  %223 = phi i64 [ 0, %.lr.ph34 ], [ %231, %229 ]
  %224 = extractelement <vscale x 4 x i1> %49, i64 %223
  br i1 %224, label %225, label %229

225:                                              ; preds = %221
  %.idx35 = shl nuw nsw i64 %223, 8
  %226 = getelementptr inbounds nuw i8, ptr %gep32, i64 %.idx35
  %227 = load float, ptr %226, align 4
  %228 = insertelement <vscale x 4 x float> %222, float %227, i64 %223
  br label %229

229:                                              ; preds = %225, %221
  %230 = phi <vscale x 4 x float> [ %228, %225 ], [ %222, %221 ]
  %231 = add nuw nsw i64 %223, 1
  %exitcond69.not = icmp eq i64 %231, %24
  br i1 %exitcond69.not, label %._crit_edge35, label %221

._crit_edge35:                                    ; preds = %229, %.preheader16
  %.lcssa = phi <vscale x 4 x float> [ poison, %.preheader16 ], [ %230, %229 ]
  %232 = and i64 %215, 512
  %233 = getelementptr [4 x i8], ptr %9, i64 %232
  %.idx33 = shl nuw nsw i64 %217, 7
  %234 = getelementptr i8, ptr %233, i64 %.idx33
  %235 = getelementptr [4 x i8], ptr %234, i64 %218
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %.lcssa, ptr align 4 %235, <vscale x 4 x i1> %49)
  %236 = add nuw nsw i64 %215, 1
  %exitcond70.not = icmp eq i64 %236, 1024
  br i1 %exitcond70.not, label %.preheader15, label %.preheader16

.preheader14:                                     ; preds = %.lr.ph36, %.preheader15
  br i1 %.not, label %.preheader13, label %.lr.ph51

.lr.ph36:                                         ; preds = %.preheader15, %.lr.ph36
  %237 = phi i64 [ %253, %.lr.ph36 ], [ 0, %.preheader15 ]
  %.frozen16 = freeze i64 %237
  %.frozen17 = freeze i64 %52
  %238 = udiv i64 %.frozen16, %.frozen17
  %239 = mul i64 %238, %.frozen17
  %.decomposed18 = sub i64 %.frozen16, %239
  %240 = udiv i64 %.decomposed18, %26
  %241 = urem i64 %237, %26
  %242 = mul nsw i64 %241, %24
  %243 = sub i64 32, %242
  %244 = tail call i64 @llvm.smin.i64(i64 %243, i64 %24)
  %245 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %244)
  %.idx29 = shl i64 %240, 8
  %246 = getelementptr i8, ptr %10, i64 %.idx29
  %.idx30 = shl i64 %238, 7
  %247 = getelementptr i8, ptr %246, i64 %.idx30
  %248 = getelementptr [4 x i8], ptr %247, i64 %242
  %249 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %248, <vscale x 4 x i1> %245, <vscale x 4 x float> poison)
  %.idx31 = shl i64 %238, 12
  %250 = getelementptr i8, ptr %11, i64 %.idx31
  %.idx32 = shl i64 %240, 7
  %251 = getelementptr i8, ptr %250, i64 %.idx32
  %252 = getelementptr [4 x i8], ptr %251, i64 %242
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %249, ptr align 4 %252, <vscale x 4 x i1> %245)
  %253 = add nuw nsw i64 %237, 1
  %exitcond72.not = icmp eq i64 %253, %smax71
  br i1 %exitcond72.not, label %.preheader14, label %.lr.ph36

.preheader13:                                     ; preds = %._crit_edge46, %.preheader14
  br i1 %51, label %.lr.ph52, label %.preheader12

.lr.ph51:                                         ; preds = %.preheader14, %._crit_edge46
  %254 = phi i64 [ %426, %._crit_edge46 ], [ 0, %.preheader14 ]
  %.frozen19 = freeze i64 %254
  %.frozen20 = freeze i64 %30
  %255 = udiv i64 %.frozen19, %.frozen20
  %256 = mul i64 %255, %.frozen20
  %.decomposed21 = sub i64 %.frozen19, %256
  %257 = sdiv i64 %.decomposed21, %29
  %258 = srem i64 %254, %29
  %259 = mul nsw i64 %258, %27
  %260 = mul nsw i64 %257, %27
  %261 = shl nsw i64 %255, 10
  %262 = shl nsw i64 %260, 5
  %263 = add i64 %262, %261
  %264 = add i64 %263, %259
  br i1 %50, label %.lr.ph38, label %.preheader6

.lr.ph38:                                         ; preds = %.lr.ph51
  %265 = getelementptr [4 x i8], ptr %11, i64 %264
  br label %266

.lr.ph39:                                         ; preds = %266
  %gep48 = getelementptr [4 x i8], ptr %invariant.gep47, i64 %264
  br label %272

266:                                              ; preds = %.lr.ph38, %266
  %267 = phi i64 [ 0, %.lr.ph38 ], [ %270, %266 ]
  %.idx28 = shl i64 %267, 7
  %268 = getelementptr i8, ptr %265, i64 %.idx28
  %269 = trunc i64 %267 to i32
  tail call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %268, i32 0, i32 %269)
  %270 = add nuw nsw i64 %267, 1
  %exitcond73.not = icmp eq i64 %270, %24
  br i1 %exitcond73.not, label %.lr.ph39, label %266

.lr.ph41:                                         ; preds = %272
  %271 = getelementptr [4 x i8], ptr %11, i64 %264
  br label %276

272:                                              ; preds = %.lr.ph39, %272
  %273 = phi i64 [ 0, %.lr.ph39 ], [ %275, %272 ]
  %.idx27 = shl i64 %273, 7
  %gep = getelementptr i8, ptr %gep48, i64 %.idx27
  %274 = trunc i64 %273 to i32
  tail call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %gep, i32 1, i32 %274)
  %275 = add nuw nsw i64 %273, 1
  %exitcond74.not = icmp eq i64 %275, %24
  br i1 %exitcond74.not, label %.lr.ph41, label %272

.lr.ph42:                                         ; preds = %276
  %gep50 = getelementptr [4 x i8], ptr %invariant.gep47, i64 %264
  br label %411

276:                                              ; preds = %.lr.ph41, %276
  %277 = phi i64 [ 0, %.lr.ph41 ], [ %281, %276 ]
  %278 = add nuw i64 %277, %24
  %.idx26 = shl i64 %278, 7
  %279 = getelementptr i8, ptr %271, i64 %.idx26
  %280 = trunc i64 %277 to i32
  tail call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %279, i32 2, i32 %280)
  %281 = add nuw nsw i64 %277, 1
  %exitcond75.not = icmp eq i64 %281, %24
  br i1 %exitcond75.not, label %.lr.ph42, label %276

.preheader6:                                      ; preds = %411, %.lr.ph51
  %282 = getelementptr [4 x i8], ptr %8, i64 %260
  %.idx24 = shl i64 %255, 11
  %283 = getelementptr i8, ptr %9, i64 %.idx24
  %284 = getelementptr [4 x i8], ptr %283, i64 %259
  %285 = load <vscale x 8 x float>, ptr %282, align 4
  %286 = load <vscale x 8 x float>, ptr %284, align 4
  %287 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %285, i64 0)
  %288 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %286, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %287, <vscale x 4 x float> %288)
  %289 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %286, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %287, <vscale x 4 x float> %289)
  %290 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %285, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %290, <vscale x 4 x float> %288)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %290, <vscale x 4 x float> %289)
  %291 = getelementptr i8, ptr %282, i64 128
  %292 = load <vscale x 8 x float>, ptr %291, align 4
  %293 = getelementptr i8, ptr %284, i64 128
  %294 = load <vscale x 8 x float>, ptr %293, align 4
  %295 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %292, i64 0)
  %296 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %294, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %295, <vscale x 4 x float> %296)
  %297 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %294, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %295, <vscale x 4 x float> %297)
  %298 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %292, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %298, <vscale x 4 x float> %296)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %298, <vscale x 4 x float> %297)
  %299 = getelementptr i8, ptr %282, i64 256
  %300 = load <vscale x 8 x float>, ptr %299, align 4
  %301 = getelementptr i8, ptr %284, i64 256
  %302 = load <vscale x 8 x float>, ptr %301, align 4
  %303 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %300, i64 0)
  %304 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %302, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %303, <vscale x 4 x float> %304)
  %305 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %302, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %303, <vscale x 4 x float> %305)
  %306 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %300, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %306, <vscale x 4 x float> %304)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %306, <vscale x 4 x float> %305)
  %307 = getelementptr i8, ptr %282, i64 384
  %308 = load <vscale x 8 x float>, ptr %307, align 4
  %309 = getelementptr i8, ptr %284, i64 384
  %310 = load <vscale x 8 x float>, ptr %309, align 4
  %311 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %308, i64 0)
  %312 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %310, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %311, <vscale x 4 x float> %312)
  %313 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %310, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %311, <vscale x 4 x float> %313)
  %314 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %308, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %314, <vscale x 4 x float> %312)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %314, <vscale x 4 x float> %313)
  %315 = getelementptr i8, ptr %282, i64 512
  %316 = load <vscale x 8 x float>, ptr %315, align 4
  %317 = getelementptr i8, ptr %284, i64 512
  %318 = load <vscale x 8 x float>, ptr %317, align 4
  %319 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %316, i64 0)
  %320 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %318, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %319, <vscale x 4 x float> %320)
  %321 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %318, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %319, <vscale x 4 x float> %321)
  %322 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %316, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %322, <vscale x 4 x float> %320)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %322, <vscale x 4 x float> %321)
  %323 = getelementptr i8, ptr %282, i64 640
  %324 = load <vscale x 8 x float>, ptr %323, align 4
  %325 = getelementptr i8, ptr %284, i64 640
  %326 = load <vscale x 8 x float>, ptr %325, align 4
  %327 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %324, i64 0)
  %328 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %326, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %327, <vscale x 4 x float> %328)
  %329 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %326, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %327, <vscale x 4 x float> %329)
  %330 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %324, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %330, <vscale x 4 x float> %328)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %330, <vscale x 4 x float> %329)
  %331 = getelementptr i8, ptr %282, i64 768
  %332 = load <vscale x 8 x float>, ptr %331, align 4
  %333 = getelementptr i8, ptr %284, i64 768
  %334 = load <vscale x 8 x float>, ptr %333, align 4
  %335 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %332, i64 0)
  %336 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %334, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %335, <vscale x 4 x float> %336)
  %337 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %334, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %335, <vscale x 4 x float> %337)
  %338 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %332, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %338, <vscale x 4 x float> %336)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %338, <vscale x 4 x float> %337)
  %339 = getelementptr i8, ptr %282, i64 896
  %340 = load <vscale x 8 x float>, ptr %339, align 4
  %341 = getelementptr i8, ptr %284, i64 896
  %342 = load <vscale x 8 x float>, ptr %341, align 4
  %343 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %340, i64 0)
  %344 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %342, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %343, <vscale x 4 x float> %344)
  %345 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %342, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %343, <vscale x 4 x float> %345)
  %346 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %340, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %346, <vscale x 4 x float> %344)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %346, <vscale x 4 x float> %345)
  %347 = getelementptr i8, ptr %282, i64 1024
  %348 = load <vscale x 8 x float>, ptr %347, align 4
  %349 = getelementptr i8, ptr %284, i64 1024
  %350 = load <vscale x 8 x float>, ptr %349, align 4
  %351 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %348, i64 0)
  %352 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %350, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %351, <vscale x 4 x float> %352)
  %353 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %350, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %351, <vscale x 4 x float> %353)
  %354 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %348, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %354, <vscale x 4 x float> %352)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %354, <vscale x 4 x float> %353)
  %355 = getelementptr i8, ptr %282, i64 1152
  %356 = load <vscale x 8 x float>, ptr %355, align 4
  %357 = getelementptr i8, ptr %284, i64 1152
  %358 = load <vscale x 8 x float>, ptr %357, align 4
  %359 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %356, i64 0)
  %360 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %358, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %359, <vscale x 4 x float> %360)
  %361 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %358, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %359, <vscale x 4 x float> %361)
  %362 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %356, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %362, <vscale x 4 x float> %360)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %362, <vscale x 4 x float> %361)
  %363 = getelementptr i8, ptr %282, i64 1280
  %364 = load <vscale x 8 x float>, ptr %363, align 4
  %365 = getelementptr i8, ptr %284, i64 1280
  %366 = load <vscale x 8 x float>, ptr %365, align 4
  %367 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %364, i64 0)
  %368 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %366, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %367, <vscale x 4 x float> %368)
  %369 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %366, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %367, <vscale x 4 x float> %369)
  %370 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %364, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %370, <vscale x 4 x float> %368)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %370, <vscale x 4 x float> %369)
  %371 = getelementptr i8, ptr %282, i64 1408
  %372 = load <vscale x 8 x float>, ptr %371, align 4
  %373 = getelementptr i8, ptr %284, i64 1408
  %374 = load <vscale x 8 x float>, ptr %373, align 4
  %375 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %372, i64 0)
  %376 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %374, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %375, <vscale x 4 x float> %376)
  %377 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %374, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %375, <vscale x 4 x float> %377)
  %378 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %372, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %378, <vscale x 4 x float> %376)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %378, <vscale x 4 x float> %377)
  %379 = getelementptr i8, ptr %282, i64 1536
  %380 = load <vscale x 8 x float>, ptr %379, align 4
  %381 = getelementptr i8, ptr %284, i64 1536
  %382 = load <vscale x 8 x float>, ptr %381, align 4
  %383 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %380, i64 0)
  %384 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %382, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %383, <vscale x 4 x float> %384)
  %385 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %382, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %383, <vscale x 4 x float> %385)
  %386 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %380, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %386, <vscale x 4 x float> %384)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %386, <vscale x 4 x float> %385)
  %387 = getelementptr i8, ptr %282, i64 1664
  %388 = load <vscale x 8 x float>, ptr %387, align 4
  %389 = getelementptr i8, ptr %284, i64 1664
  %390 = load <vscale x 8 x float>, ptr %389, align 4
  %391 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %388, i64 0)
  %392 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %390, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %391, <vscale x 4 x float> %392)
  %393 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %390, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %391, <vscale x 4 x float> %393)
  %394 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %388, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %394, <vscale x 4 x float> %392)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %394, <vscale x 4 x float> %393)
  %395 = getelementptr i8, ptr %282, i64 1792
  %396 = load <vscale x 8 x float>, ptr %395, align 4
  %397 = getelementptr i8, ptr %284, i64 1792
  %398 = load <vscale x 8 x float>, ptr %397, align 4
  %399 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %396, i64 0)
  %400 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %398, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %399, <vscale x 4 x float> %400)
  %401 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %398, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %399, <vscale x 4 x float> %401)
  %402 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %396, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %402, <vscale x 4 x float> %400)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %402, <vscale x 4 x float> %401)
  %403 = getelementptr i8, ptr %282, i64 1920
  %404 = load <vscale x 8 x float>, ptr %403, align 4
  %405 = getelementptr i8, ptr %284, i64 1920
  %406 = load <vscale x 8 x float>, ptr %405, align 4
  %407 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %404, i64 0)
  %408 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %406, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %407, <vscale x 4 x float> %408)
  %409 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %406, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %407, <vscale x 4 x float> %409)
  %410 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %404, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %410, <vscale x 4 x float> %408)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %410, <vscale x 4 x float> %409)
  br i1 %50, label %.lr.ph45, label %._crit_edge46

411:                                              ; preds = %.lr.ph42, %411
  %412 = phi i64 [ 0, %.lr.ph42 ], [ %415, %411 ]
  %413 = add nuw i64 %412, %24
  %.idx25 = shl i64 %413, 7
  %gep44 = getelementptr i8, ptr %gep50, i64 %.idx25
  %414 = trunc i64 %412 to i32
  tail call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %gep44, i32 3, i32 %414)
  %415 = add nuw nsw i64 %412, 1
  %exitcond76.not = icmp eq i64 %415, %24
  br i1 %exitcond76.not, label %.preheader6, label %411

.lr.ph45:                                         ; preds = %.preheader6
  %416 = getelementptr [4 x i8], ptr %11, i64 %264
  br label %417

417:                                              ; preds = %.lr.ph45, %417
  %418 = phi i64 [ 0, %.lr.ph45 ], [ %425, %417 ]
  %.idx1 = shl i64 %418, 7
  %419 = getelementptr i8, ptr %416, i64 %.idx1
  %420 = trunc i64 %418 to i32
  tail call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %419, i32 0, i32 %420)
  %421 = getelementptr [4 x i8], ptr %419, i64 %24
  tail call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %421, i32 1, i32 %420)
  %422 = add nuw i64 %418, %24
  %.idx2 = shl i64 %422, 7
  %423 = getelementptr i8, ptr %416, i64 %.idx2
  tail call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %423, i32 2, i32 %420)
  %424 = getelementptr [4 x i8], ptr %423, i64 %24
  tail call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %424, i32 3, i32 %420)
  %425 = add nuw nsw i64 %418, 1
  %exitcond78.not = icmp eq i64 %425, %24
  br i1 %exitcond78.not, label %._crit_edge46, label %417

._crit_edge46:                                    ; preds = %417, %.preheader6
  %426 = add nuw nsw i64 %254, 1
  %exitcond79.not = icmp eq i64 %426, %umax
  br i1 %exitcond79.not, label %.preheader13, label %.lr.ph51

.preheader12:                                     ; preds = %.lr.ph52, %.preheader13
  br i1 %54, label %.lr.ph53, label %._crit_edge54

.lr.ph52:                                         ; preds = %.preheader13, %.lr.ph52
  %427 = phi i64 [ %443, %.lr.ph52 ], [ 0, %.preheader13 ]
  %.frozen22 = freeze i64 %427
  %.frozen23 = freeze i64 %53
  %428 = udiv i64 %.frozen22, %.frozen23
  %429 = mul i64 %428, %.frozen23
  %.decomposed24 = sub i64 %.frozen22, %429
  %430 = udiv i64 %.decomposed24, %26
  %431 = urem i64 %427, %26
  %432 = mul nsw i64 %431, %24
  %433 = sub i64 32, %432
  %434 = tail call i64 @llvm.smin.i64(i64 %433, i64 %24)
  %435 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %434)
  %.idx = shl i64 %430, 12
  %436 = getelementptr i8, ptr %11, i64 %.idx
  %.idx21 = shl i64 %428, 7
  %437 = getelementptr i8, ptr %436, i64 %.idx21
  %438 = getelementptr [4 x i8], ptr %437, i64 %432
  %439 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %438, <vscale x 4 x i1> %435, <vscale x 4 x float> poison)
  %.idx22 = shl i64 %428, 8
  %440 = getelementptr i8, ptr %12, i64 %.idx22
  %.idx23 = shl i64 %430, 7
  %441 = getelementptr i8, ptr %440, i64 %.idx23
  %442 = getelementptr [4 x i8], ptr %441, i64 %432
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %439, ptr align 4 %442, <vscale x 4 x i1> %435)
  %443 = add nuw nsw i64 %427, 1
  %exitcond81.not = icmp eq i64 %443, %smax71
  br i1 %exitcond81.not, label %.preheader12, label %.lr.ph52

.lr.ph53:                                         ; preds = %.preheader12, %.lr.ph53
  %444 = phi i64 [ %461, %.lr.ph53 ], [ 0, %.preheader12 ]
  %.frozen25 = freeze i64 %444
  %.frozen26 = freeze i64 %32
  %445 = udiv i64 %.frozen25, %.frozen26
  %446 = mul i64 %445, %32
  %447 = icmp ne i64 %444, %446
  %448 = and i1 %55, %447
  %449 = sext i1 %448 to i64
  %450 = add i64 %445, %449
  %451 = mul i64 %445, %.frozen26
  %.decomposed27 = sub i64 %.frozen25, %451
  %452 = mul nsw i64 %.decomposed27, %24
  %453 = sub i64 64, %452
  %454 = tail call i64 @llvm.smin.i64(i64 %453, i64 %24)
  %455 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %454)
  %456 = shl nsw i64 %450, 6
  %457 = add i64 %456, %452
  %458 = getelementptr [4 x i8], ptr %12, i64 %457
  %459 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %458, <vscale x 4 x i1> %455, <vscale x 4 x float> poison)
  %460 = getelementptr [4 x i8], ptr %10, i64 %457
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %459, ptr align 4 %460, <vscale x 4 x i1> %455)
  %461 = add nuw nsw i64 %444, 1
  %exitcond83.not = icmp eq i64 %461, %smax82
  br i1 %exitcond83.not, label %._crit_edge54, label %.lr.ph53

._crit_edge54:                                    ; preds = %.lr.ph53, %.preheader12
  %462 = add nsw i64 %58, 16
  %463 = add i64 %57, %34
  tail call void @free(ptr %81)
  tail call void @free(ptr %140)
  %464 = add nuw nsw i32 %59, 1
  %indvars.iv.next = add i32 %indvars.iv, -16
  %exitcond84.not = icmp eq i32 %464, %36
  br i1 %exitcond84.not, label %._crit_edge57, label %56

._crit_edge57:                                    ; preds = %._crit_edge54, %15
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.vscale.i64() #4

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smin.i32(i32, i32) #5

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smin.i64(i64, i64) #5

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smax.i64(i64, i64) #5

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare ptr @llvm.stacksave.p0() #6

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.stackrestore.p0(ptr) #6

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64, i64) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float>, ptr captures(none), <vscale x 4 x i1>) #7

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr captures(none), <vscale x 4 x i1>, <vscale x 4 x float>) #8

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite)
declare void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1>, ptr, i32 immarg, i32) #9

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float>, i64 immarg) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(target_mem1: readwrite)
declare void @llvm.aarch64.sme.mopa.nxv4f32(i32 immarg, <vscale x 4 x i1>, <vscale x 4 x i1>, <vscale x 4 x float>, <vscale x 4 x float>) #10

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite)
declare void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1>, ptr, i32 immarg, i32) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smax.i32(i32, i32) #11

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umin.i32(i32, i32) #11

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umax.i64(i64, i64) #11

attributes #0 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "target-features"="+sve,+sve2,+sme" }
attributes #1 = { "target-features"="+sve,+sve2,+sme" }
attributes #2 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite, errnomem: write) "alloc-family"="malloc" "target-features"="+sve,+sve2,+sme" }
attributes #3 = { nounwind memory(readwrite, target_mem0: none) "aarch64_new_za" "aarch64_pstate_sm_enabled" "target-features"="+sve,+sve2,+sme" }
attributes #4 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) "target-features"="+sve,+sve2,+sme" }
attributes #5 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) "target-features"="+sve,+sve2,+sme" }
attributes #6 = { mustprogress nocallback nofree nosync nounwind willreturn "target-features"="+sve,+sve2,+sme" }
attributes #7 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write) "target-features"="+sve,+sve2,+sme" }
attributes #8 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read) "target-features"="+sve,+sve2,+sme" }
attributes #9 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite) "target-features"="+sve,+sve2,+sme" }
attributes #10 = { mustprogress nocallback nofree nosync nounwind willreturn memory(target_mem1: readwrite) "target-features"="+sve,+sve2,+sme" }
attributes #11 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #12 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
