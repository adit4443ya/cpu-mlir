; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target triple = "aarch64"

declare void @memrefCopy(i64, ptr, ptr)

declare void @free(ptr)

declare ptr @malloc(i64)

define void @matmul_kernel(i64 %0, ptr %1, i64 %2, ptr %3, i64 %4, ptr %5, i32 %6, i32 %7, i32 %8, i32 %9, i32 %10, i32 %11, i32 %12, i32 %13, i32 %14, i32 %15, i32 %16, i32 %17) #0 {
  %19 = insertvalue { i64, ptr } poison, i64 %4, 0
  %20 = insertvalue { i64, ptr } %19, ptr %5, 1
  %21 = insertvalue { i64, ptr } poison, i64 %2, 0
  %22 = insertvalue { i64, ptr } %21, ptr %3, 1
  %23 = insertvalue { i64, ptr } poison, i64 %0, 0
  %24 = insertvalue { i64, ptr } %23, ptr %1, 1
  %25 = call ptr @malloc(i64 8256)
  %26 = ptrtoint ptr %25 to i64
  %27 = add i64 %26, 63
  %28 = urem i64 %27, 64
  %29 = sub i64 %27, %28
  %30 = inttoptr i64 %29 to ptr
  %31 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %25, 0
  %32 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %31, ptr %30, 1
  %33 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %32, i64 0, 2
  %34 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %33, i64 32, 3, 0
  %35 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %34, i64 64, 3, 1
  %36 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %35, i64 64, 4, 0
  %37 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %36, i64 1, 4, 1
  %38 = call i64 @llvm.vscale.i64()
  %39 = mul i64 %38, 4
  %40 = sdiv i64 63, %39
  %41 = add i64 %40, 1
  %42 = sdiv i64 63, %39
  %43 = add i64 %42, 1
  %44 = mul nsw i64 %43, 32
  br label %45

45:                                               ; preds = %48, %18
  %46 = phi i64 [ %79, %48 ], [ 0, %18 ]
  %47 = icmp slt i64 %46, %44
  br i1 %47, label %48, label %80

48:                                               ; preds = %45
  %49 = sdiv i64 %46, %41
  %50 = mul i64 %49, %41
  %51 = icmp ne i64 %46, %50
  %52 = icmp slt i64 %46, 0
  %53 = icmp slt i64 %41, 0
  %54 = icmp ne i1 %52, %53
  %55 = and i1 %51, %54
  %56 = add i64 %49, -1
  %57 = select i1 %55, i64 %56, i64 %49
  %58 = srem i64 %46, %41
  %59 = icmp slt i64 %58, 0
  %60 = add nsw i64 %58, %41
  %61 = select i1 %59, i64 %60, i64 %58
  %62 = mul nsw i64 %39, %61
  %63 = mul nsw i64 %39, %61
  %64 = mul nsw i64 %63, -1
  %65 = add i64 %64, 64
  %66 = call i64 @llvm.smin.i64(i64 %65, i64 %39)
  %67 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %66)
  %68 = mul nsw i64 %57, 64
  %69 = add i64 %68, %62
  %70 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %25, 0
  %71 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %70, ptr %30, 1
  %72 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %71, i64 %69, 2
  %73 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %72, i64 %66, 3, 0
  %74 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %73, i64 1, 4, 0
  %75 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %74, 1
  %76 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %74, 2
  %77 = getelementptr float, ptr %75, i64 %76
  %78 = getelementptr float, ptr %77, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> zeroinitializer, ptr align 4 %78, <vscale x 4 x i1> %67)
  %79 = add i64 %46, 1
  br label %45

80:                                               ; preds = %45
  %81 = add i32 %6, 31
  %82 = sdiv i32 %81, 32
  %83 = add i32 %7, 63
  %84 = sdiv i32 %83, 64
  %85 = mul i32 %84, 8
  %86 = sdiv i32 %15, %85
  %87 = mul i32 %86, 8
  %88 = sub i32 %82, %87
  %89 = call i32 @llvm.smin.i32(i32 %88, i32 8)
  %90 = srem i32 %15, %89
  %91 = add i32 %87, %90
  %92 = srem i32 %15, %85
  %93 = sdiv i32 %92, %89
  %94 = mul i32 %91, 32
  %95 = sext i32 %94 to i64
  %96 = mul i32 %93, 64
  %97 = sext i32 %96 to i64
  %98 = sext i32 %6 to i64
  %99 = sext i32 %9 to i64
  %100 = mul i64 %95, %99
  %101 = mul i64 %98, %99
  %102 = sext i32 %10 to i64
  %103 = sext i32 %7 to i64
  %104 = add i32 %8, 15
  %105 = sdiv i32 %104, 16
  %106 = mul i32 %10, 16
  %107 = sext i32 %106 to i64
  %108 = call ptr @malloc(i64 8256)
  %109 = ptrtoint ptr %108 to i64
  %110 = add i64 %109, 63
  %111 = urem i64 %110, 64
  %112 = sub i64 %110, %111
  %113 = inttoptr i64 %112 to ptr
  %114 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %108, 0
  %115 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, ptr %113, 1
  %116 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %115, i64 0, 2
  %117 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %116, i64 1, 3, 0
  %118 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %117, i64 2, 3, 1
  %119 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %118, i64 32, 3, 2
  %120 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %119, i64 32, 3, 3
  %121 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %120, i64 2048, 4, 0
  %122 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %121, i64 1024, 4, 1
  %123 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %122, i64 32, 4, 2
  %124 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %123, i64 1, 4, 3
  %125 = sdiv i64 31, %39
  %126 = add i64 %125, 1
  %127 = sdiv i64 31, %39
  %128 = add i64 %127, 1
  %129 = mul nsw i64 %128, 64
  br label %130

130:                                              ; preds = %133, %80
  %131 = phi i64 [ %186, %133 ], [ 0, %80 ]
  %132 = icmp slt i64 %131, %129
  br i1 %132, label %133, label %187

133:                                              ; preds = %130
  %134 = mul nuw nsw i64 %126, 32
  %135 = sdiv i64 %131, %134
  %136 = mul i64 %135, %134
  %137 = icmp ne i64 %131, %136
  %138 = icmp slt i64 %131, 0
  %139 = icmp slt i64 %134, 0
  %140 = icmp ne i1 %138, %139
  %141 = and i1 %137, %140
  %142 = add i64 %135, -1
  %143 = select i1 %141, i64 %142, i64 %135
  %144 = srem i64 %131, %134
  %145 = icmp slt i64 %144, 0
  %146 = add nsw i64 %144, %134
  %147 = select i1 %145, i64 %146, i64 %144
  %148 = sdiv i64 %147, %126
  %149 = srem i64 %131, %126
  %150 = icmp slt i64 %149, 0
  %151 = add nsw i64 %149, %126
  %152 = select i1 %150, i64 %151, i64 %149
  %153 = mul nsw i64 %39, %152
  %154 = mul nsw i64 %39, %152
  %155 = mul nsw i64 %154, -1
  %156 = add i64 %155, 32
  %157 = call i64 @llvm.smin.i64(i64 %156, i64 %39)
  %158 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %157)
  %159 = mul nsw i64 %148, 64
  %160 = mul nsw i64 %143, 32
  %161 = add i64 %159, %160
  %162 = add i64 %161, %153
  %163 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %25, 0
  %164 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %163, ptr %30, 1
  %165 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %164, i64 %162, 2
  %166 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %165, i64 %157, 3, 0
  %167 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %166, i64 1, 4, 0
  %168 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %167, 1
  %169 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %167, 2
  %170 = getelementptr float, ptr %168, i64 %169
  %171 = getelementptr float, ptr %170, i64 0
  %172 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %171, <vscale x 4 x i1> %158, <vscale x 4 x float> poison)
  %173 = mul nsw i64 %143, 1024
  %174 = mul nsw i64 %148, 32
  %175 = add i64 %173, %174
  %176 = add i64 %175, %153
  %177 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %108, 0
  %178 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %177, ptr %113, 1
  %179 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %178, i64 %176, 2
  %180 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %179, i64 %157, 3, 0
  %181 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %180, i64 1, 4, 0
  %182 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %181, 1
  %183 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %181, 2
  %184 = getelementptr float, ptr %182, i64 %183
  %185 = getelementptr float, ptr %184, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %172, ptr align 4 %185, <vscale x 4 x i1> %158)
  %186 = add i64 %131, 1
  br label %130

187:                                              ; preds = %130
  %188 = call ptr @malloc(i64 2112)
  %189 = ptrtoint ptr %188 to i64
  %190 = add i64 %189, 63
  %191 = urem i64 %190, 64
  %192 = sub i64 %190, %191
  %193 = inttoptr i64 %192 to ptr
  %194 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %188, 0
  %195 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %194, ptr %193, 1
  %196 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %195, i64 0, 2
  %197 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %196, i64 1, 3, 0
  %198 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %197, i64 16, 3, 1
  %199 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %198, i64 32, 3, 2
  %200 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %199, i64 1, 3, 3
  %201 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %200, i64 512, 4, 0
  %202 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %201, i64 32, 4, 1
  %203 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %202, i64 1, 4, 2
  %204 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %203, i64 1, 4, 3
  %205 = call ptr @malloc(i64 4160)
  %206 = ptrtoint ptr %205 to i64
  %207 = add i64 %206, 63
  %208 = urem i64 %207, 64
  %209 = sub i64 %207, %208
  %210 = inttoptr i64 %209 to ptr
  %211 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %205, 0
  %212 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %211, ptr %210, 1
  %213 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %212, i64 0, 2
  %214 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %213, i64 2, 3, 0
  %215 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %214, i64 16, 3, 1
  %216 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %215, i64 32, 3, 2
  %217 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %216, i64 1, 3, 3
  %218 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %217, i64 512, 4, 0
  %219 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %218, i64 32, 4, 1
  %220 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %219, i64 1, 4, 2
  %221 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %220, i64 1, 4, 3
  %222 = mul i64 %38, 8
  %223 = sdiv i64 31, %222
  %224 = add i64 %223, 1
  %225 = sdiv i64 31, %222
  %226 = add i64 %225, 1
  %227 = sdiv i64 31, %222
  %228 = add i64 %227, 1
  %229 = mul nsw i64 %226, %228
  %230 = mul nsw i64 %229, 2
  br label %231

231:                                              ; preds = %872, %187
  %232 = phi i32 [ %875, %872 ], [ 0, %187 ]
  %233 = phi i64 [ %873, %872 ], [ %100, %187 ]
  %234 = phi i64 [ %874, %872 ], [ 0, %187 ]
  %235 = icmp slt i32 %232, %105
  br i1 %235, label %236, label %876

236:                                              ; preds = %231
  %237 = add i64 %234, %97
  %238 = srem i64 %237, %103
  %239 = sub i64 %237, %238
  %240 = add i64 %238, 64
  %241 = call i64 @llvm.smin.i64(i64 %240, i64 %103)
  %242 = sub i64 %241, %238
  %243 = extractvalue { i64, ptr } %22, 1
  %244 = load ptr, ptr %243, align 8
  %245 = getelementptr ptr, ptr %243, i32 1
  %246 = load ptr, ptr %245, align 8
  %247 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %244, 0
  %248 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %247, ptr %246, 1
  %249 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %248, i64 %237, 2
  %250 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %249, i64 16, 3, 0
  %251 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %250, i64 %102, 4, 0
  %252 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %251, i64 %242, 3, 1
  %253 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %252, i64 1, 4, 1
  %254 = sub i64 64, %242
  %255 = extractvalue { i64, ptr } %22, 1
  %256 = load ptr, ptr %255, align 8
  %257 = getelementptr ptr, ptr %255, i32 1
  %258 = load ptr, ptr %257, align 8
  %259 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %256, 0
  %260 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %259, ptr %258, 1
  %261 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %260, i64 %239, 2
  %262 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %261, i64 16, 3, 0
  %263 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %262, i64 %102, 4, 0
  %264 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %263, i64 %254, 3, 1
  %265 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %264, i64 1, 4, 1
  %266 = srem i64 %233, %99
  %267 = add i64 %101, %266
  %268 = sub i64 %267, %233
  %269 = sdiv i64 %268, %99
  %270 = call i64 @llvm.smin.i64(i64 %269, i64 32)
  %271 = extractvalue { i64, ptr } %24, 1
  %272 = load ptr, ptr %271, align 8
  %273 = getelementptr ptr, ptr %271, i32 1
  %274 = load ptr, ptr %273, align 8
  %275 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %272, 0
  %276 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %275, ptr %274, 1
  %277 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %276, i64 %233, 2
  %278 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %277, i64 %270, 3, 0
  %279 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %278, i64 %99, 4, 0
  %280 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %279, i64 16, 3, 1
  %281 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %280, i64 1, 4, 1
  %282 = sub i64 32, %270
  %283 = extractvalue { i64, ptr } %24, 1
  %284 = load ptr, ptr %283, align 8
  %285 = getelementptr ptr, ptr %283, i32 1
  %286 = load ptr, ptr %285, align 8
  %287 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %284, 0
  %288 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %287, ptr %286, 1
  %289 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %288, i64 %266, 2
  %290 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %289, i64 %282, 3, 0
  %291 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %290, i64 %99, 4, 0
  %292 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %291, i64 16, 3, 1
  %293 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %292, i64 1, 4, 1
  %294 = mul i32 %232, 16
  %295 = sub i32 %8, %294
  %296 = sext i32 %295 to i64
  %297 = call i64 @llvm.smin.i64(i64 %296, i64 16)
  %298 = call i64 @llvm.smax.i64(i64 %297, i64 0)
  %299 = call ptr @malloc(i64 2048)
  %300 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %299, 0
  %301 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %300, ptr %299, 1
  %302 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %301, i64 0, 2
  %303 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %302, i64 32, 3, 0
  %304 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %303, i64 16, 3, 1
  %305 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %304, i64 16, 4, 0
  %306 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %305, i64 1, 4, 1
  %307 = icmp slt i64 %298, 16
  br i1 %307, label %308, label %321

308:                                              ; preds = %319, %236
  %309 = phi i64 [ %320, %319 ], [ 0, %236 ]
  %310 = icmp slt i64 %309, 32
  br i1 %310, label %311, label %321

311:                                              ; preds = %314, %308
  %312 = phi i64 [ %318, %314 ], [ 0, %308 ]
  %313 = icmp slt i64 %312, 16
  br i1 %313, label %314, label %319

314:                                              ; preds = %311
  %315 = mul nuw nsw i64 %309, 16
  %316 = add nuw nsw i64 %315, %312
  %317 = getelementptr inbounds nuw float, ptr %299, i64 %316
  store float 0.000000e+00, ptr %317, align 4
  %318 = add i64 %312, 1
  br label %311

319:                                              ; preds = %311
  %320 = add i64 %309, 1
  br label %308

321:                                              ; preds = %308, %236
  %322 = icmp sle i64 %298, 0
  %323 = sub i64 0, %298
  %324 = sub i64 %298, 1
  %325 = select i1 %322, i64 %323, i64 %324
  %326 = sdiv i64 %325, %39
  %327 = sub i64 0, %326
  %328 = add i64 %326, 1
  %329 = select i1 %322, i64 %327, i64 %328
  %330 = icmp sle i64 %298, 0
  %331 = sub i64 0, %298
  %332 = sub i64 %298, 1
  %333 = select i1 %330, i64 %331, i64 %332
  %334 = sdiv i64 %333, %39
  %335 = sub i64 0, %334
  %336 = add i64 %334, 1
  %337 = select i1 %330, i64 %335, i64 %336
  %338 = mul nsw i64 %270, %337
  br label %339

339:                                              ; preds = %342, %321
  %340 = phi i64 [ %389, %342 ], [ 0, %321 ]
  %341 = icmp slt i64 %340, %338
  br i1 %341, label %342, label %390

342:                                              ; preds = %339
  %343 = sdiv i64 %340, %329
  %344 = mul i64 %343, %329
  %345 = icmp ne i64 %340, %344
  %346 = icmp slt i64 %340, 0
  %347 = icmp slt i64 %329, 0
  %348 = icmp ne i1 %346, %347
  %349 = and i1 %345, %348
  %350 = add i64 %343, -1
  %351 = select i1 %349, i64 %350, i64 %343
  %352 = srem i64 %340, %329
  %353 = icmp slt i64 %352, 0
  %354 = add nsw i64 %352, %329
  %355 = select i1 %353, i64 %354, i64 %352
  %356 = mul nsw i64 %39, %355
  %357 = mul nsw i64 %39, %355
  %358 = mul nsw i64 %357, -1
  %359 = add i64 %298, %358
  %360 = call i64 @llvm.smin.i64(i64 %359, i64 %39)
  %361 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %360)
  %362 = insertvalue { ptr, ptr, i64 } poison, ptr %272, 0
  %363 = insertvalue { ptr, ptr, i64 } %362, ptr %274, 1
  %364 = insertvalue { ptr, ptr, i64 } %363, i64 0, 2
  %365 = mul nsw i64 %351, %99
  %366 = add i64 %233, %365
  %367 = add i64 %366, %356
  %368 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %272, 0
  %369 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %368, ptr %274, 1
  %370 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %369, i64 %367, 2
  %371 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %370, i64 %360, 3, 0
  %372 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %371, i64 1, 4, 0
  %373 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %372, 1
  %374 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %372, 2
  %375 = getelementptr float, ptr %373, i64 %374
  %376 = getelementptr float, ptr %375, i64 0
  %377 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %376, <vscale x 4 x i1> %361, <vscale x 4 x float> poison)
  %378 = mul nsw i64 %351, 16
  %379 = add i64 %378, %356
  %380 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %299, 0
  %381 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %380, ptr %299, 1
  %382 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %381, i64 %379, 2
  %383 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %382, i64 %360, 3, 0
  %384 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %383, i64 1, 4, 0
  %385 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %384, 1
  %386 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %384, 2
  %387 = getelementptr float, ptr %385, i64 %386
  %388 = getelementptr float, ptr %387, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %377, ptr align 4 %388, <vscale x 4 x i1> %361)
  %389 = add i64 %340, 1
  br label %339

390:                                              ; preds = %339
  %391 = icmp sle i64 %298, 0
  %392 = sub i64 0, %298
  %393 = sub i64 %298, 1
  %394 = select i1 %391, i64 %392, i64 %393
  %395 = sdiv i64 %394, %39
  %396 = sub i64 0, %395
  %397 = add i64 %395, 1
  %398 = select i1 %391, i64 %396, i64 %397
  %399 = mul nsw i64 %282, %398
  br label %400

400:                                              ; preds = %403, %390
  %401 = phi i64 [ %452, %403 ], [ 0, %390 ]
  %402 = icmp slt i64 %401, %399
  br i1 %402, label %403, label %453

403:                                              ; preds = %400
  %404 = sdiv i64 %401, %329
  %405 = mul i64 %404, %329
  %406 = icmp ne i64 %401, %405
  %407 = icmp slt i64 %401, 0
  %408 = icmp slt i64 %329, 0
  %409 = icmp ne i1 %407, %408
  %410 = and i1 %406, %409
  %411 = add i64 %404, -1
  %412 = select i1 %410, i64 %411, i64 %404
  %413 = srem i64 %401, %329
  %414 = icmp slt i64 %413, 0
  %415 = add nsw i64 %413, %329
  %416 = select i1 %414, i64 %415, i64 %413
  %417 = mul nsw i64 %39, %416
  %418 = mul nsw i64 %39, %416
  %419 = mul nsw i64 %418, -1
  %420 = add i64 %298, %419
  %421 = call i64 @llvm.smin.i64(i64 %420, i64 %39)
  %422 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %421)
  %423 = insertvalue { ptr, ptr, i64 } poison, ptr %284, 0
  %424 = insertvalue { ptr, ptr, i64 } %423, ptr %286, 1
  %425 = insertvalue { ptr, ptr, i64 } %424, i64 0, 2
  %426 = mul nsw i64 %412, %99
  %427 = add i64 %266, %426
  %428 = add i64 %427, %417
  %429 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %284, 0
  %430 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %429, ptr %286, 1
  %431 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %430, i64 %428, 2
  %432 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %431, i64 %421, 3, 0
  %433 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %432, i64 1, 4, 0
  %434 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %433, 1
  %435 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %433, 2
  %436 = getelementptr float, ptr %434, i64 %435
  %437 = getelementptr float, ptr %436, i64 0
  %438 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %437, <vscale x 4 x i1> %422, <vscale x 4 x float> poison)
  %439 = mul nsw i64 %270, 16
  %440 = mul nsw i64 %412, 16
  %441 = add i64 %439, %440
  %442 = add i64 %441, %417
  %443 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %299, 0
  %444 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %443, ptr %299, 1
  %445 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %444, i64 %442, 2
  %446 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %445, i64 %421, 3, 0
  %447 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %446, i64 1, 4, 0
  %448 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %447, 1
  %449 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %447, 2
  %450 = getelementptr float, ptr %448, i64 %449
  %451 = getelementptr float, ptr %450, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %438, ptr align 4 %451, <vscale x 4 x i1> %422)
  %452 = add i64 %401, 1
  br label %400

453:                                              ; preds = %400
  %454 = call ptr @malloc(i64 4096)
  %455 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %454, 0
  %456 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %455, ptr %454, 1
  %457 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %456, i64 0, 2
  %458 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %457, i64 16, 3, 0
  %459 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %458, i64 64, 3, 1
  %460 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %459, i64 64, 4, 0
  %461 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %460, i64 1, 4, 1
  br i1 %307, label %462, label %475

462:                                              ; preds = %473, %453
  %463 = phi i64 [ %474, %473 ], [ 0, %453 ]
  %464 = icmp slt i64 %463, 16
  br i1 %464, label %465, label %475

465:                                              ; preds = %468, %462
  %466 = phi i64 [ %472, %468 ], [ 0, %462 ]
  %467 = icmp slt i64 %466, 64
  br i1 %467, label %468, label %473

468:                                              ; preds = %465
  %469 = mul nuw nsw i64 %463, 64
  %470 = add nuw nsw i64 %469, %466
  %471 = getelementptr inbounds nuw float, ptr %454, i64 %470
  store float 0.000000e+00, ptr %471, align 4
  %472 = add i64 %466, 1
  br label %465

473:                                              ; preds = %465
  %474 = add i64 %463, 1
  br label %462

475:                                              ; preds = %462, %453
  %476 = icmp sle i64 %242, 0
  %477 = sub i64 0, %242
  %478 = sub i64 %242, 1
  %479 = select i1 %476, i64 %477, i64 %478
  %480 = sdiv i64 %479, %39
  %481 = sub i64 0, %480
  %482 = add i64 %480, 1
  %483 = select i1 %476, i64 %481, i64 %482
  %484 = icmp sle i64 %242, 0
  %485 = sub i64 0, %242
  %486 = sub i64 %242, 1
  %487 = select i1 %484, i64 %485, i64 %486
  %488 = sdiv i64 %487, %39
  %489 = sub i64 0, %488
  %490 = add i64 %488, 1
  %491 = select i1 %484, i64 %489, i64 %490
  %492 = mul nsw i64 %298, %491
  br label %493

493:                                              ; preds = %496, %475
  %494 = phi i64 [ %543, %496 ], [ 0, %475 ]
  %495 = icmp slt i64 %494, %492
  br i1 %495, label %496, label %544

496:                                              ; preds = %493
  %497 = sdiv i64 %494, %483
  %498 = mul i64 %497, %483
  %499 = icmp ne i64 %494, %498
  %500 = icmp slt i64 %494, 0
  %501 = icmp slt i64 %483, 0
  %502 = icmp ne i1 %500, %501
  %503 = and i1 %499, %502
  %504 = add i64 %497, -1
  %505 = select i1 %503, i64 %504, i64 %497
  %506 = srem i64 %494, %483
  %507 = icmp slt i64 %506, 0
  %508 = add nsw i64 %506, %483
  %509 = select i1 %507, i64 %508, i64 %506
  %510 = mul nsw i64 %39, %509
  %511 = mul nsw i64 %39, %509
  %512 = mul nsw i64 %511, -1
  %513 = add i64 %242, %512
  %514 = call i64 @llvm.smin.i64(i64 %513, i64 %39)
  %515 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %514)
  %516 = insertvalue { ptr, ptr, i64 } poison, ptr %244, 0
  %517 = insertvalue { ptr, ptr, i64 } %516, ptr %246, 1
  %518 = insertvalue { ptr, ptr, i64 } %517, i64 0, 2
  %519 = mul nsw i64 %505, %102
  %520 = add i64 %237, %519
  %521 = add i64 %520, %510
  %522 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %244, 0
  %523 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %522, ptr %246, 1
  %524 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %523, i64 %521, 2
  %525 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %524, i64 %514, 3, 0
  %526 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %525, i64 1, 4, 0
  %527 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %526, 1
  %528 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %526, 2
  %529 = getelementptr float, ptr %527, i64 %528
  %530 = getelementptr float, ptr %529, i64 0
  %531 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %530, <vscale x 4 x i1> %515, <vscale x 4 x float> poison)
  %532 = mul nsw i64 %505, 64
  %533 = add i64 %532, %510
  %534 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %454, 0
  %535 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %534, ptr %454, 1
  %536 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %535, i64 %533, 2
  %537 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %536, i64 %514, 3, 0
  %538 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %537, i64 1, 4, 0
  %539 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %538, 1
  %540 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %538, 2
  %541 = getelementptr float, ptr %539, i64 %540
  %542 = getelementptr float, ptr %541, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %531, ptr align 4 %542, <vscale x 4 x i1> %515)
  %543 = add i64 %494, 1
  br label %493

544:                                              ; preds = %493
  %545 = icmp sle i64 %254, 0
  %546 = sub i64 0, %254
  %547 = sub i64 %254, 1
  %548 = select i1 %545, i64 %546, i64 %547
  %549 = sdiv i64 %548, %39
  %550 = sub i64 0, %549
  %551 = add i64 %549, 1
  %552 = select i1 %545, i64 %550, i64 %551
  %553 = icmp sle i64 %254, 0
  %554 = sub i64 0, %254
  %555 = sub i64 %254, 1
  %556 = select i1 %553, i64 %554, i64 %555
  %557 = sdiv i64 %556, %39
  %558 = sub i64 0, %557
  %559 = add i64 %557, 1
  %560 = select i1 %553, i64 %558, i64 %559
  %561 = mul nsw i64 %298, %560
  br label %562

562:                                              ; preds = %565, %544
  %563 = phi i64 [ %613, %565 ], [ 0, %544 ]
  %564 = icmp slt i64 %563, %561
  br i1 %564, label %565, label %614

565:                                              ; preds = %562
  %566 = sdiv i64 %563, %552
  %567 = mul i64 %566, %552
  %568 = icmp ne i64 %563, %567
  %569 = icmp slt i64 %563, 0
  %570 = icmp slt i64 %552, 0
  %571 = icmp ne i1 %569, %570
  %572 = and i1 %568, %571
  %573 = add i64 %566, -1
  %574 = select i1 %572, i64 %573, i64 %566
  %575 = srem i64 %563, %552
  %576 = icmp slt i64 %575, 0
  %577 = add nsw i64 %575, %552
  %578 = select i1 %576, i64 %577, i64 %575
  %579 = mul nsw i64 %39, %578
  %580 = mul nsw i64 %39, %578
  %581 = mul nsw i64 %580, -1
  %582 = add i64 %254, %581
  %583 = call i64 @llvm.smin.i64(i64 %582, i64 %39)
  %584 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %583)
  %585 = insertvalue { ptr, ptr, i64 } poison, ptr %256, 0
  %586 = insertvalue { ptr, ptr, i64 } %585, ptr %258, 1
  %587 = insertvalue { ptr, ptr, i64 } %586, i64 0, 2
  %588 = mul nsw i64 %574, %102
  %589 = add i64 %239, %588
  %590 = add i64 %589, %579
  %591 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %256, 0
  %592 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %591, ptr %258, 1
  %593 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %592, i64 %590, 2
  %594 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %593, i64 %583, 3, 0
  %595 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %594, i64 1, 4, 0
  %596 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %595, 1
  %597 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %595, 2
  %598 = getelementptr float, ptr %596, i64 %597
  %599 = getelementptr float, ptr %598, i64 0
  %600 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %599, <vscale x 4 x i1> %584, <vscale x 4 x float> poison)
  %601 = mul nsw i64 %574, 64
  %602 = add i64 %242, %601
  %603 = add i64 %602, %579
  %604 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %454, 0
  %605 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %604, ptr %454, 1
  %606 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %605, i64 %603, 2
  %607 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %606, i64 %583, 3, 0
  %608 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %607, i64 1, 4, 0
  %609 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %608, 1
  %610 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %608, 2
  %611 = getelementptr float, ptr %609, i64 %610
  %612 = getelementptr float, ptr %611, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %600, ptr align 4 %612, <vscale x 4 x i1> %584)
  %613 = add i64 %563, 1
  br label %562

614:                                              ; preds = %562
  br label %615

615:                                              ; preds = %618, %614
  %616 = phi i64 [ %656, %618 ], [ 0, %614 ]
  %617 = icmp slt i64 %616, 512
  br i1 %617, label %618, label %657

618:                                              ; preds = %615
  %619 = sdiv i64 %616, 32
  %620 = mul i64 %619, 32
  %621 = icmp ne i64 %616, %620
  %622 = icmp slt i64 %616, 0
  %623 = icmp ne i1 %622, false
  %624 = and i1 %621, %623
  %625 = add i64 %619, -1
  %626 = select i1 %624, i64 %625, i64 %619
  %627 = srem i64 %616, 32
  %628 = icmp slt i64 %627, 0
  %629 = add nsw i64 %627, 32
  %630 = select i1 %628, i64 %629, i64 %627
  %631 = call i64 @llvm.smin.i64(i64 %39, i64 1)
  %632 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %631)
  %633 = mul nsw i64 %630, 16
  %634 = add i64 %633, %626
  %635 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %299, 0
  %636 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %635, ptr %299, 1
  %637 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %636, i64 %634, 2
  %638 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %637, i64 %631, 3, 0
  %639 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %638, i64 1, 4, 0
  %640 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %639, 1
  %641 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %639, 2
  %642 = getelementptr float, ptr %640, i64 %641
  %643 = getelementptr float, ptr %642, i64 0
  %644 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %643, <vscale x 4 x i1> %632, <vscale x 4 x float> poison)
  %645 = mul nsw i64 %626, 32
  %646 = add i64 %645, %630
  %647 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %188, 0
  %648 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %647, ptr %193, 1
  %649 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %648, i64 %646, 2
  %650 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %649, i64 %631, 3, 0
  %651 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %650, i64 1, 4, 0
  %652 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %651, 1
  %653 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %651, 2
  %654 = getelementptr float, ptr %652, i64 %653
  %655 = getelementptr float, ptr %654, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %644, ptr align 4 %655, <vscale x 4 x i1> %632)
  %656 = add i64 %616, 1
  br label %615

657:                                              ; preds = %615
  br label %658

658:                                              ; preds = %705, %657
  %659 = phi i64 [ %719, %705 ], [ 0, %657 ]
  %660 = icmp slt i64 %659, 1024
  br i1 %660, label %661, label %720

661:                                              ; preds = %658
  %662 = sdiv i64 %659, 512
  %663 = mul i64 %662, 512
  %664 = icmp ne i64 %659, %663
  %665 = icmp slt i64 %659, 0
  %666 = icmp ne i1 %665, false
  %667 = and i1 %664, %666
  %668 = add i64 %662, -1
  %669 = select i1 %667, i64 %668, i64 %662
  %670 = srem i64 %659, 512
  %671 = icmp slt i64 %670, 0
  %672 = add nsw i64 %670, 512
  %673 = select i1 %671, i64 %672, i64 %670
  %674 = sdiv i64 %673, 32
  %675 = srem i64 %659, 32
  %676 = icmp slt i64 %675, 0
  %677 = add nsw i64 %675, 32
  %678 = select i1 %676, i64 %677, i64 %675
  %679 = call i64 @llvm.smin.i64(i64 %39, i64 1)
  %680 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %679)
  %681 = mul nsw i64 %674, 64
  %682 = mul nsw i64 %669, 32
  %683 = add i64 %681, %682
  %684 = add i64 %683, %678
  %685 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %454, 0
  %686 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %685, ptr %454, 1
  %687 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %686, i64 %684, 2
  %688 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %687, i64 %679, 3, 0
  %689 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %688, i64 64, 4, 0
  br label %690

690:                                              ; preds = %702, %661
  %691 = phi i64 [ %704, %702 ], [ 0, %661 ]
  %692 = phi <vscale x 4 x float> [ %703, %702 ], [ poison, %661 ]
  %693 = icmp slt i64 %691, %39
  br i1 %693, label %694, label %705

694:                                              ; preds = %690
  %695 = extractelement <vscale x 4 x i1> %680, i64 %691
  br i1 %695, label %696, label %702

696:                                              ; preds = %694
  %697 = getelementptr float, ptr %454, i64 %684
  %698 = mul nuw nsw i64 %691, 64
  %699 = getelementptr inbounds nuw float, ptr %697, i64 %698
  %700 = load float, ptr %699, align 4
  %701 = insertelement <vscale x 4 x float> %692, float %700, i64 %691
  br label %702

702:                                              ; preds = %696, %694
  %703 = phi <vscale x 4 x float> [ %701, %696 ], [ %692, %694 ]
  %704 = add i64 %691, 1
  br label %690

705:                                              ; preds = %690
  %706 = mul nsw i64 %669, 512
  %707 = mul nsw i64 %674, 32
  %708 = add i64 %706, %707
  %709 = add i64 %708, %678
  %710 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %205, 0
  %711 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %710, ptr %210, 1
  %712 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %711, i64 %709, 2
  %713 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %712, i64 %679, 3, 0
  %714 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %713, i64 1, 4, 0
  %715 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %714, 1
  %716 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %714, 2
  %717 = getelementptr float, ptr %715, i64 %716
  %718 = getelementptr float, ptr %717, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %692, ptr align 4 %718, <vscale x 4 x i1> %680)
  %719 = add i64 %659, 1
  br label %658

720:                                              ; preds = %870, %658
  %721 = phi i64 [ %871, %870 ], [ 0, %658 ]
  %722 = icmp slt i64 %721, %230
  br i1 %722, label %723, label %872

723:                                              ; preds = %720
  %724 = mul nuw nsw i64 %224, %224
  %725 = sdiv i64 %721, %724
  %726 = mul i64 %725, %724
  %727 = icmp ne i64 %721, %726
  %728 = icmp slt i64 %721, 0
  %729 = icmp slt i64 %724, 0
  %730 = icmp ne i1 %728, %729
  %731 = and i1 %727, %730
  %732 = add i64 %725, -1
  %733 = select i1 %731, i64 %732, i64 %725
  %734 = srem i64 %721, %724
  %735 = icmp slt i64 %734, 0
  %736 = add nsw i64 %734, %724
  %737 = select i1 %735, i64 %736, i64 %734
  %738 = sdiv i64 %737, %224
  %739 = srem i64 %721, %224
  %740 = icmp slt i64 %739, 0
  %741 = add nsw i64 %739, %224
  %742 = select i1 %740, i64 %741, i64 %739
  %743 = mul nsw i64 %222, %742
  %744 = mul nsw i64 %222, %738
  %745 = mul nsw i64 %222, %738
  %746 = mul nsw i64 %745, -1
  %747 = add i64 %746, 32
  %748 = call i64 @llvm.smin.i64(i64 %747, i64 %222)
  %749 = mul nsw i64 %222, %742
  %750 = mul nsw i64 %749, -1
  %751 = add i64 %750, 32
  %752 = call i64 @llvm.smin.i64(i64 %751, i64 %222)
  %753 = mul nsw i64 %733, 1024
  %754 = mul nsw i64 %744, 32
  %755 = add i64 %753, %754
  %756 = add i64 %755, %743
  %757 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %108, 0
  %758 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %757, ptr %113, 1
  %759 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %758, i64 %756, 2
  %760 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %759, i64 %748, 3, 0
  %761 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %760, i64 32, 4, 0
  %762 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %761, i64 %752, 3, 1
  %763 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %762, i64 1, 4, 1
  br label %764

764:                                              ; preds = %767, %723
  %765 = phi i64 [ %775, %767 ], [ 0, %723 ]
  %766 = icmp slt i64 %765, %39
  br i1 %766, label %767, label %776

767:                                              ; preds = %764
  %768 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %763, 1
  %769 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %763, 2
  %770 = getelementptr float, ptr %768, i64 %769
  %771 = mul i64 %765, 32
  %772 = add i64 %771, 0
  %773 = getelementptr float, ptr %770, i64 %772
  %774 = trunc i64 %765 to i32
  call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %773, i32 0, i32 %774)
  %775 = add i64 %765, 1
  br label %764

776:                                              ; preds = %764
  br label %777

777:                                              ; preds = %780, %776
  %778 = phi i64 [ %788, %780 ], [ 0, %776 ]
  %779 = icmp slt i64 %778, %39
  br i1 %779, label %780, label %789

780:                                              ; preds = %777
  %781 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %763, 1
  %782 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %763, 2
  %783 = getelementptr float, ptr %781, i64 %782
  %784 = mul i64 %778, 32
  %785 = add i64 %784, %39
  %786 = getelementptr float, ptr %783, i64 %785
  %787 = trunc i64 %778 to i32
  call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %786, i32 1, i32 %787)
  %788 = add i64 %778, 1
  br label %777

789:                                              ; preds = %792, %777
  %790 = phi i64 [ %801, %792 ], [ 0, %777 ]
  %791 = icmp slt i64 %790, %39
  br i1 %791, label %792, label %802

792:                                              ; preds = %789
  %793 = add i64 %39, %790
  %794 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %763, 1
  %795 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %763, 2
  %796 = getelementptr float, ptr %794, i64 %795
  %797 = mul i64 %793, 32
  %798 = add i64 %797, 0
  %799 = getelementptr float, ptr %796, i64 %798
  %800 = trunc i64 %790 to i32
  call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %799, i32 2, i32 %800)
  %801 = add i64 %790, 1
  br label %789

802:                                              ; preds = %805, %789
  %803 = phi i64 [ %814, %805 ], [ 0, %789 ]
  %804 = icmp slt i64 %803, %39
  br i1 %804, label %805, label %815

805:                                              ; preds = %802
  %806 = add i64 %39, %803
  %807 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %763, 1
  %808 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %763, 2
  %809 = getelementptr float, ptr %807, i64 %808
  %810 = mul i64 %806, 32
  %811 = add i64 %810, %39
  %812 = getelementptr float, ptr %809, i64 %811
  %813 = trunc i64 %803 to i32
  call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %812, i32 3, i32 %813)
  %814 = add i64 %803, 1
  br label %802

815:                                              ; preds = %818, %802
  %816 = phi i64 [ %849, %818 ], [ 0, %802 ]
  %817 = icmp slt i64 %816, 16
  br i1 %817, label %818, label %850

818:                                              ; preds = %815
  %819 = mul nsw i64 %816, 32
  %820 = add i64 %744, %819
  %821 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %188, 0
  %822 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %821, ptr %193, 1
  %823 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %822, i64 %820, 2
  %824 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %823, i64 %748, 3, 0
  %825 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %824, i64 1, 4, 0
  %826 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %825, 1
  %827 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %825, 2
  %828 = getelementptr float, ptr %826, i64 %827
  %829 = getelementptr float, ptr %828, i64 0
  %830 = load <vscale x 8 x float>, ptr %829, align 4
  %831 = mul nsw i64 %733, 512
  %832 = add i64 %831, %743
  %833 = mul nsw i64 %816, 32
  %834 = add i64 %832, %833
  %835 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %205, 0
  %836 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %835, ptr %210, 1
  %837 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %836, i64 %834, 2
  %838 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %837, i64 %752, 3, 0
  %839 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %838, i64 1, 4, 0
  %840 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %839, 1
  %841 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %839, 2
  %842 = getelementptr float, ptr %840, i64 %841
  %843 = getelementptr float, ptr %842, i64 0
  %844 = load <vscale x 8 x float>, ptr %843, align 4
  %845 = call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %830, i64 0)
  %846 = call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %844, i64 0)
  call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %845, <vscale x 4 x float> %846)
  %847 = call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %844, i64 4)
  call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %845, <vscale x 4 x float> %847)
  %848 = call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %830, i64 4)
  call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %848, <vscale x 4 x float> %846)
  call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %848, <vscale x 4 x float> %847)
  %849 = add i64 %816, 1
  br label %815

850:                                              ; preds = %853, %815
  %851 = phi i64 [ %869, %853 ], [ 0, %815 ]
  %852 = icmp slt i64 %851, %39
  br i1 %852, label %853, label %870

853:                                              ; preds = %850
  %854 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %763, 1
  %855 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %763, 2
  %856 = getelementptr float, ptr %854, i64 %855
  %857 = mul i64 %851, 32
  %858 = add i64 %857, 0
  %859 = getelementptr float, ptr %856, i64 %858
  %860 = trunc i64 %851 to i32
  call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %859, i32 0, i32 %860)
  %861 = add i64 %857, %39
  %862 = getelementptr float, ptr %856, i64 %861
  call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %862, i32 1, i32 %860)
  %863 = add i64 %39, %851
  %864 = mul i64 %863, 32
  %865 = add i64 %864, 0
  %866 = getelementptr float, ptr %856, i64 %865
  call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %866, i32 2, i32 %860)
  %867 = add i64 %864, %39
  %868 = getelementptr float, ptr %856, i64 %867
  call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %868, i32 3, i32 %860)
  %869 = add i64 %851, 1
  br label %850

870:                                              ; preds = %850
  %871 = add i64 %721, 1
  br label %720

872:                                              ; preds = %720
  %873 = add i64 %233, 16
  %874 = add i64 %234, %107
  call void @free(ptr %299)
  call void @free(ptr %454)
  %875 = add i32 %232, 1
  br label %231

876:                                              ; preds = %231
  %877 = call ptr @malloc(i64 8256)
  %878 = ptrtoint ptr %877 to i64
  %879 = add i64 %878, 63
  %880 = urem i64 %879, 64
  %881 = sub i64 %879, %880
  %882 = inttoptr i64 %881 to ptr
  %883 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %877, 0
  %884 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %883, ptr %882, 1
  %885 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %884, i64 0, 2
  %886 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %885, i64 1, 3, 0
  %887 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %886, i64 32, 3, 1
  %888 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %887, i64 2, 3, 2
  %889 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %888, i64 32, 3, 3
  %890 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %889, i64 2048, 4, 0
  %891 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %890, i64 64, 4, 1
  %892 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %891, i64 32, 4, 2
  %893 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %892, i64 1, 4, 3
  br label %894

894:                                              ; preds = %897, %876
  %895 = phi i64 [ %950, %897 ], [ 0, %876 ]
  %896 = icmp slt i64 %895, %129
  br i1 %896, label %897, label %951

897:                                              ; preds = %894
  %898 = mul nuw nsw i64 %126, 2
  %899 = sdiv i64 %895, %898
  %900 = mul i64 %899, %898
  %901 = icmp ne i64 %895, %900
  %902 = icmp slt i64 %895, 0
  %903 = icmp slt i64 %898, 0
  %904 = icmp ne i1 %902, %903
  %905 = and i1 %901, %904
  %906 = add i64 %899, -1
  %907 = select i1 %905, i64 %906, i64 %899
  %908 = srem i64 %895, %898
  %909 = icmp slt i64 %908, 0
  %910 = add nsw i64 %908, %898
  %911 = select i1 %909, i64 %910, i64 %908
  %912 = sdiv i64 %911, %126
  %913 = srem i64 %895, %126
  %914 = icmp slt i64 %913, 0
  %915 = add nsw i64 %913, %126
  %916 = select i1 %914, i64 %915, i64 %913
  %917 = mul nsw i64 %39, %916
  %918 = mul nsw i64 %39, %916
  %919 = mul nsw i64 %918, -1
  %920 = add i64 %919, 32
  %921 = call i64 @llvm.smin.i64(i64 %920, i64 %39)
  %922 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %921)
  %923 = mul nsw i64 %912, 1024
  %924 = mul nsw i64 %907, 32
  %925 = add i64 %923, %924
  %926 = add i64 %925, %917
  %927 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %108, 0
  %928 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %927, ptr %113, 1
  %929 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %928, i64 %926, 2
  %930 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %929, i64 %921, 3, 0
  %931 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %930, i64 1, 4, 0
  %932 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %931, 1
  %933 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %931, 2
  %934 = getelementptr float, ptr %932, i64 %933
  %935 = getelementptr float, ptr %934, i64 0
  %936 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %935, <vscale x 4 x i1> %922, <vscale x 4 x float> poison)
  %937 = mul nsw i64 %907, 64
  %938 = mul nsw i64 %912, 32
  %939 = add i64 %937, %938
  %940 = add i64 %939, %917
  %941 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %877, 0
  %942 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %941, ptr %882, 1
  %943 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %942, i64 %940, 2
  %944 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %943, i64 %921, 3, 0
  %945 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %944, i64 1, 4, 0
  %946 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %945, 1
  %947 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %945, 2
  %948 = getelementptr float, ptr %946, i64 %947
  %949 = getelementptr float, ptr %948, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %936, ptr align 4 %949, <vscale x 4 x i1> %922)
  %950 = add i64 %895, 1
  br label %894

951:                                              ; preds = %894
  br label %952

952:                                              ; preds = %955, %951
  %953 = phi i64 [ %998, %955 ], [ 0, %951 ]
  %954 = icmp slt i64 %953, %44
  br i1 %954, label %955, label %999

955:                                              ; preds = %952
  %956 = sdiv i64 %953, %41
  %957 = mul i64 %956, %41
  %958 = icmp ne i64 %953, %957
  %959 = icmp slt i64 %953, 0
  %960 = icmp slt i64 %41, 0
  %961 = icmp ne i1 %959, %960
  %962 = and i1 %958, %961
  %963 = add i64 %956, -1
  %964 = select i1 %962, i64 %963, i64 %956
  %965 = srem i64 %953, %41
  %966 = icmp slt i64 %965, 0
  %967 = add nsw i64 %965, %41
  %968 = select i1 %966, i64 %967, i64 %965
  %969 = mul nsw i64 %39, %968
  %970 = mul nsw i64 %39, %968
  %971 = mul nsw i64 %970, -1
  %972 = add i64 %971, 64
  %973 = call i64 @llvm.smin.i64(i64 %972, i64 %39)
  %974 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %973)
  %975 = mul nsw i64 %964, 64
  %976 = add i64 %975, %969
  %977 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %877, 0
  %978 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %977, ptr %882, 1
  %979 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %978, i64 %976, 2
  %980 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %979, i64 %973, 3, 0
  %981 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %980, i64 1, 4, 0
  %982 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %981, 1
  %983 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %981, 2
  %984 = getelementptr float, ptr %982, i64 %983
  %985 = getelementptr float, ptr %984, i64 0
  %986 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %985, <vscale x 4 x i1> %974, <vscale x 4 x float> poison)
  %987 = mul nsw i64 %964, 64
  %988 = add i64 %987, %969
  %989 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %25, 0
  %990 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %989, ptr %30, 1
  %991 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %990, i64 %988, 2
  %992 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %991, i64 %973, 3, 0
  %993 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %992, i64 1, 4, 0
  %994 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %993, 1
  %995 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %993, 2
  %996 = getelementptr float, ptr %994, i64 %995
  %997 = getelementptr float, ptr %996, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %986, ptr align 4 %997, <vscale x 4 x i1> %974)
  %998 = add i64 %953, 1
  br label %952

999:                                              ; preds = %952
  %1000 = sext i32 %11 to i64
  %1001 = mul i64 %95, %1000
  %1002 = add i64 %1001, %97
  %1003 = add i64 %95, 32
  %1004 = call i64 @llvm.smin.i64(i64 %1003, i64 %98)
  %1005 = call i64 @llvm.smax.i64(i64 %1004, i64 %95)
  %1006 = sub i64 %1005, %95
  %1007 = add i64 %97, 64
  %1008 = call i64 @llvm.smin.i64(i64 %1007, i64 %103)
  %1009 = call i64 @llvm.smax.i64(i64 %1008, i64 %97)
  %1010 = sub i64 %1009, %97
  %1011 = call i64 @llvm.smin.i64(i64 %1006, i64 32)
  %1012 = call i64 @llvm.smin.i64(i64 %1010, i64 64)
  %1013 = extractvalue { i64, ptr } %20, 1
  %1014 = load ptr, ptr %1013, align 8
  %1015 = getelementptr ptr, ptr %1013, i32 1
  %1016 = load ptr, ptr %1015, align 8
  %1017 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %1014, 0
  %1018 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %1017, ptr %1016, 1
  %1019 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %1018, i64 %1002, 2
  %1020 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %1019, i64 32, 3, 0
  %1021 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %1020, i64 %1000, 4, 0
  %1022 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %1021, i64 64, 3, 1
  %1023 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %1022, i64 1, 4, 1
  %1024 = insertvalue { ptr, ptr, i64 } poison, ptr %1014, 0
  %1025 = insertvalue { ptr, ptr, i64 } %1024, ptr %1016, 1
  %1026 = insertvalue { ptr, ptr, i64 } %1025, i64 0, 2
  %1027 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %1014, 0
  %1028 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %1027, ptr %1016, 1
  %1029 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %1028, i64 %1002, 2
  %1030 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %1029, i64 %1011, 3, 0
  %1031 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %1030, i64 %1000, 4, 0
  %1032 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %1031, i64 %1012, 3, 1
  %1033 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %1032, i64 1, 4, 1
  %1034 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %25, 0
  %1035 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %1034, ptr %30, 1
  %1036 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %1035, i64 0, 2
  %1037 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %1036, i64 %1011, 3, 0
  %1038 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %1037, i64 64, 4, 0
  %1039 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %1038, i64 %1012, 3, 1
  %1040 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %1039, i64 1, 4, 1
  %1041 = call ptr @llvm.stacksave.p0()
  %1042 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %1040, ptr %1042, align 8
  %1043 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %1042, 1
  %1044 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %1033, ptr %1044, align 8
  %1045 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %1044, 1
  %1046 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %1043, ptr %1046, align 8
  %1047 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %1045, ptr %1047, align 8
  call void @memrefCopy(i64 4, ptr %1046, ptr %1047)
  call void @llvm.stackrestore.p0(ptr %1041)
  call void @free(ptr %25)
  call void @free(ptr %108)
  call void @free(ptr %188)
  call void @free(ptr %205)
  call void @free(ptr %877)
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.vscale.i64() #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smin.i32(i32, i32) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smin.i64(i64, i64) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smax.i64(i64, i64) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare ptr @llvm.stacksave.p0() #3

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare void @llvm.stackrestore.p0(ptr) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64, i64) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr captures(none), <vscale x 4 x i1>, <vscale x 4 x float>) #4

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float>, ptr captures(none), <vscale x 4 x i1>) #5

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite)
declare void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1>, ptr, i32 immarg, i32) #6

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float>, i64 immarg) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(target_mem1: readwrite)
declare void @llvm.aarch64.sme.mopa.nxv4f32(i32 immarg, <vscale x 4 x i1>, <vscale x 4 x i1>, <vscale x 4 x float>, <vscale x 4 x float>) #7

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite)
declare void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1>, ptr, i32 immarg, i32) #6

attributes #0 = { "aarch64_new_za" "aarch64_pstate_sm_enabled" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nosync nounwind willreturn }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite) }
attributes #7 = { nocallback nofree nosync nounwind willreturn memory(target_mem1: readwrite) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
