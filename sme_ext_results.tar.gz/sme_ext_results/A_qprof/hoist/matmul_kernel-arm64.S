	.file	"LLVMDialectModule"
	.text
	.globl	matmul_kernel                   // -- Begin function matmul_kernel
	.p2align	2
	.type	matmul_kernel,@function
matmul_kernel:                          // @matmul_kernel
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-112]!          // 16-byte Folded Spill
	.cfi_def_cfa_offset 112
	cntd	x9
	stp	x28, x27, [sp, #32]             // 16-byte Folded Spill
	str	x9, [sp, #16]                   // 8-byte Spill
	stp	x26, x25, [sp, #48]             // 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 112
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	.cfi_offset vg, -96
	.cfi_offset w30, -104
	.cfi_offset w29, -112
	sub	sp, sp, #1024
	addvl	sp, sp, #-9
	str	z15, [sp]                       // 16-byte Folded Spill
	str	z14, [sp, #1, mul vl]           // 16-byte Folded Spill
	str	z13, [sp, #2, mul vl]           // 16-byte Folded Spill
	str	z12, [sp, #3, mul vl]           // 16-byte Folded Spill
	str	z11, [sp, #4, mul vl]           // 16-byte Folded Spill
	str	z10, [sp, #5, mul vl]           // 16-byte Folded Spill
	str	z9, [sp, #6, mul vl]            // 16-byte Folded Spill
	str	z8, [sp, #7, mul vl]            // 16-byte Folded Spill
	.cfi_escape 0x10, 0x48, 0x0e, 0x12, 0x11, 0xa0, 0x7f, 0x22, 0x06, 0x11, 0x70, 0x1e, 0x22, 0x11, 0x90, 0x77, 0x22 // $d8  @ cfa - 16 * IncomingVG - 1136
	.cfi_escape 0x10, 0x49, 0x0e, 0x12, 0x11, 0xa0, 0x7f, 0x22, 0x06, 0x11, 0x68, 0x1e, 0x22, 0x11, 0x90, 0x77, 0x22 // $d9  @ cfa - 24 * IncomingVG - 1136
	.cfi_escape 0x10, 0x4a, 0x0e, 0x12, 0x11, 0xa0, 0x7f, 0x22, 0x06, 0x11, 0x60, 0x1e, 0x22, 0x11, 0x90, 0x77, 0x22 // $d10  @ cfa - 32 * IncomingVG - 1136
	.cfi_escape 0x10, 0x4b, 0x0e, 0x12, 0x11, 0xa0, 0x7f, 0x22, 0x06, 0x11, 0x58, 0x1e, 0x22, 0x11, 0x90, 0x77, 0x22 // $d11  @ cfa - 40 * IncomingVG - 1136
	.cfi_escape 0x10, 0x4c, 0x0e, 0x12, 0x11, 0xa0, 0x7f, 0x22, 0x06, 0x11, 0x50, 0x1e, 0x22, 0x11, 0x90, 0x77, 0x22 // $d12  @ cfa - 48 * IncomingVG - 1136
	.cfi_escape 0x10, 0x4d, 0x0e, 0x12, 0x11, 0xa0, 0x7f, 0x22, 0x06, 0x11, 0x48, 0x1e, 0x22, 0x11, 0x90, 0x77, 0x22 // $d13  @ cfa - 56 * IncomingVG - 1136
	.cfi_escape 0x10, 0x4e, 0x0e, 0x12, 0x11, 0xa0, 0x7f, 0x22, 0x06, 0x11, 0x40, 0x1e, 0x22, 0x11, 0x90, 0x77, 0x22 // $d14  @ cfa - 64 * IncomingVG - 1136
	.cfi_escape 0x10, 0x4f, 0x0f, 0x12, 0x11, 0xa0, 0x7f, 0x22, 0x06, 0x11, 0xb8, 0x7f, 0x1e, 0x22, 0x11, 0x90, 0x77, 0x22 // $d15  @ cfa - 72 * IncomingVG - 1136
	sub	sp, sp, #1360
	addvl	sp, sp, #-1
	rdsvl	x8, #1
	mov	x9, sp
	mov	x19, sp
	msub	x9, x8, x8, x9
	mov	sp, x9
	stp	x9, x8, [x19, #320]
	mrs	x8, TPIDR2_EL0
	cbz	x8, .LBB0_2
// %bb.1:
	bl	__arm_tpidr2_save
	msr	TPIDR2_EL0, xzr
	zero	{za}
.LBB0_2:
	smstart	za
	ldr	w8, [x29, #112]
	ldr	w22, [x29, #168]
	mov	w24, w7
	mov	w23, w6
	str	x5, [x19, #56]                  // 8-byte Spill
	str	w8, [x19, #220]                 // 4-byte Spill
	add	x8, x19, #320
	stp	x1, x3, [x19, #176]             // 16-byte Folded Spill
	msr	TPIDR2_EL0, x8
	smstop	sm
	mov	w0, #8256                       // =0x2040
	bl	malloc
	smstart	sm
	cntw	x21
	mov	w8, #63                         // =0x3f
	rdvl	x20, #1
	sdiv	x9, x8, x21
	add	x8, x0, #63
	str	x0, [x19, #64]                  // 8-byte Spill
	and	x26, x8, #0xffffffffffffffc0
	add	x13, x9, #1
	lsl	x1, x13, #5
	smstart	za
	mrs	x8, TPIDR2_EL0
	add	x0, x19, #320
	cbnz	x8, .LBB0_4
// %bb.3:
	bl	__arm_tpidr2_restore
.LBB0_4:
	msr	TPIDR2_EL0, xzr
	str	x9, [x19, #24]                  // 8-byte Spill
	tbnz	x9, #63, .LBB0_7
// %bb.5:                               // %.lr.ph.preheader
	mov	z0.s, #0                        // =0x0
	mov	x8, xzr
	mov	w9, #64                         // =0x40
.LBB0_6:                                // %.lr.ph
                                        // =>This Inner Loop Header: Depth=1
	udiv	x10, x8, x13
	msub	x11, x10, x13, x8
	add	x10, x26, x10, lsl #8
	add	x8, x8, #1
	mul	x11, x11, x21
	sub	x12, x9, x11
	cmp	x12, x21
	csel	x12, x12, x21, lt
	whilelt	p0.s, xzr, x12
	cmp	x1, x8
	st1w	{ z0.s }, p0, [x10, x11, lsl #2]
	b.ne	.LBB0_6
.LBB0_7:                                // %._crit_edge
	mov	w9, w23
	adds	w8, w23, #31
	add	w10, w24, #126
	str	x9, [x19, #96]                  // 8-byte Spill
	add	w9, w23, #62
	mov	w12, #8                         // =0x8
	csel	w8, w9, w8, mi
	adds	w9, w24, #63
	str	x1, [x19, #32]                  // 8-byte Spill
	csel	w9, w10, w9, mi
	asr	w8, w8, #5
	asr	w9, w9, #6
	lsl	w9, w9, #3
	sdiv	w10, w22, w9
	lsl	w11, w10, #3
	msub	w9, w10, w9, w22
	sub	w8, w8, w11
	cmp	w8, #8
	csel	w8, w8, w12, lt
	sdiv	w12, w22, w8
	sdiv	w9, w9, w8
	msub	w8, w12, w8, w22
	add	w8, w11, w8
	lsl	w8, w8, #5
	str	x8, [x19, #72]                  // 8-byte Spill
	ldr	w8, [x19, #220]                 // 4-byte Reload
	lsl	w25, w9, #6
	adds	w23, w8, #15
	add	w8, w8, #30
	add	x9, x19, #320
	csel	w22, w8, w23, mi
	msr	TPIDR2_EL0, x9
	smstop	sm
	mov	w0, #8256                       // =0x2040
	bl	malloc
	smstart	sm
	mov	w8, #31                         // =0x1f
	str	x0, [x19, #40]                  // 8-byte Spill
	sdiv	x9, x8, x21
	add	x8, x0, #63
	and	x3, x8, #0xffffffffffffffc0
	add	x1, x9, #1
	lsl	x2, x1, #6
	smstart	za
	mrs	x8, TPIDR2_EL0
	add	x0, x19, #320
	cbnz	x8, .LBB0_9
// %bb.8:                               // %._crit_edge
	bl	__arm_tpidr2_restore
.LBB0_9:                                // %._crit_edge
	msr	TPIDR2_EL0, xzr
	str	x9, [x19, #8]                   // 8-byte Spill
	tbnz	x9, #63, .LBB0_12
// %bb.10:                              // %.lr.ph93
	lsl	x9, x1, #5
	mov	x8, xzr
	and	w10, w1, #0xffff
	mov	w11, #32                        // =0x20
.LBB0_11:                               // =>This Inner Loop Header: Depth=1
	udiv	x12, x8, x9
	udiv	x13, x8, x1
	msub	w14, w12, w9, w8
	and	w14, w14, #0xffff
	msub	x13, x13, x1, x8
	udiv	w14, w14, w10
	add	x8, x8, #1
	mul	x13, x13, x21
	add	x16, x26, x14, lsl #8
	sub	x15, x11, x13
	cmp	x15, x21
	csel	x15, x15, x21, lt
	whilelt	p0.s, xzr, x15
	add	x15, x16, x12, lsl #7
	add	x12, x3, x12, lsl #12
	cmp	x2, x8
	ld1w	{ z0.s }, p0/z, [x15, x13, lsl #2]
	add	x12, x12, x14, lsl #7
	st1w	{ z0.s }, p0, [x12, x13, lsl #2]
	b.ne	.LBB0_11
.LBB0_12:                               // %._crit_edge94
	sxtw	x8, w25
	str	x2, [x19, #16]                  // 8-byte Spill
	str	x26, [x19, #48]                 // 8-byte Spill
	stp	x8, x3, [x19, #200]             // 16-byte Folded Spill
	sxtw	x8, w24
	str	x8, [x19, #192]                 // 8-byte Spill
	add	x8, x19, #320
	msr	TPIDR2_EL0, x8
	smstop	sm
	mov	w0, #2112                       // =0x840
	bl	malloc
	str	x0, [x19, #88]                  // 8-byte Spill
	smstart	sm
	smstop	sm
	mov	w0, #4160                       // =0x1040
	bl	malloc
	str	x0, [x19, #80]                  // 8-byte Spill
	smstart	sm
	smstart	za
	mrs	x8, TPIDR2_EL0
	add	x0, x19, #320
	cbnz	x8, .LBB0_14
// %bb.13:                              // %._crit_edge94
	bl	__arm_tpidr2_restore
.LBB0_14:                               // %._crit_edge94
	cmp	w23, #16
	msr	TPIDR2_EL0, xzr
	b.lt	.LBB0_67
// %bb.15:                              // %.lr.ph128
	lsr	x8, x20, #4
	asr	w11, w22, #4
	cmp	x21, #1
	ldr	w10, [x29, #120]
	ldr	x14, [x19, #208]                // 8-byte Reload
	mov	x17, xzr
	lsl	x9, x8, #3
	mov	w8, #31                         // =0x1f
	str	w11, [x19, #164]                // 4-byte Spill
	ldp	x12, x11, [x19, #80]            // 16-byte Folded Reload
	incb	x14
	sdiv	x8, x8, x9
	str	x9, [x19, #168]                 // 8-byte Spill
	ldr	w9, [x29, #128]
	sxtw	x26, w10
	mov	w13, wzr
	add	x15, x19, #320
	add	x11, x11, #63
	add	x12, x12, #63
	sxtw	x20, w9
	and	x23, x11, #0xffffffffffffffc0
	and	x22, x12, #0xffffffffffffffc0
	lsl	w11, w9, #4
	ldr	x12, [x19, #72]                 // 8-byte Reload
	str	x26, [x19, #104]                // 8-byte Spill
	smull	x25, w12, w10
	add	x27, x8, #1
	csinc	x8, x21, xzr, lt
	mul	x16, x27, x27
	whilelt	p0.s, xzr, x8
	ldr	x8, [x19, #96]                  // 8-byte Reload
	smull	x8, w10, w8
	mov	z0.s, p0/z, #1                  // =0x1
	ldr	w10, [x19, #220]                // 4-byte Reload
	str	p0, [x29, #-1, mul vl]          // 2-byte Spill
	lsl	x12, x16, #1
	str	x8, [x19, #136]                 // 8-byte Spill
	sxtw	x8, w11
	stp	x16, x14, [x19, #144]           // 16-byte Folded Spill
	str	x8, [x19, #128]                 // 8-byte Spill
	cmp	x12, #1
	sub	x8, x29, #1024
	str	z0, [x8, #-10, mul vl]          // 16-byte Folded Spill
	csinc	x8, x12, xzr, hi
	stp	x20, x8, [x19, #112]            // 16-byte Folded Spill
	b	.LBB0_17
.LBB0_16:                               // %._crit_edge126
                                        //   in Loop: Header=BB0_17 Depth=1
	ldr	w8, [x19, #164]                 // 4-byte Reload
	mov	x17, x20
	msr	TPIDR2_EL0, xzr
	ldr	x20, [x19, #112]                // 8-byte Reload
	add	x15, x19, #320
	cmp	w13, w8
	b.eq	.LBB0_67
.LBB0_17:                               // =>This Loop Header: Depth=1
                                        //     Child Loop BB0_25 Depth 2
                                        //     Child Loop BB0_28 Depth 2
                                        //     Child Loop BB0_37 Depth 2
                                        //     Child Loop BB0_40 Depth 2
                                        //     Child Loop BB0_42 Depth 2
                                        //     Child Loop BB0_45 Depth 2
                                        //       Child Loop BB0_48 Depth 3
                                        //     Child Loop BB0_53 Depth 2
                                        //       Child Loop BB0_55 Depth 3
                                        //       Child Loop BB0_57 Depth 3
                                        //       Child Loop BB0_59 Depth 3
                                        //       Child Loop BB0_61 Depth 3
                                        //       Child Loop BB0_64 Depth 3
	sdiv	x8, x25, x26
	ldp	x11, x9, [x19, #192]            // 16-byte Folded Reload
	str	w10, [x19, #280]                // 4-byte Spill
	str	x25, [x19, #312]                // 8-byte Spill
	add	x14, x17, x9
	str	x17, [x19, #288]                // 8-byte Spill
	str	w13, [x19, #284]                // 4-byte Spill
	sdiv	x9, x14, x11
	mul	x12, x8, x26
	ldr	x8, [x19, #136]                 // 8-byte Reload
	sub	x8, x8, x12
	stp	x12, x14, [x19, #224]           // 16-byte Folded Spill
	sdiv	x8, x8, x26
	mul	x12, x9, x11
	bic	w9, w10, w10, asr #31
	ldr	w10, [x19, #220]                // 4-byte Reload
	cmp	x9, #16
	sub	w26, w10, w13, lsl #4
	str	x12, [x19, #240]                // 8-byte Spill
	sub	x12, x14, x12
	str	x12, [x19, #264]                // 8-byte Spill
	add	x10, x12, #64
	mov	w12, #16                        // =0x10
	csel	x9, x9, x12, lo
	cmp	x10, x11
	csel	x10, x10, x11, lt
	str	x9, [x19, #272]                 // 8-byte Spill
	bic	w9, w26, w26, asr #31
	str	x10, [x19, #256]                // 8-byte Spill
	ldr	x10, [x19, #184]                // 8-byte Reload
	ldr	x10, [x10, #8]
	str	x10, [x19, #296]                // 8-byte Spill
	mov	w10, #32                        // =0x20
	cmp	x8, #32
	csel	x24, x8, x10, lt
	ldr	x8, [x19, #176]                 // 8-byte Reload
	cmp	w9, #16
	csel	w25, w9, w12, lt
	ldr	x8, [x8, #8]
	str	x8, [x19, #248]                 // 8-byte Spill
	msr	TPIDR2_EL0, x15
	smstop	sm
	mov	w0, #2048                       // =0x800
	bl	malloc
	mov	x28, x0
	smstart	sm
	smstart	za
	mrs	x8, TPIDR2_EL0
	add	x0, x19, #320
	cbnz	x8, .LBB0_19
// %bb.18:                              //   in Loop: Header=BB0_17 Depth=1
	bl	__arm_tpidr2_restore
.LBB0_19:                               //   in Loop: Header=BB0_17 Depth=1
	cmp	w26, #15
	str	w26, [x19, #308]                // 4-byte Spill
	msr	TPIDR2_EL0, xzr
	b.gt	.LBB0_23
// %bb.20:                              // %.preheader85.preheader
                                        //   in Loop: Header=BB0_17 Depth=1
	add	x8, x19, #320
	mov	x0, x28
	mov	w1, wzr
	mov	w2, #2048                       // =0x800
	msr	TPIDR2_EL0, x8
	bl	__arm_sc_memset
	smstart	za
	mrs	x8, TPIDR2_EL0
	add	x0, x19, #320
	cbnz	x8, .LBB0_22
// %bb.21:                              // %.preheader85.preheader
                                        //   in Loop: Header=BB0_17 Depth=1
	bl	__arm_tpidr2_restore
.LBB0_22:                               // %.preheader85.preheader
                                        //   in Loop: Header=BB0_17 Depth=1
	msr	TPIDR2_EL0, xzr
.LBB0_23:                               // %.loopexit91
                                        //   in Loop: Header=BB0_17 Depth=1
	ldr	w10, [x19, #308]                // 4-byte Reload
	sub	x8, x25, #1
	ldr	x17, [x19, #312]                // 8-byte Reload
	ldr	x26, [x19, #104]                // 8-byte Reload
	ldr	x18, [x19, #248]                // 8-byte Reload
	cmp	w10, #1
	csneg	x8, x8, x25, ge
	cmp	w10, #1
	sdiv	x8, x8, x21
	neg	x9, x8
	csinc	x8, x9, x8, lt
	mul	x9, x8, x24
	cmp	x9, #1
	b.lt	.LBB0_26
// %bb.24:                              // %.lr.ph96
                                        //   in Loop: Header=BB0_17 Depth=1
	add	x10, x18, x17, lsl #2
	mov	x11, xzr
.LBB0_25:                               //   Parent Loop BB0_17 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	sdiv	x12, x11, x8
	cmp	x8, #0
	cset	w14, mi
	mul	x13, x12, x8
	subs	x13, x11, x13
	add	x11, x11, #1
	mul	x13, x13, x21
	csel	w14, wzr, w14, eq
	sub	x12, x12, x14
	mul	x14, x12, x26
	add	x12, x28, x12, lsl #6
	sub	x15, x25, x13
	cmp	x15, x21
	csel	x15, x15, x21, lt
	add	x14, x10, x14, lsl #2
	whilelt	p0.s, xzr, x15
	cmp	x9, x11
	ld1w	{ z0.s }, p0/z, [x14, x13, lsl #2]
	st1w	{ z0.s }, p0, [x12, x13, lsl #2]
	b.ne	.LBB0_25
.LBB0_26:                               // %._crit_edge97
                                        //   in Loop: Header=BB0_17 Depth=1
	mov	w9, #32                         // =0x20
	add	x16, x19, #320
	sub	x9, x9, x24
	mul	x9, x8, x9
	cmp	x9, #1
	b.lt	.LBB0_29
// %bb.27:                              // %.lr.ph99
                                        //   in Loop: Header=BB0_17 Depth=1
	ldr	x10, [x19, #224]                // 8-byte Reload
	mov	x11, xzr
	sub	x10, x17, x10
	add	x10, x18, x10, lsl #2
.LBB0_28:                               //   Parent Loop BB0_17 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	sdiv	x12, x11, x8
	cmp	x8, #0
	cset	w14, mi
	mul	x13, x12, x8
	subs	x13, x11, x13
	add	x11, x11, #1
	mul	x13, x13, x21
	csel	w14, wzr, w14, eq
	sub	x12, x12, x14
	mul	x14, x12, x26
	add	x12, x12, x24
	add	x12, x28, x12, lsl #6
	sub	x15, x25, x13
	cmp	x15, x21
	csel	x15, x15, x21, lt
	add	x14, x10, x14, lsl #2
	whilelt	p0.s, xzr, x15
	cmp	x9, x11
	ld1w	{ z0.s }, p0/z, [x14, x13, lsl #2]
	st1w	{ z0.s }, p0, [x12, x13, lsl #2]
	b.ne	.LBB0_28
.LBB0_29:                               // %._crit_edge100
                                        //   in Loop: Header=BB0_17 Depth=1
	msr	TPIDR2_EL0, x16
	smstop	sm
	mov	w0, #4096                       // =0x1000
	bl	malloc
	mov	x24, x0
	smstart	sm
	smstart	za
	mrs	x8, TPIDR2_EL0
	add	x0, x19, #320
	cbnz	x8, .LBB0_31
// %bb.30:                              // %._crit_edge100
                                        //   in Loop: Header=BB0_17 Depth=1
	bl	__arm_tpidr2_restore
.LBB0_31:                               // %._crit_edge100
                                        //   in Loop: Header=BB0_17 Depth=1
	ldr	w8, [x19, #308]                 // 4-byte Reload
	msr	TPIDR2_EL0, xzr
	cmp	w8, #15
	b.gt	.LBB0_35
// %bb.32:                              // %.preheader84.preheader
                                        //   in Loop: Header=BB0_17 Depth=1
	add	x8, x19, #320
	mov	x0, x24
	mov	w1, wzr
	mov	w2, #4096                       // =0x1000
	msr	TPIDR2_EL0, x8
	bl	__arm_sc_memset
	smstart	za
	mrs	x8, TPIDR2_EL0
	add	x0, x19, #320
	cbnz	x8, .LBB0_34
// %bb.33:                              // %.preheader84.preheader
                                        //   in Loop: Header=BB0_17 Depth=1
	bl	__arm_tpidr2_restore
.LBB0_34:                               // %.preheader84.preheader
                                        //   in Loop: Header=BB0_17 Depth=1
	msr	TPIDR2_EL0, xzr
.LBB0_35:                               // %.loopexit
                                        //   in Loop: Header=BB0_17 Depth=1
	ldp	x9, x8, [x19, #256]             // 16-byte Folded Reload
	ldr	x17, [x19, #272]                // 8-byte Reload
	sub	x8, x9, x8
	neg	x9, x8
	subs	x10, x8, #1
	csel	x9, x9, x10, lt
	cmp	x8, #1
	sdiv	x9, x9, x21
	neg	x10, x9
	csinc	x9, x10, x9, lt
	mul	x10, x9, x25
	cmp	x10, #1
	b.lt	.LBB0_38
// %bb.36:                              // %.lr.ph102
                                        //   in Loop: Header=BB0_17 Depth=1
	mul	x10, x9, x17
	ldr	x11, [x19, #296]                // 8-byte Reload
	ldr	x12, [x19, #232]                // 8-byte Reload
	add	x11, x11, x12, lsl #2
	mov	x12, xzr
.LBB0_37:                               //   Parent Loop BB0_17 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	sdiv	x13, x12, x9
	cmp	x9, #0
	cset	w15, mi
	mul	x14, x13, x9
	subs	x14, x12, x14
	add	x12, x12, #1
	mul	x14, x14, x21
	csel	w15, wzr, w15, eq
	sub	x13, x13, x15
	mul	x15, x13, x20
	add	x13, x24, x13, lsl #8
	sub	x16, x8, x14
	cmp	x16, x21
	csel	x16, x16, x21, lt
	add	x15, x11, x15, lsl #2
	whilelt	p0.s, xzr, x16
	cmp	x10, x12
	ld1w	{ z0.s }, p0/z, [x15, x14, lsl #2]
	st1w	{ z0.s }, p0, [x13, x14, lsl #2]
	b.ne	.LBB0_37
.LBB0_38:                               // %._crit_edge103
                                        //   in Loop: Header=BB0_17 Depth=1
	mov	w10, #63                        // =0x3f
	sub	x9, x8, #64
	cmp	x8, #63
	sub	x10, x10, x8
	ldp	x2, x0, [x19, #144]             // 16-byte Folded Reload
	csel	x9, x9, x10, gt
	cmp	x8, #63
	ldr	p2, [x29, #-1, mul vl]          // 2-byte Reload
	sdiv	x9, x9, x21
	ldr	x18, [x19, #208]                // 8-byte Reload
	mov	x1, #32                         // =0x20
	mov	x3, #64                         // =0x40
	mov	x4, #96                         // =0x60
	mov	x5, #128                        // =0x80
	mov	x6, #160                        // =0xa0
	mov	x7, #192                        // =0xc0
	mov	x30, #224                       // =0xe0
	neg	x10, x9
	csinc	x9, x10, x9, gt
	mul	x10, x9, x25
	cmp	x10, #1
	sub	x10, x29, #1024
	ldr	z3, [x10, #-10, mul vl]         // 16-byte Folded Reload
	b.lt	.LBB0_41
// %bb.39:                              // %.lr.ph105
                                        //   in Loop: Header=BB0_17 Depth=1
	mul	x11, x9, x17
	ldr	x12, [x19, #240]                // 8-byte Reload
	ldr	x13, [x19, #296]                // 8-byte Reload
	mov	w14, #64                        // =0x40
	mov	x10, xzr
	add	x12, x13, x12, lsl #2
	add	x13, x24, x8, lsl #2
	sub	x8, x14, x8
.LBB0_40:                               //   Parent Loop BB0_17 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	sdiv	x14, x10, x9
	cmp	x9, #0
	cset	w16, mi
	mul	x15, x14, x9
	subs	x15, x10, x15
	add	x10, x10, #1
	mul	x15, x15, x21
	csel	w16, wzr, w16, eq
	sub	x14, x14, x16
	mul	x16, x14, x20
	add	x14, x13, x14, lsl #8
	sub	x17, x8, x15
	cmp	x17, x21
	csel	x17, x17, x21, lt
	add	x16, x12, x16, lsl #2
	whilelt	p0.s, xzr, x17
	cmp	x11, x10
	ld1w	{ z0.s }, p0/z, [x16, x15, lsl #2]
	st1w	{ z0.s }, p0, [x14, x15, lsl #2]
	b.ne	.LBB0_40
.LBB0_41:                               // %.preheader88.preheader
                                        //   in Loop: Header=BB0_17 Depth=1
	ldr	x25, [x19, #120]                // 8-byte Reload
	mov	x8, xzr
	mov	x9, xzr
.LBB0_42:                               // %.preheader88
                                        //   Parent Loop BB0_17 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	and	x10, x8, #0x7c0
	lsr	x11, x9, #5
	add	x8, x8, #64
	add	x10, x28, x10
	add	x10, x10, x11, lsl #2
	ld1w	{ z0.s }, p2/z, [x10]
	st1w	{ z0.s }, p2, [x23, x9, lsl #2]
	add	x9, x9, #1
	cmp	x9, #512
	b.ne	.LBB0_42
// %bb.43:                              // %.preheader87.preheader
                                        //   in Loop: Header=BB0_17 Depth=1
	index	z0.s, #0, #1
	ptrue	p0.s
	ldr	x17, [x19, #168]                // 8-byte Reload
	mov	x8, xzr
	b	.LBB0_45
.LBB0_44:                               // %._crit_edge110
                                        //   in Loop: Header=BB0_45 Depth=2
	and	x10, x8, #0x200
	and	x11, x8, #0x1f
	add	x8, x8, #1
	add	x10, x22, x10, lsl #2
	cmp	x8, #1024
	add	x9, x10, x9, lsl #7
	st1w	{ z1.s }, p2, [x9, x11, lsl #2]
	b.eq	.LBB0_50
.LBB0_45:                               // %.preheader87
                                        //   Parent Loop BB0_17 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB0_48 Depth 3
	ubfx	x9, x8, #5, #4
	cmp	x21, #1
                                        // implicit-def: $z1
	b.lt	.LBB0_44
// %bb.46:                              // %.lr.ph109
                                        //   in Loop: Header=BB0_45 Depth=2
	lsl	x11, x9, #8
	lsr	x12, x8, #9
	mov	x10, xzr
                                        // implicit-def: $z1
	add	x11, x11, x12, lsl #7
	bfi	x11, x8, #2, #5
	add	x11, x24, x11
	b	.LBB0_48
.LBB0_47:                               //   in Loop: Header=BB0_48 Depth=3
	add	x10, x10, #1
	add	x11, x11, #256
	mov	x12, x10
	decw	x12
	cbz	x12, .LBB0_44
.LBB0_48:                               //   Parent Loop BB0_17 Depth=1
                                        //     Parent Loop BB0_45 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	whilels	p1.s, xzr, x10
	lastb	w12, p1, z3.s
	tbz	w12, #0, .LBB0_47
// %bb.49:                              //   in Loop: Header=BB0_48 Depth=3
	mov	z2.s, w10
	cmpeq	p1.s, p0/z, z0.s, z2.s
	ldr	s2, [x11]
	mov	z1.s, p1/m, s2
	b	.LBB0_47
.LBB0_50:                               // %.preheader86
                                        //   in Loop: Header=BB0_17 Depth=1
	cbz	x27, .LBB0_65
// %bb.51:                              // %.lr.ph125.preheader
                                        //   in Loop: Header=BB0_17 Depth=1
	mov	x8, xzr
	b	.LBB0_53
.LBB0_52:                               // %._crit_edge120
                                        //   in Loop: Header=BB0_53 Depth=2
	add	x8, x8, #1
	cmp	x8, x25
	b.eq	.LBB0_65
.LBB0_53:                               // %.lr.ph125
                                        //   Parent Loop BB0_17 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB0_55 Depth 3
                                        //       Child Loop BB0_57 Depth 3
                                        //       Child Loop BB0_59 Depth 3
                                        //       Child Loop BB0_61 Depth 3
                                        //       Child Loop BB0_64 Depth 3
	udiv	x10, x8, x2
	cmp	x21, #1
	msub	x11, x10, x2, x8
	sdiv	x9, x8, x27
	sdiv	x11, x11, x27
	msub	x9, x9, x27, x8
	mul	x12, x9, x17
	mul	x13, x11, x17
	lsl	x9, x13, #5
	add	x9, x9, x10, lsl #10
	add	x11, x9, x12
	add	x9, x18, x11, lsl #2
	b.lt	.LBB0_62
// %bb.54:                              // %.lr.ph112
                                        //   in Loop: Header=BB0_53 Depth=2
	mov	x14, xzr
.LBB0_55:                               //   Parent Loop BB0_17 Depth=1
                                        //     Parent Loop BB0_53 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	add	x15, x9, x14, lsl #7
	ld1w	{za0h.s[w14, 0]}, p0/z, [x15]
	add	x14, x14, #1
	mov	x15, x14
	decw	x15
	cbnz	x15, .LBB0_55
// %bb.56:                              // %.lr.ph113
                                        //   in Loop: Header=BB0_53 Depth=2
	add	x11, x0, x11, lsl #2
	mov	x14, xzr
.LBB0_57:                               //   Parent Loop BB0_17 Depth=1
                                        //     Parent Loop BB0_53 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	add	x15, x11, x14, lsl #7
	ld1w	{za1h.s[w14, 0]}, p0/z, [x15]
	add	x14, x14, #1
	mov	x15, x14
	decw	x15
	cbnz	x15, .LBB0_57
// %bb.58:                              // %.lr.ph115
                                        //   in Loop: Header=BB0_53 Depth=2
	mov	x14, xzr
.LBB0_59:                               //   Parent Loop BB0_17 Depth=1
                                        //     Parent Loop BB0_53 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	mov	x15, x14
	cntw	x16
	incw	x15
	add	x15, x9, x15, lsl #7
	ld1w	{za2h.s[w14, 0]}, p0/z, [x15]
	add	x14, x14, #1
	cmp	x14, x16
	b.ne	.LBB0_59
// %bb.60:                              // %.lr.ph116
                                        //   in Loop: Header=BB0_53 Depth=2
	mov	x14, xzr
.LBB0_61:                               //   Parent Loop BB0_17 Depth=1
                                        //     Parent Loop BB0_53 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	mov	x15, x14
	cntw	x16
	incw	x15
	add	x15, x11, x15, lsl #7
	ld1w	{za3h.s[w14, 0]}, p0/z, [x15]
	add	x14, x14, #1
	cmp	x14, x16
	b.ne	.LBB0_61
.LBB0_62:                               // %.preheader80
                                        //   in Loop: Header=BB0_53 Depth=2
	add	x14, x22, x10, lsl #11
	add	x11, x23, x13, lsl #2
	ld1w	{ z0.s }, p0/z, [x23, x13, lsl #2]
	cmp	x21, #0
	add	x10, x14, x12, lsl #2
	ld1w	{ z1.s }, p0/z, [x14, x12, lsl #2]
	ldr	z2, [x11, #1, mul vl]
	add	x12, x11, #128
	mov	x14, #288                       // =0x120
	ldr	z3, [x10, #1, mul vl]
	add	x13, x10, #128
	fmopa	za0.s, p0/m, p0/m, z0.s, z1.s
	fmopa	za1.s, p0/m, p0/m, z0.s, z3.s
	fmopa	za2.s, p0/m, p0/m, z2.s, z1.s
	fmopa	za3.s, p0/m, p0/m, z2.s, z3.s
	ld1w	{ z0.s }, p0/z, [x11, x1, lsl #2]
	ldr	z1, [x13, #1, mul vl]
	ld1w	{ z2.s }, p0/z, [x10, x1, lsl #2]
	ldr	z3, [x12, #1, mul vl]
	add	x12, x11, #256
	add	x13, x10, #256
	fmopa	za0.s, p0/m, p0/m, z0.s, z2.s
	fmopa	za1.s, p0/m, p0/m, z0.s, z1.s
	fmopa	za2.s, p0/m, p0/m, z3.s, z2.s
	fmopa	za3.s, p0/m, p0/m, z3.s, z1.s
	ldr	z0, [x12, #1, mul vl]
	ld1w	{ z1.s }, p0/z, [x11, x3, lsl #2]
	ldr	z2, [x13, #1, mul vl]
	ld1w	{ z3.s }, p0/z, [x10, x3, lsl #2]
	add	x12, x11, #384
	add	x13, x10, #384
	fmopa	za0.s, p0/m, p0/m, z1.s, z3.s
	fmopa	za1.s, p0/m, p0/m, z1.s, z2.s
	fmopa	za2.s, p0/m, p0/m, z0.s, z3.s
	fmopa	za3.s, p0/m, p0/m, z0.s, z2.s
	ld1w	{ z0.s }, p0/z, [x11, x4, lsl #2]
	ld1w	{ z1.s }, p0/z, [x10, x4, lsl #2]
	ldr	z2, [x12, #1, mul vl]
	ldr	z3, [x13, #1, mul vl]
	add	x12, x11, #512
	add	x13, x10, #512
	fmopa	za0.s, p0/m, p0/m, z0.s, z1.s
	fmopa	za1.s, p0/m, p0/m, z0.s, z3.s
	fmopa	za2.s, p0/m, p0/m, z2.s, z1.s
	fmopa	za3.s, p0/m, p0/m, z2.s, z3.s
	ld1w	{ z0.s }, p0/z, [x11, x5, lsl #2]
	ldr	z1, [x13, #1, mul vl]
	ld1w	{ z2.s }, p0/z, [x10, x5, lsl #2]
	ldr	z3, [x12, #1, mul vl]
	add	x12, x11, #640
	add	x13, x10, #640
	fmopa	za0.s, p0/m, p0/m, z0.s, z2.s
	fmopa	za1.s, p0/m, p0/m, z0.s, z1.s
	fmopa	za2.s, p0/m, p0/m, z3.s, z2.s
	fmopa	za3.s, p0/m, p0/m, z3.s, z1.s
	ldr	z0, [x12, #1, mul vl]
	ld1w	{ z1.s }, p0/z, [x11, x6, lsl #2]
	ldr	z2, [x13, #1, mul vl]
	ld1w	{ z3.s }, p0/z, [x10, x6, lsl #2]
	add	x12, x11, #768
	add	x13, x10, #768
	fmopa	za0.s, p0/m, p0/m, z1.s, z3.s
	fmopa	za1.s, p0/m, p0/m, z1.s, z2.s
	fmopa	za2.s, p0/m, p0/m, z0.s, z3.s
	fmopa	za3.s, p0/m, p0/m, z0.s, z2.s
	ld1w	{ z0.s }, p0/z, [x11, x7, lsl #2]
	ld1w	{ z1.s }, p0/z, [x10, x7, lsl #2]
	ldr	z2, [x12, #1, mul vl]
	ldr	z3, [x13, #1, mul vl]
	add	x12, x11, #896
	add	x13, x10, #896
	fmopa	za0.s, p0/m, p0/m, z0.s, z1.s
	fmopa	za1.s, p0/m, p0/m, z0.s, z3.s
	fmopa	za2.s, p0/m, p0/m, z2.s, z1.s
	fmopa	za3.s, p0/m, p0/m, z2.s, z3.s
	ld1w	{ z0.s }, p0/z, [x11, x30, lsl #2]
	ldr	z1, [x13, #1, mul vl]
	ld1w	{ z2.s }, p0/z, [x10, x30, lsl #2]
	ldr	z3, [x12, #1, mul vl]
	add	x12, x11, #1024
	add	x13, x10, #1024
	fmopa	za0.s, p0/m, p0/m, z0.s, z2.s
	fmopa	za1.s, p0/m, p0/m, z0.s, z1.s
	fmopa	za2.s, p0/m, p0/m, z3.s, z2.s
	fmopa	za3.s, p0/m, p0/m, z3.s, z1.s
	ldr	z0, [x12, #1, mul vl]
	mov	x12, #256                       // =0x100
	ldr	z2, [x13, #1, mul vl]
	add	x13, x10, #1152
	ld1w	{ z1.s }, p0/z, [x11, x12, lsl #2]
	ld1w	{ z3.s }, p0/z, [x10, x12, lsl #2]
	add	x12, x11, #1152
	fmopa	za0.s, p0/m, p0/m, z1.s, z3.s
	fmopa	za1.s, p0/m, p0/m, z1.s, z2.s
	fmopa	za2.s, p0/m, p0/m, z0.s, z3.s
	fmopa	za3.s, p0/m, p0/m, z0.s, z2.s
	ld1w	{ z0.s }, p0/z, [x11, x14, lsl #2]
	ld1w	{ z1.s }, p0/z, [x10, x14, lsl #2]
	ldr	z2, [x12, #1, mul vl]
	ldr	z3, [x13, #1, mul vl]
	add	x12, x11, #1280
	add	x13, x10, #1280
	mov	x14, #320                       // =0x140
	fmopa	za0.s, p0/m, p0/m, z0.s, z1.s
	fmopa	za1.s, p0/m, p0/m, z0.s, z3.s
	fmopa	za2.s, p0/m, p0/m, z2.s, z1.s
	fmopa	za3.s, p0/m, p0/m, z2.s, z3.s
	ld1w	{ z0.s }, p0/z, [x11, x14, lsl #2]
	ldr	z1, [x13, #1, mul vl]
	ld1w	{ z2.s }, p0/z, [x10, x14, lsl #2]
	ldr	z3, [x12, #1, mul vl]
	add	x12, x11, #1408
	add	x13, x10, #1408
	mov	x14, #448                       // =0x1c0
	fmopa	za0.s, p0/m, p0/m, z0.s, z2.s
	fmopa	za1.s, p0/m, p0/m, z0.s, z1.s
	fmopa	za2.s, p0/m, p0/m, z3.s, z2.s
	fmopa	za3.s, p0/m, p0/m, z3.s, z1.s
	ldr	z0, [x12, #1, mul vl]
	mov	x12, #352                       // =0x160
	ldr	z2, [x13, #1, mul vl]
	mov	x13, #384                       // =0x180
	ld1w	{ z1.s }, p0/z, [x11, x12, lsl #2]
	ld1w	{ z3.s }, p0/z, [x10, x12, lsl #2]
	add	x12, x11, #1536
	fmopa	za0.s, p0/m, p0/m, z1.s, z3.s
	fmopa	za1.s, p0/m, p0/m, z1.s, z2.s
	fmopa	za2.s, p0/m, p0/m, z0.s, z3.s
	fmopa	za3.s, p0/m, p0/m, z0.s, z2.s
	ldr	z0, [x12, #1, mul vl]
	add	x12, x10, #1536
	ld1w	{ z1.s }, p0/z, [x11, x13, lsl #2]
	ldr	z2, [x12, #1, mul vl]
	ld1w	{ z3.s }, p0/z, [x10, x13, lsl #2]
	add	x12, x11, #1664
	mov	x13, #416                       // =0x1a0
	fmopa	za0.s, p0/m, p0/m, z1.s, z3.s
	fmopa	za1.s, p0/m, p0/m, z1.s, z2.s
	fmopa	za2.s, p0/m, p0/m, z0.s, z3.s
	fmopa	za3.s, p0/m, p0/m, z0.s, z2.s
	ldr	z0, [x12, #1, mul vl]
	add	x12, x10, #1664
	ld1w	{ z1.s }, p0/z, [x11, x13, lsl #2]
	ldr	z2, [x12, #1, mul vl]
	ld1w	{ z3.s }, p0/z, [x10, x13, lsl #2]
	add	x12, x11, #1792
	add	x13, x10, #1792
	fmopa	za0.s, p0/m, p0/m, z1.s, z3.s
	fmopa	za1.s, p0/m, p0/m, z1.s, z2.s
	fmopa	za2.s, p0/m, p0/m, z0.s, z3.s
	fmopa	za3.s, p0/m, p0/m, z0.s, z2.s
	ld1w	{ z0.s }, p0/z, [x11, x14, lsl #2]
	ldr	z1, [x13, #1, mul vl]
	ld1w	{ z2.s }, p0/z, [x10, x14, lsl #2]
	ldr	z3, [x12, #1, mul vl]
	mov	x13, #480                       // =0x1e0
	add	x12, x11, #1920
	fmopa	za0.s, p0/m, p0/m, z0.s, z2.s
	fmopa	za1.s, p0/m, p0/m, z0.s, z1.s
	fmopa	za2.s, p0/m, p0/m, z3.s, z2.s
	fmopa	za3.s, p0/m, p0/m, z3.s, z1.s
	ld1w	{ z0.s }, p0/z, [x11, x13, lsl #2]
	add	x11, x10, #1920
	ld1w	{ z1.s }, p0/z, [x10, x13, lsl #2]
	ldr	z2, [x12, #1, mul vl]
	ldr	z3, [x11, #1, mul vl]
	fmopa	za0.s, p0/m, p0/m, z0.s, z1.s
	fmopa	za1.s, p0/m, p0/m, z0.s, z3.s
	fmopa	za2.s, p0/m, p0/m, z2.s, z1.s
	fmopa	za3.s, p0/m, p0/m, z2.s, z3.s
	b.le	.LBB0_52
// %bb.63:                              // %.lr.ph119
                                        //   in Loop: Header=BB0_53 Depth=2
	mov	x12, xzr
.LBB0_64:                               //   Parent Loop BB0_17 Depth=1
                                        //     Parent Loop BB0_53 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	add	x10, x9, x12, lsl #7
	mov	x11, x12
	incw	x11
	st1w	{za0h.s[w12, 0]}, p0, [x10]
	incb	x10
	add	x11, x9, x11, lsl #7
	st1w	{za1h.s[w12, 0]}, p0, [x10]
	cntw	x10
	st1w	{za2h.s[w12, 0]}, p0, [x11]
	incb	x11
	st1w	{za3h.s[w12, 0]}, p0, [x11]
	add	x12, x12, #1
	cmp	x12, x10
	b.ne	.LBB0_64
	b	.LBB0_52
.LBB0_65:                               // %._crit_edge126
                                        //   in Loop: Header=BB0_17 Depth=1
	ldr	x25, [x19, #312]                // 8-byte Reload
	ldr	x8, [x19, #128]                 // 8-byte Reload
	ldr	x20, [x19, #288]                // 8-byte Reload
	add	x25, x25, #16
	add	x20, x20, x8
	add	x8, x19, #320
	msr	TPIDR2_EL0, x8
	smstop	sm
	mov	x0, x28
	bl	free
	mov	x0, x24
	bl	free
	smstart	sm
	ldr	w13, [x19, #284]                // 4-byte Reload
	ldr	w10, [x19, #280]                // 4-byte Reload
	add	w13, w13, #1
	sub	w10, w10, #16
	smstart	za
	mrs	x8, TPIDR2_EL0
	add	x0, x19, #320
	cbnz	x8, .LBB0_16
// %bb.66:                              // %._crit_edge126
                                        //   in Loop: Header=BB0_17 Depth=1
	bl	__arm_tpidr2_restore
	b	.LBB0_16
.LBB0_67:                               // %._crit_edge129
	ldr	x8, [x19, #72]                  // 8-byte Reload
	sxtw	x20, w8
	add	x8, x19, #320
	msr	TPIDR2_EL0, x8
	smstop	sm
	mov	w0, #8256                       // =0x2040
	bl	malloc
	mov	x24, x0
	smstart	sm
	add	x8, x0, #63
	and	x8, x8, #0xffffffffffffffc0
	smstart	za
	mrs	x9, TPIDR2_EL0
	add	x0, x19, #320
	cbnz	x9, .LBB0_69
// %bb.68:                              // %._crit_edge129
	bl	__arm_tpidr2_restore
.LBB0_69:                               // %._crit_edge129
	msr	TPIDR2_EL0, xzr
	ldp	x9, x18, [x19, #8]              // 16-byte Folded Reload
	ldr	x0, [x19, #208]                 // 8-byte Reload
	add	x17, x9, #1
	tbnz	x9, #63, .LBB0_72
// %bb.70:                              // %.lr.ph131
	lsl	x10, x17, #1
	mov	x9, xzr
	mov	w11, #32                        // =0x20
.LBB0_71:                               // =>This Inner Loop Header: Depth=1
	udiv	x12, x9, x10
	udiv	x13, x9, x17
	msub	x14, x12, x10, x9
	udiv	x14, x14, x17
	msub	x13, x13, x17, x9
	add	x9, x9, #1
	mul	x13, x13, x21
	sub	x15, x11, x13
	cmp	x15, x21
	csel	x15, x15, x21, lt
	whilelt	p0.s, xzr, x15
	cmp	x18, x9
	add	x16, x0, x14, lsl #12
	add	x15, x16, x12, lsl #7
	add	x12, x8, x12, lsl #8
	ld1w	{ z0.s }, p0/z, [x15, x13, lsl #2]
	add	x12, x12, x14, lsl #7
	st1w	{ z0.s }, p0, [x12, x13, lsl #2]
	b.ne	.LBB0_71
.LBB0_72:                               // %.preheader
	ldr	x10, [x19, #96]                 // 8-byte Reload
	ldp	x11, x18, [x19, #24]            // 16-byte Folded Reload
	ldr	w9, [x29, #136]
	ldr	x17, [x19, #48]                 // 8-byte Reload
	sxtw	x10, w10
	add	x16, x11, #1
	tbnz	x11, #63, .LBB0_75
// %bb.73:                              // %.lr.ph132.preheader
	mov	x11, xzr
	mov	w12, #64                        // =0x40
.LBB0_74:                               // %.lr.ph132
                                        // =>This Inner Loop Header: Depth=1
	udiv	x13, x11, x16
	msub	x14, x13, x16, x11
	add	x11, x11, #1
	mul	x14, x14, x21
	sub	x15, x12, x14
	add	x13, x14, x13, lsl #6
	cmp	x15, x21
	csel	x15, x15, x21, lt
	whilelt	p0.s, xzr, x15
	cmp	x18, x11
	ld1w	{ z0.s }, p0/z, [x8, x13, lsl #2]
	st1w	{ z0.s }, p0, [x17, x13, lsl #2]
	b.ne	.LBB0_74
.LBB0_75:                               // %._crit_edge133
	add	x8, x20, #32
	ldp	x11, x13, [x19, #192]           // 16-byte Folded Reload
	cmp	x8, x10
	mov	w12, #32                        // =0x20
	mov	x15, sp
	csel	x8, x8, x10, lt
	sub	x16, x15, #64
	mov	x21, sp
	add	x10, x13, #64
	cmp	x8, x20
	csel	x8, x8, x20, gt
	cmp	x10, x11
	csel	x10, x10, x11, lt
	smaddl	x11, w20, w9, x13
	sub	x8, x8, x20
	ldp	x14, x20, [x19, #56]            // 16-byte Folded Reload
	cmp	x10, x13
	csel	x10, x10, x13, gt
	cmp	x8, #32
	sxtw	x9, w9
	sub	x10, x10, x13
	csel	x8, x8, x12, lt
	mov	w12, #64                        // =0x40
	ldp	x13, x14, [x14]
	cmp	x10, #64
	csel	x10, x10, x12, lt
	mov	sp, x16
	stp	x10, x12, [x15, #-32]
	mov	w12, #1                         // =0x1
	stp	x20, x17, [x15, #-64]
	stp	xzr, x8, [x15, #-48]
	stur	x12, [x15, #-16]
	mov	x15, sp
	sub	x17, x15, #64
	mov	sp, x17
	stp	x11, x8, [x15, #-48]
	mov	x8, sp
	sub	x1, x8, #16
	stp	x13, x14, [x15, #-64]
	stp	x10, x9, [x15, #-32]
	stur	x12, [x15, #-16]
	mov	sp, x1
	mov	w9, #2                          // =0x2
	stp	x9, x16, [x8, #-16]
	mov	x8, sp
	sub	x2, x8, #16
	mov	sp, x2
	add	x10, x19, #320
	stp	x9, x17, [x8, #-16]
	msr	TPIDR2_EL0, x10
	smstop	sm
	mov	w0, #4                          // =0x4
	bl	memrefCopy
	mov	sp, x21
	mov	x0, x20
	bl	free
	ldr	x0, [x19, #40]                  // 8-byte Reload
	bl	free
	ldr	x0, [x19, #88]                  // 8-byte Reload
	bl	free
	ldr	x0, [x19, #80]                  // 8-byte Reload
	bl	free
	mov	x0, x24
	bl	free
	smstart	sm
	msr	TPIDR2_EL0, xzr
	smstop	za
	sub	x8, x29, #1024
	addvl	sp, x8, #-9
	ldr	z15, [sp]                       // 16-byte Folded Reload
	ldr	z14, [sp, #1, mul vl]           // 16-byte Folded Reload
	ldr	z13, [sp, #2, mul vl]           // 16-byte Folded Reload
	ldr	z12, [sp, #3, mul vl]           // 16-byte Folded Reload
	ldr	z11, [sp, #4, mul vl]           // 16-byte Folded Reload
	ldr	z10, [sp, #5, mul vl]           // 16-byte Folded Reload
	ldr	z9, [sp, #6, mul vl]            // 16-byte Folded Reload
	ldr	z8, [sp, #7, mul vl]            // 16-byte Folded Reload
	.cfi_restore z8
	.cfi_restore z9
	.cfi_restore z10
	.cfi_restore z11
	.cfi_restore z12
	.cfi_restore z13
	.cfi_restore z14
	.cfi_restore z15
	mov	sp, x29
	.cfi_def_cfa wsp, 112
	ldp	x20, x19, [sp, #96]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             // 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             // 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             // 16-byte Folded Reload
	ldp	x28, x27, [sp, #32]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #112            // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore vg
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end0:
	.size	matmul_kernel, .Lfunc_end0-matmul_kernel
	.cfi_endproc
                                        // -- End function
	.section	".note.GNU-stack","",@progbits
