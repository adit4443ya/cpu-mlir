; ModuleID = '/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/A_qprof/hoist/matmul_kernel-llvm-ir.ll'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64"

declare void @memrefCopy(i64, ptr, ptr) local_unnamed_addr #0

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @free(ptr allocptr noundef captures(none)) local_unnamed_addr #1

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite, errnomem: write)
declare noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #2

define void @matmul_kernel(i64 %0, ptr nofree readonly captures(none) %1, i64 %2, ptr nofree readonly captures(none) %3, i64 %4, ptr nofree readonly captures(none) %5, i32 %6, i32 %7, i32 %8, i32 %9, i32 %10, i32 %11, i32 %12, i32 %13, i32 %14, i32 %15, i32 %16, i32 %17) local_unnamed_addr #3 {
  %19 = tail call dereferenceable_or_null(8256) ptr @malloc(i64 8256)
  %20 = ptrtoint ptr %19 to i64
  %21 = add i64 %20, 63
  %22 = and i64 %21, -64
  %23 = inttoptr i64 %22 to ptr
  %24 = tail call i64 @llvm.vscale.i64()
  %25 = shl i64 %24, 2
  %26 = sdiv i64 63, %25
  %27 = add nsw i64 %26, 1
  %28 = shl nsw i64 %27, 5
  %29 = icmp sgt i64 %26, -1
  br i1 %29, label %.lr.ph, label %._crit_edge

.lr.ph:                                           ; preds = %18, %.lr.ph
  %30 = phi i64 [ %39, %.lr.ph ], [ 0, %18 ]
  %.frozen = freeze i64 %30
  %.frozen170 = freeze i64 %27
  %31 = udiv i64 %.frozen, %.frozen170
  %32 = mul i64 %31, %.frozen170
  %.decomposed = sub i64 %.frozen, %32
  %33 = mul nsw i64 %.decomposed, %25
  %34 = sub i64 64, %33
  %35 = tail call i64 @llvm.smin.i64(i64 %34, i64 %25)
  %36 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %35)
  %.idx73 = shl i64 %31, 8
  %37 = getelementptr i8, ptr %23, i64 %.idx73
  %38 = getelementptr [4 x i8], ptr %37, i64 %33
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> zeroinitializer, ptr align 16 %38, <vscale x 4 x i1> %36)
  %39 = add nuw nsw i64 %30, 1
  %exitcond.not = icmp eq i64 %39, %28
  br i1 %exitcond.not, label %._crit_edge, label %.lr.ph

._crit_edge:                                      ; preds = %.lr.ph, %18
  %40 = add i32 %6, 31
  %41 = sdiv i32 %40, 32
  %42 = add i32 %7, 63
  %43 = sdiv i32 %42, 64
  %44 = shl nsw i32 %43, 3
  %.frozen171 = freeze i32 %15
  %.frozen172 = freeze i32 %44
  %45 = sdiv i32 %.frozen171, %.frozen172
  %46 = shl i32 %45, 3
  %47 = sub i32 %41, %46
  %48 = tail call i32 @llvm.smin.i32(i32 %47, i32 8)
  %49 = srem i32 %15, %48
  %50 = add i32 %46, %49
  %51 = mul i32 %45, %.frozen172
  %.decomposed173 = sub i32 %.frozen171, %51
  %52 = sdiv i32 %.decomposed173, %48
  %53 = shl i32 %50, 5
  %54 = sext i32 %53 to i64
  %55 = shl i32 %52, 6
  %56 = sext i32 %55 to i64
  %57 = sext i32 %6 to i64
  %58 = sext i32 %9 to i64
  %59 = mul nsw i64 %54, %58
  %60 = mul nsw i64 %58, %57
  %61 = sext i32 %10 to i64
  %62 = sext i32 %7 to i64
  %63 = add i32 %8, 15
  %64 = sdiv i32 %63, 16
  %65 = shl i32 %10, 4
  %66 = sext i32 %65 to i64
  %67 = tail call dereferenceable_or_null(8256) ptr @malloc(i64 8256)
  %68 = ptrtoint ptr %67 to i64
  %69 = add i64 %68, 63
  %70 = and i64 %69, -64
  %71 = inttoptr i64 %70 to ptr
  %72 = sdiv i64 31, %25
  %73 = add nsw i64 %72, 1
  %74 = shl nsw i64 %73, 6
  %75 = icmp sgt i64 %72, -1
  br i1 %75, label %.lr.ph93, label %._crit_edge94

.lr.ph93:                                         ; preds = %._crit_edge
  %76 = shl nuw nsw i64 %73, 5
  %.rhs.trunc = trunc i64 %73 to i16
  br label %77

77:                                               ; preds = %.lr.ph93, %77
  %78 = phi i64 [ 0, %.lr.ph93 ], [ %94, %77 ]
  %.frozen174 = freeze i64 %78
  %.frozen175 = freeze i64 %76
  %79 = udiv i64 %.frozen174, %.frozen175
  %80 = mul i64 %79, %.frozen175
  %.decomposed176 = sub i64 %.frozen174, %80
  %.lhs.trunc = trunc i64 %.decomposed176 to i16
  %81 = udiv i16 %.lhs.trunc, %.rhs.trunc
  %.zext = zext i16 %81 to i64
  %82 = urem i64 %78, %73
  %83 = mul nsw i64 %82, %25
  %84 = sub i64 32, %83
  %85 = tail call i64 @llvm.smin.i64(i64 %84, i64 %25)
  %86 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %85)
  %.idx69 = shl nuw nsw i64 %.zext, 8
  %87 = getelementptr i8, ptr %23, i64 %.idx69
  %.idx70 = shl i64 %79, 7
  %88 = getelementptr i8, ptr %87, i64 %.idx70
  %89 = getelementptr [4 x i8], ptr %88, i64 %83
  %90 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 16 %89, <vscale x 4 x i1> %86, <vscale x 4 x float> poison)
  %.idx71 = shl i64 %79, 12
  %91 = getelementptr i8, ptr %71, i64 %.idx71
  %.idx72 = shl nuw nsw i64 %.zext, 7
  %92 = getelementptr i8, ptr %91, i64 %.idx72
  %93 = getelementptr [4 x i8], ptr %92, i64 %83
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %90, ptr align 16 %93, <vscale x 4 x i1> %86)
  %94 = add nuw nsw i64 %78, 1
  %exitcond136.not = icmp eq i64 %94, %74
  br i1 %exitcond136.not, label %._crit_edge94, label %77

._crit_edge94:                                    ; preds = %77, %._crit_edge
  %95 = tail call dereferenceable_or_null(2112) ptr @malloc(i64 2112)
  %96 = ptrtoint ptr %95 to i64
  %97 = add i64 %96, 63
  %98 = and i64 %97, -64
  %99 = inttoptr i64 %98 to ptr
  %100 = tail call dereferenceable_or_null(4160) ptr @malloc(i64 4160)
  %101 = ptrtoint ptr %100 to i64
  %102 = add i64 %101, 63
  %103 = and i64 %102, -64
  %104 = inttoptr i64 %103 to ptr
  %105 = shl i64 %24, 3
  %106 = sdiv i64 31, %105
  %107 = add nsw i64 %106, 1
  %108 = mul nsw i64 %107, %107
  %109 = icmp sgt i32 %63, 15
  br i1 %109, label %.lr.ph128, label %._crit_edge129

.lr.ph128:                                        ; preds = %._crit_edge94
  %110 = shl nuw nsw i64 %108, 1
  %111 = getelementptr i8, ptr %3, i64 8
  %112 = getelementptr i8, ptr %1, i64 8
  %113 = tail call i64 @llvm.smin.i64(i64 %25, i64 1)
  %114 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %113)
  %115 = icmp sgt i64 %25, 0
  %invariant.gep121 = getelementptr [4 x i8], ptr %71, i64 %25
  %.not = icmp eq i64 %107, 0
  %umax = tail call i64 @llvm.umax.i64(i64 %110, i64 1)
  br label %116

116:                                              ; preds = %.lr.ph128, %._crit_edge126
  %indvars.iv = phi i32 [ %8, %.lr.ph128 ], [ %indvars.iv.next, %._crit_edge126 ]
  %117 = phi i64 [ 0, %.lr.ph128 ], [ %471, %._crit_edge126 ]
  %118 = phi i64 [ %59, %.lr.ph128 ], [ %470, %._crit_edge126 ]
  %119 = phi i32 [ 0, %.lr.ph128 ], [ %472, %._crit_edge126 ]
  %smax141 = tail call i32 @llvm.smax.i32(i32 %indvars.iv, i32 0)
  %120 = tail call i32 @llvm.umin.i32(i32 %smax141, i32 16)
  %umin142 = zext nneg i32 %120 to i64
  %121 = add nsw i64 %117, %56
  %122 = srem i64 %121, %62
  %123 = sub i64 %121, %122
  %124 = add nsw i64 %122, 64
  %125 = tail call i64 @llvm.smin.i64(i64 %124, i64 %62)
  %126 = sub nsw i64 %125, %122
  %127 = sub nsw i64 0, %126
  %128 = load ptr, ptr %111, align 8
  %.neg = add nsw i64 %126, -64
  %129 = srem i64 %118, %58
  %130 = sub i64 %60, %118
  %131 = add i64 %130, %129
  %132 = sdiv i64 %131, %58
  %133 = tail call i64 @llvm.smin.i64(i64 %132, i64 32)
  %134 = load ptr, ptr %112, align 8
  %135 = sub i64 32, %133
  %136 = shl nuw nsw i32 %119, 4
  %137 = sub nsw i32 %8, %136
  %138 = tail call i32 @llvm.smax.i32(i32 %137, i32 0)
  %139 = tail call i32 @llvm.umin.i32(i32 %138, i32 16)
  %140 = zext nneg i32 %139 to i64
  %141 = tail call dereferenceable_or_null(2048) ptr @malloc(i64 2048)
  %142 = icmp slt i32 %137, 16
  br i1 %142, label %.preheader85.preheader, label %.loopexit91

.preheader85.preheader:                           ; preds = %116
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(2048) %141, i8 0, i64 2048, i1 false)
  br label %.loopexit91

.loopexit91:                                      ; preds = %.preheader85.preheader, %116
  %143 = icmp slt i32 %137, 1
  %144 = sub nsw i64 0, %140
  %145 = add nsw i64 %140, -1
  %146 = select i1 %143, i64 %144, i64 %145
  %147 = sdiv i64 %146, %25
  %148 = sub nsw i64 0, %147
  %149 = add nsw i64 %147, 1
  %150 = select i1 %143, i64 %148, i64 %149
  %151 = mul nsw i64 %150, %133
  %152 = icmp sgt i64 %151, 0
  br i1 %152, label %.lr.ph96, label %._crit_edge97

.lr.ph96:                                         ; preds = %.loopexit91
  %153 = icmp slt i64 %150, 0
  %154 = getelementptr [4 x i8], ptr %134, i64 %118
  br label %155

155:                                              ; preds = %.lr.ph96, %155
  %156 = phi i64 [ 0, %.lr.ph96 ], [ %174, %155 ]
  %.frozen177 = freeze i64 %156
  %.frozen178 = freeze i64 %150
  %157 = sdiv i64 %.frozen177, %.frozen178
  %158 = mul i64 %157, %150
  %159 = icmp ne i64 %156, %158
  %160 = and i1 %153, %159
  %161 = sext i1 %160 to i64
  %162 = add i64 %157, %161
  %163 = mul i64 %157, %.frozen178
  %.decomposed179 = sub i64 %.frozen177, %163
  %164 = mul nsw i64 %.decomposed179, %25
  %165 = sub i64 %140, %164
  %166 = tail call i64 @llvm.smin.i64(i64 %165, i64 %25)
  %167 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %166)
  %168 = mul nsw i64 %162, %58
  %169 = getelementptr [4 x i8], ptr %154, i64 %168
  %170 = getelementptr [4 x i8], ptr %169, i64 %164
  %171 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %170, <vscale x 4 x i1> %167, <vscale x 4 x float> poison)
  %.idx67 = shl i64 %162, 6
  %172 = getelementptr i8, ptr %141, i64 %.idx67
  %173 = getelementptr [4 x i8], ptr %172, i64 %164
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %171, ptr align 4 %173, <vscale x 4 x i1> %167)
  %174 = add nuw nsw i64 %156, 1
  %exitcond137.not = icmp eq i64 %174, %151
  br i1 %exitcond137.not, label %._crit_edge97, label %155

._crit_edge97:                                    ; preds = %155, %.loopexit91
  %175 = mul nsw i64 %150, %135
  %176 = icmp sgt i64 %175, 0
  br i1 %176, label %.lr.ph99, label %._crit_edge100

.lr.ph99:                                         ; preds = %._crit_edge97
  %177 = icmp slt i64 %150, 0
  %178 = getelementptr [4 x i8], ptr %134, i64 %129
  br label %179

179:                                              ; preds = %.lr.ph99, %179
  %180 = phi i64 [ 0, %.lr.ph99 ], [ %199, %179 ]
  %.frozen180 = freeze i64 %180
  %.frozen181 = freeze i64 %150
  %181 = sdiv i64 %.frozen180, %.frozen181
  %182 = mul i64 %181, %150
  %183 = icmp ne i64 %180, %182
  %184 = and i1 %177, %183
  %185 = sext i1 %184 to i64
  %186 = add i64 %181, %185
  %187 = mul i64 %181, %.frozen181
  %.decomposed182 = sub i64 %.frozen180, %187
  %188 = mul nsw i64 %.decomposed182, %25
  %189 = sub i64 %140, %188
  %190 = tail call i64 @llvm.smin.i64(i64 %189, i64 %25)
  %191 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %190)
  %192 = mul nsw i64 %186, %58
  %193 = getelementptr [4 x i8], ptr %178, i64 %192
  %194 = getelementptr [4 x i8], ptr %193, i64 %188
  %195 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %194, <vscale x 4 x i1> %191, <vscale x 4 x float> poison)
  %196 = add i64 %186, %133
  %.idx66 = shl i64 %196, 6
  %197 = getelementptr i8, ptr %141, i64 %.idx66
  %198 = getelementptr [4 x i8], ptr %197, i64 %188
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %195, ptr align 4 %198, <vscale x 4 x i1> %191)
  %199 = add nuw nsw i64 %180, 1
  %exitcond138.not = icmp eq i64 %199, %175
  br i1 %exitcond138.not, label %._crit_edge100, label %179

._crit_edge100:                                   ; preds = %179, %._crit_edge97
  %200 = tail call dereferenceable_or_null(4096) ptr @malloc(i64 4096)
  br i1 %142, label %.preheader84.preheader, label %.loopexit

.preheader84.preheader:                           ; preds = %._crit_edge100
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(4096) %200, i8 0, i64 4096, i1 false)
  br label %.loopexit

.loopexit:                                        ; preds = %.preheader84.preheader, %._crit_edge100
  %201 = icmp slt i64 %126, 1
  %202 = add nsw i64 %126, -1
  %203 = select i1 %201, i64 %127, i64 %202
  %204 = sdiv i64 %203, %25
  %205 = sub nsw i64 0, %204
  %206 = add nsw i64 %204, 1
  %207 = select i1 %201, i64 %205, i64 %206
  %208 = mul nsw i64 %207, %140
  %209 = icmp sgt i64 %208, 0
  br i1 %209, label %.lr.ph102, label %._crit_edge103

.lr.ph102:                                        ; preds = %.loopexit
  %210 = icmp slt i64 %207, 0
  %211 = getelementptr [4 x i8], ptr %128, i64 %121
  %212 = mul nsw i64 %207, %umin142
  br label %213

213:                                              ; preds = %.lr.ph102, %213
  %214 = phi i64 [ 0, %.lr.ph102 ], [ %232, %213 ]
  %.frozen183 = freeze i64 %214
  %.frozen184 = freeze i64 %207
  %215 = sdiv i64 %.frozen183, %.frozen184
  %216 = mul i64 %215, %207
  %217 = icmp ne i64 %214, %216
  %218 = and i1 %210, %217
  %219 = sext i1 %218 to i64
  %220 = add i64 %215, %219
  %221 = mul i64 %215, %.frozen184
  %.decomposed185 = sub i64 %.frozen183, %221
  %222 = mul nsw i64 %.decomposed185, %25
  %223 = sub i64 %126, %222
  %224 = tail call i64 @llvm.smin.i64(i64 %223, i64 %25)
  %225 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %224)
  %226 = mul nsw i64 %220, %61
  %227 = getelementptr [4 x i8], ptr %211, i64 %226
  %228 = getelementptr [4 x i8], ptr %227, i64 %222
  %229 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %228, <vscale x 4 x i1> %225, <vscale x 4 x float> poison)
  %.idx64 = shl i64 %220, 8
  %230 = getelementptr i8, ptr %200, i64 %.idx64
  %231 = getelementptr [4 x i8], ptr %230, i64 %222
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %229, ptr align 4 %231, <vscale x 4 x i1> %225)
  %232 = add nuw nsw i64 %214, 1
  %exitcond140.not = icmp eq i64 %232, %212
  br i1 %exitcond140.not, label %._crit_edge103, label %213

._crit_edge103:                                   ; preds = %213, %.loopexit
  %233 = icmp sgt i64 %126, 63
  %234 = sub nsw i64 63, %126
  %235 = select i1 %233, i64 %.neg, i64 %234
  %236 = sdiv i64 %235, %25
  %237 = sub nsw i64 0, %236
  %238 = add nsw i64 %236, 1
  %239 = select i1 %233, i64 %237, i64 %238
  %240 = mul nsw i64 %239, %140
  %241 = icmp sgt i64 %240, 0
  br i1 %241, label %.lr.ph105, label %.preheader88.preheader

.lr.ph105:                                        ; preds = %._crit_edge103
  %242 = icmp slt i64 %239, 0
  %243 = getelementptr [4 x i8], ptr %128, i64 %123
  %244 = getelementptr [4 x i8], ptr %200, i64 %126
  %245 = mul nsw i64 %239, %umin142
  br label %246

246:                                              ; preds = %.lr.ph105, %246
  %247 = phi i64 [ 0, %.lr.ph105 ], [ %266, %246 ]
  %.frozen186 = freeze i64 %247
  %.frozen187 = freeze i64 %239
  %248 = sdiv i64 %.frozen186, %.frozen187
  %249 = mul i64 %248, %239
  %250 = icmp ne i64 %247, %249
  %251 = and i1 %242, %250
  %252 = sext i1 %251 to i64
  %253 = add i64 %248, %252
  %254 = mul i64 %248, %.frozen187
  %.decomposed188 = sub i64 %.frozen186, %254
  %255 = mul nsw i64 %.decomposed188, %25
  %256 = add i64 %126, %255
  %257 = sub i64 64, %256
  %258 = tail call i64 @llvm.smin.i64(i64 %257, i64 %25)
  %259 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %258)
  %260 = mul nsw i64 %253, %61
  %261 = getelementptr [4 x i8], ptr %243, i64 %260
  %262 = getelementptr [4 x i8], ptr %261, i64 %255
  %263 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %262, <vscale x 4 x i1> %259, <vscale x 4 x float> poison)
  %.idx63 = shl i64 %253, 8
  %264 = getelementptr i8, ptr %244, i64 %.idx63
  %265 = getelementptr [4 x i8], ptr %264, i64 %255
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %263, ptr align 4 %265, <vscale x 4 x i1> %259)
  %266 = add nuw nsw i64 %247, 1
  %exitcond143.not = icmp eq i64 %266, %245
  br i1 %exitcond143.not, label %.preheader88.preheader, label %246

.preheader88.preheader:                           ; preds = %246, %._crit_edge103
  br label %.preheader88

.preheader88:                                     ; preds = %.preheader88.preheader, %.preheader88
  %267 = phi i64 [ %274, %.preheader88 ], [ 0, %.preheader88.preheader ]
  %268 = lshr i64 %267, 5
  %269 = shl nuw nsw i64 %267, 6
  %.idx62 = and i64 %269, 1984
  %270 = getelementptr i8, ptr %141, i64 %.idx62
  %271 = getelementptr [4 x i8], ptr %270, i64 %268
  %272 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %271, <vscale x 4 x i1> %114, <vscale x 4 x float> poison)
  %273 = getelementptr [4 x i8], ptr %99, i64 %267
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %272, ptr align 4 %273, <vscale x 4 x i1> %114)
  %274 = add nuw nsw i64 %267, 1
  %exitcond144.not = icmp eq i64 %274, 512
  br i1 %exitcond144.not, label %.preheader87, label %.preheader88

.preheader86:                                     ; preds = %._crit_edge110
  br i1 %.not, label %._crit_edge126, label %.lr.ph125

.preheader87:                                     ; preds = %.preheader88, %._crit_edge110
  %275 = phi i64 [ %296, %._crit_edge110 ], [ 0, %.preheader88 ]
  %276 = lshr i64 %275, 5
  %277 = and i64 %276, 15
  %278 = and i64 %275, 31
  br i1 %115, label %.lr.ph109, label %._crit_edge110

.lr.ph109:                                        ; preds = %.preheader87
  %279 = lshr i64 %275, 4
  %280 = and i64 %279, 32
  %invariant.gep = getelementptr [4 x i8], ptr %200, i64 %280
  %invariant.gep106 = getelementptr [4 x i8], ptr %invariant.gep, i64 %278
  %.idx60 = shl nuw nsw i64 %277, 8
  %gep107 = getelementptr i8, ptr %invariant.gep106, i64 %.idx60
  br label %281

281:                                              ; preds = %.lr.ph109, %289
  %282 = phi <vscale x 4 x float> [ poison, %.lr.ph109 ], [ %290, %289 ]
  %283 = phi i64 [ 0, %.lr.ph109 ], [ %291, %289 ]
  %284 = extractelement <vscale x 4 x i1> %114, i64 %283
  br i1 %284, label %285, label %289

285:                                              ; preds = %281
  %.idx61 = shl nuw nsw i64 %283, 8
  %286 = getelementptr inbounds nuw i8, ptr %gep107, i64 %.idx61
  %287 = load float, ptr %286, align 4
  %288 = insertelement <vscale x 4 x float> %282, float %287, i64 %283
  br label %289

289:                                              ; preds = %285, %281
  %290 = phi <vscale x 4 x float> [ %288, %285 ], [ %282, %281 ]
  %291 = add nuw nsw i64 %283, 1
  %exitcond145.not = icmp eq i64 %291, %25
  br i1 %exitcond145.not, label %._crit_edge110, label %281

._crit_edge110:                                   ; preds = %289, %.preheader87
  %.lcssa = phi <vscale x 4 x float> [ poison, %.preheader87 ], [ %290, %289 ]
  %292 = and i64 %275, 512
  %293 = getelementptr [4 x i8], ptr %104, i64 %292
  %.idx59 = shl nuw nsw i64 %277, 7
  %294 = getelementptr i8, ptr %293, i64 %.idx59
  %295 = getelementptr [4 x i8], ptr %294, i64 %278
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %.lcssa, ptr align 4 %295, <vscale x 4 x i1> %114)
  %296 = add nuw nsw i64 %275, 1
  %exitcond146.not = icmp eq i64 %296, 1024
  br i1 %exitcond146.not, label %.preheader86, label %.preheader87

.lr.ph125:                                        ; preds = %.preheader86, %._crit_edge120
  %297 = phi i64 [ %469, %._crit_edge120 ], [ 0, %.preheader86 ]
  %.frozen189 = freeze i64 %297
  %.frozen190 = freeze i64 %108
  %298 = udiv i64 %.frozen189, %.frozen190
  %299 = mul i64 %298, %.frozen190
  %.decomposed191 = sub i64 %.frozen189, %299
  %300 = sdiv i64 %.decomposed191, %107
  %301 = srem i64 %297, %107
  %302 = mul nsw i64 %301, %105
  %303 = mul nsw i64 %300, %105
  %304 = shl nsw i64 %298, 10
  %305 = shl nsw i64 %303, 5
  %306 = add i64 %305, %304
  %307 = add i64 %306, %302
  br i1 %115, label %.lr.ph112, label %.preheader80

.lr.ph112:                                        ; preds = %.lr.ph125
  %308 = getelementptr [4 x i8], ptr %71, i64 %307
  br label %309

.lr.ph113:                                        ; preds = %309
  %gep122 = getelementptr [4 x i8], ptr %invariant.gep121, i64 %307
  br label %315

309:                                              ; preds = %.lr.ph112, %309
  %310 = phi i64 [ 0, %.lr.ph112 ], [ %313, %309 ]
  %.idx58 = shl i64 %310, 7
  %311 = getelementptr i8, ptr %308, i64 %.idx58
  %312 = trunc i64 %310 to i32
  tail call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %311, i32 0, i32 %312)
  %313 = add nuw nsw i64 %310, 1
  %exitcond147.not = icmp eq i64 %313, %25
  br i1 %exitcond147.not, label %.lr.ph113, label %309

.lr.ph115:                                        ; preds = %315
  %314 = getelementptr [4 x i8], ptr %71, i64 %307
  br label %319

315:                                              ; preds = %.lr.ph113, %315
  %316 = phi i64 [ 0, %.lr.ph113 ], [ %318, %315 ]
  %.idx57 = shl i64 %316, 7
  %gep = getelementptr i8, ptr %gep122, i64 %.idx57
  %317 = trunc i64 %316 to i32
  tail call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %gep, i32 1, i32 %317)
  %318 = add nuw nsw i64 %316, 1
  %exitcond148.not = icmp eq i64 %318, %25
  br i1 %exitcond148.not, label %.lr.ph115, label %315

.lr.ph116:                                        ; preds = %319
  %gep124 = getelementptr [4 x i8], ptr %invariant.gep121, i64 %307
  br label %454

319:                                              ; preds = %.lr.ph115, %319
  %320 = phi i64 [ 0, %.lr.ph115 ], [ %324, %319 ]
  %321 = add nuw i64 %320, %25
  %.idx56 = shl i64 %321, 7
  %322 = getelementptr i8, ptr %314, i64 %.idx56
  %323 = trunc i64 %320 to i32
  tail call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %322, i32 2, i32 %323)
  %324 = add nuw nsw i64 %320, 1
  %exitcond149.not = icmp eq i64 %324, %25
  br i1 %exitcond149.not, label %.lr.ph116, label %319

.preheader80:                                     ; preds = %454, %.lr.ph125
  %325 = getelementptr [4 x i8], ptr %99, i64 %303
  %.idx54 = shl i64 %298, 11
  %326 = getelementptr i8, ptr %104, i64 %.idx54
  %327 = getelementptr [4 x i8], ptr %326, i64 %302
  %328 = load <vscale x 8 x float>, ptr %325, align 32
  %329 = load <vscale x 8 x float>, ptr %327, align 32
  %330 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %328, i64 0)
  %331 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %329, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %330, <vscale x 4 x float> %331)
  %332 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %329, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %330, <vscale x 4 x float> %332)
  %333 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %328, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %333, <vscale x 4 x float> %331)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %333, <vscale x 4 x float> %332)
  %334 = getelementptr i8, ptr %325, i64 128
  %335 = load <vscale x 8 x float>, ptr %334, align 32
  %336 = getelementptr i8, ptr %327, i64 128
  %337 = load <vscale x 8 x float>, ptr %336, align 32
  %338 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %335, i64 0)
  %339 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %337, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %338, <vscale x 4 x float> %339)
  %340 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %337, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %338, <vscale x 4 x float> %340)
  %341 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %335, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %341, <vscale x 4 x float> %339)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %341, <vscale x 4 x float> %340)
  %342 = getelementptr i8, ptr %325, i64 256
  %343 = load <vscale x 8 x float>, ptr %342, align 32
  %344 = getelementptr i8, ptr %327, i64 256
  %345 = load <vscale x 8 x float>, ptr %344, align 32
  %346 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %343, i64 0)
  %347 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %345, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %346, <vscale x 4 x float> %347)
  %348 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %345, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %346, <vscale x 4 x float> %348)
  %349 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %343, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %349, <vscale x 4 x float> %347)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %349, <vscale x 4 x float> %348)
  %350 = getelementptr i8, ptr %325, i64 384
  %351 = load <vscale x 8 x float>, ptr %350, align 32
  %352 = getelementptr i8, ptr %327, i64 384
  %353 = load <vscale x 8 x float>, ptr %352, align 32
  %354 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %351, i64 0)
  %355 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %353, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %354, <vscale x 4 x float> %355)
  %356 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %353, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %354, <vscale x 4 x float> %356)
  %357 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %351, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %357, <vscale x 4 x float> %355)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %357, <vscale x 4 x float> %356)
  %358 = getelementptr i8, ptr %325, i64 512
  %359 = load <vscale x 8 x float>, ptr %358, align 32
  %360 = getelementptr i8, ptr %327, i64 512
  %361 = load <vscale x 8 x float>, ptr %360, align 32
  %362 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %359, i64 0)
  %363 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %361, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %362, <vscale x 4 x float> %363)
  %364 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %361, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %362, <vscale x 4 x float> %364)
  %365 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %359, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %365, <vscale x 4 x float> %363)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %365, <vscale x 4 x float> %364)
  %366 = getelementptr i8, ptr %325, i64 640
  %367 = load <vscale x 8 x float>, ptr %366, align 32
  %368 = getelementptr i8, ptr %327, i64 640
  %369 = load <vscale x 8 x float>, ptr %368, align 32
  %370 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %367, i64 0)
  %371 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %369, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %370, <vscale x 4 x float> %371)
  %372 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %369, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %370, <vscale x 4 x float> %372)
  %373 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %367, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %373, <vscale x 4 x float> %371)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %373, <vscale x 4 x float> %372)
  %374 = getelementptr i8, ptr %325, i64 768
  %375 = load <vscale x 8 x float>, ptr %374, align 32
  %376 = getelementptr i8, ptr %327, i64 768
  %377 = load <vscale x 8 x float>, ptr %376, align 32
  %378 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %375, i64 0)
  %379 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %377, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %378, <vscale x 4 x float> %379)
  %380 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %377, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %378, <vscale x 4 x float> %380)
  %381 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %375, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %381, <vscale x 4 x float> %379)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %381, <vscale x 4 x float> %380)
  %382 = getelementptr i8, ptr %325, i64 896
  %383 = load <vscale x 8 x float>, ptr %382, align 32
  %384 = getelementptr i8, ptr %327, i64 896
  %385 = load <vscale x 8 x float>, ptr %384, align 32
  %386 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %383, i64 0)
  %387 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %385, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %386, <vscale x 4 x float> %387)
  %388 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %385, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %386, <vscale x 4 x float> %388)
  %389 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %383, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %389, <vscale x 4 x float> %387)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %389, <vscale x 4 x float> %388)
  %390 = getelementptr i8, ptr %325, i64 1024
  %391 = load <vscale x 8 x float>, ptr %390, align 32
  %392 = getelementptr i8, ptr %327, i64 1024
  %393 = load <vscale x 8 x float>, ptr %392, align 32
  %394 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %391, i64 0)
  %395 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %393, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %394, <vscale x 4 x float> %395)
  %396 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %393, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %394, <vscale x 4 x float> %396)
  %397 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %391, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %397, <vscale x 4 x float> %395)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %397, <vscale x 4 x float> %396)
  %398 = getelementptr i8, ptr %325, i64 1152
  %399 = load <vscale x 8 x float>, ptr %398, align 32
  %400 = getelementptr i8, ptr %327, i64 1152
  %401 = load <vscale x 8 x float>, ptr %400, align 32
  %402 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %399, i64 0)
  %403 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %401, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %402, <vscale x 4 x float> %403)
  %404 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %401, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %402, <vscale x 4 x float> %404)
  %405 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %399, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %405, <vscale x 4 x float> %403)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %405, <vscale x 4 x float> %404)
  %406 = getelementptr i8, ptr %325, i64 1280
  %407 = load <vscale x 8 x float>, ptr %406, align 32
  %408 = getelementptr i8, ptr %327, i64 1280
  %409 = load <vscale x 8 x float>, ptr %408, align 32
  %410 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %407, i64 0)
  %411 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %409, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %410, <vscale x 4 x float> %411)
  %412 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %409, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %410, <vscale x 4 x float> %412)
  %413 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %407, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %413, <vscale x 4 x float> %411)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %413, <vscale x 4 x float> %412)
  %414 = getelementptr i8, ptr %325, i64 1408
  %415 = load <vscale x 8 x float>, ptr %414, align 32
  %416 = getelementptr i8, ptr %327, i64 1408
  %417 = load <vscale x 8 x float>, ptr %416, align 32
  %418 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %415, i64 0)
  %419 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %417, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %418, <vscale x 4 x float> %419)
  %420 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %417, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %418, <vscale x 4 x float> %420)
  %421 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %415, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %421, <vscale x 4 x float> %419)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %421, <vscale x 4 x float> %420)
  %422 = getelementptr i8, ptr %325, i64 1536
  %423 = load <vscale x 8 x float>, ptr %422, align 32
  %424 = getelementptr i8, ptr %327, i64 1536
  %425 = load <vscale x 8 x float>, ptr %424, align 32
  %426 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %423, i64 0)
  %427 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %425, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %426, <vscale x 4 x float> %427)
  %428 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %425, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %426, <vscale x 4 x float> %428)
  %429 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %423, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %429, <vscale x 4 x float> %427)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %429, <vscale x 4 x float> %428)
  %430 = getelementptr i8, ptr %325, i64 1664
  %431 = load <vscale x 8 x float>, ptr %430, align 32
  %432 = getelementptr i8, ptr %327, i64 1664
  %433 = load <vscale x 8 x float>, ptr %432, align 32
  %434 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %431, i64 0)
  %435 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %433, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %434, <vscale x 4 x float> %435)
  %436 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %433, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %434, <vscale x 4 x float> %436)
  %437 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %431, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %437, <vscale x 4 x float> %435)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %437, <vscale x 4 x float> %436)
  %438 = getelementptr i8, ptr %325, i64 1792
  %439 = load <vscale x 8 x float>, ptr %438, align 32
  %440 = getelementptr i8, ptr %327, i64 1792
  %441 = load <vscale x 8 x float>, ptr %440, align 32
  %442 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %439, i64 0)
  %443 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %441, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %442, <vscale x 4 x float> %443)
  %444 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %441, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %442, <vscale x 4 x float> %444)
  %445 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %439, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %445, <vscale x 4 x float> %443)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %445, <vscale x 4 x float> %444)
  %446 = getelementptr i8, ptr %325, i64 1920
  %447 = load <vscale x 8 x float>, ptr %446, align 32
  %448 = getelementptr i8, ptr %327, i64 1920
  %449 = load <vscale x 8 x float>, ptr %448, align 32
  %450 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %447, i64 0)
  %451 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %449, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %450, <vscale x 4 x float> %451)
  %452 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %449, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %450, <vscale x 4 x float> %452)
  %453 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %447, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %453, <vscale x 4 x float> %451)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %453, <vscale x 4 x float> %452)
  br i1 %115, label %.lr.ph119, label %._crit_edge120

454:                                              ; preds = %.lr.ph116, %454
  %455 = phi i64 [ 0, %.lr.ph116 ], [ %458, %454 ]
  %456 = add nuw i64 %455, %25
  %.idx55 = shl i64 %456, 7
  %gep118 = getelementptr i8, ptr %gep124, i64 %.idx55
  %457 = trunc i64 %455 to i32
  tail call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %gep118, i32 3, i32 %457)
  %458 = add nuw nsw i64 %455, 1
  %exitcond150.not = icmp eq i64 %458, %25
  br i1 %exitcond150.not, label %.preheader80, label %454

.lr.ph119:                                        ; preds = %.preheader80
  %459 = getelementptr [4 x i8], ptr %71, i64 %307
  br label %460

460:                                              ; preds = %.lr.ph119, %460
  %461 = phi i64 [ 0, %.lr.ph119 ], [ %468, %460 ]
  %.idx74 = shl i64 %461, 7
  %462 = getelementptr i8, ptr %459, i64 %.idx74
  %463 = trunc i64 %461 to i32
  tail call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %462, i32 0, i32 %463)
  %464 = getelementptr [4 x i8], ptr %462, i64 %25
  tail call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %464, i32 1, i32 %463)
  %465 = add nuw i64 %461, %25
  %.idx75 = shl i64 %465, 7
  %466 = getelementptr i8, ptr %459, i64 %.idx75
  tail call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %466, i32 2, i32 %463)
  %467 = getelementptr [4 x i8], ptr %466, i64 %25
  tail call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %467, i32 3, i32 %463)
  %468 = add nuw nsw i64 %461, 1
  %exitcond152.not = icmp eq i64 %468, %25
  br i1 %exitcond152.not, label %._crit_edge120, label %460

._crit_edge120:                                   ; preds = %460, %.preheader80
  %469 = add nuw nsw i64 %297, 1
  %exitcond153.not = icmp eq i64 %469, %umax
  br i1 %exitcond153.not, label %._crit_edge126, label %.lr.ph125

._crit_edge126:                                   ; preds = %._crit_edge120, %.preheader86
  %470 = add nsw i64 %118, 16
  %471 = add i64 %117, %66
  tail call void @free(ptr %141)
  tail call void @free(ptr %200)
  %472 = add nuw nsw i32 %119, 1
  %indvars.iv.next = add i32 %indvars.iv, -16
  %exitcond154.not = icmp eq i32 %472, %64
  br i1 %exitcond154.not, label %._crit_edge129, label %116

._crit_edge129:                                   ; preds = %._crit_edge126, %._crit_edge94
  %473 = tail call dereferenceable_or_null(8256) ptr @malloc(i64 8256)
  %474 = ptrtoint ptr %473 to i64
  %475 = add i64 %474, 63
  %476 = and i64 %475, -64
  %477 = inttoptr i64 %476 to ptr
  br i1 %75, label %.lr.ph131, label %.preheader

.lr.ph131:                                        ; preds = %._crit_edge129
  %478 = shl nuw nsw i64 %73, 1
  br label %479

.preheader:                                       ; preds = %479, %._crit_edge129
  br i1 %29, label %.lr.ph132, label %._crit_edge133

479:                                              ; preds = %.lr.ph131, %479
  %480 = phi i64 [ 0, %.lr.ph131 ], [ %496, %479 ]
  %.frozen192 = freeze i64 %480
  %.frozen193 = freeze i64 %478
  %481 = udiv i64 %.frozen192, %.frozen193
  %482 = mul i64 %481, %.frozen193
  %.decomposed194 = sub i64 %.frozen192, %482
  %483 = udiv i64 %.decomposed194, %73
  %484 = urem i64 %480, %73
  %485 = mul nsw i64 %484, %25
  %486 = sub i64 32, %485
  %487 = tail call i64 @llvm.smin.i64(i64 %486, i64 %25)
  %488 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %487)
  %.idx = shl i64 %483, 12
  %489 = getelementptr i8, ptr %71, i64 %.idx
  %.idx51 = shl i64 %481, 7
  %490 = getelementptr i8, ptr %489, i64 %.idx51
  %491 = getelementptr [4 x i8], ptr %490, i64 %485
  %492 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 16 %491, <vscale x 4 x i1> %488, <vscale x 4 x float> poison)
  %.idx52 = shl i64 %481, 8
  %493 = getelementptr i8, ptr %477, i64 %.idx52
  %.idx53 = shl i64 %483, 7
  %494 = getelementptr i8, ptr %493, i64 %.idx53
  %495 = getelementptr [4 x i8], ptr %494, i64 %485
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %492, ptr align 16 %495, <vscale x 4 x i1> %488)
  %496 = add nuw nsw i64 %480, 1
  %exitcond156.not = icmp eq i64 %496, %74
  br i1 %exitcond156.not, label %.preheader, label %479

.lr.ph132:                                        ; preds = %.preheader, %.lr.ph132
  %497 = phi i64 [ %509, %.lr.ph132 ], [ 0, %.preheader ]
  %.frozen195 = freeze i64 %497
  %.frozen196 = freeze i64 %27
  %498 = udiv i64 %.frozen195, %.frozen196
  %499 = mul i64 %498, %.frozen196
  %.decomposed197 = sub i64 %.frozen195, %499
  %500 = mul nsw i64 %.decomposed197, %25
  %501 = sub i64 64, %500
  %502 = tail call i64 @llvm.smin.i64(i64 %501, i64 %25)
  %503 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %502)
  %504 = shl nsw i64 %498, 6
  %505 = add i64 %504, %500
  %506 = getelementptr [4 x i8], ptr %477, i64 %505
  %507 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 16 %506, <vscale x 4 x i1> %503, <vscale x 4 x float> poison)
  %508 = getelementptr [4 x i8], ptr %23, i64 %505
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %507, ptr align 16 %508, <vscale x 4 x i1> %503)
  %509 = add nuw nsw i64 %497, 1
  %exitcond158.not = icmp eq i64 %509, %28
  br i1 %exitcond158.not, label %._crit_edge133, label %.lr.ph132

._crit_edge133:                                   ; preds = %.lr.ph132, %.preheader
  %510 = sext i32 %11 to i64
  %511 = mul nsw i64 %54, %510
  %512 = add nsw i64 %511, %56
  %513 = add nsw i64 %54, 32
  %514 = tail call i64 @llvm.smin.i64(i64 %513, i64 %57)
  %515 = tail call i64 @llvm.smax.i64(i64 %514, i64 %54)
  %516 = sub nsw i64 %515, %54
  %517 = add nsw i64 %56, 64
  %518 = tail call i64 @llvm.smin.i64(i64 %517, i64 %62)
  %519 = tail call i64 @llvm.smax.i64(i64 %518, i64 %56)
  %520 = sub nsw i64 %519, %56
  %521 = tail call i64 @llvm.smin.i64(i64 %516, i64 32)
  %522 = tail call i64 @llvm.smin.i64(i64 %520, i64 64)
  %523 = load ptr, ptr %5, align 8
  %524 = getelementptr i8, ptr %5, i64 8
  %525 = load ptr, ptr %524, align 8
  %526 = tail call ptr @llvm.stacksave.p0()
  %527 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, align 8
  store ptr %19, ptr %527, align 8
  %.repack24 = getelementptr inbounds nuw i8, ptr %527, i64 8
  store ptr %23, ptr %.repack24, align 8
  %.repack26 = getelementptr inbounds nuw i8, ptr %527, i64 16
  store i64 0, ptr %.repack26, align 8
  %.repack28 = getelementptr inbounds nuw i8, ptr %527, i64 24
  store i64 %521, ptr %.repack28, align 8
  %.repack28.repack32 = getelementptr inbounds nuw i8, ptr %527, i64 32
  store i64 %522, ptr %.repack28.repack32, align 8
  %.repack30 = getelementptr inbounds nuw i8, ptr %527, i64 40
  store i64 64, ptr %.repack30, align 8
  %.repack30.repack34 = getelementptr inbounds nuw i8, ptr %527, i64 48
  store i64 1, ptr %.repack30.repack34, align 8
  %528 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, align 8
  store ptr %523, ptr %528, align 8
  %.repack35 = getelementptr inbounds nuw i8, ptr %528, i64 8
  store ptr %525, ptr %.repack35, align 8
  %.repack37 = getelementptr inbounds nuw i8, ptr %528, i64 16
  store i64 %512, ptr %.repack37, align 8
  %.repack39 = getelementptr inbounds nuw i8, ptr %528, i64 24
  store i64 %521, ptr %.repack39, align 8
  %.repack39.repack43 = getelementptr inbounds nuw i8, ptr %528, i64 32
  store i64 %522, ptr %.repack39.repack43, align 8
  %.repack41 = getelementptr inbounds nuw i8, ptr %528, i64 40
  store i64 %510, ptr %.repack41, align 8
  %.repack41.repack45 = getelementptr inbounds nuw i8, ptr %528, i64 48
  store i64 1, ptr %.repack41.repack45, align 8
  %529 = alloca { i64, ptr }, align 8
  store i64 2, ptr %529, align 8
  %.repack47 = getelementptr inbounds nuw i8, ptr %529, i64 8
  store ptr %527, ptr %.repack47, align 8
  %530 = alloca { i64, ptr }, align 8
  store i64 2, ptr %530, align 8
  %.repack49 = getelementptr inbounds nuw i8, ptr %530, i64 8
  store ptr %528, ptr %.repack49, align 8
  call void @memrefCopy(i64 4, ptr nonnull %529, ptr nonnull %530)
  call void @llvm.stackrestore.p0(ptr %526)
  call void @free(ptr %19)
  call void @free(ptr %67)
  call void @free(ptr %95)
  call void @free(ptr %100)
  call void @free(ptr %473)
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.vscale.i64() #4

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smin.i32(i32, i32) #5

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smin.i64(i64, i64) #5

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smax.i64(i64, i64) #5

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare ptr @llvm.stacksave.p0() #6

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.stackrestore.p0(ptr) #6

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64, i64) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr captures(none), <vscale x 4 x i1>, <vscale x 4 x float>) #7

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float>, ptr captures(none), <vscale x 4 x i1>) #8

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite)
declare void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1>, ptr, i32 immarg, i32) #9

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float>, i64 immarg) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(target_mem1: readwrite)
declare void @llvm.aarch64.sme.mopa.nxv4f32(i32 immarg, <vscale x 4 x i1>, <vscale x 4 x i1>, <vscale x 4 x float>, <vscale x 4 x float>) #10

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite)
declare void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1>, ptr, i32 immarg, i32) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smax.i32(i32, i32) #11

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umin.i32(i32, i32) #11

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umax.i64(i64, i64) #11

attributes #0 = { "target-features"="+sve,+sve2,+sme" }
attributes #1 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "target-features"="+sve,+sve2,+sme" }
attributes #2 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite, errnomem: write) "alloc-family"="malloc" "target-features"="+sve,+sve2,+sme" }
attributes #3 = { "aarch64_new_za" "aarch64_pstate_sm_enabled" "target-features"="+sve,+sve2,+sme" }
attributes #4 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) "target-features"="+sve,+sve2,+sme" }
attributes #5 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) "target-features"="+sve,+sve2,+sme" }
attributes #6 = { mustprogress nocallback nofree nosync nounwind willreturn "target-features"="+sve,+sve2,+sme" }
attributes #7 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read) "target-features"="+sve,+sve2,+sme" }
attributes #8 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write) "target-features"="+sve,+sve2,+sme" }
attributes #9 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite) "target-features"="+sve,+sve2,+sme" }
attributes #10 = { mustprogress nocallback nofree nosync nounwind willreturn memory(target_mem1: readwrite) "target-features"="+sve,+sve2,+sme" }
attributes #11 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #12 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
