; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target triple = "aarch64"

declare void @free(ptr)

declare void @memrefCopy(i64, ptr, ptr)

declare ptr @malloc(i64)

define void @matmul_kernel(i64 %0, ptr %1, i64 %2, ptr %3, i64 %4, ptr %5, i32 %6, i32 %7, i32 %8, i32 %9, i32 %10, i32 %11, i32 %12, i32 %13, i32 %14, i32 %15, i32 %16, i32 %17) {
  %19 = insertvalue { i64, ptr } poison, i64 %4, 0
  %20 = insertvalue { i64, ptr } %19, ptr %5, 1
  %21 = insertvalue { i64, ptr } poison, i64 %0, 0
  %22 = insertvalue { i64, ptr } %21, ptr %1, 1
  %23 = insertvalue { i64, ptr } poison, i64 %2, 0
  %24 = insertvalue { i64, ptr } %23, ptr %3, 1
  %25 = call ptr @malloc(i64 8256)
  %26 = ptrtoint ptr %25 to i64
  %27 = add i64 %26, 63
  %28 = urem i64 %27, 64
  %29 = sub i64 %27, %28
  %30 = inttoptr i64 %29 to ptr
  %31 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %25, 0
  %32 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %31, ptr %30, 1
  %33 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %32, i64 0, 2
  %34 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %33, i64 32, 3, 0
  %35 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %34, i64 64, 3, 1
  %36 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %35, i64 64, 4, 0
  %37 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %36, i64 1, 4, 1
  %38 = call i64 @llvm.vscale.i64()
  %39 = mul i64 %38, 4
  %40 = sdiv i64 63, %39
  %41 = add i64 %40, 1
  %42 = sdiv i64 63, %39
  %43 = add i64 %42, 1
  %44 = mul nsw i64 %43, 32
  br label %45

45:                                               ; preds = %48, %18
  %46 = phi i64 [ %79, %48 ], [ 0, %18 ]
  %47 = icmp slt i64 %46, %44
  br i1 %47, label %48, label %80

48:                                               ; preds = %45
  %49 = sdiv i64 %46, %41
  %50 = mul i64 %49, %41
  %51 = icmp ne i64 %46, %50
  %52 = icmp slt i64 %46, 0
  %53 = icmp slt i64 %41, 0
  %54 = icmp ne i1 %52, %53
  %55 = and i1 %51, %54
  %56 = add i64 %49, -1
  %57 = select i1 %55, i64 %56, i64 %49
  %58 = srem i64 %46, %41
  %59 = icmp slt i64 %58, 0
  %60 = add nsw i64 %58, %41
  %61 = select i1 %59, i64 %60, i64 %58
  %62 = mul nsw i64 %39, %61
  %63 = mul nsw i64 %39, %61
  %64 = mul nsw i64 %63, -1
  %65 = add i64 %64, 64
  %66 = call i64 @llvm.smin.i64(i64 %65, i64 %39)
  %67 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %66)
  %68 = mul nsw i64 %57, 64
  %69 = add i64 %68, %62
  %70 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %25, 0
  %71 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %70, ptr %30, 1
  %72 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %71, i64 %69, 2
  %73 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %72, i64 %66, 3, 0
  %74 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %73, i64 1, 4, 0
  %75 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %74, 1
  %76 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %74, 2
  %77 = getelementptr float, ptr %75, i64 %76
  %78 = getelementptr float, ptr %77, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> zeroinitializer, ptr align 4 %78, <vscale x 4 x i1> %67)
  %79 = add i64 %46, 1
  br label %45

80:                                               ; preds = %45
  %81 = add i32 %6, 31
  %82 = sdiv i32 %81, 32
  %83 = add i32 %7, 63
  %84 = sdiv i32 %83, 64
  %85 = mul i32 %84, 8
  %86 = sdiv i32 %15, %85
  %87 = mul i32 %86, 8
  %88 = sub i32 %82, %87
  %89 = call i32 @llvm.smin.i32(i32 %88, i32 8)
  %90 = srem i32 %15, %89
  %91 = add i32 %87, %90
  %92 = srem i32 %15, %85
  %93 = sdiv i32 %92, %89
  %94 = mul i32 %91, 32
  %95 = sext i32 %94 to i64
  %96 = mul i32 %93, 64
  %97 = sext i32 %96 to i64
  %98 = sext i32 %6 to i64
  %99 = sext i32 %7 to i64
  %100 = call ptr @malloc(i64 8256)
  %101 = ptrtoint ptr %100 to i64
  %102 = add i64 %101, 63
  %103 = urem i64 %102, 64
  %104 = sub i64 %102, %103
  %105 = inttoptr i64 %104 to ptr
  %106 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %100, 0
  %107 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %106, ptr %105, 1
  %108 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %107, i64 0, 2
  %109 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %108, i64 1, 3, 0
  %110 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %109, i64 2, 3, 1
  %111 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %110, i64 32, 3, 2
  %112 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %111, i64 32, 3, 3
  %113 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %112, i64 2048, 4, 0
  %114 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %113, i64 1024, 4, 1
  %115 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %114, i64 32, 4, 2
  %116 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %115, i64 1, 4, 3
  %117 = sdiv i64 31, %39
  %118 = add i64 %117, 1
  %119 = sdiv i64 31, %39
  %120 = add i64 %119, 1
  %121 = mul nsw i64 %120, 64
  br label %122

122:                                              ; preds = %125, %80
  %123 = phi i64 [ %178, %125 ], [ 0, %80 ]
  %124 = icmp slt i64 %123, %121
  br i1 %124, label %125, label %179

125:                                              ; preds = %122
  %126 = mul nuw nsw i64 %118, 32
  %127 = sdiv i64 %123, %126
  %128 = mul i64 %127, %126
  %129 = icmp ne i64 %123, %128
  %130 = icmp slt i64 %123, 0
  %131 = icmp slt i64 %126, 0
  %132 = icmp ne i1 %130, %131
  %133 = and i1 %129, %132
  %134 = add i64 %127, -1
  %135 = select i1 %133, i64 %134, i64 %127
  %136 = srem i64 %123, %126
  %137 = icmp slt i64 %136, 0
  %138 = add nsw i64 %136, %126
  %139 = select i1 %137, i64 %138, i64 %136
  %140 = sdiv i64 %139, %118
  %141 = srem i64 %123, %118
  %142 = icmp slt i64 %141, 0
  %143 = add nsw i64 %141, %118
  %144 = select i1 %142, i64 %143, i64 %141
  %145 = mul nsw i64 %39, %144
  %146 = mul nsw i64 %39, %144
  %147 = mul nsw i64 %146, -1
  %148 = add i64 %147, 32
  %149 = call i64 @llvm.smin.i64(i64 %148, i64 %39)
  %150 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %149)
  %151 = mul nsw i64 %140, 64
  %152 = mul nsw i64 %135, 32
  %153 = add i64 %151, %152
  %154 = add i64 %153, %145
  %155 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %25, 0
  %156 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %155, ptr %30, 1
  %157 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %156, i64 %154, 2
  %158 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %157, i64 %149, 3, 0
  %159 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %158, i64 1, 4, 0
  %160 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %159, 1
  %161 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %159, 2
  %162 = getelementptr float, ptr %160, i64 %161
  %163 = getelementptr float, ptr %162, i64 0
  %164 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %163, <vscale x 4 x i1> %150, <vscale x 4 x float> poison)
  %165 = mul nsw i64 %135, 1024
  %166 = mul nsw i64 %140, 32
  %167 = add i64 %165, %166
  %168 = add i64 %167, %145
  %169 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %100, 0
  %170 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %169, ptr %105, 1
  %171 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %170, i64 %168, 2
  %172 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %171, i64 %149, 3, 0
  %173 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %172, i64 1, 4, 0
  %174 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %173, 1
  %175 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %173, 2
  %176 = getelementptr float, ptr %174, i64 %175
  %177 = getelementptr float, ptr %176, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %164, ptr align 4 %177, <vscale x 4 x i1> %150)
  %178 = add i64 %123, 1
  br label %122

179:                                              ; preds = %122
  %180 = call ptr @malloc(i64 2112)
  %181 = ptrtoint ptr %180 to i64
  %182 = add i64 %181, 63
  %183 = urem i64 %182, 64
  %184 = sub i64 %182, %183
  %185 = inttoptr i64 %184 to ptr
  %186 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %180, 0
  %187 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %186, ptr %185, 1
  %188 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %187, i64 0, 2
  %189 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %188, i64 1, 3, 0
  %190 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %189, i64 16, 3, 1
  %191 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %190, i64 32, 3, 2
  %192 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %191, i64 1, 3, 3
  %193 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %192, i64 512, 4, 0
  %194 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %193, i64 32, 4, 1
  %195 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %194, i64 1, 4, 2
  %196 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %195, i64 1, 4, 3
  %197 = call ptr @malloc(i64 4160)
  %198 = ptrtoint ptr %197 to i64
  %199 = add i64 %198, 63
  %200 = urem i64 %199, 64
  %201 = sub i64 %199, %200
  %202 = inttoptr i64 %201 to ptr
  %203 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %197, 0
  %204 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %203, ptr %202, 1
  %205 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %204, i64 0, 2
  %206 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %205, i64 2, 3, 0
  %207 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %206, i64 16, 3, 1
  %208 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %207, i64 32, 3, 2
  %209 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %208, i64 1, 3, 3
  %210 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %209, i64 512, 4, 0
  %211 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %210, i64 32, 4, 1
  %212 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %211, i64 1, 4, 2
  %213 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %212, i64 1, 4, 3
  %214 = call { i64, i64 } @matmul_kernel_sme_0(i32 %93, i32 %7, i64 %2, ptr %3, i32 %10, i32 %9, i32 %6, i64 %0, ptr %1, i32 %8, ptr %180, ptr %185, i64 0, i64 1, i64 16, i64 32, i64 1, i64 512, i64 32, i64 1, i64 1, ptr %197, ptr %202, i64 0, i64 2, i64 16, i64 32, i64 1, i64 512, i64 32, i64 1, i64 1, ptr %100, ptr %105, i64 0, i64 1, i64 2, i64 32, i64 32, i64 2048, i64 1024, i64 32, i64 1, i32 %86, i32 %90)
  %215 = extractvalue { i64, i64 } %214, 0
  %216 = extractvalue { i64, i64 } %214, 1
  %217 = call ptr @malloc(i64 8256)
  %218 = ptrtoint ptr %217 to i64
  %219 = add i64 %218, 63
  %220 = urem i64 %219, 64
  %221 = sub i64 %219, %220
  %222 = inttoptr i64 %221 to ptr
  %223 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %217, 0
  %224 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %223, ptr %222, 1
  %225 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %224, i64 0, 2
  %226 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %225, i64 1, 3, 0
  %227 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %226, i64 32, 3, 1
  %228 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %227, i64 2, 3, 2
  %229 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %228, i64 32, 3, 3
  %230 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %229, i64 2048, 4, 0
  %231 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %230, i64 64, 4, 1
  %232 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %231, i64 32, 4, 2
  %233 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %232, i64 1, 4, 3
  br label %234

234:                                              ; preds = %237, %179
  %235 = phi i64 [ %290, %237 ], [ 0, %179 ]
  %236 = icmp slt i64 %235, %121
  br i1 %236, label %237, label %291

237:                                              ; preds = %234
  %238 = mul nuw nsw i64 %118, 2
  %239 = sdiv i64 %235, %238
  %240 = mul i64 %239, %238
  %241 = icmp ne i64 %235, %240
  %242 = icmp slt i64 %235, 0
  %243 = icmp slt i64 %238, 0
  %244 = icmp ne i1 %242, %243
  %245 = and i1 %241, %244
  %246 = add i64 %239, -1
  %247 = select i1 %245, i64 %246, i64 %239
  %248 = srem i64 %235, %238
  %249 = icmp slt i64 %248, 0
  %250 = add nsw i64 %248, %238
  %251 = select i1 %249, i64 %250, i64 %248
  %252 = sdiv i64 %251, %118
  %253 = srem i64 %235, %118
  %254 = icmp slt i64 %253, 0
  %255 = add nsw i64 %253, %118
  %256 = select i1 %254, i64 %255, i64 %253
  %257 = mul nsw i64 %39, %256
  %258 = mul nsw i64 %39, %256
  %259 = mul nsw i64 %258, -1
  %260 = add i64 %259, 32
  %261 = call i64 @llvm.smin.i64(i64 %260, i64 %39)
  %262 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %261)
  %263 = mul nsw i64 %252, 1024
  %264 = mul nsw i64 %247, 32
  %265 = add i64 %263, %264
  %266 = add i64 %265, %257
  %267 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %100, 0
  %268 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %267, ptr %105, 1
  %269 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %268, i64 %266, 2
  %270 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %269, i64 %261, 3, 0
  %271 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %270, i64 1, 4, 0
  %272 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %271, 1
  %273 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %271, 2
  %274 = getelementptr float, ptr %272, i64 %273
  %275 = getelementptr float, ptr %274, i64 0
  %276 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %275, <vscale x 4 x i1> %262, <vscale x 4 x float> poison)
  %277 = mul nsw i64 %247, 64
  %278 = mul nsw i64 %252, 32
  %279 = add i64 %277, %278
  %280 = add i64 %279, %257
  %281 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %217, 0
  %282 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %281, ptr %222, 1
  %283 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %282, i64 %280, 2
  %284 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %283, i64 %261, 3, 0
  %285 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %284, i64 1, 4, 0
  %286 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %285, 1
  %287 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %285, 2
  %288 = getelementptr float, ptr %286, i64 %287
  %289 = getelementptr float, ptr %288, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %276, ptr align 4 %289, <vscale x 4 x i1> %262)
  %290 = add i64 %235, 1
  br label %234

291:                                              ; preds = %234
  br label %292

292:                                              ; preds = %295, %291
  %293 = phi i64 [ %338, %295 ], [ 0, %291 ]
  %294 = icmp slt i64 %293, %44
  br i1 %294, label %295, label %339

295:                                              ; preds = %292
  %296 = sdiv i64 %293, %41
  %297 = mul i64 %296, %41
  %298 = icmp ne i64 %293, %297
  %299 = icmp slt i64 %293, 0
  %300 = icmp slt i64 %41, 0
  %301 = icmp ne i1 %299, %300
  %302 = and i1 %298, %301
  %303 = add i64 %296, -1
  %304 = select i1 %302, i64 %303, i64 %296
  %305 = srem i64 %293, %41
  %306 = icmp slt i64 %305, 0
  %307 = add nsw i64 %305, %41
  %308 = select i1 %306, i64 %307, i64 %305
  %309 = mul nsw i64 %39, %308
  %310 = mul nsw i64 %39, %308
  %311 = mul nsw i64 %310, -1
  %312 = add i64 %311, 64
  %313 = call i64 @llvm.smin.i64(i64 %312, i64 %39)
  %314 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %313)
  %315 = mul nsw i64 %304, 64
  %316 = add i64 %315, %309
  %317 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %217, 0
  %318 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %317, ptr %222, 1
  %319 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %318, i64 %316, 2
  %320 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %319, i64 %313, 3, 0
  %321 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %320, i64 1, 4, 0
  %322 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %321, 1
  %323 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %321, 2
  %324 = getelementptr float, ptr %322, i64 %323
  %325 = getelementptr float, ptr %324, i64 0
  %326 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %325, <vscale x 4 x i1> %314, <vscale x 4 x float> poison)
  %327 = mul nsw i64 %304, 64
  %328 = add i64 %327, %309
  %329 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %25, 0
  %330 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %329, ptr %30, 1
  %331 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %330, i64 %328, 2
  %332 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %331, i64 %313, 3, 0
  %333 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %332, i64 1, 4, 0
  %334 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %333, 1
  %335 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %333, 2
  %336 = getelementptr float, ptr %334, i64 %335
  %337 = getelementptr float, ptr %336, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %326, ptr align 4 %337, <vscale x 4 x i1> %314)
  %338 = add i64 %293, 1
  br label %292

339:                                              ; preds = %292
  %340 = sext i32 %11 to i64
  %341 = mul i64 %95, %340
  %342 = add i64 %341, %97
  %343 = add i64 %95, 32
  %344 = call i64 @llvm.smin.i64(i64 %343, i64 %98)
  %345 = call i64 @llvm.smax.i64(i64 %344, i64 %95)
  %346 = sub i64 %345, %95
  %347 = add i64 %97, 64
  %348 = call i64 @llvm.smin.i64(i64 %347, i64 %99)
  %349 = call i64 @llvm.smax.i64(i64 %348, i64 %97)
  %350 = sub i64 %349, %97
  %351 = call i64 @llvm.smin.i64(i64 %346, i64 32)
  %352 = call i64 @llvm.smin.i64(i64 %350, i64 64)
  %353 = extractvalue { i64, ptr } %20, 1
  %354 = load ptr, ptr %353, align 8
  %355 = getelementptr ptr, ptr %353, i32 1
  %356 = load ptr, ptr %355, align 8
  %357 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %354, 0
  %358 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %357, ptr %356, 1
  %359 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %358, i64 %342, 2
  %360 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %359, i64 32, 3, 0
  %361 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %360, i64 %340, 4, 0
  %362 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %361, i64 64, 3, 1
  %363 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %362, i64 1, 4, 1
  %364 = insertvalue { ptr, ptr, i64 } poison, ptr %354, 0
  %365 = insertvalue { ptr, ptr, i64 } %364, ptr %356, 1
  %366 = insertvalue { ptr, ptr, i64 } %365, i64 0, 2
  %367 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %354, 0
  %368 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %367, ptr %356, 1
  %369 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %368, i64 %342, 2
  %370 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %369, i64 %351, 3, 0
  %371 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %370, i64 %340, 4, 0
  %372 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %371, i64 %352, 3, 1
  %373 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %372, i64 1, 4, 1
  %374 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %25, 0
  %375 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %374, ptr %30, 1
  %376 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %375, i64 0, 2
  %377 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %376, i64 %351, 3, 0
  %378 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %377, i64 64, 4, 0
  %379 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %378, i64 %352, 3, 1
  %380 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %379, i64 1, 4, 1
  %381 = call ptr @llvm.stacksave.p0()
  %382 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %380, ptr %382, align 8
  %383 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %382, 1
  %384 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, i64 1, align 8
  store { ptr, ptr, i64, [2 x i64], [2 x i64] } %373, ptr %384, align 8
  %385 = insertvalue { i64, ptr } { i64 2, ptr poison }, ptr %384, 1
  %386 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %383, ptr %386, align 8
  %387 = alloca { i64, ptr }, i64 1, align 8
  store { i64, ptr } %385, ptr %387, align 8
  call void @memrefCopy(i64 4, ptr %386, ptr %387)
  call void @llvm.stackrestore.p0(ptr %381)
  call void @free(ptr %25)
  call void @free(ptr %100)
  call void @free(ptr %180)
  call void @free(ptr %197)
  call void @free(ptr %217)
  ret void
}

define internal { i64, i64 } @matmul_kernel_sme_0(i32 %0, i32 %1, i64 %2, ptr %3, i32 %4, i32 %5, i32 %6, i64 %7, ptr %8, i32 %9, ptr %10, ptr %11, i64 %12, i64 %13, i64 %14, i64 %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20, ptr %21, ptr %22, i64 %23, i64 %24, i64 %25, i64 %26, i64 %27, i64 %28, i64 %29, i64 %30, i64 %31, ptr %32, ptr %33, i64 %34, i64 %35, i64 %36, i64 %37, i64 %38, i64 %39, i64 %40, i64 %41, i64 %42, i32 %43, i32 %44) #0 {
  %46 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %32, 0
  %47 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %46, ptr %33, 1
  %48 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %47, i64 %34, 2
  %49 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %48, i64 %35, 3, 0
  %50 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %49, i64 %39, 4, 0
  %51 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %50, i64 %36, 3, 1
  %52 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %51, i64 %40, 4, 1
  %53 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %52, i64 %37, 3, 2
  %54 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %53, i64 %41, 4, 2
  %55 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %54, i64 %38, 3, 3
  %56 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %55, i64 %42, 4, 3
  %57 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %21, 0
  %58 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %57, ptr %22, 1
  %59 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %58, i64 %23, 2
  %60 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %59, i64 %24, 3, 0
  %61 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %60, i64 %28, 4, 0
  %62 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %61, i64 %25, 3, 1
  %63 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %62, i64 %29, 4, 1
  %64 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %63, i64 %26, 3, 2
  %65 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %64, i64 %30, 4, 2
  %66 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %65, i64 %27, 3, 3
  %67 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %66, i64 %31, 4, 3
  %68 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } poison, ptr %10, 0
  %69 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %68, ptr %11, 1
  %70 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %69, i64 %12, 2
  %71 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %70, i64 %13, 3, 0
  %72 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %71, i64 %17, 4, 0
  %73 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %72, i64 %14, 3, 1
  %74 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %73, i64 %18, 4, 1
  %75 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %74, i64 %15, 3, 2
  %76 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %75, i64 %19, 4, 2
  %77 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %76, i64 %16, 3, 3
  %78 = insertvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %77, i64 %20, 4, 3
  %79 = insertvalue { i64, ptr } poison, i64 %7, 0
  %80 = insertvalue { i64, ptr } %79, ptr %8, 1
  %81 = insertvalue { i64, ptr } poison, i64 %2, 0
  %82 = insertvalue { i64, ptr } %81, ptr %3, 1
  %83 = mul i32 %0, 64
  %84 = sext i32 %83 to i64
  %85 = sext i32 %1 to i64
  %86 = sext i32 %4 to i64
  %87 = sext i32 %5 to i64
  %88 = sext i32 %6 to i64
  %89 = mul i64 %88, %87
  %90 = call i64 @llvm.vscale.i64()
  %91 = mul i64 %90, 4
  %92 = mul i64 %90, 8
  %93 = sdiv i64 31, %92
  %94 = add i64 %93, 1
  %95 = sdiv i64 31, %92
  %96 = add i64 %95, 1
  %97 = sdiv i64 31, %92
  %98 = add i64 %97, 1
  %99 = mul nsw i64 %96, %98
  %100 = mul nsw i64 %99, 2
  %101 = mul i32 %4, 16
  %102 = sext i32 %101 to i64
  %103 = add i32 %9, 15
  %104 = sdiv i32 %103, 16
  %105 = mul i32 %43, 8
  %106 = add i32 %105, %44
  %107 = mul i32 %106, 32
  %108 = sext i32 %107 to i64
  %109 = mul i64 %108, %87
  br label %110

110:                                              ; preds = %821, %45
  %111 = phi i32 [ %824, %821 ], [ 0, %45 ]
  %112 = phi i64 [ %822, %821 ], [ %109, %45 ]
  %113 = phi i64 [ %823, %821 ], [ 0, %45 ]
  %114 = icmp slt i32 %111, %104
  br i1 %114, label %115, label %825

115:                                              ; preds = %110
  %116 = add i64 %113, %84
  %117 = srem i64 %116, %85
  %118 = sub i64 %116, %117
  %119 = add i64 %117, 64
  %120 = call i64 @llvm.smin.i64(i64 %119, i64 %85)
  %121 = sub i64 %120, %117
  %122 = extractvalue { i64, ptr } %82, 1
  %123 = load ptr, ptr %122, align 8
  %124 = getelementptr ptr, ptr %122, i32 1
  %125 = load ptr, ptr %124, align 8
  %126 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %123, 0
  %127 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %126, ptr %125, 1
  %128 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %127, i64 %116, 2
  %129 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %128, i64 16, 3, 0
  %130 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %129, i64 %86, 4, 0
  %131 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %130, i64 %121, 3, 1
  %132 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %131, i64 1, 4, 1
  %133 = sub i64 64, %121
  %134 = extractvalue { i64, ptr } %82, 1
  %135 = load ptr, ptr %134, align 8
  %136 = getelementptr ptr, ptr %134, i32 1
  %137 = load ptr, ptr %136, align 8
  %138 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %135, 0
  %139 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %138, ptr %137, 1
  %140 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %139, i64 %118, 2
  %141 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %140, i64 16, 3, 0
  %142 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %141, i64 %86, 4, 0
  %143 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %142, i64 %133, 3, 1
  %144 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %143, i64 1, 4, 1
  %145 = srem i64 %112, %87
  %146 = add i64 %89, %145
  %147 = sub i64 %146, %112
  %148 = sdiv i64 %147, %87
  %149 = call i64 @llvm.smin.i64(i64 %148, i64 32)
  %150 = extractvalue { i64, ptr } %80, 1
  %151 = load ptr, ptr %150, align 8
  %152 = getelementptr ptr, ptr %150, i32 1
  %153 = load ptr, ptr %152, align 8
  %154 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %151, 0
  %155 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %154, ptr %153, 1
  %156 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %155, i64 %112, 2
  %157 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %156, i64 %149, 3, 0
  %158 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %157, i64 %87, 4, 0
  %159 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %158, i64 16, 3, 1
  %160 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %159, i64 1, 4, 1
  %161 = sub i64 32, %149
  %162 = extractvalue { i64, ptr } %80, 1
  %163 = load ptr, ptr %162, align 8
  %164 = getelementptr ptr, ptr %162, i32 1
  %165 = load ptr, ptr %164, align 8
  %166 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %163, 0
  %167 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %166, ptr %165, 1
  %168 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %167, i64 %145, 2
  %169 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %168, i64 %161, 3, 0
  %170 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %169, i64 %87, 4, 0
  %171 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %170, i64 16, 3, 1
  %172 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %171, i64 1, 4, 1
  %173 = mul i32 %111, 16
  %174 = sub i32 %9, %173
  %175 = sext i32 %174 to i64
  %176 = call i64 @llvm.smin.i64(i64 %175, i64 16)
  %177 = call i64 @llvm.smax.i64(i64 %176, i64 0)
  %178 = call ptr @malloc(i64 2048)
  %179 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %178, 0
  %180 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %179, ptr %178, 1
  %181 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %180, i64 0, 2
  %182 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %181, i64 32, 3, 0
  %183 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %182, i64 16, 3, 1
  %184 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %183, i64 16, 4, 0
  %185 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %184, i64 1, 4, 1
  %186 = icmp slt i64 %177, 16
  br i1 %186, label %187, label %200

187:                                              ; preds = %198, %115
  %188 = phi i64 [ %199, %198 ], [ 0, %115 ]
  %189 = icmp slt i64 %188, 32
  br i1 %189, label %190, label %200

190:                                              ; preds = %193, %187
  %191 = phi i64 [ %197, %193 ], [ 0, %187 ]
  %192 = icmp slt i64 %191, 16
  br i1 %192, label %193, label %198

193:                                              ; preds = %190
  %194 = mul nuw nsw i64 %188, 16
  %195 = add nuw nsw i64 %194, %191
  %196 = getelementptr inbounds nuw float, ptr %178, i64 %195
  store float 0.000000e+00, ptr %196, align 4
  %197 = add i64 %191, 1
  br label %190

198:                                              ; preds = %190
  %199 = add i64 %188, 1
  br label %187

200:                                              ; preds = %187, %115
  %201 = icmp sle i64 %177, 0
  %202 = sub i64 0, %177
  %203 = sub i64 %177, 1
  %204 = select i1 %201, i64 %202, i64 %203
  %205 = sdiv i64 %204, %91
  %206 = sub i64 0, %205
  %207 = add i64 %205, 1
  %208 = select i1 %201, i64 %206, i64 %207
  %209 = icmp sle i64 %177, 0
  %210 = sub i64 0, %177
  %211 = sub i64 %177, 1
  %212 = select i1 %209, i64 %210, i64 %211
  %213 = sdiv i64 %212, %91
  %214 = sub i64 0, %213
  %215 = add i64 %213, 1
  %216 = select i1 %209, i64 %214, i64 %215
  %217 = mul nsw i64 %149, %216
  br label %218

218:                                              ; preds = %221, %200
  %219 = phi i64 [ %268, %221 ], [ 0, %200 ]
  %220 = icmp slt i64 %219, %217
  br i1 %220, label %221, label %269

221:                                              ; preds = %218
  %222 = sdiv i64 %219, %208
  %223 = mul i64 %222, %208
  %224 = icmp ne i64 %219, %223
  %225 = icmp slt i64 %219, 0
  %226 = icmp slt i64 %208, 0
  %227 = icmp ne i1 %225, %226
  %228 = and i1 %224, %227
  %229 = add i64 %222, -1
  %230 = select i1 %228, i64 %229, i64 %222
  %231 = srem i64 %219, %208
  %232 = icmp slt i64 %231, 0
  %233 = add nsw i64 %231, %208
  %234 = select i1 %232, i64 %233, i64 %231
  %235 = mul nsw i64 %91, %234
  %236 = mul nsw i64 %91, %234
  %237 = mul nsw i64 %236, -1
  %238 = add i64 %177, %237
  %239 = call i64 @llvm.smin.i64(i64 %238, i64 %91)
  %240 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %239)
  %241 = insertvalue { ptr, ptr, i64 } poison, ptr %151, 0
  %242 = insertvalue { ptr, ptr, i64 } %241, ptr %153, 1
  %243 = insertvalue { ptr, ptr, i64 } %242, i64 0, 2
  %244 = mul nsw i64 %230, %87
  %245 = add i64 %112, %244
  %246 = add i64 %245, %235
  %247 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %151, 0
  %248 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %247, ptr %153, 1
  %249 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %248, i64 %246, 2
  %250 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %249, i64 %239, 3, 0
  %251 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %250, i64 1, 4, 0
  %252 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %251, 1
  %253 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %251, 2
  %254 = getelementptr float, ptr %252, i64 %253
  %255 = getelementptr float, ptr %254, i64 0
  %256 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %255, <vscale x 4 x i1> %240, <vscale x 4 x float> poison)
  %257 = mul nsw i64 %230, 16
  %258 = add i64 %257, %235
  %259 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %178, 0
  %260 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %259, ptr %178, 1
  %261 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %260, i64 %258, 2
  %262 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %261, i64 %239, 3, 0
  %263 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %262, i64 1, 4, 0
  %264 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %263, 1
  %265 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %263, 2
  %266 = getelementptr float, ptr %264, i64 %265
  %267 = getelementptr float, ptr %266, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %256, ptr align 4 %267, <vscale x 4 x i1> %240)
  %268 = add i64 %219, 1
  br label %218

269:                                              ; preds = %218
  %270 = icmp sle i64 %177, 0
  %271 = sub i64 0, %177
  %272 = sub i64 %177, 1
  %273 = select i1 %270, i64 %271, i64 %272
  %274 = sdiv i64 %273, %91
  %275 = sub i64 0, %274
  %276 = add i64 %274, 1
  %277 = select i1 %270, i64 %275, i64 %276
  %278 = mul nsw i64 %161, %277
  br label %279

279:                                              ; preds = %282, %269
  %280 = phi i64 [ %331, %282 ], [ 0, %269 ]
  %281 = icmp slt i64 %280, %278
  br i1 %281, label %282, label %332

282:                                              ; preds = %279
  %283 = sdiv i64 %280, %208
  %284 = mul i64 %283, %208
  %285 = icmp ne i64 %280, %284
  %286 = icmp slt i64 %280, 0
  %287 = icmp slt i64 %208, 0
  %288 = icmp ne i1 %286, %287
  %289 = and i1 %285, %288
  %290 = add i64 %283, -1
  %291 = select i1 %289, i64 %290, i64 %283
  %292 = srem i64 %280, %208
  %293 = icmp slt i64 %292, 0
  %294 = add nsw i64 %292, %208
  %295 = select i1 %293, i64 %294, i64 %292
  %296 = mul nsw i64 %91, %295
  %297 = mul nsw i64 %91, %295
  %298 = mul nsw i64 %297, -1
  %299 = add i64 %177, %298
  %300 = call i64 @llvm.smin.i64(i64 %299, i64 %91)
  %301 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %300)
  %302 = insertvalue { ptr, ptr, i64 } poison, ptr %163, 0
  %303 = insertvalue { ptr, ptr, i64 } %302, ptr %165, 1
  %304 = insertvalue { ptr, ptr, i64 } %303, i64 0, 2
  %305 = mul nsw i64 %291, %87
  %306 = add i64 %145, %305
  %307 = add i64 %306, %296
  %308 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %163, 0
  %309 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %308, ptr %165, 1
  %310 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %309, i64 %307, 2
  %311 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %310, i64 %300, 3, 0
  %312 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %311, i64 1, 4, 0
  %313 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %312, 1
  %314 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %312, 2
  %315 = getelementptr float, ptr %313, i64 %314
  %316 = getelementptr float, ptr %315, i64 0
  %317 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %316, <vscale x 4 x i1> %301, <vscale x 4 x float> poison)
  %318 = mul nsw i64 %149, 16
  %319 = mul nsw i64 %291, 16
  %320 = add i64 %318, %319
  %321 = add i64 %320, %296
  %322 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %178, 0
  %323 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %322, ptr %178, 1
  %324 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %323, i64 %321, 2
  %325 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %324, i64 %300, 3, 0
  %326 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %325, i64 1, 4, 0
  %327 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %326, 1
  %328 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %326, 2
  %329 = getelementptr float, ptr %327, i64 %328
  %330 = getelementptr float, ptr %329, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %317, ptr align 4 %330, <vscale x 4 x i1> %301)
  %331 = add i64 %280, 1
  br label %279

332:                                              ; preds = %279
  %333 = call ptr @malloc(i64 4096)
  %334 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %333, 0
  %335 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %334, ptr %333, 1
  %336 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %335, i64 0, 2
  %337 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %336, i64 16, 3, 0
  %338 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %337, i64 64, 3, 1
  %339 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %338, i64 64, 4, 0
  %340 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %339, i64 1, 4, 1
  br i1 %186, label %341, label %354

341:                                              ; preds = %352, %332
  %342 = phi i64 [ %353, %352 ], [ 0, %332 ]
  %343 = icmp slt i64 %342, 16
  br i1 %343, label %344, label %354

344:                                              ; preds = %347, %341
  %345 = phi i64 [ %351, %347 ], [ 0, %341 ]
  %346 = icmp slt i64 %345, 64
  br i1 %346, label %347, label %352

347:                                              ; preds = %344
  %348 = mul nuw nsw i64 %342, 64
  %349 = add nuw nsw i64 %348, %345
  %350 = getelementptr inbounds nuw float, ptr %333, i64 %349
  store float 0.000000e+00, ptr %350, align 4
  %351 = add i64 %345, 1
  br label %344

352:                                              ; preds = %344
  %353 = add i64 %342, 1
  br label %341

354:                                              ; preds = %341, %332
  %355 = icmp sle i64 %121, 0
  %356 = sub i64 0, %121
  %357 = sub i64 %121, 1
  %358 = select i1 %355, i64 %356, i64 %357
  %359 = sdiv i64 %358, %91
  %360 = sub i64 0, %359
  %361 = add i64 %359, 1
  %362 = select i1 %355, i64 %360, i64 %361
  %363 = icmp sle i64 %121, 0
  %364 = sub i64 0, %121
  %365 = sub i64 %121, 1
  %366 = select i1 %363, i64 %364, i64 %365
  %367 = sdiv i64 %366, %91
  %368 = sub i64 0, %367
  %369 = add i64 %367, 1
  %370 = select i1 %363, i64 %368, i64 %369
  %371 = mul nsw i64 %177, %370
  br label %372

372:                                              ; preds = %375, %354
  %373 = phi i64 [ %422, %375 ], [ 0, %354 ]
  %374 = icmp slt i64 %373, %371
  br i1 %374, label %375, label %423

375:                                              ; preds = %372
  %376 = sdiv i64 %373, %362
  %377 = mul i64 %376, %362
  %378 = icmp ne i64 %373, %377
  %379 = icmp slt i64 %373, 0
  %380 = icmp slt i64 %362, 0
  %381 = icmp ne i1 %379, %380
  %382 = and i1 %378, %381
  %383 = add i64 %376, -1
  %384 = select i1 %382, i64 %383, i64 %376
  %385 = srem i64 %373, %362
  %386 = icmp slt i64 %385, 0
  %387 = add nsw i64 %385, %362
  %388 = select i1 %386, i64 %387, i64 %385
  %389 = mul nsw i64 %91, %388
  %390 = mul nsw i64 %91, %388
  %391 = mul nsw i64 %390, -1
  %392 = add i64 %121, %391
  %393 = call i64 @llvm.smin.i64(i64 %392, i64 %91)
  %394 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %393)
  %395 = insertvalue { ptr, ptr, i64 } poison, ptr %123, 0
  %396 = insertvalue { ptr, ptr, i64 } %395, ptr %125, 1
  %397 = insertvalue { ptr, ptr, i64 } %396, i64 0, 2
  %398 = mul nsw i64 %384, %86
  %399 = add i64 %116, %398
  %400 = add i64 %399, %389
  %401 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %123, 0
  %402 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %401, ptr %125, 1
  %403 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %402, i64 %400, 2
  %404 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %403, i64 %393, 3, 0
  %405 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %404, i64 1, 4, 0
  %406 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %405, 1
  %407 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %405, 2
  %408 = getelementptr float, ptr %406, i64 %407
  %409 = getelementptr float, ptr %408, i64 0
  %410 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %409, <vscale x 4 x i1> %394, <vscale x 4 x float> poison)
  %411 = mul nsw i64 %384, 64
  %412 = add i64 %411, %389
  %413 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %333, 0
  %414 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %413, ptr %333, 1
  %415 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %414, i64 %412, 2
  %416 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %415, i64 %393, 3, 0
  %417 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %416, i64 1, 4, 0
  %418 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %417, 1
  %419 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %417, 2
  %420 = getelementptr float, ptr %418, i64 %419
  %421 = getelementptr float, ptr %420, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %410, ptr align 4 %421, <vscale x 4 x i1> %394)
  %422 = add i64 %373, 1
  br label %372

423:                                              ; preds = %372
  %424 = icmp sle i64 %133, 0
  %425 = sub i64 0, %133
  %426 = sub i64 %133, 1
  %427 = select i1 %424, i64 %425, i64 %426
  %428 = sdiv i64 %427, %91
  %429 = sub i64 0, %428
  %430 = add i64 %428, 1
  %431 = select i1 %424, i64 %429, i64 %430
  %432 = icmp sle i64 %133, 0
  %433 = sub i64 0, %133
  %434 = sub i64 %133, 1
  %435 = select i1 %432, i64 %433, i64 %434
  %436 = sdiv i64 %435, %91
  %437 = sub i64 0, %436
  %438 = add i64 %436, 1
  %439 = select i1 %432, i64 %437, i64 %438
  %440 = mul nsw i64 %177, %439
  br label %441

441:                                              ; preds = %444, %423
  %442 = phi i64 [ %492, %444 ], [ 0, %423 ]
  %443 = icmp slt i64 %442, %440
  br i1 %443, label %444, label %493

444:                                              ; preds = %441
  %445 = sdiv i64 %442, %431
  %446 = mul i64 %445, %431
  %447 = icmp ne i64 %442, %446
  %448 = icmp slt i64 %442, 0
  %449 = icmp slt i64 %431, 0
  %450 = icmp ne i1 %448, %449
  %451 = and i1 %447, %450
  %452 = add i64 %445, -1
  %453 = select i1 %451, i64 %452, i64 %445
  %454 = srem i64 %442, %431
  %455 = icmp slt i64 %454, 0
  %456 = add nsw i64 %454, %431
  %457 = select i1 %455, i64 %456, i64 %454
  %458 = mul nsw i64 %91, %457
  %459 = mul nsw i64 %91, %457
  %460 = mul nsw i64 %459, -1
  %461 = add i64 %133, %460
  %462 = call i64 @llvm.smin.i64(i64 %461, i64 %91)
  %463 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %462)
  %464 = insertvalue { ptr, ptr, i64 } poison, ptr %135, 0
  %465 = insertvalue { ptr, ptr, i64 } %464, ptr %137, 1
  %466 = insertvalue { ptr, ptr, i64 } %465, i64 0, 2
  %467 = mul nsw i64 %453, %86
  %468 = add i64 %118, %467
  %469 = add i64 %468, %458
  %470 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %135, 0
  %471 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %470, ptr %137, 1
  %472 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %471, i64 %469, 2
  %473 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %472, i64 %462, 3, 0
  %474 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %473, i64 1, 4, 0
  %475 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %474, 1
  %476 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %474, 2
  %477 = getelementptr float, ptr %475, i64 %476
  %478 = getelementptr float, ptr %477, i64 0
  %479 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %478, <vscale x 4 x i1> %463, <vscale x 4 x float> poison)
  %480 = mul nsw i64 %453, 64
  %481 = add i64 %121, %480
  %482 = add i64 %481, %458
  %483 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %333, 0
  %484 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %483, ptr %333, 1
  %485 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %484, i64 %482, 2
  %486 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %485, i64 %462, 3, 0
  %487 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %486, i64 1, 4, 0
  %488 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %487, 1
  %489 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %487, 2
  %490 = getelementptr float, ptr %488, i64 %489
  %491 = getelementptr float, ptr %490, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %479, ptr align 4 %491, <vscale x 4 x i1> %463)
  %492 = add i64 %442, 1
  br label %441

493:                                              ; preds = %441
  br label %494

494:                                              ; preds = %497, %493
  %495 = phi i64 [ %549, %497 ], [ 0, %493 ]
  %496 = icmp slt i64 %495, 512
  br i1 %496, label %497, label %550

497:                                              ; preds = %494
  %498 = sdiv i64 %495, 32
  %499 = mul i64 %498, 32
  %500 = icmp ne i64 %495, %499
  %501 = icmp slt i64 %495, 0
  %502 = icmp ne i1 %501, false
  %503 = and i1 %500, %502
  %504 = add i64 %498, -1
  %505 = select i1 %503, i64 %504, i64 %498
  %506 = srem i64 %495, 32
  %507 = icmp slt i64 %506, 0
  %508 = add nsw i64 %506, 32
  %509 = select i1 %507, i64 %508, i64 %506
  %510 = call i64 @llvm.smin.i64(i64 %91, i64 1)
  %511 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %510)
  %512 = mul nsw i64 %509, 16
  %513 = add i64 %512, %505
  %514 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %178, 0
  %515 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %514, ptr %178, 1
  %516 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %515, i64 %513, 2
  %517 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %516, i64 %510, 3, 0
  %518 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %517, i64 1, 4, 0
  %519 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %518, 1
  %520 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %518, 2
  %521 = getelementptr float, ptr %519, i64 %520
  %522 = getelementptr float, ptr %521, i64 0
  %523 = call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %522, <vscale x 4 x i1> %511, <vscale x 4 x float> poison)
  %524 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, 0
  %525 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, 1
  %526 = insertvalue { ptr, ptr, i64 } poison, ptr %524, 0
  %527 = insertvalue { ptr, ptr, i64 } %526, ptr %525, 1
  %528 = insertvalue { ptr, ptr, i64 } %527, i64 0, 2
  %529 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, 2
  %530 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, 3, 0
  %531 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, 3, 1
  %532 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, 3, 2
  %533 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, 3, 3
  %534 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, 4, 0
  %535 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, 4, 1
  %536 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, 4, 2
  %537 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, 4, 3
  %538 = mul nsw i64 %505, 32
  %539 = add i64 %538, %509
  %540 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %524, 0
  %541 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %540, ptr %525, 1
  %542 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %541, i64 %539, 2
  %543 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %542, i64 %510, 3, 0
  %544 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %543, i64 1, 4, 0
  %545 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %544, 1
  %546 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %544, 2
  %547 = getelementptr float, ptr %545, i64 %546
  %548 = getelementptr float, ptr %547, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %523, ptr align 4 %548, <vscale x 4 x i1> %511)
  %549 = add i64 %495, 1
  br label %494

550:                                              ; preds = %494
  br label %551

551:                                              ; preds = %598, %550
  %552 = phi i64 [ %626, %598 ], [ 0, %550 ]
  %553 = icmp slt i64 %552, 1024
  br i1 %553, label %554, label %627

554:                                              ; preds = %551
  %555 = sdiv i64 %552, 512
  %556 = mul i64 %555, 512
  %557 = icmp ne i64 %552, %556
  %558 = icmp slt i64 %552, 0
  %559 = icmp ne i1 %558, false
  %560 = and i1 %557, %559
  %561 = add i64 %555, -1
  %562 = select i1 %560, i64 %561, i64 %555
  %563 = srem i64 %552, 512
  %564 = icmp slt i64 %563, 0
  %565 = add nsw i64 %563, 512
  %566 = select i1 %564, i64 %565, i64 %563
  %567 = sdiv i64 %566, 32
  %568 = srem i64 %552, 32
  %569 = icmp slt i64 %568, 0
  %570 = add nsw i64 %568, 32
  %571 = select i1 %569, i64 %570, i64 %568
  %572 = call i64 @llvm.smin.i64(i64 %91, i64 1)
  %573 = call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %572)
  %574 = mul nsw i64 %567, 64
  %575 = mul nsw i64 %562, 32
  %576 = add i64 %574, %575
  %577 = add i64 %576, %571
  %578 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %333, 0
  %579 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %578, ptr %333, 1
  %580 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %579, i64 %577, 2
  %581 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %580, i64 %572, 3, 0
  %582 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %581, i64 64, 4, 0
  br label %583

583:                                              ; preds = %595, %554
  %584 = phi i64 [ %597, %595 ], [ 0, %554 ]
  %585 = phi <vscale x 4 x float> [ %596, %595 ], [ poison, %554 ]
  %586 = icmp slt i64 %584, %91
  br i1 %586, label %587, label %598

587:                                              ; preds = %583
  %588 = extractelement <vscale x 4 x i1> %573, i64 %584
  br i1 %588, label %589, label %595

589:                                              ; preds = %587
  %590 = getelementptr float, ptr %333, i64 %577
  %591 = mul nuw nsw i64 %584, 64
  %592 = getelementptr inbounds nuw float, ptr %590, i64 %591
  %593 = load float, ptr %592, align 4
  %594 = insertelement <vscale x 4 x float> %585, float %593, i64 %584
  br label %595

595:                                              ; preds = %589, %587
  %596 = phi <vscale x 4 x float> [ %594, %589 ], [ %585, %587 ]
  %597 = add i64 %584, 1
  br label %583

598:                                              ; preds = %583
  %599 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, 0
  %600 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, 1
  %601 = insertvalue { ptr, ptr, i64 } poison, ptr %599, 0
  %602 = insertvalue { ptr, ptr, i64 } %601, ptr %600, 1
  %603 = insertvalue { ptr, ptr, i64 } %602, i64 0, 2
  %604 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, 2
  %605 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, 3, 0
  %606 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, 3, 1
  %607 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, 3, 2
  %608 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, 3, 3
  %609 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, 4, 0
  %610 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, 4, 1
  %611 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, 4, 2
  %612 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, 4, 3
  %613 = mul nsw i64 %562, 512
  %614 = mul nsw i64 %567, 32
  %615 = add i64 %613, %614
  %616 = add i64 %615, %571
  %617 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %599, 0
  %618 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %617, ptr %600, 1
  %619 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %618, i64 %616, 2
  %620 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %619, i64 %572, 3, 0
  %621 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %620, i64 1, 4, 0
  %622 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %621, 1
  %623 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %621, 2
  %624 = getelementptr float, ptr %622, i64 %623
  %625 = getelementptr float, ptr %624, i64 0
  call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %585, ptr align 4 %625, <vscale x 4 x i1> %573)
  %626 = add i64 %552, 1
  br label %551

627:                                              ; preds = %819, %551
  %628 = phi i64 [ %820, %819 ], [ 0, %551 ]
  %629 = icmp slt i64 %628, %100
  br i1 %629, label %630, label %821

630:                                              ; preds = %627
  %631 = mul nuw nsw i64 %94, %94
  %632 = sdiv i64 %628, %631
  %633 = mul i64 %632, %631
  %634 = icmp ne i64 %628, %633
  %635 = icmp slt i64 %628, 0
  %636 = icmp slt i64 %631, 0
  %637 = icmp ne i1 %635, %636
  %638 = and i1 %634, %637
  %639 = add i64 %632, -1
  %640 = select i1 %638, i64 %639, i64 %632
  %641 = srem i64 %628, %631
  %642 = icmp slt i64 %641, 0
  %643 = add nsw i64 %641, %631
  %644 = select i1 %642, i64 %643, i64 %641
  %645 = sdiv i64 %644, %94
  %646 = srem i64 %628, %94
  %647 = icmp slt i64 %646, 0
  %648 = add nsw i64 %646, %94
  %649 = select i1 %647, i64 %648, i64 %646
  %650 = mul nsw i64 %92, %649
  %651 = mul nsw i64 %92, %645
  %652 = mul nsw i64 %92, %645
  %653 = mul nsw i64 %652, -1
  %654 = add i64 %653, 32
  %655 = call i64 @llvm.smin.i64(i64 %654, i64 %92)
  %656 = mul nsw i64 %92, %649
  %657 = mul nsw i64 %656, -1
  %658 = add i64 %657, 32
  %659 = call i64 @llvm.smin.i64(i64 %658, i64 %92)
  %660 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %56, 0
  %661 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %56, 1
  %662 = insertvalue { ptr, ptr, i64 } poison, ptr %660, 0
  %663 = insertvalue { ptr, ptr, i64 } %662, ptr %661, 1
  %664 = insertvalue { ptr, ptr, i64 } %663, i64 0, 2
  %665 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %56, 2
  %666 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %56, 3, 0
  %667 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %56, 3, 1
  %668 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %56, 3, 2
  %669 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %56, 3, 3
  %670 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %56, 4, 0
  %671 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %56, 4, 1
  %672 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %56, 4, 2
  %673 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %56, 4, 3
  %674 = mul nsw i64 %640, 1024
  %675 = mul nsw i64 %651, 32
  %676 = add i64 %674, %675
  %677 = add i64 %676, %650
  %678 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } poison, ptr %660, 0
  %679 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %678, ptr %661, 1
  %680 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %679, i64 %677, 2
  %681 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %680, i64 %655, 3, 0
  %682 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %681, i64 32, 4, 0
  %683 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %682, i64 %659, 3, 1
  %684 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %683, i64 1, 4, 1
  br label %685

685:                                              ; preds = %688, %630
  %686 = phi i64 [ %696, %688 ], [ 0, %630 ]
  %687 = icmp slt i64 %686, %91
  br i1 %687, label %688, label %697

688:                                              ; preds = %685
  %689 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %684, 1
  %690 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %684, 2
  %691 = getelementptr float, ptr %689, i64 %690
  %692 = mul i64 %686, 32
  %693 = add i64 %692, 0
  %694 = getelementptr float, ptr %691, i64 %693
  %695 = trunc i64 %686 to i32
  call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %694, i32 0, i32 %695)
  %696 = add i64 %686, 1
  br label %685

697:                                              ; preds = %685
  br label %698

698:                                              ; preds = %701, %697
  %699 = phi i64 [ %709, %701 ], [ 0, %697 ]
  %700 = icmp slt i64 %699, %91
  br i1 %700, label %701, label %710

701:                                              ; preds = %698
  %702 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %684, 1
  %703 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %684, 2
  %704 = getelementptr float, ptr %702, i64 %703
  %705 = mul i64 %699, 32
  %706 = add i64 %705, %91
  %707 = getelementptr float, ptr %704, i64 %706
  %708 = trunc i64 %699 to i32
  call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %707, i32 1, i32 %708)
  %709 = add i64 %699, 1
  br label %698

710:                                              ; preds = %713, %698
  %711 = phi i64 [ %722, %713 ], [ 0, %698 ]
  %712 = icmp slt i64 %711, %91
  br i1 %712, label %713, label %723

713:                                              ; preds = %710
  %714 = add i64 %91, %711
  %715 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %684, 1
  %716 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %684, 2
  %717 = getelementptr float, ptr %715, i64 %716
  %718 = mul i64 %714, 32
  %719 = add i64 %718, 0
  %720 = getelementptr float, ptr %717, i64 %719
  %721 = trunc i64 %711 to i32
  call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %720, i32 2, i32 %721)
  %722 = add i64 %711, 1
  br label %710

723:                                              ; preds = %726, %710
  %724 = phi i64 [ %735, %726 ], [ 0, %710 ]
  %725 = icmp slt i64 %724, %91
  br i1 %725, label %726, label %736

726:                                              ; preds = %723
  %727 = add i64 %91, %724
  %728 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %684, 1
  %729 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %684, 2
  %730 = getelementptr float, ptr %728, i64 %729
  %731 = mul i64 %727, 32
  %732 = add i64 %731, %91
  %733 = getelementptr float, ptr %730, i64 %732
  %734 = trunc i64 %724 to i32
  call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %733, i32 3, i32 %734)
  %735 = add i64 %724, 1
  br label %723

736:                                              ; preds = %739, %723
  %737 = phi i64 [ %798, %739 ], [ 0, %723 ]
  %738 = icmp slt i64 %737, 16
  br i1 %738, label %739, label %799

739:                                              ; preds = %736
  %740 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, 0
  %741 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, 1
  %742 = insertvalue { ptr, ptr, i64 } poison, ptr %740, 0
  %743 = insertvalue { ptr, ptr, i64 } %742, ptr %741, 1
  %744 = insertvalue { ptr, ptr, i64 } %743, i64 0, 2
  %745 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, 2
  %746 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, 3, 0
  %747 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, 3, 1
  %748 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, 3, 2
  %749 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, 3, 3
  %750 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, 4, 0
  %751 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, 4, 1
  %752 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, 4, 2
  %753 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %78, 4, 3
  %754 = mul nsw i64 %737, 32
  %755 = add i64 %651, %754
  %756 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %740, 0
  %757 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %756, ptr %741, 1
  %758 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %757, i64 %755, 2
  %759 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %758, i64 %655, 3, 0
  %760 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %759, i64 1, 4, 0
  %761 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %760, 1
  %762 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %760, 2
  %763 = getelementptr float, ptr %761, i64 %762
  %764 = getelementptr float, ptr %763, i64 0
  %765 = load <vscale x 8 x float>, ptr %764, align 4
  %766 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, 0
  %767 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, 1
  %768 = insertvalue { ptr, ptr, i64 } poison, ptr %766, 0
  %769 = insertvalue { ptr, ptr, i64 } %768, ptr %767, 1
  %770 = insertvalue { ptr, ptr, i64 } %769, i64 0, 2
  %771 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, 2
  %772 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, 3, 0
  %773 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, 3, 1
  %774 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, 3, 2
  %775 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, 3, 3
  %776 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, 4, 0
  %777 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, 4, 1
  %778 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, 4, 2
  %779 = extractvalue { ptr, ptr, i64, [4 x i64], [4 x i64] } %67, 4, 3
  %780 = mul nsw i64 %640, 512
  %781 = add i64 %780, %650
  %782 = mul nsw i64 %737, 32
  %783 = add i64 %781, %782
  %784 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %766, 0
  %785 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %784, ptr %767, 1
  %786 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %785, i64 %783, 2
  %787 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %786, i64 %659, 3, 0
  %788 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %787, i64 1, 4, 0
  %789 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %788, 1
  %790 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %788, 2
  %791 = getelementptr float, ptr %789, i64 %790
  %792 = getelementptr float, ptr %791, i64 0
  %793 = load <vscale x 8 x float>, ptr %792, align 4
  %794 = call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %765, i64 0)
  %795 = call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %793, i64 0)
  call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %794, <vscale x 4 x float> %795)
  %796 = call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %793, i64 4)
  call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %794, <vscale x 4 x float> %796)
  %797 = call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %765, i64 4)
  call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %797, <vscale x 4 x float> %795)
  call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %797, <vscale x 4 x float> %796)
  %798 = add i64 %737, 1
  br label %736

799:                                              ; preds = %802, %736
  %800 = phi i64 [ %818, %802 ], [ 0, %736 ]
  %801 = icmp slt i64 %800, %91
  br i1 %801, label %802, label %819

802:                                              ; preds = %799
  %803 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %684, 1
  %804 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %684, 2
  %805 = getelementptr float, ptr %803, i64 %804
  %806 = mul i64 %800, 32
  %807 = add i64 %806, 0
  %808 = getelementptr float, ptr %805, i64 %807
  %809 = trunc i64 %800 to i32
  call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %808, i32 0, i32 %809)
  %810 = add i64 %806, %91
  %811 = getelementptr float, ptr %805, i64 %810
  call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %811, i32 1, i32 %809)
  %812 = add i64 %91, %800
  %813 = mul i64 %812, 32
  %814 = add i64 %813, 0
  %815 = getelementptr float, ptr %805, i64 %814
  call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %815, i32 2, i32 %809)
  %816 = add i64 %813, %91
  %817 = getelementptr float, ptr %805, i64 %816
  call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %817, i32 3, i32 %809)
  %818 = add i64 %800, 1
  br label %799

819:                                              ; preds = %799
  %820 = add i64 %628, 1
  br label %627

821:                                              ; preds = %627
  %822 = add i64 %112, 16
  %823 = add i64 %113, %102
  call void @free(ptr %178)
  call void @free(ptr %333)
  %824 = add i32 %111, 1
  br label %110

825:                                              ; preds = %110
  %826 = insertvalue { i64, i64 } poison, i64 %112, 0
  %827 = insertvalue { i64, i64 } %826, i64 %113, 1
  ret { i64, i64 } %827
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.vscale.i64() #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smin.i32(i32, i32) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smin.i64(i64, i64) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smax.i64(i64, i64) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare ptr @llvm.stacksave.p0() #3

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare void @llvm.stackrestore.p0(ptr) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64, i64) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr captures(none), <vscale x 4 x i1>, <vscale x 4 x float>) #4

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float>, ptr captures(none), <vscale x 4 x i1>) #5

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite)
declare void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1>, ptr, i32 immarg, i32) #6

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float>, i64 immarg) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(target_mem1: readwrite)
declare void @llvm.aarch64.sme.mopa.nxv4f32(i32 immarg, <vscale x 4 x i1>, <vscale x 4 x i1>, <vscale x 4 x float>, <vscale x 4 x float>) #7

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite)
declare void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1>, ptr, i32 immarg, i32) #6

attributes #0 = { "aarch64_new_za" "aarch64_pstate_sm_enabled" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nosync nounwind willreturn }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite) }
attributes #7 = { nocallback nofree nosync nounwind willreturn memory(target_mem1: readwrite) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
