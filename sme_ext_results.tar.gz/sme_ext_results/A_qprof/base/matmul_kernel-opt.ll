; ModuleID = '/local/mnt/workspace/adittriv/triton-mlir/sme_ext_results/A_qprof/base/matmul_kernel-llvm-ir.ll'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64"

declare void @memrefCopy(i64, ptr, ptr) local_unnamed_addr #0

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @free(ptr allocptr noundef captures(none)) local_unnamed_addr #1

; Function Attrs: mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite, errnomem: write)
declare noalias noundef ptr @malloc(i64 noundef) local_unnamed_addr #2

define void @matmul_kernel(i64 %0, ptr nofree readonly captures(none) %1, i64 %2, ptr nofree readonly captures(none) %3, i64 %4, ptr nofree readonly captures(none) %5, i32 %6, i32 %7, i32 %8, i32 %9, i32 %10, i32 %11, i32 %12, i32 %13, i32 %14, i32 %15, i32 %16, i32 %17) local_unnamed_addr #3 {
  %19 = tail call dereferenceable_or_null(8256) ptr @malloc(i64 8256)
  %20 = ptrtoint ptr %19 to i64
  %21 = add i64 %20, 63
  %22 = and i64 %21, -64
  %23 = inttoptr i64 %22 to ptr
  %24 = tail call i64 @llvm.vscale.i64()
  %25 = shl i64 %24, 2
  %26 = sdiv i64 63, %25
  %27 = add nsw i64 %26, 1
  %28 = shl nsw i64 %27, 5
  %29 = icmp sgt i64 %26, -1
  br i1 %29, label %.lr.ph, label %._crit_edge

.lr.ph:                                           ; preds = %18, %.lr.ph
  %30 = phi i64 [ %39, %.lr.ph ], [ 0, %18 ]
  %.frozen = freeze i64 %30
  %.frozen167 = freeze i64 %27
  %31 = udiv i64 %.frozen, %.frozen167
  %32 = mul i64 %31, %.frozen167
  %.decomposed = sub i64 %.frozen, %32
  %33 = mul nsw i64 %.decomposed, %25
  %34 = sub i64 64, %33
  %35 = tail call i64 @llvm.smin.i64(i64 %34, i64 %25)
  %36 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %35)
  %.idx72 = shl i64 %31, 8
  %37 = getelementptr i8, ptr %23, i64 %.idx72
  %38 = getelementptr [4 x i8], ptr %37, i64 %33
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> zeroinitializer, ptr align 16 %38, <vscale x 4 x i1> %36)
  %39 = add nuw nsw i64 %30, 1
  %exitcond.not = icmp eq i64 %39, %28
  br i1 %exitcond.not, label %._crit_edge, label %.lr.ph

._crit_edge:                                      ; preds = %.lr.ph, %18
  %40 = add i32 %6, 31
  %41 = sdiv i32 %40, 32
  %42 = add i32 %7, 63
  %43 = sdiv i32 %42, 64
  %44 = shl nsw i32 %43, 3
  %.frozen168 = freeze i32 %15
  %.frozen169 = freeze i32 %44
  %45 = sdiv i32 %.frozen168, %.frozen169
  %46 = shl i32 %45, 3
  %47 = sub i32 %41, %46
  %48 = tail call i32 @llvm.smin.i32(i32 %47, i32 8)
  %49 = srem i32 %15, %48
  %50 = add i32 %46, %49
  %51 = mul i32 %45, %.frozen169
  %.decomposed170 = sub i32 %.frozen168, %51
  %52 = sdiv i32 %.decomposed170, %48
  %53 = shl i32 %50, 5
  %54 = sext i32 %53 to i64
  %55 = shl i32 %52, 6
  %56 = sext i32 %55 to i64
  %57 = sext i32 %6 to i64
  %58 = sext i32 %9 to i64
  %59 = mul nsw i64 %58, %57
  %60 = sext i32 %10 to i64
  %61 = sext i32 %7 to i64
  %62 = add i32 %8, 15
  %63 = sdiv i32 %62, 16
  %64 = shl i32 %10, 4
  %65 = sext i32 %64 to i64
  %66 = tail call dereferenceable_or_null(2112) ptr @malloc(i64 2112)
  %67 = ptrtoint ptr %66 to i64
  %68 = add i64 %67, 63
  %69 = and i64 %68, -64
  %70 = inttoptr i64 %69 to ptr
  %71 = tail call dereferenceable_or_null(4160) ptr @malloc(i64 4160)
  %72 = ptrtoint ptr %71 to i64
  %73 = add i64 %72, 63
  %74 = and i64 %73, -64
  %75 = inttoptr i64 %74 to ptr
  %76 = tail call dereferenceable_or_null(8256) ptr @malloc(i64 8256)
  %77 = ptrtoint ptr %76 to i64
  %78 = add i64 %77, 63
  %79 = and i64 %78, -64
  %80 = inttoptr i64 %79 to ptr
  %81 = sdiv i64 31, %25
  %82 = add nsw i64 %81, 1
  %83 = shl i64 %24, 3
  %84 = sdiv i64 31, %83
  %85 = add nsw i64 %84, 1
  %86 = mul nsw i64 %85, %85
  %87 = tail call dereferenceable_or_null(8256) ptr @malloc(i64 8256)
  %88 = ptrtoint ptr %87 to i64
  %89 = add i64 %88, 63
  %90 = and i64 %89, -64
  %91 = inttoptr i64 %90 to ptr
  %92 = icmp sgt i32 %62, 15
  br i1 %92, label %.lr.ph129, label %._crit_edge130

.lr.ph129:                                        ; preds = %._crit_edge
  %93 = shl nuw nsw i64 %86, 1
  %94 = shl nsw i64 %82, 6
  %95 = mul nsw i64 %54, %58
  %96 = getelementptr i8, ptr %3, i64 8
  %97 = getelementptr i8, ptr %1, i64 8
  %98 = tail call i64 @llvm.smin.i64(i64 %25, i64 1)
  %99 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %98)
  %100 = icmp sgt i64 %25, 0
  %101 = icmp sgt i64 %81, -1
  %102 = shl nuw nsw i64 %82, 5
  %invariant.gep120 = getelementptr [4 x i8], ptr %80, i64 %25
  %.not = icmp eq i64 %85, 0
  %103 = shl nuw nsw i64 %82, 1
  %104 = icmp slt i64 %26, -1
  %smax142 = tail call i64 @llvm.smax.i64(i64 %94, i64 1)
  %umax = tail call i64 @llvm.umax.i64(i64 %93, i64 1)
  %smax153 = tail call i64 @llvm.smax.i64(i64 %28, i64 1)
  br label %105

105:                                              ; preds = %.lr.ph129, %._crit_edge127
  %indvars.iv = phi i32 [ %8, %.lr.ph129 ], [ %indvars.iv.next, %._crit_edge127 ]
  %106 = phi i64 [ 0, %.lr.ph129 ], [ %512, %._crit_edge127 ]
  %107 = phi i64 [ %95, %.lr.ph129 ], [ %511, %._crit_edge127 ]
  %108 = phi i32 [ 0, %.lr.ph129 ], [ %513, %._crit_edge127 ]
  %smax136 = tail call i32 @llvm.smax.i32(i32 %indvars.iv, i32 0)
  %109 = tail call i32 @llvm.umin.i32(i32 %smax136, i32 16)
  %umin137 = zext nneg i32 %109 to i64
  %110 = add nsw i64 %106, %56
  %111 = srem i64 %110, %61
  %112 = sub i64 %110, %111
  %113 = add nsw i64 %111, 64
  %114 = tail call i64 @llvm.smin.i64(i64 %113, i64 %61)
  %115 = sub nsw i64 %114, %111
  %116 = sub nsw i64 0, %115
  %117 = load ptr, ptr %96, align 8
  %.neg = add nsw i64 %115, -64
  %118 = srem i64 %107, %58
  %119 = sub i64 %59, %107
  %120 = add i64 %119, %118
  %121 = sdiv i64 %120, %58
  %122 = tail call i64 @llvm.smin.i64(i64 %121, i64 32)
  %123 = load ptr, ptr %97, align 8
  %124 = sub i64 32, %122
  %125 = shl nuw nsw i32 %108, 4
  %126 = sub nsw i32 %8, %125
  %127 = tail call i32 @llvm.smax.i32(i32 %126, i32 0)
  %128 = tail call i32 @llvm.umin.i32(i32 %127, i32 16)
  %129 = zext nneg i32 %128 to i64
  %130 = tail call dereferenceable_or_null(2048) ptr @malloc(i64 2048)
  %131 = icmp slt i32 %126, 16
  br i1 %131, label %.preheader83.preheader, label %.loopexit92

.preheader83.preheader:                           ; preds = %105
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(2048) %130, i8 0, i64 2048, i1 false)
  br label %.loopexit92

.loopexit92:                                      ; preds = %.preheader83.preheader, %105
  %132 = icmp slt i32 %126, 1
  %133 = sub nsw i64 0, %129
  %134 = add nsw i64 %129, -1
  %135 = select i1 %132, i64 %133, i64 %134
  %136 = sdiv i64 %135, %25
  %137 = sub nsw i64 0, %136
  %138 = add nsw i64 %136, 1
  %139 = select i1 %132, i64 %137, i64 %138
  %140 = mul nsw i64 %139, %122
  %141 = icmp sgt i64 %140, 0
  br i1 %141, label %.lr.ph94, label %._crit_edge95

.lr.ph94:                                         ; preds = %.loopexit92
  %142 = icmp slt i64 %139, 0
  %143 = getelementptr [4 x i8], ptr %123, i64 %107
  br label %144

144:                                              ; preds = %.lr.ph94, %144
  %145 = phi i64 [ 0, %.lr.ph94 ], [ %163, %144 ]
  %.frozen171 = freeze i64 %145
  %.frozen172 = freeze i64 %139
  %146 = sdiv i64 %.frozen171, %.frozen172
  %147 = mul i64 %146, %139
  %148 = icmp ne i64 %145, %147
  %149 = and i1 %142, %148
  %150 = sext i1 %149 to i64
  %151 = add i64 %146, %150
  %152 = mul i64 %146, %.frozen172
  %.decomposed173 = sub i64 %.frozen171, %152
  %153 = mul nsw i64 %.decomposed173, %25
  %154 = sub i64 %129, %153
  %155 = tail call i64 @llvm.smin.i64(i64 %154, i64 %25)
  %156 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %155)
  %157 = mul nsw i64 %151, %58
  %158 = getelementptr [4 x i8], ptr %143, i64 %157
  %159 = getelementptr [4 x i8], ptr %158, i64 %153
  %160 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %159, <vscale x 4 x i1> %156, <vscale x 4 x float> poison)
  %.idx70 = shl i64 %151, 6
  %161 = getelementptr i8, ptr %130, i64 %.idx70
  %162 = getelementptr [4 x i8], ptr %161, i64 %153
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %160, ptr align 4 %162, <vscale x 4 x i1> %156)
  %163 = add nuw nsw i64 %145, 1
  %exitcond132.not = icmp eq i64 %163, %140
  br i1 %exitcond132.not, label %._crit_edge95, label %144

._crit_edge95:                                    ; preds = %144, %.loopexit92
  %164 = mul nsw i64 %139, %124
  %165 = icmp sgt i64 %164, 0
  br i1 %165, label %.lr.ph97, label %._crit_edge98

.lr.ph97:                                         ; preds = %._crit_edge95
  %166 = icmp slt i64 %139, 0
  %167 = getelementptr [4 x i8], ptr %123, i64 %118
  br label %168

168:                                              ; preds = %.lr.ph97, %168
  %169 = phi i64 [ 0, %.lr.ph97 ], [ %188, %168 ]
  %.frozen174 = freeze i64 %169
  %.frozen175 = freeze i64 %139
  %170 = sdiv i64 %.frozen174, %.frozen175
  %171 = mul i64 %170, %139
  %172 = icmp ne i64 %169, %171
  %173 = and i1 %166, %172
  %174 = sext i1 %173 to i64
  %175 = add i64 %170, %174
  %176 = mul i64 %170, %.frozen175
  %.decomposed176 = sub i64 %.frozen174, %176
  %177 = mul nsw i64 %.decomposed176, %25
  %178 = sub i64 %129, %177
  %179 = tail call i64 @llvm.smin.i64(i64 %178, i64 %25)
  %180 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %179)
  %181 = mul nsw i64 %175, %58
  %182 = getelementptr [4 x i8], ptr %167, i64 %181
  %183 = getelementptr [4 x i8], ptr %182, i64 %177
  %184 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %183, <vscale x 4 x i1> %180, <vscale x 4 x float> poison)
  %185 = add i64 %175, %122
  %.idx69 = shl i64 %185, 6
  %186 = getelementptr i8, ptr %130, i64 %.idx69
  %187 = getelementptr [4 x i8], ptr %186, i64 %177
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %184, ptr align 4 %187, <vscale x 4 x i1> %180)
  %188 = add nuw nsw i64 %169, 1
  %exitcond133.not = icmp eq i64 %188, %164
  br i1 %exitcond133.not, label %._crit_edge98, label %168

._crit_edge98:                                    ; preds = %168, %._crit_edge95
  %189 = tail call dereferenceable_or_null(4096) ptr @malloc(i64 4096)
  br i1 %131, label %.preheader82.preheader, label %.loopexit

.preheader82.preheader:                           ; preds = %._crit_edge98
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(4096) %189, i8 0, i64 4096, i1 false)
  br label %.loopexit

.loopexit:                                        ; preds = %.preheader82.preheader, %._crit_edge98
  %190 = icmp slt i64 %115, 1
  %191 = add nsw i64 %115, -1
  %192 = select i1 %190, i64 %116, i64 %191
  %193 = sdiv i64 %192, %25
  %194 = sub nsw i64 0, %193
  %195 = add nsw i64 %193, 1
  %196 = select i1 %190, i64 %194, i64 %195
  %197 = mul nsw i64 %196, %129
  %198 = icmp sgt i64 %197, 0
  br i1 %198, label %.lr.ph100, label %._crit_edge101

.lr.ph100:                                        ; preds = %.loopexit
  %199 = icmp slt i64 %196, 0
  %200 = getelementptr [4 x i8], ptr %117, i64 %110
  %201 = mul nsw i64 %196, %umin137
  br label %202

202:                                              ; preds = %.lr.ph100, %202
  %203 = phi i64 [ 0, %.lr.ph100 ], [ %221, %202 ]
  %.frozen177 = freeze i64 %203
  %.frozen178 = freeze i64 %196
  %204 = sdiv i64 %.frozen177, %.frozen178
  %205 = mul i64 %204, %196
  %206 = icmp ne i64 %203, %205
  %207 = and i1 %199, %206
  %208 = sext i1 %207 to i64
  %209 = add i64 %204, %208
  %210 = mul i64 %204, %.frozen178
  %.decomposed179 = sub i64 %.frozen177, %210
  %211 = mul nsw i64 %.decomposed179, %25
  %212 = sub i64 %115, %211
  %213 = tail call i64 @llvm.smin.i64(i64 %212, i64 %25)
  %214 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %213)
  %215 = mul nsw i64 %209, %60
  %216 = getelementptr [4 x i8], ptr %200, i64 %215
  %217 = getelementptr [4 x i8], ptr %216, i64 %211
  %218 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %217, <vscale x 4 x i1> %214, <vscale x 4 x float> poison)
  %.idx67 = shl i64 %209, 8
  %219 = getelementptr i8, ptr %189, i64 %.idx67
  %220 = getelementptr [4 x i8], ptr %219, i64 %211
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %218, ptr align 4 %220, <vscale x 4 x i1> %214)
  %221 = add nuw nsw i64 %203, 1
  %exitcond135.not = icmp eq i64 %221, %201
  br i1 %exitcond135.not, label %._crit_edge101, label %202

._crit_edge101:                                   ; preds = %202, %.loopexit
  %222 = icmp sgt i64 %115, 63
  %223 = sub nsw i64 63, %115
  %224 = select i1 %222, i64 %.neg, i64 %223
  %225 = sdiv i64 %224, %25
  %226 = sub nsw i64 0, %225
  %227 = add nsw i64 %225, 1
  %228 = select i1 %222, i64 %226, i64 %227
  %229 = mul nsw i64 %228, %129
  %230 = icmp sgt i64 %229, 0
  br i1 %230, label %.lr.ph103, label %.preheader89.preheader

.lr.ph103:                                        ; preds = %._crit_edge101
  %231 = icmp slt i64 %228, 0
  %232 = getelementptr [4 x i8], ptr %117, i64 %112
  %233 = getelementptr [4 x i8], ptr %189, i64 %115
  %234 = mul nsw i64 %228, %umin137
  br label %235

235:                                              ; preds = %.lr.ph103, %235
  %236 = phi i64 [ 0, %.lr.ph103 ], [ %255, %235 ]
  %.frozen180 = freeze i64 %236
  %.frozen181 = freeze i64 %228
  %237 = sdiv i64 %.frozen180, %.frozen181
  %238 = mul i64 %237, %228
  %239 = icmp ne i64 %236, %238
  %240 = and i1 %231, %239
  %241 = sext i1 %240 to i64
  %242 = add i64 %237, %241
  %243 = mul i64 %237, %.frozen181
  %.decomposed182 = sub i64 %.frozen180, %243
  %244 = mul nsw i64 %.decomposed182, %25
  %245 = add i64 %115, %244
  %246 = sub i64 64, %245
  %247 = tail call i64 @llvm.smin.i64(i64 %246, i64 %25)
  %248 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %247)
  %249 = mul nsw i64 %242, %60
  %250 = getelementptr [4 x i8], ptr %232, i64 %249
  %251 = getelementptr [4 x i8], ptr %250, i64 %244
  %252 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %251, <vscale x 4 x i1> %248, <vscale x 4 x float> poison)
  %.idx66 = shl i64 %242, 8
  %253 = getelementptr i8, ptr %233, i64 %.idx66
  %254 = getelementptr [4 x i8], ptr %253, i64 %244
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %252, ptr align 4 %254, <vscale x 4 x i1> %248)
  %255 = add nuw nsw i64 %236, 1
  %exitcond138.not = icmp eq i64 %255, %234
  br i1 %exitcond138.not, label %.preheader89.preheader, label %235

.preheader89.preheader:                           ; preds = %235, %._crit_edge101
  br label %.preheader89

.preheader89:                                     ; preds = %.preheader89.preheader, %.preheader89
  %256 = phi i64 [ %263, %.preheader89 ], [ 0, %.preheader89.preheader ]
  %257 = lshr i64 %256, 5
  %258 = shl nuw nsw i64 %256, 6
  %.idx65 = and i64 %258, 1984
  %259 = getelementptr i8, ptr %130, i64 %.idx65
  %260 = getelementptr [4 x i8], ptr %259, i64 %257
  %261 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 4 %260, <vscale x 4 x i1> %99, <vscale x 4 x float> poison)
  %262 = getelementptr [4 x i8], ptr %70, i64 %256
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %261, ptr align 4 %262, <vscale x 4 x i1> %99)
  %263 = add nuw nsw i64 %256, 1
  %exitcond139.not = icmp eq i64 %263, 512
  br i1 %exitcond139.not, label %.preheader88, label %.preheader89

.preheader87:                                     ; preds = %._crit_edge108
  br i1 %101, label %.lr.ph109, label %.preheader86

.preheader88:                                     ; preds = %.preheader89, %._crit_edge108
  %264 = phi i64 [ %285, %._crit_edge108 ], [ 0, %.preheader89 ]
  %265 = lshr i64 %264, 5
  %266 = and i64 %265, 15
  %267 = and i64 %264, 31
  br i1 %100, label %.lr.ph107, label %._crit_edge108

.lr.ph107:                                        ; preds = %.preheader88
  %268 = lshr i64 %264, 4
  %269 = and i64 %268, 32
  %invariant.gep = getelementptr [4 x i8], ptr %189, i64 %269
  %invariant.gep104 = getelementptr [4 x i8], ptr %invariant.gep, i64 %267
  %.idx63 = shl nuw nsw i64 %266, 8
  %gep105 = getelementptr i8, ptr %invariant.gep104, i64 %.idx63
  br label %270

270:                                              ; preds = %.lr.ph107, %278
  %271 = phi <vscale x 4 x float> [ poison, %.lr.ph107 ], [ %279, %278 ]
  %272 = phi i64 [ 0, %.lr.ph107 ], [ %280, %278 ]
  %273 = extractelement <vscale x 4 x i1> %99, i64 %272
  br i1 %273, label %274, label %278

274:                                              ; preds = %270
  %.idx64 = shl nuw nsw i64 %272, 8
  %275 = getelementptr inbounds nuw i8, ptr %gep105, i64 %.idx64
  %276 = load float, ptr %275, align 4
  %277 = insertelement <vscale x 4 x float> %271, float %276, i64 %272
  br label %278

278:                                              ; preds = %274, %270
  %279 = phi <vscale x 4 x float> [ %277, %274 ], [ %271, %270 ]
  %280 = add nuw nsw i64 %272, 1
  %exitcond140.not = icmp eq i64 %280, %25
  br i1 %exitcond140.not, label %._crit_edge108, label %270

._crit_edge108:                                   ; preds = %278, %.preheader88
  %.lcssa = phi <vscale x 4 x float> [ poison, %.preheader88 ], [ %279, %278 ]
  %281 = and i64 %264, 512
  %282 = getelementptr [4 x i8], ptr %75, i64 %281
  %.idx62 = shl nuw nsw i64 %266, 7
  %283 = getelementptr i8, ptr %282, i64 %.idx62
  %284 = getelementptr [4 x i8], ptr %283, i64 %267
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %.lcssa, ptr align 4 %284, <vscale x 4 x i1> %99)
  %285 = add nuw nsw i64 %264, 1
  %exitcond141.not = icmp eq i64 %285, 1024
  br i1 %exitcond141.not, label %.preheader87, label %.preheader88

.preheader86:                                     ; preds = %.lr.ph109, %.preheader87
  br i1 %.not, label %.preheader85, label %.lr.ph124

.lr.ph109:                                        ; preds = %.preheader87, %.lr.ph109
  %286 = phi i64 [ %302, %.lr.ph109 ], [ 0, %.preheader87 ]
  %.frozen183 = freeze i64 %286
  %.frozen184 = freeze i64 %102
  %287 = udiv i64 %.frozen183, %.frozen184
  %288 = mul i64 %287, %.frozen184
  %.decomposed185 = sub i64 %.frozen183, %288
  %289 = udiv i64 %.decomposed185, %82
  %290 = urem i64 %286, %82
  %291 = mul nsw i64 %290, %25
  %292 = sub i64 32, %291
  %293 = tail call i64 @llvm.smin.i64(i64 %292, i64 %25)
  %294 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %293)
  %.idx58 = shl i64 %289, 8
  %295 = getelementptr i8, ptr %23, i64 %.idx58
  %.idx59 = shl i64 %287, 7
  %296 = getelementptr i8, ptr %295, i64 %.idx59
  %297 = getelementptr [4 x i8], ptr %296, i64 %291
  %298 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 16 %297, <vscale x 4 x i1> %294, <vscale x 4 x float> poison)
  %.idx60 = shl i64 %287, 12
  %299 = getelementptr i8, ptr %80, i64 %.idx60
  %.idx61 = shl i64 %289, 7
  %300 = getelementptr i8, ptr %299, i64 %.idx61
  %301 = getelementptr [4 x i8], ptr %300, i64 %291
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %298, ptr align 16 %301, <vscale x 4 x i1> %294)
  %302 = add nuw nsw i64 %286, 1
  %exitcond143.not = icmp eq i64 %302, %smax142
  br i1 %exitcond143.not, label %.preheader86, label %.lr.ph109

.preheader85:                                     ; preds = %._crit_edge119, %.preheader86
  br i1 %101, label %.lr.ph125, label %.preheader84

.lr.ph124:                                        ; preds = %.preheader86, %._crit_edge119
  %303 = phi i64 [ %475, %._crit_edge119 ], [ 0, %.preheader86 ]
  %.frozen186 = freeze i64 %303
  %.frozen187 = freeze i64 %86
  %304 = udiv i64 %.frozen186, %.frozen187
  %305 = mul i64 %304, %.frozen187
  %.decomposed188 = sub i64 %.frozen186, %305
  %306 = sdiv i64 %.decomposed188, %85
  %307 = srem i64 %303, %85
  %308 = mul nsw i64 %307, %83
  %309 = mul nsw i64 %306, %83
  %310 = shl nsw i64 %304, 10
  %311 = shl nsw i64 %309, 5
  %312 = add i64 %311, %310
  %313 = add i64 %312, %308
  br i1 %100, label %.lr.ph111, label %.preheader78

.lr.ph111:                                        ; preds = %.lr.ph124
  %314 = getelementptr [4 x i8], ptr %80, i64 %313
  br label %315

.lr.ph112:                                        ; preds = %315
  %gep121 = getelementptr [4 x i8], ptr %invariant.gep120, i64 %313
  br label %321

315:                                              ; preds = %.lr.ph111, %315
  %316 = phi i64 [ 0, %.lr.ph111 ], [ %319, %315 ]
  %.idx57 = shl i64 %316, 7
  %317 = getelementptr i8, ptr %314, i64 %.idx57
  %318 = trunc i64 %316 to i32
  tail call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %317, i32 0, i32 %318)
  %319 = add nuw nsw i64 %316, 1
  %exitcond144.not = icmp eq i64 %319, %25
  br i1 %exitcond144.not, label %.lr.ph112, label %315

.lr.ph114:                                        ; preds = %321
  %320 = getelementptr [4 x i8], ptr %80, i64 %313
  br label %325

321:                                              ; preds = %.lr.ph112, %321
  %322 = phi i64 [ 0, %.lr.ph112 ], [ %324, %321 ]
  %.idx56 = shl i64 %322, 7
  %gep = getelementptr i8, ptr %gep121, i64 %.idx56
  %323 = trunc i64 %322 to i32
  tail call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %gep, i32 1, i32 %323)
  %324 = add nuw nsw i64 %322, 1
  %exitcond145.not = icmp eq i64 %324, %25
  br i1 %exitcond145.not, label %.lr.ph114, label %321

.lr.ph115:                                        ; preds = %325
  %gep123 = getelementptr [4 x i8], ptr %invariant.gep120, i64 %313
  br label %460

325:                                              ; preds = %.lr.ph114, %325
  %326 = phi i64 [ 0, %.lr.ph114 ], [ %330, %325 ]
  %327 = add nuw i64 %326, %25
  %.idx55 = shl i64 %327, 7
  %328 = getelementptr i8, ptr %320, i64 %.idx55
  %329 = trunc i64 %326 to i32
  tail call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %328, i32 2, i32 %329)
  %330 = add nuw nsw i64 %326, 1
  %exitcond146.not = icmp eq i64 %330, %25
  br i1 %exitcond146.not, label %.lr.ph115, label %325

.preheader78:                                     ; preds = %460, %.lr.ph124
  %331 = getelementptr [4 x i8], ptr %70, i64 %309
  %.idx53 = shl i64 %304, 11
  %332 = getelementptr i8, ptr %75, i64 %.idx53
  %333 = getelementptr [4 x i8], ptr %332, i64 %308
  %334 = load <vscale x 8 x float>, ptr %331, align 32
  %335 = load <vscale x 8 x float>, ptr %333, align 32
  %336 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %334, i64 0)
  %337 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %335, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %336, <vscale x 4 x float> %337)
  %338 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %335, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %336, <vscale x 4 x float> %338)
  %339 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %334, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %339, <vscale x 4 x float> %337)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %339, <vscale x 4 x float> %338)
  %340 = getelementptr i8, ptr %331, i64 128
  %341 = load <vscale x 8 x float>, ptr %340, align 32
  %342 = getelementptr i8, ptr %333, i64 128
  %343 = load <vscale x 8 x float>, ptr %342, align 32
  %344 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %341, i64 0)
  %345 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %343, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %344, <vscale x 4 x float> %345)
  %346 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %343, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %344, <vscale x 4 x float> %346)
  %347 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %341, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %347, <vscale x 4 x float> %345)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %347, <vscale x 4 x float> %346)
  %348 = getelementptr i8, ptr %331, i64 256
  %349 = load <vscale x 8 x float>, ptr %348, align 32
  %350 = getelementptr i8, ptr %333, i64 256
  %351 = load <vscale x 8 x float>, ptr %350, align 32
  %352 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %349, i64 0)
  %353 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %351, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %352, <vscale x 4 x float> %353)
  %354 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %351, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %352, <vscale x 4 x float> %354)
  %355 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %349, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %355, <vscale x 4 x float> %353)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %355, <vscale x 4 x float> %354)
  %356 = getelementptr i8, ptr %331, i64 384
  %357 = load <vscale x 8 x float>, ptr %356, align 32
  %358 = getelementptr i8, ptr %333, i64 384
  %359 = load <vscale x 8 x float>, ptr %358, align 32
  %360 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %357, i64 0)
  %361 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %359, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %360, <vscale x 4 x float> %361)
  %362 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %359, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %360, <vscale x 4 x float> %362)
  %363 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %357, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %363, <vscale x 4 x float> %361)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %363, <vscale x 4 x float> %362)
  %364 = getelementptr i8, ptr %331, i64 512
  %365 = load <vscale x 8 x float>, ptr %364, align 32
  %366 = getelementptr i8, ptr %333, i64 512
  %367 = load <vscale x 8 x float>, ptr %366, align 32
  %368 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %365, i64 0)
  %369 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %367, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %368, <vscale x 4 x float> %369)
  %370 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %367, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %368, <vscale x 4 x float> %370)
  %371 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %365, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %371, <vscale x 4 x float> %369)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %371, <vscale x 4 x float> %370)
  %372 = getelementptr i8, ptr %331, i64 640
  %373 = load <vscale x 8 x float>, ptr %372, align 32
  %374 = getelementptr i8, ptr %333, i64 640
  %375 = load <vscale x 8 x float>, ptr %374, align 32
  %376 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %373, i64 0)
  %377 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %375, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %376, <vscale x 4 x float> %377)
  %378 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %375, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %376, <vscale x 4 x float> %378)
  %379 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %373, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %379, <vscale x 4 x float> %377)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %379, <vscale x 4 x float> %378)
  %380 = getelementptr i8, ptr %331, i64 768
  %381 = load <vscale x 8 x float>, ptr %380, align 32
  %382 = getelementptr i8, ptr %333, i64 768
  %383 = load <vscale x 8 x float>, ptr %382, align 32
  %384 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %381, i64 0)
  %385 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %383, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %384, <vscale x 4 x float> %385)
  %386 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %383, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %384, <vscale x 4 x float> %386)
  %387 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %381, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %387, <vscale x 4 x float> %385)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %387, <vscale x 4 x float> %386)
  %388 = getelementptr i8, ptr %331, i64 896
  %389 = load <vscale x 8 x float>, ptr %388, align 32
  %390 = getelementptr i8, ptr %333, i64 896
  %391 = load <vscale x 8 x float>, ptr %390, align 32
  %392 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %389, i64 0)
  %393 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %391, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %392, <vscale x 4 x float> %393)
  %394 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %391, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %392, <vscale x 4 x float> %394)
  %395 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %389, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %395, <vscale x 4 x float> %393)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %395, <vscale x 4 x float> %394)
  %396 = getelementptr i8, ptr %331, i64 1024
  %397 = load <vscale x 8 x float>, ptr %396, align 32
  %398 = getelementptr i8, ptr %333, i64 1024
  %399 = load <vscale x 8 x float>, ptr %398, align 32
  %400 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %397, i64 0)
  %401 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %399, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %400, <vscale x 4 x float> %401)
  %402 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %399, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %400, <vscale x 4 x float> %402)
  %403 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %397, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %403, <vscale x 4 x float> %401)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %403, <vscale x 4 x float> %402)
  %404 = getelementptr i8, ptr %331, i64 1152
  %405 = load <vscale x 8 x float>, ptr %404, align 32
  %406 = getelementptr i8, ptr %333, i64 1152
  %407 = load <vscale x 8 x float>, ptr %406, align 32
  %408 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %405, i64 0)
  %409 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %407, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %408, <vscale x 4 x float> %409)
  %410 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %407, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %408, <vscale x 4 x float> %410)
  %411 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %405, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %411, <vscale x 4 x float> %409)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %411, <vscale x 4 x float> %410)
  %412 = getelementptr i8, ptr %331, i64 1280
  %413 = load <vscale x 8 x float>, ptr %412, align 32
  %414 = getelementptr i8, ptr %333, i64 1280
  %415 = load <vscale x 8 x float>, ptr %414, align 32
  %416 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %413, i64 0)
  %417 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %415, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %416, <vscale x 4 x float> %417)
  %418 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %415, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %416, <vscale x 4 x float> %418)
  %419 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %413, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %419, <vscale x 4 x float> %417)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %419, <vscale x 4 x float> %418)
  %420 = getelementptr i8, ptr %331, i64 1408
  %421 = load <vscale x 8 x float>, ptr %420, align 32
  %422 = getelementptr i8, ptr %333, i64 1408
  %423 = load <vscale x 8 x float>, ptr %422, align 32
  %424 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %421, i64 0)
  %425 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %423, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %424, <vscale x 4 x float> %425)
  %426 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %423, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %424, <vscale x 4 x float> %426)
  %427 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %421, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %427, <vscale x 4 x float> %425)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %427, <vscale x 4 x float> %426)
  %428 = getelementptr i8, ptr %331, i64 1536
  %429 = load <vscale x 8 x float>, ptr %428, align 32
  %430 = getelementptr i8, ptr %333, i64 1536
  %431 = load <vscale x 8 x float>, ptr %430, align 32
  %432 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %429, i64 0)
  %433 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %431, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %432, <vscale x 4 x float> %433)
  %434 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %431, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %432, <vscale x 4 x float> %434)
  %435 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %429, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %435, <vscale x 4 x float> %433)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %435, <vscale x 4 x float> %434)
  %436 = getelementptr i8, ptr %331, i64 1664
  %437 = load <vscale x 8 x float>, ptr %436, align 32
  %438 = getelementptr i8, ptr %333, i64 1664
  %439 = load <vscale x 8 x float>, ptr %438, align 32
  %440 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %437, i64 0)
  %441 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %439, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %440, <vscale x 4 x float> %441)
  %442 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %439, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %440, <vscale x 4 x float> %442)
  %443 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %437, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %443, <vscale x 4 x float> %441)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %443, <vscale x 4 x float> %442)
  %444 = getelementptr i8, ptr %331, i64 1792
  %445 = load <vscale x 8 x float>, ptr %444, align 32
  %446 = getelementptr i8, ptr %333, i64 1792
  %447 = load <vscale x 8 x float>, ptr %446, align 32
  %448 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %445, i64 0)
  %449 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %447, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %448, <vscale x 4 x float> %449)
  %450 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %447, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %448, <vscale x 4 x float> %450)
  %451 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %445, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %451, <vscale x 4 x float> %449)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %451, <vscale x 4 x float> %450)
  %452 = getelementptr i8, ptr %331, i64 1920
  %453 = load <vscale x 8 x float>, ptr %452, align 32
  %454 = getelementptr i8, ptr %333, i64 1920
  %455 = load <vscale x 8 x float>, ptr %454, align 32
  %456 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %453, i64 0)
  %457 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %455, i64 0)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 0, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %456, <vscale x 4 x float> %457)
  %458 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %455, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 1, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %456, <vscale x 4 x float> %458)
  %459 = tail call <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float> %453, i64 4)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 2, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %459, <vscale x 4 x float> %457)
  tail call void @llvm.aarch64.sme.mopa.nxv4f32(i32 3, <vscale x 4 x i1> splat (i1 true), <vscale x 4 x i1> splat (i1 true), <vscale x 4 x float> %459, <vscale x 4 x float> %458)
  br i1 %100, label %.lr.ph118, label %._crit_edge119

460:                                              ; preds = %.lr.ph115, %460
  %461 = phi i64 [ 0, %.lr.ph115 ], [ %464, %460 ]
  %462 = add nuw i64 %461, %25
  %.idx54 = shl i64 %462, 7
  %gep117 = getelementptr i8, ptr %gep123, i64 %.idx54
  %463 = trunc i64 %461 to i32
  tail call void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %gep117, i32 3, i32 %463)
  %464 = add nuw nsw i64 %461, 1
  %exitcond147.not = icmp eq i64 %464, %25
  br i1 %exitcond147.not, label %.preheader78, label %460

.lr.ph118:                                        ; preds = %.preheader78
  %465 = getelementptr [4 x i8], ptr %80, i64 %313
  br label %466

466:                                              ; preds = %.lr.ph118, %466
  %467 = phi i64 [ 0, %.lr.ph118 ], [ %474, %466 ]
  %.idx73 = shl i64 %467, 7
  %468 = getelementptr i8, ptr %465, i64 %.idx73
  %469 = trunc i64 %467 to i32
  tail call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %468, i32 0, i32 %469)
  %470 = getelementptr [4 x i8], ptr %468, i64 %25
  tail call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %470, i32 1, i32 %469)
  %471 = add nuw i64 %467, %25
  %.idx74 = shl i64 %471, 7
  %472 = getelementptr i8, ptr %465, i64 %.idx74
  tail call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %472, i32 2, i32 %469)
  %473 = getelementptr [4 x i8], ptr %472, i64 %25
  tail call void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1> splat (i1 true), ptr %473, i32 3, i32 %469)
  %474 = add nuw nsw i64 %467, 1
  %exitcond149.not = icmp eq i64 %474, %25
  br i1 %exitcond149.not, label %._crit_edge119, label %466

._crit_edge119:                                   ; preds = %466, %.preheader78
  %475 = add nuw nsw i64 %303, 1
  %exitcond150.not = icmp eq i64 %475, %umax
  br i1 %exitcond150.not, label %.preheader85, label %.lr.ph124

.preheader84:                                     ; preds = %.lr.ph125, %.preheader85
  br i1 %29, label %.lr.ph126, label %._crit_edge127

.lr.ph125:                                        ; preds = %.preheader85, %.lr.ph125
  %476 = phi i64 [ %492, %.lr.ph125 ], [ 0, %.preheader85 ]
  %.frozen189 = freeze i64 %476
  %.frozen190 = freeze i64 %103
  %477 = udiv i64 %.frozen189, %.frozen190
  %478 = mul i64 %477, %.frozen190
  %.decomposed191 = sub i64 %.frozen189, %478
  %479 = udiv i64 %.decomposed191, %82
  %480 = urem i64 %476, %82
  %481 = mul nsw i64 %480, %25
  %482 = sub i64 32, %481
  %483 = tail call i64 @llvm.smin.i64(i64 %482, i64 %25)
  %484 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %483)
  %.idx = shl i64 %479, 12
  %485 = getelementptr i8, ptr %80, i64 %.idx
  %.idx50 = shl i64 %477, 7
  %486 = getelementptr i8, ptr %485, i64 %.idx50
  %487 = getelementptr [4 x i8], ptr %486, i64 %481
  %488 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 16 %487, <vscale x 4 x i1> %484, <vscale x 4 x float> poison)
  %.idx51 = shl i64 %477, 8
  %489 = getelementptr i8, ptr %91, i64 %.idx51
  %.idx52 = shl i64 %479, 7
  %490 = getelementptr i8, ptr %489, i64 %.idx52
  %491 = getelementptr [4 x i8], ptr %490, i64 %481
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %488, ptr align 16 %491, <vscale x 4 x i1> %484)
  %492 = add nuw nsw i64 %476, 1
  %exitcond152.not = icmp eq i64 %492, %smax142
  br i1 %exitcond152.not, label %.preheader84, label %.lr.ph125

.lr.ph126:                                        ; preds = %.preheader84, %.lr.ph126
  %493 = phi i64 [ %510, %.lr.ph126 ], [ 0, %.preheader84 ]
  %.frozen192 = freeze i64 %493
  %.frozen193 = freeze i64 %27
  %494 = udiv i64 %.frozen192, %.frozen193
  %495 = mul i64 %494, %27
  %496 = icmp ne i64 %493, %495
  %497 = and i1 %104, %496
  %498 = sext i1 %497 to i64
  %499 = add i64 %494, %498
  %500 = mul i64 %494, %.frozen193
  %.decomposed194 = sub i64 %.frozen192, %500
  %501 = mul nsw i64 %.decomposed194, %25
  %502 = sub i64 64, %501
  %503 = tail call i64 @llvm.smin.i64(i64 %502, i64 %25)
  %504 = tail call <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64 0, i64 %503)
  %505 = shl nsw i64 %499, 6
  %506 = add i64 %505, %501
  %507 = getelementptr [4 x i8], ptr %91, i64 %506
  %508 = tail call <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr align 16 %507, <vscale x 4 x i1> %504, <vscale x 4 x float> poison)
  %509 = getelementptr [4 x i8], ptr %23, i64 %506
  tail call void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float> %508, ptr align 16 %509, <vscale x 4 x i1> %504)
  %510 = add nuw nsw i64 %493, 1
  %exitcond154.not = icmp eq i64 %510, %smax153
  br i1 %exitcond154.not, label %._crit_edge127, label %.lr.ph126

._crit_edge127:                                   ; preds = %.lr.ph126, %.preheader84
  %511 = add nsw i64 %107, 16
  %512 = add i64 %106, %65
  tail call void @free(ptr %130)
  tail call void @free(ptr %189)
  %513 = add nuw nsw i32 %108, 1
  %indvars.iv.next = add i32 %indvars.iv, -16
  %exitcond155.not = icmp eq i32 %513, %63
  br i1 %exitcond155.not, label %._crit_edge130, label %105

._crit_edge130:                                   ; preds = %._crit_edge127, %._crit_edge
  %514 = sext i32 %11 to i64
  %515 = mul nsw i64 %54, %514
  %516 = add nsw i64 %515, %56
  %517 = add nsw i64 %54, 32
  %518 = tail call i64 @llvm.smin.i64(i64 %517, i64 %57)
  %519 = tail call i64 @llvm.smax.i64(i64 %518, i64 %54)
  %520 = sub nsw i64 %519, %54
  %521 = add nsw i64 %56, 64
  %522 = tail call i64 @llvm.smin.i64(i64 %521, i64 %61)
  %523 = tail call i64 @llvm.smax.i64(i64 %522, i64 %56)
  %524 = sub nsw i64 %523, %56
  %525 = tail call i64 @llvm.smin.i64(i64 %520, i64 32)
  %526 = tail call i64 @llvm.smin.i64(i64 %524, i64 64)
  %527 = load ptr, ptr %5, align 8
  %528 = getelementptr i8, ptr %5, i64 8
  %529 = load ptr, ptr %528, align 8
  %530 = tail call ptr @llvm.stacksave.p0()
  %531 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, align 8
  store ptr %19, ptr %531, align 8
  %.repack23 = getelementptr inbounds nuw i8, ptr %531, i64 8
  store ptr %23, ptr %.repack23, align 8
  %.repack25 = getelementptr inbounds nuw i8, ptr %531, i64 16
  store i64 0, ptr %.repack25, align 8
  %.repack27 = getelementptr inbounds nuw i8, ptr %531, i64 24
  store i64 %525, ptr %.repack27, align 8
  %.repack27.repack31 = getelementptr inbounds nuw i8, ptr %531, i64 32
  store i64 %526, ptr %.repack27.repack31, align 8
  %.repack29 = getelementptr inbounds nuw i8, ptr %531, i64 40
  store i64 64, ptr %.repack29, align 8
  %.repack29.repack33 = getelementptr inbounds nuw i8, ptr %531, i64 48
  store i64 1, ptr %.repack29.repack33, align 8
  %532 = alloca { ptr, ptr, i64, [2 x i64], [2 x i64] }, align 8
  store ptr %527, ptr %532, align 8
  %.repack34 = getelementptr inbounds nuw i8, ptr %532, i64 8
  store ptr %529, ptr %.repack34, align 8
  %.repack36 = getelementptr inbounds nuw i8, ptr %532, i64 16
  store i64 %516, ptr %.repack36, align 8
  %.repack38 = getelementptr inbounds nuw i8, ptr %532, i64 24
  store i64 %525, ptr %.repack38, align 8
  %.repack38.repack42 = getelementptr inbounds nuw i8, ptr %532, i64 32
  store i64 %526, ptr %.repack38.repack42, align 8
  %.repack40 = getelementptr inbounds nuw i8, ptr %532, i64 40
  store i64 %514, ptr %.repack40, align 8
  %.repack40.repack44 = getelementptr inbounds nuw i8, ptr %532, i64 48
  store i64 1, ptr %.repack40.repack44, align 8
  %533 = alloca { i64, ptr }, align 8
  store i64 2, ptr %533, align 8
  %.repack46 = getelementptr inbounds nuw i8, ptr %533, i64 8
  store ptr %531, ptr %.repack46, align 8
  %534 = alloca { i64, ptr }, align 8
  store i64 2, ptr %534, align 8
  %.repack48 = getelementptr inbounds nuw i8, ptr %534, i64 8
  store ptr %532, ptr %.repack48, align 8
  call void @memrefCopy(i64 4, ptr nonnull %533, ptr nonnull %534)
  call void @llvm.stackrestore.p0(ptr %530)
  call void @free(ptr %19)
  call void @free(ptr %66)
  call void @free(ptr %71)
  call void @free(ptr %76)
  call void @free(ptr %87)
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.vscale.i64() #4

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smin.i32(i32, i32) #5

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smin.i64(i64, i64) #5

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smax.i64(i64, i64) #5

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare ptr @llvm.stacksave.p0() #6

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.stackrestore.p0(ptr) #6

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x i1> @llvm.aarch64.sve.whilelt.nxv4i1.i64(i64, i64) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <vscale x 4 x float> @llvm.masked.load.nxv4f32.p0(ptr captures(none), <vscale x 4 x i1>, <vscale x 4 x float>) #7

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.nxv4f32.p0(<vscale x 4 x float>, ptr captures(none), <vscale x 4 x i1>) #8

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite)
declare void @llvm.aarch64.sme.st1w.horiz.p0(<vscale x 4 x i1>, ptr, i32 immarg, i32) #9

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <vscale x 4 x float> @llvm.vector.extract.nxv4f32.nxv8f32(<vscale x 8 x float>, i64 immarg) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(target_mem1: readwrite)
declare void @llvm.aarch64.sme.mopa.nxv4f32(i32 immarg, <vscale x 4 x i1>, <vscale x 4 x i1>, <vscale x 4 x float>, <vscale x 4 x float>) #10

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite)
declare void @llvm.aarch64.sme.ld1w.horiz.p0(<vscale x 4 x i1>, ptr, i32 immarg, i32) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smax.i32(i32, i32) #11

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umin.i32(i32, i32) #11

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umax.i64(i64, i64) #11

attributes #0 = { "target-features"="+sve,+sve2,+sme" }
attributes #1 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "target-features"="+sve,+sve2,+sme" }
attributes #2 = { mustprogress nofree nounwind willreturn allockind("alloc,uninitialized") allocsize(0) memory(inaccessiblemem: readwrite, errnomem: write) "alloc-family"="malloc" "target-features"="+sve,+sve2,+sme" }
attributes #3 = { "aarch64_new_za" "aarch64_pstate_sm_enabled" "target-features"="+sve,+sve2,+sme" }
attributes #4 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) "target-features"="+sve,+sve2,+sme" }
attributes #5 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) "target-features"="+sve,+sve2,+sme" }
attributes #6 = { mustprogress nocallback nofree nosync nounwind willreturn "target-features"="+sve,+sve2,+sme" }
attributes #7 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read) "target-features"="+sve,+sve2,+sme" }
attributes #8 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write) "target-features"="+sve,+sve2,+sme" }
attributes #9 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, target_mem1: readwrite) "target-features"="+sve,+sve2,+sme" }
attributes #10 = { mustprogress nocallback nofree nosync nounwind willreturn memory(target_mem1: readwrite) "target-features"="+sve,+sve2,+sme" }
attributes #11 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #12 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
