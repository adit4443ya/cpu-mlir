	.file	"LLVMDialectModule"
	.text
	.globl	matmul_kernel                   // -- Begin function matmul_kernel
	.p2align	2
	.type	matmul_kernel,@function
matmul_kernel:                          // @matmul_kernel
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-112]!          // 16-byte Folded Spill
	.cfi_def_cfa_offset 112
	cntd	x9
	stp	x28, x27, [sp, #32]             // 16-byte Folded Spill
	str	x9, [sp, #16]                   // 8-byte Spill
	stp	x26, x25, [sp, #48]             // 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 112
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	.cfi_offset vg, -96
	.cfi_offset w30, -104
	.cfi_offset w29, -112
	sub	sp, sp, #1024
	addvl	sp, sp, #-9
	str	z15, [sp]                       // 16-byte Folded Spill
	str	z14, [sp, #1, mul vl]           // 16-byte Folded Spill
	str	z13, [sp, #2, mul vl]           // 16-byte Folded Spill
	str	z12, [sp, #3, mul vl]           // 16-byte Folded Spill
	str	z11, [sp, #4, mul vl]           // 16-byte Folded Spill
	str	z10, [sp, #5, mul vl]           // 16-byte Folded Spill
	str	z9, [sp, #6, mul vl]            // 16-byte Folded Spill
	str	z8, [sp, #7, mul vl]            // 16-byte Folded Spill
	.cfi_escape 0x10, 0x48, 0x0e, 0x12, 0x11, 0xa0, 0x7f, 0x22, 0x06, 0x11, 0x70, 0x1e, 0x22, 0x11, 0x90, 0x77, 0x22 // $d8  @ cfa - 16 * IncomingVG - 1136
	.cfi_escape 0x10, 0x49, 0x0e, 0x12, 0x11, 0xa0, 0x7f, 0x22, 0x06, 0x11, 0x68, 0x1e, 0x22, 0x11, 0x90, 0x77, 0x22 // $d9  @ cfa - 24 * IncomingVG - 1136
	.cfi_escape 0x10, 0x4a, 0x0e, 0x12, 0x11, 0xa0, 0x7f, 0x22, 0x06, 0x11, 0x60, 0x1e, 0x22, 0x11, 0x90, 0x77, 0x22 // $d10  @ cfa - 32 * IncomingVG - 1136
	.cfi_escape 0x10, 0x4b, 0x0e, 0x12, 0x11, 0xa0, 0x7f, 0x22, 0x06, 0x11, 0x58, 0x1e, 0x22, 0x11, 0x90, 0x77, 0x22 // $d11  @ cfa - 40 * IncomingVG - 1136
	.cfi_escape 0x10, 0x4c, 0x0e, 0x12, 0x11, 0xa0, 0x7f, 0x22, 0x06, 0x11, 0x50, 0x1e, 0x22, 0x11, 0x90, 0x77, 0x22 // $d12  @ cfa - 48 * IncomingVG - 1136
	.cfi_escape 0x10, 0x4d, 0x0e, 0x12, 0x11, 0xa0, 0x7f, 0x22, 0x06, 0x11, 0x48, 0x1e, 0x22, 0x11, 0x90, 0x77, 0x22 // $d13  @ cfa - 56 * IncomingVG - 1136
	.cfi_escape 0x10, 0x4e, 0x0e, 0x12, 0x11, 0xa0, 0x7f, 0x22, 0x06, 0x11, 0x40, 0x1e, 0x22, 0x11, 0x90, 0x77, 0x22 // $d14  @ cfa - 64 * IncomingVG - 1136
	.cfi_escape 0x10, 0x4f, 0x0f, 0x12, 0x11, 0xa0, 0x7f, 0x22, 0x06, 0x11, 0xb8, 0x7f, 0x1e, 0x22, 0x11, 0x90, 0x77, 0x22 // $d15  @ cfa - 72 * IncomingVG - 1136
	sub	sp, sp, #1408
	addvl	sp, sp, #-1
	rdsvl	x8, #1
	mov	x9, sp
	mov	x19, sp
	msub	x9, x8, x8, x9
	mov	sp, x9
	stp	x9, x8, [x19, #368]
	mrs	x8, TPIDR2_EL0
	cbz	x8, .LBB0_2
// %bb.1:
	bl	__arm_tpidr2_save
	msr	TPIDR2_EL0, xzr
	zero	{za}
.LBB0_2:
	smstart	za
	ldr	w8, [x29, #112]
	ldr	w22, [x29, #168]
	mov	w25, w7
	mov	w24, w6
	str	x5, [x19, #24]                  // 8-byte Spill
	str	w8, [x19, #252]                 // 4-byte Spill
	add	x8, x19, #368
	stp	x1, x3, [x19, #208]             // 16-byte Folded Spill
	msr	TPIDR2_EL0, x8
	smstop	sm
	mov	w0, #8256                       // =0x2040
	bl	malloc
	smstart	sm
	cntw	x21
	mov	w8, #63                         // =0x3f
	rdvl	x20, #1
	sdiv	x9, x8, x21
	add	x8, x0, #63
	str	x0, [x19, #32]                  // 8-byte Spill
	and	x13, x8, #0xffffffffffffffc0
	add	x1, x9, #1
	lsl	x27, x1, #5
	smstart	za
	mrs	x8, TPIDR2_EL0
	add	x0, x19, #368
	cbnz	x8, .LBB0_4
// %bb.3:
	bl	__arm_tpidr2_restore
.LBB0_4:
	msr	TPIDR2_EL0, xzr
	str	x9, [x19, #200]                 // 8-byte Spill
	tbnz	x9, #63, .LBB0_7
// %bb.5:                               // %.lr.ph.preheader
	mov	z0.s, #0                        // =0x0
	mov	x8, xzr
	mov	w9, #64                         // =0x40
.LBB0_6:                                // %.lr.ph
                                        // =>This Inner Loop Header: Depth=1
	udiv	x10, x8, x1
	msub	x11, x10, x1, x8
	add	x10, x13, x10, lsl #8
	add	x8, x8, #1
	mul	x11, x11, x21
	sub	x12, x9, x11
	cmp	x12, x21
	csel	x12, x12, x21, lt
	whilelt	p0.s, xzr, x12
	cmp	x27, x8
	st1w	{ z0.s }, p0, [x10, x11, lsl #2]
	b.ne	.LBB0_6
.LBB0_7:                                // %._crit_edge
	adds	w8, w24, #31
	add	w9, w24, #62
	add	w10, w25, #126
	csel	w8, w9, w8, mi
	adds	w9, w25, #63
	mov	w12, #8                         // =0x8
	csel	w9, w10, w9, mi
	asr	w8, w8, #5
	str	x1, [x19, #192]                 // 8-byte Spill
	asr	w9, w9, #6
	str	x13, [x19, #240]                // 8-byte Spill
	lsl	w9, w9, #3
	sdiv	w10, w22, w9
	lsl	w11, w10, #3
	msub	w9, w10, w9, w22
	ldr	w10, [x29, #136]
	sub	w8, w8, w11
	str	x10, [x19, #16]                 // 8-byte Spill
	sxtw	x10, w24
	cmp	w8, #8
	csel	w8, w8, w12, lt
	str	x10, [x19, #8]                  // 8-byte Spill
	sxtw	x10, w25
	sdiv	w12, w22, w8
	sdiv	w9, w9, w8
	msub	w8, w12, w8, w22
	add	w8, w11, w8
	lsl	w8, w8, #5
	sxtw	x8, w8
	lsl	w9, w9, #6
	str	x8, [x19, #40]                  // 8-byte Spill
	ldr	w8, [x19, #252]                 // 4-byte Reload
	sxtw	x9, w9
	adds	w23, w8, #15
	add	w8, w8, #30
	csel	w22, w8, w23, mi
	stp	x10, x9, [x19, #224]            // 16-byte Folded Spill
	add	x9, x19, #368
	msr	TPIDR2_EL0, x9
	smstop	sm
	mov	w0, #2112                       // =0x840
	bl	malloc
	str	x0, [x19, #72]                  // 8-byte Spill
	smstart	sm
	smstop	sm
	mov	w0, #4160                       // =0x1040
	bl	malloc
	str	x0, [x19, #64]                  // 8-byte Spill
	smstart	sm
	smstop	sm
	mov	w0, #8256                       // =0x2040
	bl	malloc
	str	x0, [x19, #56]                  // 8-byte Spill
	smstart	sm
	smstop	sm
	mov	w0, #8256                       // =0x2040
	bl	malloc
	str	x0, [x19, #48]                  // 8-byte Spill
	smstart	sm
	smstart	za
	mrs	x8, TPIDR2_EL0
	add	x0, x19, #368
	cbnz	x8, .LBB0_9
// %bb.8:                               // %._crit_edge
	bl	__arm_tpidr2_restore
.LBB0_9:                                // %._crit_edge
	cmp	w23, #16
	msr	TPIDR2_EL0, xzr
	b.lt	.LBB0_71
// %bb.10:                              // %.lr.ph129
	lsr	x8, x20, #4
	ldr	w10, [x29, #128]
	cmp	x21, #1
	ldr	w1, [x19, #252]                 // 4-byte Reload
	mov	w12, wzr
	lsl	x9, x8, #3
	mov	w8, #31                         // =0x1f
	sdiv	x13, x8, x21
	str	x9, [x19, #184]                 // 8-byte Spill
	sdiv	x9, x8, x9
	ldr	w8, [x29, #120]
	str	x13, [x19, #336]                // 8-byte Spill
	smull	x11, w8, w24
	sxtw	x14, w8
	lsl	w8, w10, #4
	str	x14, [x19, #328]                // 8-byte Spill
	add	x25, x9, #1
	sxtw	x9, w10
	csinc	x10, x21, xzr, lt
	mul	x15, x25, x25
	whilelt	p0.s, xzr, x10
	ldr	x10, [x19, #40]                 // 8-byte Reload
	stp	x9, x11, [x19, #168]            // 16-byte Folded Spill
	asr	w9, w22, #4
	sxtw	x11, w8
	add	x22, x13, #1
	smull	x10, w10, w14
	mov	z0.s, p0/z, #1                  // =0x1
	str	w9, [x19, #164]                 // 4-byte Spill
	ldp	x9, x8, [x19, #64]              // 16-byte Folded Reload
	str	p0, [x29, #-1, mul vl]          // 2-byte Spill
	str	x15, [x19, #152]                // 8-byte Spill
	add	x8, x8, #63
	add	x9, x9, #63
	and	x26, x8, #0xffffffffffffffc0
	ldr	x8, [x19, #56]                  // 8-byte Reload
	and	x23, x9, #0xffffffffffffffc0
	lsl	x9, x22, #6
	str	x23, [x19, #80]                 // 8-byte Spill
	add	x8, x8, #63
	and	x20, x8, #0xffffffffffffffc0
	ldr	x8, [x19, #48]                  // 8-byte Reload
	cmp	x9, #1
	mov	x13, x20
	csinc	x9, x9, xzr, gt
	add	x8, x8, #63
	incb	x13
	and	x8, x8, #0xffffffffffffffc0
	stp	x8, x11, [x19, #136]            // 16-byte Folded Spill
	lsl	x8, x15, #1
	lsl	x15, x22, #5
	cmp	x8, #1
	stp	x13, x15, [x19, #120]           // 16-byte Folded Spill
	mov	w13, #32                        // =0x20
	csinc	x8, x8, xzr, hi
	cmp	x27, #1
	add	x15, x19, #368
	stp	x8, x9, [x19, #104]             // 16-byte Folded Spill
	lsl	x9, x22, #1
	csinc	x8, x27, xzr, gt
	mov	x27, xzr
	stp	x8, x9, [x19, #88]              // 16-byte Folded Spill
	sub	x8, x29, #1024
	str	z0, [x8, #-10, mul vl]          // 16-byte Folded Spill
	b	.LBB0_12
.LBB0_11:                               // %._crit_edge127
                                        //   in Loop: Header=BB0_12 Depth=1
	ldr	w8, [x19, #164]                 // 4-byte Reload
	msr	TPIDR2_EL0, xzr
	ldr	x14, [x19, #328]                // 8-byte Reload
	add	x15, x19, #368
	mov	x10, x28
	mov	w13, #32                        // =0x20
	cmp	w12, w8
	b.eq	.LBB0_71
.LBB0_12:                               // =>This Loop Header: Depth=1
                                        //     Child Loop BB0_20 Depth 2
                                        //     Child Loop BB0_23 Depth 2
                                        //     Child Loop BB0_32 Depth 2
                                        //     Child Loop BB0_35 Depth 2
                                        //     Child Loop BB0_37 Depth 2
                                        //     Child Loop BB0_40 Depth 2
                                        //       Child Loop BB0_43 Depth 3
                                        //     Child Loop BB0_47 Depth 2
                                        //     Child Loop BB0_51 Depth 2
                                        //       Child Loop BB0_53 Depth 3
                                        //       Child Loop BB0_55 Depth 3
                                        //       Child Loop BB0_57 Depth 3
                                        //       Child Loop BB0_59 Depth 3
                                        //       Child Loop BB0_62 Depth 3
                                        //     Child Loop BB0_65 Depth 2
                                        //     Child Loop BB0_68 Depth 2
	sdiv	x8, x10, x14
	ldp	x11, x9, [x19, #224]            // 16-byte Folded Reload
	str	x10, [x19, #360]                // 8-byte Spill
	str	w12, [x19, #316]                // 4-byte Spill
	add	x16, x27, x9
	str	x27, [x19, #320]                // 8-byte Spill
	str	w1, [x19, #312]                 // 4-byte Spill
	sdiv	x9, x16, x11
	mul	x10, x8, x14
	ldr	x8, [x19, #176]                 // 8-byte Reload
	sub	x8, x8, x10
	stp	x10, x16, [x19, #256]           // 16-byte Folded Spill
	sdiv	x8, x8, x14
	mul	x10, x9, x11
	bic	w9, w1, w1, asr #31
	cmp	x9, #16
	str	x10, [x19, #272]                // 8-byte Spill
	sub	x14, x16, x10
	ldr	w10, [x19, #252]                // 4-byte Reload
	sub	w23, w10, w12, lsl #4
	add	x10, x14, #64
	mov	w12, #16                        // =0x10
	csel	x9, x9, x12, lo
	cmp	x10, x11
	csel	x10, x10, x11, lt
	stp	x14, x9, [x19, #296]            // 16-byte Folded Spill
	bic	w9, w23, w23, asr #31
	str	x10, [x19, #288]                // 8-byte Spill
	ldr	x10, [x19, #216]                // 8-byte Reload
	ldr	x10, [x10, #8]
	str	x10, [x19, #344]                // 8-byte Spill
	cmp	x8, #32
	csel	x24, x8, x13, lt
	ldr	x8, [x19, #208]                 // 8-byte Reload
	cmp	w9, #16
	csel	w27, w9, w12, lt
	ldr	x8, [x8, #8]
	str	x8, [x19, #280]                 // 8-byte Spill
	msr	TPIDR2_EL0, x15
	smstop	sm
	mov	w0, #2048                       // =0x800
	bl	malloc
	mov	x28, x0
	smstart	sm
	smstart	za
	mrs	x8, TPIDR2_EL0
	add	x0, x19, #368
	cbnz	x8, .LBB0_14
// %bb.13:                              //   in Loop: Header=BB0_12 Depth=1
	bl	__arm_tpidr2_restore
.LBB0_14:                               //   in Loop: Header=BB0_12 Depth=1
	cmp	w23, #15
	str	w23, [x19, #356]                // 4-byte Spill
	msr	TPIDR2_EL0, xzr
	b.gt	.LBB0_18
// %bb.15:                              // %.preheader83.preheader
                                        //   in Loop: Header=BB0_12 Depth=1
	add	x8, x19, #368
	mov	x0, x28
	mov	w1, wzr
	mov	w2, #2048                       // =0x800
	msr	TPIDR2_EL0, x8
	bl	__arm_sc_memset
	smstart	za
	mrs	x8, TPIDR2_EL0
	add	x0, x19, #368
	cbnz	x8, .LBB0_17
// %bb.16:                              // %.preheader83.preheader
                                        //   in Loop: Header=BB0_12 Depth=1
	bl	__arm_tpidr2_restore
.LBB0_17:                               // %.preheader83.preheader
                                        //   in Loop: Header=BB0_12 Depth=1
	msr	TPIDR2_EL0, xzr
.LBB0_18:                               // %.loopexit92
                                        //   in Loop: Header=BB0_12 Depth=1
	ldr	w10, [x19, #356]                // 4-byte Reload
	sub	x8, x27, #1
	ldr	x16, [x19, #328]                // 8-byte Reload
	ldr	x17, [x19, #360]                // 8-byte Reload
	ldr	x18, [x19, #280]                // 8-byte Reload
	cmp	w10, #1
	csneg	x8, x8, x27, ge
	cmp	w10, #1
	sdiv	x8, x8, x21
	neg	x9, x8
	csinc	x8, x9, x8, lt
	mul	x9, x8, x24
	cmp	x9, #1
	b.lt	.LBB0_21
// %bb.19:                              // %.lr.ph94
                                        //   in Loop: Header=BB0_12 Depth=1
	add	x10, x18, x17, lsl #2
	mov	x11, xzr
.LBB0_20:                               //   Parent Loop BB0_12 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	sdiv	x12, x11, x8
	cmp	x8, #0
	cset	w14, mi
	mul	x13, x12, x8
	subs	x13, x11, x13
	add	x11, x11, #1
	mul	x13, x13, x21
	csel	w14, wzr, w14, eq
	sub	x12, x12, x14
	mul	x14, x12, x16
	add	x12, x28, x12, lsl #6
	sub	x15, x27, x13
	cmp	x15, x21
	csel	x15, x15, x21, lt
	add	x14, x10, x14, lsl #2
	whilelt	p0.s, xzr, x15
	cmp	x9, x11
	ld1w	{ z0.s }, p0/z, [x14, x13, lsl #2]
	st1w	{ z0.s }, p0, [x12, x13, lsl #2]
	b.ne	.LBB0_20
.LBB0_21:                               // %._crit_edge95
                                        //   in Loop: Header=BB0_12 Depth=1
	mov	w9, #32                         // =0x20
	ldr	x23, [x19, #80]                 // 8-byte Reload
	sub	x9, x9, x24
	mul	x9, x8, x9
	cmp	x9, #1
	b.lt	.LBB0_24
// %bb.22:                              // %.lr.ph97
                                        //   in Loop: Header=BB0_12 Depth=1
	ldr	x10, [x19, #256]                // 8-byte Reload
	mov	x11, xzr
	sub	x10, x17, x10
	add	x10, x18, x10, lsl #2
.LBB0_23:                               //   Parent Loop BB0_12 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	sdiv	x12, x11, x8
	cmp	x8, #0
	cset	w14, mi
	mul	x13, x12, x8
	subs	x13, x11, x13
	add	x11, x11, #1
	mul	x13, x13, x21
	csel	w14, wzr, w14, eq
	sub	x12, x12, x14
	mul	x14, x12, x16
	add	x12, x12, x24
	add	x12, x28, x12, lsl #6
	sub	x15, x27, x13
	cmp	x15, x21
	csel	x15, x15, x21, lt
	add	x14, x10, x14, lsl #2
	whilelt	p0.s, xzr, x15
	cmp	x9, x11
	ld1w	{ z0.s }, p0/z, [x14, x13, lsl #2]
	st1w	{ z0.s }, p0, [x12, x13, lsl #2]
	b.ne	.LBB0_23
.LBB0_24:                               // %._crit_edge98
                                        //   in Loop: Header=BB0_12 Depth=1
	add	x8, x19, #368
	msr	TPIDR2_EL0, x8
	smstop	sm
	mov	w0, #4096                       // =0x1000
	bl	malloc
	mov	x24, x0
	smstart	sm
	smstart	za
	mrs	x8, TPIDR2_EL0
	add	x0, x19, #368
	cbnz	x8, .LBB0_26
// %bb.25:                              // %._crit_edge98
                                        //   in Loop: Header=BB0_12 Depth=1
	bl	__arm_tpidr2_restore
.LBB0_26:                               // %._crit_edge98
                                        //   in Loop: Header=BB0_12 Depth=1
	ldr	w8, [x19, #356]                 // 4-byte Reload
	msr	TPIDR2_EL0, xzr
	cmp	w8, #15
	b.gt	.LBB0_30
// %bb.27:                              // %.preheader82.preheader
                                        //   in Loop: Header=BB0_12 Depth=1
	add	x8, x19, #368
	mov	x0, x24
	mov	w1, wzr
	mov	w2, #4096                       // =0x1000
	msr	TPIDR2_EL0, x8
	bl	__arm_sc_memset
	smstart	za
	mrs	x8, TPIDR2_EL0
	add	x0, x19, #368
	cbnz	x8, .LBB0_29
// %bb.28:                              // %.preheader82.preheader
                                        //   in Loop: Header=BB0_12 Depth=1
	bl	__arm_tpidr2_restore
.LBB0_29:                               // %.preheader82.preheader
                                        //   in Loop: Header=BB0_12 Depth=1
	msr	TPIDR2_EL0, xzr
.LBB0_30:                               // %.loopexit
                                        //   in Loop: Header=BB0_12 Depth=1
	ldp	x9, x8, [x19, #288]             // 16-byte Folded Reload
	ldr	x1, [x19, #168]                 // 8-byte Reload
	ldr	x17, [x19, #304]                // 8-byte Reload
	sub	x8, x9, x8
	neg	x9, x8
	subs	x10, x8, #1
	csel	x9, x9, x10, lt
	cmp	x8, #1
	sdiv	x9, x9, x21
	neg	x10, x9
	csinc	x9, x10, x9, lt
	mul	x10, x9, x27
	cmp	x10, #1
	b.lt	.LBB0_33
// %bb.31:                              // %.lr.ph100
                                        //   in Loop: Header=BB0_12 Depth=1
	mul	x10, x9, x17
	ldr	x11, [x19, #344]                // 8-byte Reload
	ldr	x12, [x19, #264]                // 8-byte Reload
	add	x11, x11, x12, lsl #2
	mov	x12, xzr
.LBB0_32:                               //   Parent Loop BB0_12 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	sdiv	x13, x12, x9
	cmp	x9, #0
	cset	w15, mi
	mul	x14, x13, x9
	subs	x14, x12, x14
	add	x12, x12, #1
	mul	x14, x14, x21
	csel	w15, wzr, w15, eq
	sub	x13, x13, x15
	mul	x15, x13, x1
	add	x13, x24, x13, lsl #8
	sub	x16, x8, x14
	cmp	x16, x21
	csel	x16, x16, x21, lt
	add	x15, x11, x15, lsl #2
	whilelt	p0.s, xzr, x16
	cmp	x10, x12
	ld1w	{ z0.s }, p0/z, [x15, x14, lsl #2]
	st1w	{ z0.s }, p0, [x13, x14, lsl #2]
	b.ne	.LBB0_32
.LBB0_33:                               // %._crit_edge101
                                        //   in Loop: Header=BB0_12 Depth=1
	mov	w10, #63                        // =0x3f
	sub	x9, x8, #64
	cmp	x8, #63
	sub	x10, x10, x8
	ldr	p2, [x29, #-1, mul vl]          // 2-byte Reload
	ldr	x18, [x19, #240]                // 8-byte Reload
	csel	x9, x9, x10, gt
	cmp	x8, #63
	ldr	x0, [x19, #192]                 // 8-byte Reload
	sdiv	x9, x9, x21
	ldp	x3, x2, [x19, #112]             // 16-byte Folded Reload
	ldr	x4, [x19, #104]                 // 8-byte Reload
	mov	w5, #32                         // =0x20
	mov	w6, #64                         // =0x40
	mov	x7, #32                         // =0x20
	mov	x30, #64                        // =0x40
	neg	x10, x9
	csinc	x9, x10, x9, gt
	mul	x10, x9, x27
	cmp	x10, #1
	sub	x10, x29, #1024
	ldr	z3, [x10, #-10, mul vl]         // 16-byte Folded Reload
	b.lt	.LBB0_36
// %bb.34:                              // %.lr.ph103
                                        //   in Loop: Header=BB0_12 Depth=1
	mul	x11, x9, x17
	ldr	x12, [x19, #272]                // 8-byte Reload
	ldr	x13, [x19, #344]                // 8-byte Reload
	mov	x10, xzr
	add	x12, x13, x12, lsl #2
	add	x13, x24, x8, lsl #2
	sub	x8, x6, x8
.LBB0_35:                               //   Parent Loop BB0_12 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	sdiv	x14, x10, x9
	cmp	x9, #0
	cset	w16, mi
	mul	x15, x14, x9
	subs	x15, x10, x15
	add	x10, x10, #1
	mul	x15, x15, x21
	csel	w16, wzr, w16, eq
	sub	x14, x14, x16
	mul	x16, x14, x1
	add	x14, x13, x14, lsl #8
	sub	x17, x8, x15
	cmp	x17, x21
	csel	x17, x17, x21, lt
	add	x16, x12, x16, lsl #2
	whilelt	p0.s, xzr, x17
	cmp	x11, x10
	ld1w	{ z0.s }, p0/z, [x16, x15, lsl #2]
	st1w	{ z0.s }, p0, [x14, x15, lsl #2]
	b.ne	.LBB0_35
.LBB0_36:                               // %.preheader89.preheader
                                        //   in Loop: Header=BB0_12 Depth=1
	ldr	x27, [x19, #320]                // 8-byte Reload
	mov	x8, xzr
	mov	x9, xzr
.LBB0_37:                               // %.preheader89
                                        //   Parent Loop BB0_12 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	and	x10, x8, #0x7c0
	lsr	x11, x9, #5
	add	x8, x8, #64
	add	x10, x28, x10
	add	x10, x10, x11, lsl #2
	ld1w	{ z0.s }, p2/z, [x10]
	st1w	{ z0.s }, p2, [x26, x9, lsl #2]
	add	x9, x9, #1
	cmp	x9, #512
	b.ne	.LBB0_37
// %bb.38:                              // %.preheader88.preheader
                                        //   in Loop: Header=BB0_12 Depth=1
	index	z0.s, #0, #1
	ptrue	p0.s
	ldr	x17, [x19, #184]                // 8-byte Reload
	ldr	x1, [x19, #152]                 // 8-byte Reload
	ldr	x14, [x19, #128]                // 8-byte Reload
	mov	x8, xzr
	b	.LBB0_40
.LBB0_39:                               // %._crit_edge108
                                        //   in Loop: Header=BB0_40 Depth=2
	and	x10, x8, #0x200
	and	x11, x8, #0x1f
	add	x8, x8, #1
	add	x10, x23, x10, lsl #2
	cmp	x8, #1024
	add	x9, x10, x9, lsl #7
	st1w	{ z1.s }, p2, [x9, x11, lsl #2]
	b.eq	.LBB0_45
.LBB0_40:                               // %.preheader88
                                        //   Parent Loop BB0_12 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB0_43 Depth 3
	ubfx	x9, x8, #5, #4
	cmp	x21, #1
                                        // implicit-def: $z1
	b.lt	.LBB0_39
// %bb.41:                              // %.lr.ph107
                                        //   in Loop: Header=BB0_40 Depth=2
	lsl	x11, x9, #8
	lsr	x12, x8, #9
	mov	x10, xzr
                                        // implicit-def: $z1
	add	x11, x11, x12, lsl #7
	bfi	x11, x8, #2, #5
	add	x11, x24, x11
	b	.LBB0_43
.LBB0_42:                               //   in Loop: Header=BB0_43 Depth=3
	add	x10, x10, #1
	add	x11, x11, #256
	mov	x12, x10
	decw	x12
	cbz	x12, .LBB0_39
.LBB0_43:                               //   Parent Loop BB0_12 Depth=1
                                        //     Parent Loop BB0_40 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	whilels	p1.s, xzr, x10
	lastb	w12, p1, z3.s
	tbz	w12, #0, .LBB0_42
// %bb.44:                              //   in Loop: Header=BB0_43 Depth=3
	mov	z2.s, w10
	cmpeq	p1.s, p0/z, z0.s, z2.s
	ldr	s2, [x11]
	mov	z1.s, p1/m, s2
	b	.LBB0_42
.LBB0_45:                               // %.preheader87
                                        //   in Loop: Header=BB0_12 Depth=1
	ldr	x8, [x19, #336]                 // 8-byte Reload
	tbnz	x8, #63, .LBB0_48
// %bb.46:                              // %.lr.ph109.preheader
                                        //   in Loop: Header=BB0_12 Depth=1
	mov	x8, xzr
.LBB0_47:                               // %.lr.ph109
                                        //   Parent Loop BB0_12 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	udiv	x9, x8, x14
	udiv	x10, x8, x22
	msub	x11, x9, x14, x8
	udiv	x11, x11, x22
	msub	x10, x10, x22, x8
	add	x8, x8, #1
	mul	x10, x10, x21
	sub	x12, x5, x10
	cmp	x12, x21
	csel	x12, x12, x21, lt
	whilelt	p1.s, xzr, x12
	cmp	x3, x8
	add	x13, x18, x11, lsl #8
	add	x12, x13, x9, lsl #7
	add	x9, x20, x9, lsl #12
	ld1w	{ z0.s }, p1/z, [x12, x10, lsl #2]
	add	x9, x9, x11, lsl #7
	st1w	{ z0.s }, p1, [x9, x10, lsl #2]
	b.ne	.LBB0_47
.LBB0_48:                               // %.preheader86
                                        //   in Loop: Header=BB0_12 Depth=1
	cbz	x25, .LBB0_63
// %bb.49:                              // %.lr.ph124.preheader
                                        //   in Loop: Header=BB0_12 Depth=1
	mov	x8, xzr
	b	.LBB0_51
.LBB0_50:                               // %._crit_edge119
                                        //   in Loop: Header=BB0_51 Depth=2
	add	x8, x8, #1
	cmp	x8, x4
	b.eq	.LBB0_63
.LBB0_51:                               // %.lr.ph124
                                        //   Parent Loop BB0_12 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB0_53 Depth 3
                                        //       Child Loop BB0_55 Depth 3
                                        //       Child Loop BB0_57 Depth 3
                                        //       Child Loop BB0_59 Depth 3
                                        //       Child Loop BB0_62 Depth 3
	udiv	x10, x8, x1
	cmp	x21, #1
	msub	x11, x10, x1, x8
	sdiv	x9, x8, x25
	sdiv	x11, x11, x25
	msub	x9, x9, x25, x8
	mul	x12, x9, x17
	mul	x13, x11, x17
	lsl	x9, x13, #5
	add	x9, x9, x10, lsl #10
	add	x11, x9, x12
	add	x9, x20, x11, lsl #2
	b.lt	.LBB0_60
// %bb.52:                              // %.lr.ph111
                                        //   in Loop: Header=BB0_51 Depth=2
	mov	x14, xzr
.LBB0_53:                               //   Parent Loop BB0_12 Depth=1
                                        //     Parent Loop BB0_51 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	add	x15, x9, x14, lsl #7
	ld1w	{za0h.s[w14, 0]}, p0/z, [x15]
	add	x14, x14, #1
	mov	x15, x14
	decw	x15
	cbnz	x15, .LBB0_53
// %bb.54:                              // %.lr.ph112
                                        //   in Loop: Header=BB0_51 Depth=2
	add	x11, x2, x11, lsl #2
	mov	x14, xzr
.LBB0_55:                               //   Parent Loop BB0_12 Depth=1
                                        //     Parent Loop BB0_51 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	add	x15, x11, x14, lsl #7
	ld1w	{za1h.s[w14, 0]}, p0/z, [x15]
	add	x14, x14, #1
	mov	x15, x14
	decw	x15
	cbnz	x15, .LBB0_55
// %bb.56:                              // %.lr.ph114
                                        //   in Loop: Header=BB0_51 Depth=2
	mov	x14, xzr
.LBB0_57:                               //   Parent Loop BB0_12 Depth=1
                                        //     Parent Loop BB0_51 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	mov	x15, x14
	cntw	x16
	incw	x15
	add	x15, x9, x15, lsl #7
	ld1w	{za2h.s[w14, 0]}, p0/z, [x15]
	add	x14, x14, #1
	cmp	x14, x16
	b.ne	.LBB0_57
// %bb.58:                              // %.lr.ph115
                                        //   in Loop: Header=BB0_51 Depth=2
	mov	x14, xzr
.LBB0_59:                               //   Parent Loop BB0_12 Depth=1
                                        //     Parent Loop BB0_51 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	mov	x15, x14
	cntw	x16
	incw	x15
	add	x15, x11, x15, lsl #7
	ld1w	{za3h.s[w14, 0]}, p0/z, [x15]
	add	x14, x14, #1
	cmp	x14, x16
	b.ne	.LBB0_59
.LBB0_60:                               // %.preheader78
                                        //   in Loop: Header=BB0_51 Depth=2
	add	x14, x23, x10, lsl #11
	add	x11, x26, x13, lsl #2
	ld1w	{ z0.s }, p0/z, [x26, x13, lsl #2]
	cmp	x21, #0
	add	x10, x14, x12, lsl #2
	ld1w	{ z1.s }, p0/z, [x14, x12, lsl #2]
	ldr	z2, [x11, #1, mul vl]
	add	x12, x11, #128
	mov	x14, #96                        // =0x60
	ldr	z3, [x10, #1, mul vl]
	add	x13, x10, #128
	fmopa	za0.s, p0/m, p0/m, z0.s, z1.s
	fmopa	za1.s, p0/m, p0/m, z0.s, z3.s
	fmopa	za2.s, p0/m, p0/m, z2.s, z1.s
	fmopa	za3.s, p0/m, p0/m, z2.s, z3.s
	ld1w	{ z0.s }, p0/z, [x11, x7, lsl #2]
	ldr	z1, [x13, #1, mul vl]
	ld1w	{ z2.s }, p0/z, [x10, x7, lsl #2]
	ldr	z3, [x12, #1, mul vl]
	add	x12, x11, #256
	add	x13, x10, #256
	fmopa	za0.s, p0/m, p0/m, z0.s, z2.s
	fmopa	za1.s, p0/m, p0/m, z0.s, z1.s
	fmopa	za2.s, p0/m, p0/m, z3.s, z2.s
	fmopa	za3.s, p0/m, p0/m, z3.s, z1.s
	ldr	z0, [x12, #1, mul vl]
	ld1w	{ z1.s }, p0/z, [x11, x30, lsl #2]
	ldr	z2, [x13, #1, mul vl]
	ld1w	{ z3.s }, p0/z, [x10, x30, lsl #2]
	add	x12, x11, #384
	add	x13, x10, #384
	fmopa	za0.s, p0/m, p0/m, z1.s, z3.s
	fmopa	za1.s, p0/m, p0/m, z1.s, z2.s
	fmopa	za2.s, p0/m, p0/m, z0.s, z3.s
	fmopa	za3.s, p0/m, p0/m, z0.s, z2.s
	ld1w	{ z0.s }, p0/z, [x11, x14, lsl #2]
	ld1w	{ z1.s }, p0/z, [x10, x14, lsl #2]
	ldr	z2, [x12, #1, mul vl]
	ldr	z3, [x13, #1, mul vl]
	add	x12, x11, #512
	add	x13, x10, #512
	mov	x14, #128                       // =0x80
	fmopa	za0.s, p0/m, p0/m, z0.s, z1.s
	fmopa	za1.s, p0/m, p0/m, z0.s, z3.s
	fmopa	za2.s, p0/m, p0/m, z2.s, z1.s
	fmopa	za3.s, p0/m, p0/m, z2.s, z3.s
	ld1w	{ z0.s }, p0/z, [x11, x14, lsl #2]
	ldr	z1, [x13, #1, mul vl]
	ld1w	{ z2.s }, p0/z, [x10, x14, lsl #2]
	ldr	z3, [x12, #1, mul vl]
	add	x12, x11, #640
	add	x13, x10, #640
	mov	x14, #192                       // =0xc0
	fmopa	za0.s, p0/m, p0/m, z0.s, z2.s
	fmopa	za1.s, p0/m, p0/m, z0.s, z1.s
	fmopa	za2.s, p0/m, p0/m, z3.s, z2.s
	fmopa	za3.s, p0/m, p0/m, z3.s, z1.s
	ldr	z0, [x12, #1, mul vl]
	mov	x12, #160                       // =0xa0
	ldr	z2, [x13, #1, mul vl]
	add	x13, x10, #768
	ld1w	{ z1.s }, p0/z, [x11, x12, lsl #2]
	ld1w	{ z3.s }, p0/z, [x10, x12, lsl #2]
	add	x12, x11, #768
	fmopa	za0.s, p0/m, p0/m, z1.s, z3.s
	fmopa	za1.s, p0/m, p0/m, z1.s, z2.s
	fmopa	za2.s, p0/m, p0/m, z0.s, z3.s
	fmopa	za3.s, p0/m, p0/m, z0.s, z2.s
	ld1w	{ z0.s }, p0/z, [x11, x14, lsl #2]
	ld1w	{ z1.s }, p0/z, [x10, x14, lsl #2]
	ldr	z2, [x12, #1, mul vl]
	ldr	z3, [x13, #1, mul vl]
	add	x12, x11, #896
	add	x13, x10, #896
	mov	x14, #224                       // =0xe0
	fmopa	za0.s, p0/m, p0/m, z0.s, z1.s
	fmopa	za1.s, p0/m, p0/m, z0.s, z3.s
	fmopa	za2.s, p0/m, p0/m, z2.s, z1.s
	fmopa	za3.s, p0/m, p0/m, z2.s, z3.s
	ld1w	{ z0.s }, p0/z, [x11, x14, lsl #2]
	ldr	z1, [x13, #1, mul vl]
	ld1w	{ z2.s }, p0/z, [x10, x14, lsl #2]
	ldr	z3, [x12, #1, mul vl]
	add	x12, x11, #1024
	add	x13, x10, #1024
	mov	x14, #288                       // =0x120
	fmopa	za0.s, p0/m, p0/m, z0.s, z2.s
	fmopa	za1.s, p0/m, p0/m, z0.s, z1.s
	fmopa	za2.s, p0/m, p0/m, z3.s, z2.s
	fmopa	za3.s, p0/m, p0/m, z3.s, z1.s
	ldr	z0, [x12, #1, mul vl]
	mov	x12, #256                       // =0x100
	ldr	z2, [x13, #1, mul vl]
	add	x13, x10, #1152
	ld1w	{ z1.s }, p0/z, [x11, x12, lsl #2]
	ld1w	{ z3.s }, p0/z, [x10, x12, lsl #2]
	add	x12, x11, #1152
	fmopa	za0.s, p0/m, p0/m, z1.s, z3.s
	fmopa	za1.s, p0/m, p0/m, z1.s, z2.s
	fmopa	za2.s, p0/m, p0/m, z0.s, z3.s
	fmopa	za3.s, p0/m, p0/m, z0.s, z2.s
	ld1w	{ z0.s }, p0/z, [x11, x14, lsl #2]
	ld1w	{ z1.s }, p0/z, [x10, x14, lsl #2]
	ldr	z2, [x12, #1, mul vl]
	ldr	z3, [x13, #1, mul vl]
	add	x12, x11, #1280
	add	x13, x10, #1280
	mov	x14, #320                       // =0x140
	fmopa	za0.s, p0/m, p0/m, z0.s, z1.s
	fmopa	za1.s, p0/m, p0/m, z0.s, z3.s
	fmopa	za2.s, p0/m, p0/m, z2.s, z1.s
	fmopa	za3.s, p0/m, p0/m, z2.s, z3.s
	ld1w	{ z0.s }, p0/z, [x11, x14, lsl #2]
	ldr	z1, [x13, #1, mul vl]
	ld1w	{ z2.s }, p0/z, [x10, x14, lsl #2]
	ldr	z3, [x12, #1, mul vl]
	add	x12, x11, #1408
	add	x13, x10, #1408
	mov	x14, #448                       // =0x1c0
	fmopa	za0.s, p0/m, p0/m, z0.s, z2.s
	fmopa	za1.s, p0/m, p0/m, z0.s, z1.s
	fmopa	za2.s, p0/m, p0/m, z3.s, z2.s
	fmopa	za3.s, p0/m, p0/m, z3.s, z1.s
	ldr	z0, [x12, #1, mul vl]
	mov	x12, #352                       // =0x160
	ldr	z2, [x13, #1, mul vl]
	mov	x13, #384                       // =0x180
	ld1w	{ z1.s }, p0/z, [x11, x12, lsl #2]
	ld1w	{ z3.s }, p0/z, [x10, x12, lsl #2]
	add	x12, x11, #1536
	fmopa	za0.s, p0/m, p0/m, z1.s, z3.s
	fmopa	za1.s, p0/m, p0/m, z1.s, z2.s
	fmopa	za2.s, p0/m, p0/m, z0.s, z3.s
	fmopa	za3.s, p0/m, p0/m, z0.s, z2.s
	ldr	z0, [x12, #1, mul vl]
	add	x12, x10, #1536
	ld1w	{ z1.s }, p0/z, [x11, x13, lsl #2]
	ldr	z2, [x12, #1, mul vl]
	ld1w	{ z3.s }, p0/z, [x10, x13, lsl #2]
	add	x12, x11, #1664
	mov	x13, #416                       // =0x1a0
	fmopa	za0.s, p0/m, p0/m, z1.s, z3.s
	fmopa	za1.s, p0/m, p0/m, z1.s, z2.s
	fmopa	za2.s, p0/m, p0/m, z0.s, z3.s
	fmopa	za3.s, p0/m, p0/m, z0.s, z2.s
	ldr	z0, [x12, #1, mul vl]
	add	x12, x10, #1664
	ld1w	{ z1.s }, p0/z, [x11, x13, lsl #2]
	ldr	z2, [x12, #1, mul vl]
	ld1w	{ z3.s }, p0/z, [x10, x13, lsl #2]
	add	x12, x11, #1792
	add	x13, x10, #1792
	fmopa	za0.s, p0/m, p0/m, z1.s, z3.s
	fmopa	za1.s, p0/m, p0/m, z1.s, z2.s
	fmopa	za2.s, p0/m, p0/m, z0.s, z3.s
	fmopa	za3.s, p0/m, p0/m, z0.s, z2.s
	ld1w	{ z0.s }, p0/z, [x11, x14, lsl #2]
	ldr	z1, [x13, #1, mul vl]
	ld1w	{ z2.s }, p0/z, [x10, x14, lsl #2]
	ldr	z3, [x12, #1, mul vl]
	mov	x13, #480                       // =0x1e0
	add	x12, x11, #1920
	fmopa	za0.s, p0/m, p0/m, z0.s, z2.s
	fmopa	za1.s, p0/m, p0/m, z0.s, z1.s
	fmopa	za2.s, p0/m, p0/m, z3.s, z2.s
	fmopa	za3.s, p0/m, p0/m, z3.s, z1.s
	ld1w	{ z0.s }, p0/z, [x11, x13, lsl #2]
	add	x11, x10, #1920
	ld1w	{ z1.s }, p0/z, [x10, x13, lsl #2]
	ldr	z2, [x12, #1, mul vl]
	ldr	z3, [x11, #1, mul vl]
	fmopa	za0.s, p0/m, p0/m, z0.s, z1.s
	fmopa	za1.s, p0/m, p0/m, z0.s, z3.s
	fmopa	za2.s, p0/m, p0/m, z2.s, z1.s
	fmopa	za3.s, p0/m, p0/m, z2.s, z3.s
	b.le	.LBB0_50
// %bb.61:                              // %.lr.ph118
                                        //   in Loop: Header=BB0_51 Depth=2
	mov	x12, xzr
.LBB0_62:                               //   Parent Loop BB0_12 Depth=1
                                        //     Parent Loop BB0_51 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	add	x10, x9, x12, lsl #7
	mov	x11, x12
	incw	x11
	st1w	{za0h.s[w12, 0]}, p0, [x10]
	incb	x10
	add	x11, x9, x11, lsl #7
	st1w	{za1h.s[w12, 0]}, p0, [x10]
	cntw	x10
	st1w	{za2h.s[w12, 0]}, p0, [x11]
	incb	x11
	st1w	{za3h.s[w12, 0]}, p0, [x11]
	add	x12, x12, #1
	cmp	x12, x10
	b.ne	.LBB0_62
	b	.LBB0_50
.LBB0_63:                               // %.preheader85
                                        //   in Loop: Header=BB0_12 Depth=1
	ldr	x8, [x19, #336]                 // 8-byte Reload
	ldr	x14, [x19, #136]                // 8-byte Reload
	ldr	x15, [x19, #96]                 // 8-byte Reload
	tbnz	x8, #63, .LBB0_66
// %bb.64:                              // %.lr.ph125.preheader
                                        //   in Loop: Header=BB0_12 Depth=1
	mov	x8, xzr
.LBB0_65:                               // %.lr.ph125
                                        //   Parent Loop BB0_12 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	udiv	x9, x8, x15
	udiv	x10, x8, x22
	msub	x11, x9, x15, x8
	udiv	x11, x11, x22
	msub	x10, x10, x22, x8
	add	x8, x8, #1
	mul	x10, x10, x21
	sub	x12, x5, x10
	cmp	x12, x21
	csel	x12, x12, x21, lt
	whilelt	p0.s, xzr, x12
	cmp	x3, x8
	add	x13, x20, x11, lsl #12
	add	x12, x13, x9, lsl #7
	add	x9, x14, x9, lsl #8
	ld1w	{ z0.s }, p0/z, [x12, x10, lsl #2]
	add	x9, x9, x11, lsl #7
	st1w	{ z0.s }, p0, [x9, x10, lsl #2]
	b.ne	.LBB0_65
.LBB0_66:                               // %.preheader84
                                        //   in Loop: Header=BB0_12 Depth=1
	ldr	x13, [x19, #200]                // 8-byte Reload
	ldr	x15, [x19, #360]                // 8-byte Reload
	ldr	x16, [x19, #88]                 // 8-byte Reload
	tbnz	x13, #63, .LBB0_69
// %bb.67:                              // %.lr.ph126.preheader
                                        //   in Loop: Header=BB0_12 Depth=1
	mov	x8, xzr
.LBB0_68:                               // %.lr.ph126
                                        //   Parent Loop BB0_12 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	udiv	x9, x8, x0
	cmn	x13, #1
	cset	w11, lt
	mul	x10, x9, x0
	subs	x10, x8, x10
	add	x8, x8, #1
	mul	x10, x10, x21
	csel	w11, wzr, w11, eq
	sub	x9, x9, x11
	sub	x12, x6, x10
	add	x9, x10, x9, lsl #6
	cmp	x12, x21
	csel	x11, x12, x21, lt
	whilelt	p0.s, xzr, x11
	cmp	x16, x8
	ld1w	{ z0.s }, p0/z, [x14, x9, lsl #2]
	st1w	{ z0.s }, p0, [x18, x9, lsl #2]
	b.ne	.LBB0_68
.LBB0_69:                               // %._crit_edge127
                                        //   in Loop: Header=BB0_12 Depth=1
	ldr	x8, [x19, #144]                 // 8-byte Reload
	add	x15, x15, #16
	add	x27, x27, x8
	add	x8, x19, #368
	msr	TPIDR2_EL0, x8
	smstop	sm
	mov	x0, x28
	mov	x28, x15
	bl	free
	mov	x0, x24
	bl	free
	smstart	sm
	ldr	w12, [x19, #316]                // 4-byte Reload
	ldr	w1, [x19, #312]                 // 4-byte Reload
	add	w12, w12, #1
	sub	w1, w1, #16
	smstart	za
	mrs	x8, TPIDR2_EL0
	add	x0, x19, #368
	cbnz	x8, .LBB0_11
// %bb.70:                              // %._crit_edge127
                                        //   in Loop: Header=BB0_12 Depth=1
	bl	__arm_tpidr2_restore
	b	.LBB0_11
.LBB0_71:                               // %._crit_edge130
	ldr	x11, [x19, #40]                 // 8-byte Reload
	ldr	x9, [x19, #8]                   // 8-byte Reload
	mov	x15, sp
	ldp	x10, x13, [x19, #224]           // 16-byte Folded Reload
	sub	x16, x15, #64
	add	x8, x11, #32
	mov	x20, sp
	cmp	x8, x9
	csel	x8, x8, x9, lt
	add	x9, x13, #64
	cmp	x8, x11
	csel	x8, x8, x11, gt
	cmp	x9, x10
	csel	x9, x9, x10, lt
	ldp	x10, x14, [x19, #16]            // 16-byte Folded Reload
	cmp	x9, x13
	sub	x8, x8, x11
	csel	x9, x9, x13, gt
	cmp	x8, #32
	mov	w12, w10
	smaddl	x10, w11, w10, x13
	mov	w11, #32                        // =0x20
	sub	x9, x9, x13
	ldp	x13, x14, [x14]
	csel	x8, x8, x11, lt
	cmp	x9, #64
	mov	w11, #64                        // =0x40
	sxtw	x12, w12
	csel	x9, x9, x11, lt
	mov	sp, x16
	ldr	x21, [x19, #32]                 // 8-byte Reload
	ldr	x17, [x19, #240]                // 8-byte Reload
	stp	x9, x11, [x15, #-32]
	mov	w11, #1                         // =0x1
	stp	xzr, x8, [x15, #-48]
	stp	x21, x17, [x15, #-64]
	stur	x11, [x15, #-16]
	mov	x15, sp
	sub	x17, x15, #64
	mov	sp, x17
	stp	x10, x8, [x15, #-48]
	mov	x8, sp
	sub	x1, x8, #16
	stp	x13, x14, [x15, #-64]
	stp	x9, x12, [x15, #-32]
	stur	x11, [x15, #-16]
	mov	sp, x1
	mov	w9, #2                          // =0x2
	stp	x9, x16, [x8, #-16]
	mov	x8, sp
	sub	x2, x8, #16
	mov	sp, x2
	add	x10, x19, #368
	stp	x9, x17, [x8, #-16]
	msr	TPIDR2_EL0, x10
	smstop	sm
	mov	w0, #4                          // =0x4
	bl	memrefCopy
	mov	sp, x20
	mov	x0, x21
	bl	free
	ldr	x0, [x19, #72]                  // 8-byte Reload
	bl	free
	ldr	x0, [x19, #64]                  // 8-byte Reload
	bl	free
	ldr	x0, [x19, #56]                  // 8-byte Reload
	bl	free
	ldr	x0, [x19, #48]                  // 8-byte Reload
	bl	free
	smstart	sm
	msr	TPIDR2_EL0, xzr
	smstop	za
	sub	x8, x29, #1024
	addvl	sp, x8, #-9
	ldr	z15, [sp]                       // 16-byte Folded Reload
	ldr	z14, [sp, #1, mul vl]           // 16-byte Folded Reload
	ldr	z13, [sp, #2, mul vl]           // 16-byte Folded Reload
	ldr	z12, [sp, #3, mul vl]           // 16-byte Folded Reload
	ldr	z11, [sp, #4, mul vl]           // 16-byte Folded Reload
	ldr	z10, [sp, #5, mul vl]           // 16-byte Folded Reload
	ldr	z9, [sp, #6, mul vl]            // 16-byte Folded Reload
	ldr	z8, [sp, #7, mul vl]            // 16-byte Folded Reload
	.cfi_restore z8
	.cfi_restore z9
	.cfi_restore z10
	.cfi_restore z11
	.cfi_restore z12
	.cfi_restore z13
	.cfi_restore z14
	.cfi_restore z15
	mov	sp, x29
	.cfi_def_cfa wsp, 112
	ldp	x20, x19, [sp, #96]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             // 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             // 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             // 16-byte Folded Reload
	ldp	x28, x27, [sp, #32]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #112            // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore vg
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end0:
	.size	matmul_kernel, .Lfunc_end0-matmul_kernel
	.cfi_endproc
                                        // -- End function
	.section	".note.GNU-stack","",@progbits
